# ElevenLabs Conversational AI Integration

## Overview
This integration allows customers to book locksmith services via phone using ElevenLabs Conversational AI. The AI agent follows the same booking flow as the web form.

## Webhook Endpoints (Client Tools)

### 1. Validate Address
**Endpoint:** `https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/validate-address`
**Purpose:** Validates customer addresses using the same logic as the web form
**Parameters:**
```json
{
  "address": "string (required)",
  "market_code": "string (optional, default: DK)"
}
```

### 2. Get Job Categories  
**Endpoint:** `https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/get-job-categories`
**Purpose:** Fetches available locksmith service categories with translations
**Parameters:**
```json
{
  "language_code": "string (optional, default: da)",
  "market_code": "string (optional, default: DK)"
}
```

### 3. Get Follow-up Questions
**Endpoint:** `https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/get-follow-up-questions`
**Purpose:** Retrieves dynamic questions based on selected job category
**Parameters:**
```json
{
  "job_category_id": "string (required)",
  "language_code": "string (optional, default: da)",
  "market_code": "string (optional, default: DK)"
}
```

### 4. Get Available Times
**Endpoint:** `https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/get-available-times`
**Purpose:** Provides scheduling options based on urgency level
**Parameters:**
```json
{
  "urgency": "string (required)",
  "preferred_date": "string (optional)"
}
```

### 5. Create Booking from Call
**Endpoint:** `https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/create-booking-from-call`
**Purpose:** Creates the final booking with all collected information
**Parameters:**
```json
{
  "address": "string (required)",
  "urgency": "string (required)",
  "job_category_id": "string (required)",
  "follow_up_answers": "object (required)",
  "caller_phone_number": "string (required)",
  "caller_name": "string (optional)",
  "call_id": "string (optional)",
  "call_duration_seconds": "number (optional)",
  "call_transcription": "string (optional)",
  "scheduled_date": "string (optional)",
  "market_code": "string (optional, default: DK)"
}
```

## ElevenLabs Agent Configuration

### Agent Prompt (Danish)
```
Du er en professionel kundeservice assistent for Lockily, en låsesmed service i Danmark. Din opgave er at hjælpe kunder med at booke låsesmed services via telefon.

SAMTALEFLOW:
1. Velkommen og forstå kundens problem
2. Få kundens adresse og valider den
3. Find ud af hvilken type låsesmed opgave (brug get-job-categories)
4. Stil opfølgende spørgsmål baseret på opgavetypen (brug get-follow-up-questions)
5. Forstå hvor hurtigt hjælp er nødvendig (brug get-available-times)
6. Få kundens telefonnummer og navn
7. Opret bookingen (brug create-booking-from-call)

VIGTIGE RETNINGSLINJER:
- Vær venlig, professionel og hjælpsom
- Tal dansk med kunden
- Hvis det er et nødstilfælde, prioriter hurtighed
- Bekræft altid information før du opretter bookingen
- Giv kunden et reference nummer når bookingen er oprettet
- Hvis der opstår fejl, vær hjælpsom og tilbyd alternativer

TEKNISKE NOTER:
- Brug værktøjerne i den rigtige rækkefølge
- Gem alle svar fra kunden til sidst
- Håndter fejl med tålmodighed
```

### Client Tools Configuration

In ElevenLabs UI, configure these client tools:

**1. validateAddress**
- Name: `validateAddress`
- Description: "Validates customer address"
- Parameters: `address` (string, required), `market_code` (string, optional)

**2. getJobCategories** 
- Name: `getJobCategories`
- Description: "Gets available locksmith service categories"
- Parameters: `language_code` (string, optional), `market_code` (string, optional)

**3. getFollowUpQuestions**
- Name: `getFollowUpQuestions` 
- Description: "Gets follow-up questions for selected job category"
- Parameters: `job_category_id` (string, required), `language_code` (string, optional), `market_code` (string, optional)

**4. getAvailableTimes**
- Name: `getAvailableTimes`
- Description: "Gets available time slots based on urgency"
- Parameters: `urgency` (string, required), `preferred_date` (string, optional)

**5. createBookingFromCall**
- Name: `createBookingFromCall`
- Description: "Creates the final booking with all information"
- Parameters: All booking fields as defined above

## Testing the Integration

1. Set up ElevenLabs agent with the above configuration
2. Test each webhook endpoint individually
3. Test the complete conversation flow
4. Verify bookings are created correctly in the database
5. Check that phone bookings appear in the admin dashboard

## Monitoring and Analytics

- All phone bookings are marked with `booking_source: 'phone'`
- Call metadata is stored in the `call_metadata` field
- Track conversion rates and call duration
- Monitor for common failure points in the conversation flow