-- Create blog page in content_pages
INSERT INTO content_pages (page_key, page_name, description) 
VALUES ('blog', 'Blog', 'Blog page translations and content');

-- Get the blog page ID for creating sections
DO $$
DECLARE
    blog_page_id UUID;
BEGIN
    SELECT id INTO blog_page_id FROM content_pages WHERE page_key = 'blog';
    
    -- Create sections for blog page
    INSERT INTO content_sections (page_id, section_key, section_name, description) VALUES
    (blog_page_id, 'hero', 'Blog Hero Section', 'Hero section content for blog page'),
    (blog_page_id, 'sidebar', 'Blog Sidebar', 'Sidebar filters and labels'),
    (blog_page_id, 'interface', 'Blog Interface', 'General UI text for blog page'),
    (blog_page_id, 'seo', 'Blog SEO', 'SEO meta content for blog pages');
END $$;

-- Insert base English translations for blog content
DO $$
DECLARE
    hero_section_id UUID;
    sidebar_section_id UUID;
    interface_section_id UUID;
    seo_section_id UUID;
BEGIN
    -- Get section IDs
    SELECT cs.id INTO hero_section_id 
    FROM content_sections cs 
    JOIN content_pages cp ON cs.page_id = cp.id 
    WHERE cp.page_key = 'blog' AND cs.section_key = 'hero';
    
    SELECT cs.id INTO sidebar_section_id 
    FROM content_sections cs 
    JOIN content_pages cp ON cs.page_id = cp.id 
    WHERE cp.page_key = 'blog' AND cs.section_key = 'sidebar';
    
    SELECT cs.id INTO interface_section_id 
    FROM content_sections cs 
    JOIN content_pages cp ON cs.page_id = cp.id 
    WHERE cp.page_key = 'blog' AND cs.section_key = 'interface';
    
    SELECT cs.id INTO seo_section_id 
    FROM content_sections cs 
    JOIN content_pages cp ON cs.page_id = cp.id 
    WHERE cp.page_key = 'blog' AND cs.section_key = 'seo';
    
    -- Insert hero section translations
    INSERT INTO content_translations (section_id, content_key, content_value, language_code) VALUES
    (hero_section_id, 'title', 'Security Insights & Tips', 'en'),
    (hero_section_id, 'subtitle', 'Expert advice, industry news, and practical tips from {country}''s trusted locksmith professionals', 'en'),
    (hero_section_id, 'security_tips_title', 'Security Tips', 'en'),
    (hero_section_id, 'security_tips_desc', 'Learn how to keep your home and business secure', 'en'),
    (hero_section_id, 'expert_insights_title', 'Expert Insights', 'en'),
    (hero_section_id, 'expert_insights_desc', 'Industry trends and professional recommendations', 'en'),
    (hero_section_id, 'how_to_guides_title', 'How-to Guides', 'en'),
    (hero_section_id, 'how_to_guides_desc', 'Step-by-step guides for common security issues', 'en');
    
    -- Insert sidebar section translations
    INSERT INTO content_translations (section_id, content_key, content_value, language_code) VALUES
    (sidebar_section_id, 'search_title', 'Search Posts', 'en'),
    (sidebar_section_id, 'search_placeholder', 'Search blog posts...', 'en'),
    (sidebar_section_id, 'categories_title', 'Categories', 'en'),
    (sidebar_section_id, 'active_filters_title', 'Active Filters', 'en'),
    (sidebar_section_id, 'clear_all_filters', 'Clear All Filters', 'en'),
    (sidebar_section_id, 'select_all', 'Select All', 'en'),
    (sidebar_section_id, 'clear_all', 'Clear All', 'en'),
    (sidebar_section_id, 'showing_results', 'Showing {filtered} of {total} posts', 'en'),
    (sidebar_section_id, 'selected_count', '{count} selected', 'en');
    
    -- Insert interface section translations
    INSERT INTO content_translations (section_id, content_key, content_value, language_code) VALUES
    (interface_section_id, 'posts_found', '{count} post found', 'en'),
    (interface_section_id, 'posts_found_plural', '{count} posts found', 'en'),
    (interface_section_id, 'posts_found_for', 'for "{query}"', 'en'),
    (interface_section_id, 'no_posts_title', 'No posts found', 'en'),
    (interface_section_id, 'no_posts_message', 'Try adjusting your search or filters', 'en'),
    (interface_section_id, 'no_posts_message_default', 'Check back soon for new content', 'en'),
    (interface_section_id, 'clear_filters', 'Clear filters', 'en'),
    (interface_section_id, 'read_more', 'Read more', 'en'),
    (interface_section_id, 'min_read', '{minutes} min read', 'en'),
    (interface_section_id, 'views', '{count} views', 'en'),
    (interface_section_id, 'uncategorized', 'Uncategorized', 'en'),
    (interface_section_id, 'unknown_category', 'Unknown Category', 'en'),
    (interface_section_id, 'search_label', 'Search:', 'en');
    
    -- Insert SEO section translations
    INSERT INTO content_translations (section_id, content_key, content_value, language_code) VALUES
    (seo_section_id, 'meta_title', 'Blog', 'en'),
    (seo_section_id, 'meta_description', 'Read the latest insights, tips, and news about locksmith services in {country}', 'en');
END $$;