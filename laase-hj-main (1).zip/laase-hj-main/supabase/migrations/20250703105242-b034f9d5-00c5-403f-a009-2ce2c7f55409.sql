-- Create Stripe Connect accounts table for locksmiths
CREATE TABLE public.stripe_connect_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL REFERENCES public.locksmith_profiles(id) ON DELETE CASCADE,
  stripe_account_id TEXT UNIQUE,
  account_status TEXT DEFAULT 'pending',
  details_submitted BOOLEAN DEFAULT false,
  payouts_enabled BOOLEAN DEFAULT false,
  charges_enabled BOOLEAN DEFAULT false,
  requirements JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create payment transactions table
CREATE TABLE public.payment_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID REFERENCES public.bookings(id) ON DELETE CASCADE,
  customer_id UUID,
  locksmith_id UUID REFERENCES public.locksmith_profiles(id),
  stripe_payment_intent_id TEXT UNIQUE,
  amount_total NUMERIC(10,2) NOT NULL,
  platform_fee NUMERIC(10,2) DEFAULT 0,
  locksmith_amount NUMERIC(10,2) NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create payout transactions table
CREATE TABLE public.payout_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL REFERENCES public.locksmith_profiles(id) ON DELETE CASCADE,
  stripe_transfer_id TEXT UNIQUE,
  amount NUMERIC(10,2) NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.stripe_connect_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_transactions ENABLE ROW LEVEL SECURITY;

-- RLS policies for stripe_connect_accounts
CREATE POLICY "Locksmiths can view their own connect account" 
ON public.stripe_connect_accounts 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.locksmith_profiles 
  WHERE id = stripe_connect_accounts.locksmith_id 
  AND id = auth.uid()
));

CREATE POLICY "Locksmiths can insert their own connect account" 
ON public.stripe_connect_accounts 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM public.locksmith_profiles 
  WHERE id = stripe_connect_accounts.locksmith_id 
  AND id = auth.uid()
));

CREATE POLICY "Locksmiths can update their own connect account" 
ON public.stripe_connect_accounts 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM public.locksmith_profiles 
  WHERE id = stripe_connect_accounts.locksmith_id 
  AND id = auth.uid()
));

CREATE POLICY "Admins can manage all connect accounts" 
ON public.stripe_connect_accounts 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS policies for payment_transactions
CREATE POLICY "Users can view their own payment transactions" 
ON public.payment_transactions 
FOR SELECT 
USING (
  auth.uid() = customer_id OR 
  EXISTS (
    SELECT 1 FROM public.locksmith_profiles 
    WHERE id = payment_transactions.locksmith_id 
    AND id = auth.uid()
  ) OR
  has_role(auth.uid(), 'admin'::user_role)
);

CREATE POLICY "Admins can manage all payment transactions" 
ON public.payment_transactions 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS policies for payout_transactions
CREATE POLICY "Locksmiths can view their own payouts" 
ON public.payout_transactions 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.locksmith_profiles 
  WHERE id = payout_transactions.locksmith_id 
  AND id = auth.uid()
));

CREATE POLICY "Admins can manage all payout transactions" 
ON public.payout_transactions 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Add updated_at trigger for stripe_connect_accounts and payment_transactions
CREATE TRIGGER update_stripe_connect_accounts_updated_at
  BEFORE UPDATE ON public.stripe_connect_accounts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payment_transactions_updated_at
  BEFORE UPDATE ON public.payment_transactions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add indexes for performance
CREATE INDEX idx_stripe_connect_accounts_locksmith_id ON public.stripe_connect_accounts(locksmith_id);
CREATE INDEX idx_stripe_connect_accounts_stripe_account_id ON public.stripe_connect_accounts(stripe_account_id);
CREATE INDEX idx_payment_transactions_booking_id ON public.payment_transactions(booking_id);
CREATE INDEX idx_payment_transactions_customer_id ON public.payment_transactions(customer_id);
CREATE INDEX idx_payment_transactions_locksmith_id ON public.payment_transactions(locksmith_id);
CREATE INDEX idx_payout_transactions_locksmith_id ON public.payout_transactions(locksmith_id);