-- First create the missing content pages and sections

-- Create pages if they don't exist
INSERT INTO content_pages (page_key, page_name, description) VALUES
('job_cards', 'Job Cards', 'Job card interface and actions')
ON CONFLICT (page_key) DO NOTHING;

INSERT INTO content_pages (page_key, page_name, description) VALUES  
('payments', 'Payments', 'Payment interface and settings')
ON CONFLICT (page_key) DO NOTHING;

INSERT INTO content_pages (page_key, page_name, description) VALUES
('service_areas', 'Service Areas', 'Service area configuration')
ON CONFLICT (page_key) DO NOTHING;

-- Create sections for job_cards page
INSERT INTO content_sections (page_id, section_key, section_name, description) VALUES
((SELECT id FROM content_pages WHERE page_key = 'job_cards'), 'interface', 'Interface', 'Job card interface elements'),
((SELECT id FROM content_pages WHERE page_key = 'job_cards'), 'actions', 'Actions', 'Job card action buttons'),
((SELECT id FROM content_pages WHERE page_key = 'job_cards'), 'status', 'Status', 'Job status labels')
ON CONFLICT (page_id, section_key) DO NOTHING;

-- Create sections for payments page
INSERT INTO content_sections (page_id, section_key, section_name, description) VALUES
((SELECT id FROM content_pages WHERE page_key = 'payments'), 'interface', 'Interface', 'Payment interface elements'),
((SELECT id FROM content_pages WHERE page_key = 'payments'), 'status', 'Status', 'Payment status labels')
ON CONFLICT (page_id, section_key) DO NOTHING;

-- Create sections for service_areas page
INSERT INTO content_sections (page_id, section_key, section_name, description) VALUES
((SELECT id FROM content_pages WHERE page_key = 'service_areas'), 'labels', 'Labels', 'Service area form labels'),
((SELECT id FROM content_pages WHERE page_key = 'service_areas'), 'messages', 'Messages', 'Service area messages')
ON CONFLICT (page_id, section_key) DO NOTHING;

-- Now add the translations
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- Job card interface
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'new_job', 'New Job', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'customer_info', 'Customer Information', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'job_details', 'Job Details', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'address', 'Address', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'arrival_time', 'Arrival Time', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'price_breakdown', 'Price Breakdown', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'base_price', 'Base Price', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'additional_fees', 'Additional Fees', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'total_price', 'Total Price', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'estimated_duration', 'Estimated Duration', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'urgency', 'Urgency', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'now', 'Now', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'later', 'Later', 'text'),

-- Job card actions
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'place_bid', 'Place Bid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'update_bid', 'Update Bid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'withdraw_bid', 'Withdraw Bid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'accept_job', 'Accept Job', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'decline_job', 'Decline Job', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'mark_complete', 'Mark Complete', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'contact_customer', 'Contact Customer', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'view_details', 'View Details', 'text'),

-- Job status
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'pending', 'Pending', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'accepted', 'Accepted', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'in_progress', 'In Progress', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'completed', 'Completed', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'cancelled', 'Cancelled', 'text'),

-- Dashboard content (using existing locksmith_portal page)
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'welcome_back', 'Welcome back', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'overview', 'Overview', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'active_jobs', 'Active Jobs', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'pending_bids', 'Pending Bids', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'completed_today', 'Completed Today', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'earnings_today', 'Earnings Today', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'recent_activity', 'Recent Activity', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'no_new_jobs', 'No new jobs available', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'check_back_later', 'Check back later for new opportunities', 'text'),

-- Settings labels (using existing settings page)
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'company_settings', 'Company Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'profile_settings', 'Profile Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'notification_settings', 'Notification Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'company_name', 'Company Name', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'cvr_number', 'CVR Number', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'contact_person', 'Contact Person', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'phone_number', 'Phone Number', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'email_address', 'Email Address', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'website', 'Website', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'address', 'Address', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'postal_code', 'Postal Code', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'city', 'City', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'description', 'Description', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'specializations', 'Specializations', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'emergency_available', 'Available for Emergency Calls', 'text'),

-- Settings messages (using existing settings page)
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'profile_updated', 'Profile updated successfully', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'save_changes', 'Save Changes', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'cancel', 'Cancel', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'required_field', 'This field is required', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'invalid_email', 'Please enter a valid email address', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'invalid_phone', 'Please enter a valid phone number', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'invalid_url', 'Please enter a valid website URL', 'text'),

-- Payment interface
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'payment_settings', 'Payment Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'stripe_account', 'Stripe Account', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'account_status', 'Account Status', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'setup_payments', 'Setup Payments', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'payment_history', 'Payment History', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'earnings', 'Earnings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'balance', 'Balance', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'payout_schedule', 'Payout Schedule', 'text'),

-- Payment status
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'connected', 'Connected', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'pending', 'Pending Setup', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'incomplete', 'Incomplete', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'payments')), 'en', 'restricted', 'Restricted', 'text'),

-- Service Areas
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'service_areas', 'Service Areas', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'coverage_type', 'Coverage Type', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'postal_codes', 'Postal Codes', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'radius_coverage', 'Radius Coverage', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'center_address', 'Center Address', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'max_distance', 'Maximum Distance', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'km', 'km', 'text'),

-- Service Areas messages
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'areas_updated', 'Service areas updated successfully', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'enter_postal_codes', 'Enter postal codes separated by commas', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'invalid_postal_code', 'Invalid postal code format', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'address_required', 'Please enter a center address', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'service_areas')), 'en', 'distance_required', 'Please enter a maximum distance', 'text');