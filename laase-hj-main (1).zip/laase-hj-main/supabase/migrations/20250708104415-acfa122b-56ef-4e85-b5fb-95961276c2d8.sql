
-- Create webhook_logs table for detailed request/response logging
CREATE TABLE public.webhook_logs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  function_name text NOT NULL,
  request_method text NOT NULL DEFAULT 'POST',
  request_url text,
  request_headers jsonb DEFAULT '{}',
  request_body jsonb,
  response_status_code integer,
  response_headers jsonb DEFAULT '{}',
  response_body jsonb,
  execution_time_ms integer,
  error_message text,
  error_stack text,
  client_ip text,
  user_agent text,
  call_metadata jsonb DEFAULT '{}',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can view all webhook logs" 
ON public.webhook_logs 
FOR SELECT 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Edge functions can insert webhook logs" 
ON public.webhook_logs 
FOR INSERT 
WITH CHECK (true);

-- Create index for efficient querying
CREATE INDEX idx_webhook_logs_function_name_created_at ON public.webhook_logs(function_name, created_at DESC);
CREATE INDEX idx_webhook_logs_status_code ON public.webhook_logs(response_status_code);
CREATE INDEX idx_webhook_logs_created_at ON public.webhook_logs(created_at DESC);

-- Enable realtime
ALTER TABLE public.webhook_logs REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.webhook_logs;
