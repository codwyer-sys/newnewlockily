-- Create Nylas integration tables for calendar sync

-- Store Nylas integration tokens and settings per locksmith
CREATE TABLE public.nylas_integrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  nylas_grant_id TEXT NOT NULL,
  calendar_accounts JSONB DEFAULT '[]'::jsonb,
  sync_enabled BOOLEAN NOT NULL DEFAULT true,
  last_sync_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(locksmith_id, nylas_grant_id)
);

-- Calendar sync preferences per locksmith
CREATE TABLE public.calendar_sync_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sync_enabled BOOLEAN NOT NULL DEFAULT true,
  busy_event_types TEXT[] DEFAULT ARRAY['default', 'busy', 'outOfOffice']::text[],
  buffer_minutes_before INTEGER DEFAULT 5,
  buffer_minutes_after INTEGER DEFAULT 5,
  override_manual_status BOOLEAN DEFAULT false,
  selected_calendars TEXT[] DEFAULT '[]'::text[],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(locksmith_id)
);

-- Store locksmith status with calendar control info
CREATE TABLE public.locksmith_status (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'ready' CHECK (status IN ('ready', 'busy', 'offline')),
  is_calendar_controlled BOOLEAN DEFAULT false,
  manual_override_until TIMESTAMP WITH TIME ZONE,
  busy_until TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(locksmith_id)
);

-- Enable RLS
ALTER TABLE public.nylas_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calendar_sync_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.locksmith_status ENABLE ROW LEVEL SECURITY;

-- RLS Policies for nylas_integrations
CREATE POLICY "Locksmiths can manage their own Nylas integrations"
ON public.nylas_integrations
FOR ALL
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = nylas_integrations.locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

-- RLS Policies for calendar_sync_settings  
CREATE POLICY "Locksmiths can manage their own calendar sync settings"
ON public.calendar_sync_settings
FOR ALL
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = calendar_sync_settings.locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

-- RLS Policies for locksmith_status
CREATE POLICY "Locksmiths can manage their own status"
ON public.locksmith_status
FOR ALL
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = locksmith_status.locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

-- Allow admins to view all statuses for job management
CREATE POLICY "Admins can view all locksmith statuses"
ON public.locksmith_status
FOR SELECT
USING (has_role(auth.uid(), 'admin'::user_role));

-- Create indexes for performance
CREATE INDEX idx_nylas_integrations_locksmith_id ON public.nylas_integrations(locksmith_id);
CREATE INDEX idx_calendar_sync_settings_locksmith_id ON public.calendar_sync_settings(locksmith_id);
CREATE INDEX idx_locksmith_status_locksmith_id ON public.locksmith_status(locksmith_id);
CREATE INDEX idx_locksmith_status_status ON public.locksmith_status(status);

-- Create trigger to update updated_at columns
CREATE TRIGGER update_nylas_integrations_updated_at
  BEFORE UPDATE ON public.nylas_integrations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_calendar_sync_settings_updated_at
  BEFORE UPDATE ON public.calendar_sync_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_locksmith_status_updated_at
  BEFORE UPDATE ON public.locksmith_status
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();