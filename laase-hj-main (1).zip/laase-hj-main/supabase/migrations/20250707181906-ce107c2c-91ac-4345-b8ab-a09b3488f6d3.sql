-- Add "How it works" section to content management system
-- First, add the content section for home page how_it_works
INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'how_it_works', 'How It Works', 'How it works timeline section on home page'
FROM public.content_pages cp WHERE cp.page_key = 'home';

-- Add the English translations for how it works content
INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'title',
  'How it works',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'subtitle',
  'Get help in 3 simple steps',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'step_1_title',
  'Submit your job',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'step_1_desc',
  'Fill out our quick form with details about what you need. Takes less than 20 seconds.',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'step_2_title',
  'We find the quickest and cheapest help',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'step_2_desc',
  'Our matching engine connects you with available local locksmiths. Get quotes in seconds through automated bidding.',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'step_3_title',
  'Wait for your locksmith',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';

INSERT INTO public.content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code
)
SELECT 
  cs.id,
  'en',
  'step_3_desc',
  'Track your locksmith en route to your location and get the help you need.',
  'text',
  null
FROM public.content_sections cs
JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works';