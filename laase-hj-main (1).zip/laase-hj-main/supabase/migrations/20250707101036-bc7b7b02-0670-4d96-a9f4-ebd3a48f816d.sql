-- Create cities table
CREATE TABLE public.cities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL,
  market_code VARCHAR NOT NULL REFERENCES public.markets(country_code),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  population INTEGER,
  is_metropolitan BOOLEAN NOT NULL DEFAULT false,
  seo_title TEXT,
  seo_description TEXT,
  seo_keywords TEXT[],
  featured_image_url TEXT,
  featured_image_alt TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(market_code, slug)
);

-- Create areas table (for metropolitan subdivisions)
CREATE TABLE public.areas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL,
  city_id UUID NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  postal_codes TEXT[] DEFAULT '{}',
  seo_title TEXT,
  seo_description TEXT,
  seo_keywords TEXT[],
  featured_image_url TEXT,
  featured_image_alt TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(city_id, slug)
);

-- Create blog post locations table for geo-tagging
CREATE TABLE public.blog_post_locations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL REFERENCES public.blog_posts(id) ON DELETE CASCADE,
  market_code VARCHAR REFERENCES public.markets(country_code),
  city_id UUID REFERENCES public.cities(id) ON DELETE CASCADE,
  area_id UUID REFERENCES public.areas(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(post_id, city_id, area_id)
);

-- Add city and area columns to bookings for analytics
ALTER TABLE public.bookings 
ADD COLUMN city_id UUID REFERENCES public.cities(id),
ADD COLUMN area_id UUID REFERENCES public.areas(id);

-- Enable Row Level Security
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.areas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_post_locations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for cities
CREATE POLICY "Anyone can view active cities" 
ON public.cities FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage cities" 
ON public.cities FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS Policies for areas
CREATE POLICY "Anyone can view active areas" 
ON public.areas FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage areas" 
ON public.areas FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS Policies for blog post locations
CREATE POLICY "Anyone can view blog post locations for published posts" 
ON public.blog_post_locations FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM blog_posts bp 
  WHERE bp.id = blog_post_locations.post_id 
  AND bp.status = 'published'
));

CREATE POLICY "Admins can manage blog post locations" 
ON public.blog_post_locations FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Authors can manage their blog post locations" 
ON public.blog_post_locations FOR ALL 
USING (EXISTS (
  SELECT 1 FROM blog_posts bp 
  WHERE bp.id = blog_post_locations.post_id 
  AND bp.author_id = auth.uid()
));

-- Create update triggers
CREATE TRIGGER update_cities_updated_at
  BEFORE UPDATE ON public.cities
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_areas_updated_at
  BEFORE UPDATE ON public.areas
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for performance
CREATE INDEX idx_cities_market_code ON public.cities(market_code);
CREATE INDEX idx_cities_slug ON public.cities(slug);
CREATE INDEX idx_cities_is_active ON public.cities(is_active);
CREATE INDEX idx_areas_city_id ON public.areas(city_id);
CREATE INDEX idx_areas_slug ON public.areas(slug);
CREATE INDEX idx_blog_post_locations_post_id ON public.blog_post_locations(post_id);
CREATE INDEX idx_blog_post_locations_city_id ON public.blog_post_locations(city_id);
CREATE INDEX idx_blog_post_locations_area_id ON public.blog_post_locations(area_id);
CREATE INDEX idx_bookings_city_id ON public.bookings(city_id);
CREATE INDEX idx_bookings_area_id ON public.bookings(area_id);