-- Phase 1: Simplify email brand settings to be global (not market-specific)

-- First, let's consolidate any existing brand settings into a single global record
INSERT INTO public.email_brand_settings (
  logo_url,
  primary_color,
  secondary_color,
  font_family,
  header_background_color,
  footer_background_color,
  border_color,
  company_name,
  company_address,
  contact_email,
  privacy_policy_url,
  unsubscribe_url
)
SELECT DISTINCT ON (1)
  COALESCE(logo_url, '/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png') as logo_url,
  primary_color,
  secondary_color,
  font_family,
  header_background_color,
  footer_background_color,
  border_color,
  company_name,
  company_address,
  contact_email,
  privacy_policy_url,
  unsubscribe_url
FROM public.email_brand_settings
WHERE market_code IS NOT NULL
LIMIT 1
ON CONFLICT DO NOTHING;

-- If no existing settings, create default global settings with logo
INSERT INTO public.email_brand_settings (
  logo_url,
  primary_color,
  secondary_color,
  font_family,
  header_background_color,
  footer_background_color,
  border_color,
  company_name,
  contact_email
)
SELECT 
  '/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png',
  '#155e63',
  '#f9f8eb',
  'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
  '#155e63',
  '#f9f8eb',
  '#155e63',
  'Lockily',
  'support@lockily.com'
WHERE NOT EXISTS (SELECT 1 FROM public.email_brand_settings WHERE market_code IS NULL);

-- Remove any market-specific brand settings (keep only the global one)
DELETE FROM public.email_brand_settings WHERE market_code IS NOT NULL;

-- Remove the market_code column since we're making this global
ALTER TABLE public.email_brand_settings DROP COLUMN IF EXISTS market_code;

-- Update RLS policies to reflect that brand settings are now global
DROP POLICY IF EXISTS "Admins can manage email brand settings" ON public.email_brand_settings;
DROP POLICY IF EXISTS "Anyone can view email brand settings" ON public.email_brand_settings;

CREATE POLICY "Admins can manage global email brand settings" 
ON public.email_brand_settings 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view global email brand settings" 
ON public.email_brand_settings 
FOR SELECT 
USING (true);