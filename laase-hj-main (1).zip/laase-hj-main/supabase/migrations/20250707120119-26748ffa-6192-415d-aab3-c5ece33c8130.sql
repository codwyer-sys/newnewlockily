-- Fix Cologne city record - update market code and English name
UPDATE cities 
SET 
  name = 'Cologne',
  market_code = 'DE'
WHERE name = 'Köln' AND market_code = 'DK';

-- Ensure proper city translation exists for Cologne
INSERT INTO city_translations (
  city_id,
  language_code,
  market_code,
  local_name,
  source,
  is_official
)
SELECT 
  c.id,
  'de',
  'DE',
  'Köln',
  'manual',
  true
FROM cities c
WHERE c.name = 'Cologne' AND c.market_code = 'DE'
ON CONFLICT (city_id, language_code, market_code) 
DO UPDATE SET 
  local_name = 'Köln',
  source = 'manual',
  is_official = true;