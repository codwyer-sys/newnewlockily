
-- Create job stage enum for booking lifecycle tracking
CREATE TYPE public.job_stage_enum AS ENUM (
  'waiting_for_quotes',
  'awaiting_client_feedback', 
  'awaiting_locksmith_acceptance',
  'locksmith_en_route',
  'locksmith_on_job',
  'job_finished'
);

-- Add job stage columns to bookings table
ALTER TABLE public.bookings 
ADD COLUMN IF NOT EXISTS job_stage public.job_stage_enum DEFAULT 'waiting_for_quotes',
ADD COLUMN IF NOT EXISTS job_stage_changed_at TIMESTAMPTZ DEFAULT now();

-- Create function to update job stage timestamp
CREATE OR REPLACE FUNCTION public.update_job_stage_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.job_stage IS DISTINCT FROM NEW.job_stage THEN
    NEW.job_stage_changed_at = now();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for job stage changes
CREATE TRIGGER update_job_stage_timestamp_trigger
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_job_stage_timestamp();

-- Add index for better performance on job stage queries
CREATE INDEX IF NOT EXISTS idx_bookings_job_stage ON public.bookings(job_stage);
CREATE INDEX IF NOT EXISTS idx_bookings_job_stage_changed_at ON public.bookings(job_stage_changed_at);

-- Update existing bookings to have proper job stage based on current status
UPDATE public.bookings 
SET job_stage = CASE 
  WHEN status = 'waiting_for_quotes' OR status = 'pending' THEN 'waiting_for_quotes'::job_stage_enum
  WHEN status = 'quotes_received' THEN 'awaiting_client_feedback'::job_stage_enum
  WHEN status = 'order_placed' THEN 'awaiting_locksmith_acceptance'::job_stage_enum
  WHEN status = 'order_fulfilled' THEN 'job_finished'::job_stage_enum
  WHEN status = 'canceled' THEN 'job_finished'::job_stage_enum
  ELSE 'waiting_for_quotes'::job_stage_enum
END
WHERE job_stage = 'waiting_for_quotes';
