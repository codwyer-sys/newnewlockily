-- Add ai_instruction field to content_translations table
ALTER TABLE public.content_translations 
ADD COLUMN ai_instruction TEXT;