-- Create content page for blog categories
INSERT INTO public.content_pages (page_key, page_name, description)
VALUES ('blog_categories', 'Blog Categories', 'Translatable content for blog categories');

-- Create content sections for blog category translations
INSERT INTO public.content_sections (page_id, section_key, section_name, description)
SELECT 
  cp.id,
  'category_management',
  'Category Management',
  'Content for managing blog category translations'
FROM public.content_pages cp
WHERE cp.page_key = 'blog_categories';

-- Add category_key column to blog_categories and is_global to blog_posts
ALTER TABLE public.blog_categories 
ADD COLUMN category_key TEXT;

ALTER TABLE public.blog_posts 
ADD COLUMN is_global BOOLEAN DEFAULT false;

-- Create unique constraint on category_key
ALTER TABLE public.blog_categories 
ADD CONSTRAINT unique_category_key UNIQUE (category_key);

-- Update existing categories with category keys (convert names to keys)
UPDATE public.blog_categories 
SET category_key = LOWER(REPLACE(REPLACE(name, ' ', '_'), '-', '_'))
WHERE category_key IS NULL;

-- Make category_key NOT NULL after populating
ALTER TABLE public.blog_categories 
ALTER COLUMN category_key SET NOT NULL;

-- Create content translations for existing categories
INSERT INTO public.content_translations (
  section_id,
  content_key,
  content_type,
  content_value,
  language_code,
  market_code
)
SELECT 
  cs.id as section_id,
  bc.category_key || '_name' as content_key,
  'text' as content_type,
  bc.name as content_value,
  'en' as language_code,
  bc.market_code
FROM public.blog_categories bc
CROSS JOIN public.content_sections cs
INNER JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'blog_categories' 
  AND cs.section_key = 'category_management'
  AND bc.name IS NOT NULL;

-- Create content translations for existing category descriptions  
INSERT INTO public.content_translations (
  section_id,
  content_key,
  content_type,
  content_value,
  language_code,
  market_code
)
SELECT 
  cs.id as section_id,
  bc.category_key || '_description' as content_key,
  'text' as content_type,
  bc.description as content_value,
  'en' as language_code,
  bc.market_code
FROM public.blog_categories bc
CROSS JOIN public.content_sections cs
INNER JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'blog_categories' 
  AND cs.section_key = 'category_management'
  AND bc.description IS NOT NULL;

-- Create content translations for SEO titles
INSERT INTO public.content_translations (
  section_id,
  content_key,
  content_type,
  content_value,
  language_code,
  market_code
)
SELECT 
  cs.id as section_id,
  bc.category_key || '_seo_title' as content_key,
  'text' as content_type,
  bc.seo_title as content_value,
  'en' as language_code,
  bc.market_code
FROM public.blog_categories bc
CROSS JOIN public.content_sections cs
INNER JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'blog_categories' 
  AND cs.section_key = 'category_management'
  AND bc.seo_title IS NOT NULL;

-- Create content translations for SEO descriptions
INSERT INTO public.content_translations (
  section_id,
  content_key,
  content_type,
  content_value,
  language_code,
  market_code
)
SELECT 
  cs.id as section_id,
  bc.category_key || '_seo_description' as content_key,
  'text' as content_type,
  bc.seo_description as content_value,
  'en' as language_code,
  bc.market_code
FROM public.blog_categories bc
CROSS JOIN public.content_sections cs
INNER JOIN public.content_pages cp ON cs.page_id = cp.id
WHERE cp.page_key = 'blog_categories' 
  AND cs.section_key = 'category_management'
  AND bc.seo_description IS NOT NULL;

-- Remove translatable columns from blog_categories (after migration)
ALTER TABLE public.blog_categories 
DROP COLUMN IF EXISTS name,
DROP COLUMN IF EXISTS description,
DROP COLUMN IF EXISTS seo_title,
DROP COLUMN IF EXISTS seo_description,
DROP COLUMN IF EXISTS market_code;

-- Update blog posts to set is_global based on market_code
UPDATE public.blog_posts 
SET is_global = (market_code IS NULL OR market_code = '');

-- Create indexes for better performance
CREATE INDEX idx_blog_categories_category_key ON public.blog_categories(category_key);
CREATE INDEX idx_blog_posts_is_global ON public.blog_posts(is_global);