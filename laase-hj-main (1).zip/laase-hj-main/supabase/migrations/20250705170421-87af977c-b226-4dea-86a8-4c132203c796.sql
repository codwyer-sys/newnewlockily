-- Create geocoding cache table to reduce MapBox API usage
CREATE TABLE public.geocoding_cache (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  address TEXT NOT NULL UNIQUE,
  latitude NUMERIC NOT NULL,
  longitude NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + INTERVAL '30 days')
);

-- Enable Row Level Security
ALTER TABLE public.geocoding_cache ENABLE ROW LEVEL SECURITY;

-- Allow public read access to cached geocoding data
CREATE POLICY "Anyone can read geocoding cache" 
ON public.geocoding_cache 
FOR SELECT 
USING (true);

-- Allow public insert for caching new addresses
CREATE POLICY "Anyone can insert geocoding cache" 
ON public.geocoding_cache 
FOR INSERT 
WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX idx_geocoding_cache_address ON public.geocoding_cache(address);
CREATE INDEX idx_geocoding_cache_expires ON public.geocoding_cache(expires_at);