-- Fix Berlin's market code from DK to DE
UPDATE cities 
SET market_code = 'DE' 
WHERE name = 'Berlin' AND market_code = 'DK';

-- Also update the city translation to use correct market code
UPDATE city_translations 
SET market_code = 'DE' 
WHERE city_id = (SELECT id FROM cities WHERE name = 'Berlin') 
AND market_code = 'DK';