-- Data Migration: Populate translation tables with existing data
-- First, let's add Danish translations for existing job categories
INSERT INTO public.job_category_translations (
  job_category_id, 
  language_code, 
  market_code, 
  name, 
  description
)
SELECT 
  jc.id,
  'da' as language_code,
  'DK' as market_code,
  jc.name,
  jc.description
FROM public.job_categories jc
WHERE NOT EXISTS (
  SELECT 1 FROM public.job_category_translations jct 
  WHERE jct.job_category_id = jc.id 
  AND jct.language_code = 'da' 
  AND jct.market_code = 'DK'
);

-- Add Danish translations for existing follow-up questions
INSERT INTO public.follow_up_question_translations (
  follow_up_question_id,
  language_code, 
  market_code,
  question,
  options,
  option_icons
)
SELECT 
  fq.id,
  'da' as language_code,
  'DK' as market_code,
  fq.question,
  fq.options,
  fq.option_icons
FROM public.follow_up_questions fq
WHERE NOT EXISTS (
  SELECT 1 FROM public.follow_up_question_translations fqt 
  WHERE fqt.follow_up_question_id = fq.id 
  AND fqt.language_code = 'da' 
  AND fqt.market_code = 'DK'
);