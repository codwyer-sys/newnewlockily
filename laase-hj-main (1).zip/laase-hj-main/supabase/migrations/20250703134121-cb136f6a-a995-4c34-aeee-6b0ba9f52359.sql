-- Add new columns to service_areas table for enhanced functionality
ALTER TABLE public.service_areas 
ADD COLUMN service_type TEXT DEFAULT 'postal_codes' CHECK (service_type IN ('postal_codes', 'radius')),
ADD COLUMN center_address TEXT,
ADD COLUMN center_coordinates POINT;

-- Create index for better performance
CREATE INDEX idx_service_areas_service_type ON public.service_areas(service_type);
CREATE INDEX idx_service_areas_locksmith_service_type ON public.service_areas(locksmith_id, service_type);