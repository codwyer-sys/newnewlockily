-- Add new markets
INSERT INTO public.markets (country_code, country_name, currency_code, currency_symbol, distance_unit, business_reg_field, business_reg_label, emergency_number, default_lat, default_lng, address_api_provider) VALUES
('IE', 'Ireland', 'EUR', '€', 'km', 'company_number', 'Company Number', '999', 53.3498, -6.2603, 'google'),
('FR', 'France', 'EUR', '€', 'km', 'siren_number', 'SIREN Number', '17', 48.8566, 2.3522, 'google'),
('ES', 'Spain', 'EUR', '€', 'km', 'cif_number', 'CIF Number', '091', 40.4168, -3.7038, 'google'),
('SE', 'Sweden', 'SEK', 'kr', 'km', 'org_number', 'Organisation Number', '112', 59.3293, 18.0686, 'google'),
('NO', 'Norway', 'NOK', 'kr', 'km', 'org_number', 'Organisation Number', '112', 59.9139, 10.7522, 'google');

-- Create market-language access control table
CREATE TABLE public.market_language_access (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  market_code TEXT NOT NULL REFERENCES public.markets(country_code),
  language_code TEXT NOT NULL,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  is_enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(market_code, language_code)
);

-- Enable RLS
ALTER TABLE public.market_language_access ENABLE ROW LEVEL SECURITY;

-- Create policies for market_language_access
CREATE POLICY "Anyone can view market language access"
ON public.market_language_access
FOR SELECT
USING (true);

CREATE POLICY "Admins can manage market language access"
ON public.market_language_access
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

-- Insert market-language access mappings
INSERT INTO public.market_language_access (market_code, language_code, is_primary, is_enabled) VALUES
-- Denmark: Danish (primary) + English
('DK', 'da', true, true),
('DK', 'en', false, true),
-- Germany: German (primary) + English
('DE', 'de', true, true),
('DE', 'en', false, true),
-- United Kingdom: English (primary)
('UK', 'en', true, true),
-- United States: English (primary)
('US', 'en', true, true),
-- Ireland: English (primary) + Irish
('IE', 'en', true, true),
('IE', 'ga', false, true),
-- France: French (primary) + English
('FR', 'fr', true, true),
('FR', 'en', false, true),
-- Spain: Spanish (primary) + English
('ES', 'es', true, true),
('ES', 'en', false, true),
-- Sweden: Swedish (primary) + English
('SE', 'sv', true, true),
('SE', 'en', false, true),
-- Norway: Norwegian (primary) + English
('NO', 'no', true, true),
('NO', 'en', false, true);

-- Add new language mappings
INSERT INTO public.language_mappings (language_code, language_name, market_code) VALUES
('en', 'English', 'IE'),
('ga', 'Irish', 'IE'),
('fr', 'French', 'FR'),
('en', 'English', 'FR'),
('es', 'Spanish', 'ES'),
('en', 'English', 'ES'),
('sv', 'Swedish', 'SE'),
('en', 'English', 'SE'),
('no', 'Norwegian', 'NO'),
('en', 'English', 'NO');

-- Create trigger for market_language_access timestamps
CREATE TRIGGER update_market_language_access_updated_at
  BEFORE UPDATE ON public.market_language_access
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();