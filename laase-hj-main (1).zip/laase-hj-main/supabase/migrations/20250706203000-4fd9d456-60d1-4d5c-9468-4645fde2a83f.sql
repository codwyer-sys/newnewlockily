-- Add content fields to blog_post_market_seo table to support market-specific content
ALTER TABLE public.blog_post_market_seo 
ADD COLUMN title text,
ADD COLUMN slug text,
ADD COLUMN excerpt text,
ADD COLUMN content text;

-- Add unique constraint on post_id and slug combination to prevent duplicate slugs per post
ALTER TABLE public.blog_post_market_seo 
ADD CONSTRAINT unique_post_market_slug UNIQUE (post_id, slug);