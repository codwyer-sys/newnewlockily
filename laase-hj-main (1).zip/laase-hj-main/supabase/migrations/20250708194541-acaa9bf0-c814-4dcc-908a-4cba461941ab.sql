-- Create quotes table for locksmith bids on bookings (only if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.quotes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  locksmith_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  price NUMERIC(10,2) NOT NULL,
  estimated_arrival_minutes INTEGER NOT NULL,
  distance_km NUMERIC(6,2) NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'expired')),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '2 hours'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Add indexes for better performance (skip if they exist)
CREATE INDEX IF NOT EXISTS idx_quotes_booking_id ON public.quotes(booking_id);
CREATE INDEX IF NOT EXISTS idx_quotes_locksmith_id ON public.quotes(locksmith_id);
CREATE INDEX IF NOT EXISTS idx_quotes_status ON public.quotes(status);
CREATE INDEX IF NOT EXISTS idx_quotes_created_at ON public.quotes(created_at);

CREATE INDEX IF NOT EXISTS idx_reviews_locksmith_id ON public.reviews(locksmith_id);
CREATE INDEX IF NOT EXISTS idx_reviews_booking_id ON public.reviews(booking_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON public.reviews(rating);

-- Add triggers for updated_at
DROP TRIGGER IF EXISTS update_quotes_updated_at ON public.quotes;
CREATE TRIGGER update_quotes_updated_at
  BEFORE UPDATE ON public.quotes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Enable RLS
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can view quotes for public bookings" ON public.quotes;
DROP POLICY IF EXISTS "Locksmiths can create quotes for their bids" ON public.quotes;
DROP POLICY IF EXISTS "Locksmiths can update their own quotes" ON public.quotes;

-- RLS Policies for quotes
CREATE POLICY "Anyone can view quotes for public bookings" 
ON public.quotes FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.bookings b 
    WHERE b.id = quotes.booking_id 
    AND (b.customer_id IS NULL OR b.customer_id = auth.uid() OR b.locksmith_id = auth.uid())
  ) OR has_role(auth.uid(), 'admin'::user_role)
);

CREATE POLICY "Locksmiths can create quotes for their bids" 
ON public.quotes FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'locksmith'::user_role
    AND ur.user_id = quotes.locksmith_id
  )
);

CREATE POLICY "Locksmiths can update their own quotes" 
ON public.quotes FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'locksmith'::user_role
    AND ur.user_id = quotes.locksmith_id
  ) OR has_role(auth.uid(), 'admin'::user_role)
);