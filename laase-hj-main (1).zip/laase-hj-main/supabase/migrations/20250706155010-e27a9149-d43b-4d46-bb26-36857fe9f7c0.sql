-- Add missing translation keys for job card actions
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- Missing job card action messages
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'bid_sent', 'Bid Sent', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'bid_sent_desc', 'Your bid of', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'error', 'Error', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'bid_error', 'An error occurred while submitting bid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'request_sent', 'Request Sent', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'request_sent_desc', 'Customer received your request for more information', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'request_error', 'An error occurred while requesting information', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'job_dismissed', 'Job Dismissed', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'job_dismissed_desc', 'This job will not be shown again', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'dismiss_error', 'An error occurred while dismissing job', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'sending', 'Sending...', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'dismissing', 'Dismissing...', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'dismiss_job', 'Dismiss Job', 'text');