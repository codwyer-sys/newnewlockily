-- Create global pricing settings table
CREATE TABLE public.global_pricing_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL,
  nighttime_fee_type TEXT NOT NULL DEFAULT 'percentage' CHECK (nighttime_fee_type IN ('percentage', 'fixed')),
  nighttime_fee_amount NUMERIC NOT NULL DEFAULT 0,
  weekend_fee_type TEXT NOT NULL DEFAULT 'percentage' CHECK (weekend_fee_type IN ('percentage', 'fixed')),
  weekend_fee_amount NUMERIC NOT NULL DEFAULT 0,
  nighttime_start_hour INTEGER NOT NULL DEFAULT 18 CHECK (nighttime_start_hour >= 0 AND nighttime_start_hour <= 23),
  nighttime_end_hour INTEGER NOT NULL DEFAULT 6 CHECK (nighttime_end_hour >= 0 AND nighttime_end_hour <= 23),
  combine_nighttime_weekend_fees BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_locksmith_global_pricing UNIQUE (locksmith_id)
);

-- Enable RLS
ALTER TABLE public.global_pricing_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for global pricing settings
CREATE POLICY "Locksmiths can manage their own global pricing settings" 
ON public.global_pricing_settings 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = global_pricing_settings.locksmith_id 
    AND ur.user_id = auth.uid() 
    AND ur.role = 'locksmith'::user_role
  )
);

-- Create follow-up question pricing table
CREATE TABLE public.follow_up_question_pricing (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL,
  job_category_id UUID NOT NULL,
  follow_up_question_id UUID NOT NULL,
  answer_value TEXT NOT NULL,
  fee_type TEXT NOT NULL DEFAULT 'fixed' CHECK (fee_type IN ('percentage', 'fixed')),
  fee_amount NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_locksmith_question_answer_pricing UNIQUE (locksmith_id, job_category_id, follow_up_question_id, answer_value)
);

-- Enable RLS
ALTER TABLE public.follow_up_question_pricing ENABLE ROW LEVEL SECURITY;

-- Create policies for follow-up question pricing
CREATE POLICY "Locksmiths can manage their own follow-up question pricing" 
ON public.follow_up_question_pricing 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM user_roles ur 
    WHERE ur.user_id = follow_up_question_pricing.locksmith_id 
    AND ur.user_id = auth.uid() 
    AND ur.role = 'locksmith'::user_role
  )
);

-- Create triggers for updated_at
CREATE TRIGGER update_global_pricing_settings_updated_at
  BEFORE UPDATE ON public.global_pricing_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_follow_up_question_pricing_updated_at
  BEFORE UPDATE ON public.follow_up_question_pricing
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Remove old pricing columns from pricing_configs as they're now global
ALTER TABLE public.pricing_configs 
DROP COLUMN IF EXISTS evening_surcharge,
DROP COLUMN IF EXISTS weekend_surcharge,
DROP COLUMN IF EXISTS emergency_surcharge,
DROP COLUMN IF EXISTS travel_fee_per_km;