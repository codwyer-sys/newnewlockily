-- Update AI translation settings to use the latest OpenAI model
UPDATE public.ai_translation_settings 
SET 
  model = 'gpt-4.1-2025-04-14',
  updated_at = now()
WHERE id = '914c75b5-96fe-4cba-a7ac-8e164e3aa2e9';