
-- Add missing INSERT policy for locksmith_profiles table
CREATE POLICY "Locksmiths can create their own profile" 
ON public.locksmith_profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

-- Also add SELECT and UPDATE policies for locksmith_profiles if not already present
CREATE POLICY "Locksmiths can view their own profile" 
ON public.locksmith_profiles FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Locksmiths can update their own profile" 
ON public.locksmith_profiles FOR UPDATE 
USING (auth.uid() = id);

-- Allow admins to view all locksmith profiles
CREATE POLICY "Admins can view all locksmith profiles" 
ON public.locksmith_profiles FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to update locksmith profiles  
CREATE POLICY "Admins can update locksmith profiles" 
ON public.locksmith_profiles FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));
