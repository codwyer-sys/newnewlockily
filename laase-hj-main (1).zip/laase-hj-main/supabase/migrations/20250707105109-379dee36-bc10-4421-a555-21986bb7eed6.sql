-- Create city_translations table
CREATE TABLE public.city_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  city_id UUID NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  language_code TEXT NOT NULL,
  market_code TEXT REFERENCES public.markets(country_code),
  local_name TEXT NOT NULL,
  is_official BOOLEAN NOT NULL DEFAULT false,
  source TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('wikidata', 'manual', 'ai_generated')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(city_id, language_code, market_code)
);

-- Create area_translations table
CREATE TABLE public.area_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  area_id UUID NOT NULL REFERENCES public.areas(id) ON DELETE CASCADE,
  language_code TEXT NOT NULL,
  market_code TEXT REFERENCES public.markets(country_code),
  local_name TEXT NOT NULL,
  is_official BOOLEAN NOT NULL DEFAULT false,
  source TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('wikidata', 'manual', 'ai_generated')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(area_id, language_code, market_code)
);

-- Enable RLS
ALTER TABLE public.city_translations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.area_translations ENABLE ROW LEVEL SECURITY;

-- Create policies for city_translations
CREATE POLICY "Anyone can view city translations" 
ON public.city_translations 
FOR SELECT 
USING (true);

CREATE POLICY "Admins can manage city translations" 
ON public.city_translations 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Create policies for area_translations
CREATE POLICY "Anyone can view area translations" 
ON public.area_translations 
FOR SELECT 
USING (true);

CREATE POLICY "Admins can manage area translations" 
ON public.area_translations 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Add triggers for updated_at
CREATE TRIGGER update_city_translations_updated_at
BEFORE UPDATE ON public.city_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_area_translations_updated_at
BEFORE UPDATE ON public.area_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();