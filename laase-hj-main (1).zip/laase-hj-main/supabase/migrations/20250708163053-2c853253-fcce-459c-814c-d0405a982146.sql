-- Update the email template content to be more complete and professional
UPDATE email_template_content 
SET default_content = '<h2>Velkommen til {{platform_name}}, {{locksmith_name}}!</h2>

<p>Tak for din tilmelding som låsesmed partner. Vi er glade for at have dig med på holdet!</p>

<p><strong>Dine oplysninger:</strong><br>
- Firma: {{company_name}}<br>
- CVR: {{cvr_number}}<br>
- Email: {{email}}<br>
- Telefon: {{phone}}<br>
- Adresse: {{address}}, {{postal_code}} {{city}}</p>

<p>For at aktivere din konto og begynde at modtage opgaver, skal du bekræfte din email adresse:</p>

{{button: Bekræft Email : {{confirmemail_link}}}}

<p>Hvis du har spørgsmål, er du velkommen til at kontakte vores support på {{support_email}}.</p>

<p>Vi glæder os til at arbejde sammen!</p>

<p>Med venlig hilsen,<br>{{platform_name}} teamet</p>',
updated_at = now()
WHERE template_id = 'ec42b1a5-41f8-4392-a201-85af5de509a3' AND content_section = 'body';