-- Update "How it works" section with new English content and AI translation guidance

-- Update main title
UPDATE content_translations 
SET 
  content_value = 'Find and book your perfect locksmith—sorted in seconds.',
  ai_instruction = 'The headline must highlight how fast and effortless the process is, with "in seconds" or an equivalent phrase standing out to promise an almost instant result.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'title' 
AND market_code IS NULL;

-- Update subtitle (keeping existing but could be updated later)
UPDATE content_translations 
SET 
  ai_instruction = 'This subtitle should complement the main headline and reinforce the simplicity of the 3-step process.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'subtitle' 
AND market_code IS NULL;

-- Update Step 1 title
UPDATE content_translations 
SET 
  content_value = 'Start your request—done in under 20 seconds.',
  ai_instruction = 'This section should emphasize that getting started is incredibly quick and easy, with a clear mention that the process takes less than 20 seconds.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'step_1_title' 
AND market_code IS NULL;

-- Update Step 1 description
UPDATE content_translations 
SET 
  content_value = 'Just tell us what you need and when, and your request is ready in less than 20 seconds—no hassle, no waiting.',
  ai_instruction = 'This section should emphasize that getting started is incredibly quick and easy, with a clear mention that the process takes less than 20 seconds.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'step_1_desc' 
AND market_code IS NULL;

-- Update Step 2 title
UPDATE content_translations 
SET 
  content_value = 'Instant quotes from trusted local locksmiths.',
  ai_instruction = 'It should be clear that users receive immediate quotes from reliable local locksmiths, making comparison and selection fast and straightforward.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'step_2_title' 
AND market_code IS NULL;

-- Update Step 2 description
UPDATE content_translations 
SET 
  content_value = 'See real-time offers from vetted professionals nearby, so you can compare and choose the best locksmith for you—right away.',
  ai_instruction = 'It should be clear that users receive immediate quotes from reliable local locksmiths, making comparison and selection fast and straightforward.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'step_2_desc' 
AND market_code IS NULL;

-- Update Step 3 title
UPDATE content_translations 
SET 
  content_value = 'Help arrives when you need it—now or later.',
  ai_instruction = 'This section should communicate that users can get help instantly for emergencies or book for a future time, highlighting both flexibility and reliability.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'step_3_title' 
AND market_code IS NULL;

-- Update Step 3 description
UPDATE content_translations 
SET 
  content_value = 'Whether it''s an emergency or a planned appointment, your chosen locksmith is on the way at the exact time you want—immediately or scheduled for later.',
  ai_instruction = 'This section should communicate that users can get help instantly for emergencies or book for a future time, highlighting both flexibility and reliability.',
  updated_at = now()
WHERE section_id = (
  SELECT cs.id FROM content_sections cs 
  JOIN content_pages cp ON cs.page_id = cp.id 
  WHERE cp.page_key = 'home' AND cs.section_key = 'how_it_works'
) 
AND language_code = 'en' 
AND content_key = 'step_3_desc' 
AND market_code IS NULL;