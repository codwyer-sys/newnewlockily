-- Add new markets: Poland, Canada, Portugal, Italy, Finland, Czech Republic
INSERT INTO public.markets (country_code, country_name, currency_code, currency_symbol, distance_unit, business_reg_field, business_reg_label, emergency_number, default_lat, default_lng, address_api_provider) VALUES
('PL', 'Poland', 'PLN', 'zł', 'km', 'nip_number', 'NIP Number', '112', 51.9194, 19.1451, 'google'),
('CA', 'Canada', 'CAD', '$', 'km', 'business_number', 'Business Number', '911', 56.1304, -106.3468, 'google'),
('PT', 'Portugal', 'EUR', '€', 'km', 'nipc_number', 'NIPC Number', '112', 39.3999, -8.2245, 'google'),
('IT', 'Italy', 'EUR', '€', 'km', 'partita_iva', 'Partita IVA', '112', 41.8719, 12.5674, 'google'),
('FI', 'Finland', 'EUR', '€', 'km', 'business_id', 'Y-tunnus', '112', 61.9241, 25.7482, 'google'),
('CZ', 'Czech Republic', 'CZK', 'Kč', 'km', 'ico_number', 'IČO Number', '112', 49.8175, 15.4730, 'google');

-- Add market-language access mappings for new markets
INSERT INTO public.market_language_access (market_code, language_code, is_primary, is_enabled) VALUES
-- Poland: Polish (primary) + English
('PL', 'pl', true, true),
('PL', 'en', false, true),
-- Canada: English (primary) + French
('CA', 'en', true, true),
('CA', 'fr', false, true),
-- Portugal: Portuguese (primary) + English
('PT', 'pt', true, true),
('PT', 'en', false, true),
-- Italy: Italian (primary) + English
('IT', 'it', true, true),
('IT', 'en', false, true),
-- Finland: Finnish (primary) + Swedish + English
('FI', 'fi', true, true),
('FI', 'sv', false, true),
('FI', 'en', false, true),
-- Czech Republic: Czech (primary) + English
('CZ', 'cs', true, true),
('CZ', 'en', false, true);

-- Add new language mappings
INSERT INTO public.language_mappings (language_code, language_name, market_code) VALUES
('pl', 'Polish', 'PL'),
('en', 'English', 'PL'),
('en', 'English', 'CA'),
('fr', 'French', 'CA'),
('pt', 'Portuguese', 'PT'),
('en', 'English', 'PT'),
('it', 'Italian', 'IT'),
('en', 'English', 'IT'),
('fi', 'Finnish', 'FI'),
('sv', 'Swedish', 'FI'),
('en', 'English', 'FI'),
('cs', 'Czech', 'CZ'),
('en', 'English', 'CZ');

-- Add address provider configurations for new markets
INSERT INTO address_provider_configs (market_code, provider_name, is_primary, is_enabled, priority) VALUES
('PL', 'google-places', true, true, 100),
('CA', 'google-places', true, true, 100),
('PT', 'google-places', true, true, 100),
('IT', 'google-places', true, true, 100),
('FI', 'google-places', true, true, 100),
('CZ', 'google-places', true, true, 100);

-- Add address validation rules for new markets
INSERT INTO address_validation_rules (market_code, input_type, validation_regex, min_length, placeholder_text, error_message) VALUES
('PL', 'full_address', null, 3, 'Wprowadź swój adres', 'Proszę wprowadzić prawidłowy adres'),
('CA', 'full_address', null, 3, 'Enter your address', 'Please enter a valid address'),
('PT', 'full_address', null, 3, 'Digite o seu endereço', 'Por favor, digite um endereço válido'),
('IT', 'full_address', null, 3, 'Inserisci il tuo indirizzo', 'Per favore inserisci un indirizzo valido'),
('FI', 'full_address', null, 3, 'Syötä osoitteesi', 'Anna kelvollinen osoite'),
('CZ', 'full_address', null, 3, 'Zadejte svou adresu', 'Zadejte prosím platnou adresu');