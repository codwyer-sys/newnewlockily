-- Update the English hero title with new content and AI translation guidance
UPDATE content_translations 
SET 
  content_value = 'Find Your Trusted Locksmith—Fast, Reliable Help for Any Situation',
  ai_instruction = 'This headline is carefully crafted to immediately communicate that Lockily is the definitive platform for anyone seeking a locksmith, whether the need is urgent or planned. The phrase "Find Your Trusted Locksmith" is chosen to emphasize both personal relevance and trust, positioning Lockily as the best place to connect with a reliable professional. The inclusion of "Fast, Reliable Help for Any Situation" clarifies that the service is suitable for emergencies as well as scheduled jobs, addressing both immediacy and flexibility. When translating, ensure that "Trusted" conveys not just familiarity but also reliability and professionalism. "Fast, Reliable Help" must express both speed and dependability, which are essential for emergency scenarios. "For Any Situation" should be rendered to cover all possible use cases, including urgent lockouts, planned upgrades, and everything in between. The tone should remain reassuring, authoritative, and inviting, making users feel confident in choosing Lockily.',
  updated_at = now()
WHERE section_id = 'be86a810-42dd-4a69-ac56-80fc3d8a8f7b'
  AND language_code = 'en'
  AND content_key = 'title'
  AND market_code IS NULL;

-- Insert the new English hero description with content and AI translation guidance
INSERT INTO content_translations (
  section_id,
  language_code,
  content_key,
  content_value,
  content_type,
  market_code,
  ai_instruction
) VALUES (
  'be86a810-42dd-4a69-ac56-80fc3d8a8f7b',
  'en',
  'description',
  'Get instant quotes from certified locksmiths near you—available 24/7 for emergencies or scheduled appointments. Quick arrival, transparent pricing, and a simple booking',
  'text',
  null,
  'This supporting text is designed to explain the Lockily process and highlight its advantages in a succinct, benefit-driven way. The phrase "Get instant quotes from certified locksmiths near you" directly addresses the user''s desire for speed and local relevance. "Available 24/7 for emergencies or scheduled appointments" makes it clear that Lockily caters to both urgent and planned needs, removing any ambiguity about the scope of the service. The next sentence, "Quick arrival, transparent pricing, and a simple booking process with Lockily," succinctly lists the platform''s main selling points: speed, honesty in pricing, and ease of use, which builds trust and sets clear expectations for the user journey. When translating, ensure "Instant quotes" is rendered as "immediate price offers" or a similar phrase that emphasizes speed and convenience. "Certified locksmiths" must retain the meaning of officially qualified professionals. "Available 24/7 for emergencies or scheduled appointments" should clearly communicate both round-the-clock availability and the option to book ahead. "Quick arrival" refers to fast response times, not just the booking process. "Transparent pricing" must communicate no hidden fees or surprises, focusing on clarity and honesty. "Simple booking process" should convey ease, minimal steps, and user-friendliness. The tone throughout should remain clear, direct, and reassuring, focusing on user benefits. This unified guidance ensures that, when translated, the texts will immediately convey trust, versatility, and ease—key factors in converting visitors into customers, regardless of their locksmith needs.'
);