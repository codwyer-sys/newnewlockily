-- Update the existing Locksmith Profil Signup Email Validation template with required variables
UPDATE email_templates 
SET requires_variables = '[
  "locksmith_name",
  "company_name", 
  "email",
  "cvr_number",
  "phone",
  "address",
  "city",
  "postal_code",
  "website",
  "support_email",
  "platform_name"
]'::jsonb
WHERE id = 'ec42b1a5-41f8-4392-a201-85af5de509a3';

-- Add content sections for the template if they don't exist
INSERT INTO email_template_content (template_id, content_section, content_key, default_content, content_type, is_required)
VALUES 
  ('ec42b1a5-41f8-4392-a201-85af5de509a3', 'subject', 'signup_email_subject', 'Velkommen til {{platform_name}} - Bekræft din email', 'text', true),
  ('ec42b1a5-41f8-4392-a201-85af5de509a3', 'preheader', 'signup_email_preheader', 'Bekræft din email for at aktivere din låsesmed profil', 'text', false),
  ('ec42b1a5-41f8-4392-a201-85af5de509a3', 'body', 'signup_email_body', '<h1>Velkommen til {{platform_name}}, {{locksmith_name}}!</h1>

<p>Tak fordi du har tilmeldt dig som låsesmed på vores platform. Vi er glade for at have {{company_name}} som en del af vores netværk.</p>

<h2>Dine oplysninger:</h2>
<ul>
  <li><strong>Firma:</strong> {{company_name}}</li>
  <li><strong>CVR:</strong> {{cvr_number}}</li>
  <li><strong>Email:</strong> {{email}}</li>
  <li><strong>Telefon:</strong> {{phone}}</li>
  <li><strong>Adresse:</strong> {{address}}, {{postal_code}} {{city}}</li>
  {{#if website}}<li><strong>Hjemmeside:</strong> {{website}}</li>{{/if}}
</ul>

<h2>Næste skridt:</h2>
<p>For at aktivere din profil skal du bekræfte din email-adresse. Tjek din indbakke for en bekræftelsesmail.</p>

<p>Hvis du har spørgsmål, er du velkommen til at kontakte os på {{support_email}}.</p>

<p>Vi ser frem til at arbejde sammen!</p>

<p>Med venlig hilsen,<br>{{platform_name}} teamet</p>', 'html', true)
ON CONFLICT (template_id, content_section, content_key) DO UPDATE SET
  default_content = EXCLUDED.default_content,
  updated_at = now();