-- Remove the restrictive language code check constraint to allow all countries and markets
ALTER TABLE public.content_translations 
DROP CONSTRAINT IF EXISTS content_translations_language_code_check;