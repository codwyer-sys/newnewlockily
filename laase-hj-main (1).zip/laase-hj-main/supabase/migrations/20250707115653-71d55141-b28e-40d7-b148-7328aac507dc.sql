-- Create a function to backfill city translations from AI for existing cities
CREATE OR REPLACE FUNCTION backfill_city_translations()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  city_record record;
  translated_name text;
  language_code text;
BEGIN
  -- Loop through all cities that don't have translations
  FOR city_record IN 
    SELECT c.id, c.name, c.market_code
    FROM cities c
    LEFT JOIN city_translations ct ON c.id = ct.city_id AND ct.market_code = c.market_code
    WHERE ct.id IS NULL AND c.is_active = true
  LOOP
    -- Get the language code for the market
    language_code := CASE city_record.market_code
      WHEN 'DK' THEN 'da'
      WHEN 'DE' THEN 'de'
      WHEN 'SE' THEN 'sv'
      WHEN 'NO' THEN 'no'
      WHEN 'UK' THEN 'en'
      WHEN 'GB' THEN 'en'
      WHEN 'US' THEN 'en'
      WHEN 'CA' THEN 'en'
      WHEN 'FR' THEN 'fr'
      WHEN 'ES' THEN 'es'
      WHEN 'IT' THEN 'it'
      WHEN 'PL' THEN 'pl'
      WHEN 'PT' THEN 'pt'
      WHEN 'FI' THEN 'fi'
      WHEN 'CZ' THEN 'cs'
      WHEN 'IE' THEN 'en'
      ELSE 'en'
    END;
    
    -- For now, just create a placeholder translation that matches the English name
    -- This can be updated later by AI or manual editing
    INSERT INTO city_translations (
      city_id,
      language_code,
      market_code,
      local_name,
      source,
      is_official
    ) VALUES (
      city_record.id,
      language_code,
      city_record.market_code,
      city_record.name, -- Start with English name as placeholder
      'manual',
      false
    );
    
    RAISE NOTICE 'Created placeholder translation for city: %', city_record.name;
  END LOOP;
END;
$$;

-- Execute the function to backfill existing cities
SELECT backfill_city_translations();