-- Add a new column for the foreign key relationship
ALTER TABLE public.bookings ADD COLUMN job_category_id UUID;

-- First, ensure we have a "Låst ude" category
INSERT INTO public.job_categories (name, emoji, description)
SELECT 'Låst ude', '🔐', 'Låst ude af hjem eller bil'
WHERE NOT EXISTS (SELECT 1 FROM public.job_categories WHERE name = 'Låst ude');

-- Update existing bookings to use proper job_category IDs based on job_type names
UPDATE public.bookings 
SET job_category_id = (
  SELECT jc.id 
  FROM public.job_categories jc 
  WHERE jc.name = public.bookings.job_type
)
WHERE job_category_id IS NULL;

-- Update any remaining null job_category_id values with the default "Låst ude" category
UPDATE public.bookings 
SET job_category_id = (
  SELECT id FROM public.job_categories WHERE name = 'Låst ude' LIMIT 1
)
WHERE job_category_id IS NULL;

-- Now make the column NOT NULL since all bookings should have a category
ALTER TABLE public.bookings ALTER COLUMN job_category_id SET NOT NULL;

-- Add the foreign key constraint
ALTER TABLE public.bookings 
ADD CONSTRAINT fk_bookings_job_category 
FOREIGN KEY (job_category_id) REFERENCES public.job_categories(id);

-- Create an index for better query performance
CREATE INDEX idx_bookings_job_category_id ON public.bookings(job_category_id);