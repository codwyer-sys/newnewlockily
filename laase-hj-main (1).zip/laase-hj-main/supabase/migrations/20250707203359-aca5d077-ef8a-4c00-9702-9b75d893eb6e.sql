-- Fix the truncated English hero description that's causing bulk translation failures
UPDATE content_translations 
SET 
  content_value = 'Get instant quotes from certified locksmiths near you—available 24/7 for emergencies or scheduled appointments. Quick arrival, transparent pricing, and a simple booking process with Lockily.',
  updated_at = now()
WHERE section_id = 'be86a810-42dd-4a69-ac56-80fc3d8a8f7b'
  AND language_code = 'en'
  AND content_key = 'description'
  AND market_code IS NULL;