-- Update the test blog post status to published so it shows up
UPDATE blog_posts 
SET status = 'published', published_at = now() 
WHERE id = '5bc3d42d-2563-413a-b400-c3a4d0a78556';