-- Add more English content entries for LocksmithSidebar and other components
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- Additional sidebar navigation items that need translation
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'statistics', 'Statistics', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'work_time', 'Work Time', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'main_menu', 'Main Menu', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'service_menu', 'Service', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'admin_menu', 'Administration', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'logout', 'Log out', 'text'),

-- Sub-menu items
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'payment_settings', 'Payment Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'company', 'Company', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'notifications', 'Notifications', 'text'),

-- Status options
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'ready', 'Ready for jobs', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'busy', 'Too busy', 'text'),

-- Status dialog
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'busy_dialog_title', 'Too busy status', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'busy_dialog_description', 'Do you want to automatically go back to active?', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'minutes_label', 'Number of minutes', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'cancel', 'Cancel', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'confirm', 'Confirm', 'text'),

-- Dashboard content
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'busy_minutes_format', 'Too busy ({minutes}m)', 'text'),

-- Create English content entries for AutoByd page
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- Settings page general
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'auto_bid_title', 'AutoBid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'auto_bid_description', 'Configure which categories to automatically bid on', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'auto_bid_enabled_count', 'AutoBid enabled for {count} categor{plural}.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'auto_bid_select_categories', 'Select categories below to enable automatic bidding.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'auto_bid_active_info', 'When AutoBid is enabled for a category, the system will automatically place bids on suitable tasks within your service areas.', 'text'),

-- Categories section
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'categories_title', 'Categories', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'labels' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'categories_description', 'Select which types of tasks you want automatic bids on', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'messages' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'settings')), 'en', 'no_categories_found', 'No categories found', 'text');