-- Final cleanup: Drop the old locksmith_profiles table
DROP TABLE IF EXISTS public.locksmith_profiles CASCADE;