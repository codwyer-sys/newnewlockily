-- Add missing translation keys for LocksmithDashboard
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- Dashboard stats and interface
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'jobs_today', 'Jobs Today', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'rating', 'Rating', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'response_time', 'Response Time', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'completed', 'Completed', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'settings', 'Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'no_active_jobs', 'No Active Jobs', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'no_active_jobs_desc', 'New jobs will appear here when they come in', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'job_accepted', 'Job Accepted', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'job_accepted_desc', 'Customer will be notified of your arrival time', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'job_rejected', 'Job Rejected', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'dashboard' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'job_rejected_desc', 'Job has been forwarded to other locksmiths', 'text');