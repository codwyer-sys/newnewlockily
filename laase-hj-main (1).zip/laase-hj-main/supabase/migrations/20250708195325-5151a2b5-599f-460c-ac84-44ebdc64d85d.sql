-- Create booking status content page and sections with translations

-- 1. Create the booking_status content page
INSERT INTO public.content_pages (id, page_key, page_name, description)
VALUES (
  'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c',
  'booking_status',
  'Booking Status Page',
  'All content for the booking status tracking page'
) ON CONFLICT (page_key) DO NOTHING;

-- 2. Create content sections for different parts of the booking status page
INSERT INTO public.content_sections (id, page_id, section_key, section_name, description) VALUES
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'hero_section', 'Hero Section', 'Hero area with dynamic titles and descriptions'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'job_stages', 'Job Stage Content', 'Titles, descriptions, and badge text for all job stages'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'booking_details', 'Booking Details Card', 'Labels and content for booking information display'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'quotes_section', 'Quotes Section', 'Quote display, sorting, and interaction content'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'locksmith_profile', 'Locksmith Profile Card', 'Locksmith contact and profile information'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'eta_circle', 'ETA Circle', 'ETA display and status messages'),
  ('b7f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'actions', 'Action Buttons', 'Main page action buttons and navigation'),
  ('b8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'a8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'loading_states', 'Loading States', 'Loading, error, and status messages')
ON CONFLICT (page_id, section_key) DO NOTHING;

-- 3. Insert English translations for job stages
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  -- Waiting for quotes stage
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_waiting_quotes_title', 'Searching for Available Locksmiths', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_waiting_quotes_description', 'We''re connecting you with qualified locksmiths in your area', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_waiting_quotes_badge', 'Finding Locksmiths', 'text'),
  
  -- Awaiting client feedback stage
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_awaiting_feedback_title', 'Choose Your Locksmith', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_awaiting_feedback_description', 'Review and select from available quotes', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_awaiting_feedback_badge', 'Select Quote', 'text'),
  
  -- Awaiting locksmith acceptance stage
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_awaiting_acceptance_title', 'Confirming Your Locksmith', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_awaiting_acceptance_description', 'Your selected locksmith is confirming availability', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_awaiting_acceptance_badge', 'Confirming', 'text'),
  
  -- Locksmith en route stage
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_en_route_title', 'Your Locksmith is on the Way', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_en_route_description', 'Track your locksmith''s arrival in real-time', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_en_route_badge', 'En Route', 'text'),
  
  -- Locksmith on job stage
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_on_job_title', 'Service in Progress', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_on_job_description', 'Your locksmith is working on your request', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_on_job_badge', 'Working', 'text'),
  
  -- Job finished stage
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_finished_title', 'Service Completed', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_finished_description', 'Your locksmith service has been completed successfully', 'text'),
  ('b2f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'stage_finished_badge', 'Completed', 'text');

-- 4. Insert English translations for booking details
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'booking_details_title', 'Booking Details', 'text'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'address_label', 'Address', 'text'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'urgency_label', 'Urgency', 'text'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'urgency_now', 'Urgent - Now', 'text'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'urgency_can_wait', 'Can Wait', 'text'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'job_type_label', 'Service Type', 'text'),
  ('b3f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'created_at_label', 'Booking Created', 'text');

-- 5. Insert English translations for quotes section
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'waiting_for_quotes_title', 'Waiting for Quotes...', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'quotes_received_title', 'Quotes Received', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'sort_by_price', 'Sort by Price', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'sort_by_distance', 'Sort by Distance', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'sort_by_rating', 'Sort by Rating', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'finding_locksmiths_title', 'Finding Available Locksmiths...', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'finding_locksmiths_description', 'We''re sending your request to locksmiths in your area. You''ll typically receive quotes within 5-10 minutes.', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'total_price_label', 'Total price', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'arrives_in_label', 'Arrives in', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'km_away_label', 'km away', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'reviews_label', 'reviews', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'accept_quote_button', 'Accept Quote', 'text'),
  ('b4f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'quote_accepted_label', 'Quote Accepted', 'text');

-- 6. Insert English translations for locksmith profile
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'professional_locksmith_fallback', 'Professional Locksmith', 'text'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'arrival_label', 'Arrival', 'text'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'distance_label', 'Distance', 'text'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'rating_label', 'Rating', 'text'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'call_locksmith_button', 'Call Locksmith', 'text'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'send_message_button', 'Send Message', 'text'),
  ('b5f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'locksmith_confirmed_message', 'Your locksmith is confirmed and on the way!', 'text');

-- 7. Insert English translations for ETA circle
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'eta_label', 'ETA', 'text'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'almost_there_message', 'Almost there! Finding the best locksmiths...', 'text'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'quotes_received_message', 'Great! {count} quote{plural} received', 'text'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'confirming_availability_message', 'Confirming availability...', 'text'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'locksmith_on_way_message', 'Your locksmith is on the way!', 'text'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'work_in_progress_message', 'Work in progress...', 'text'),
  ('b6f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'processing_message', 'Processing...', 'text');

-- 8. Insert English translations for actions
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b7f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'back_to_home_button', 'Back to Home', 'text'),
  ('b7f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'call_us_button', 'Call Us: 70 20 30 40', 'text');

-- 9. Insert English translations for loading states
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'loading_booking_message', 'Loading booking details...', 'text'),
  ('b8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'error_title', 'Error', 'text'),
  ('b8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'booking_not_found_message', 'Booking not found', 'text'),
  ('b8f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'return_home_button', 'Return Home', 'text');

-- 10. Insert English translations for hero status messages  
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'searching_locksmiths_message', 'Searching for available locksmiths...', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'quotes_count_message', '{count} quote{plural} received', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'locksmiths_ready_message', '{count} locksmith{plural} ready to help', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'waiting_confirmation_message', 'Waiting for locksmith confirmation...', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'locksmith_on_way_hero_message', 'Your locksmith is on the way', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'work_in_progress_hero_message', 'Work in progress...', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'service_completed_hero_message', 'Service completed successfully', 'text'),
  ('b1f3d2c1-4b5e-6f7a-8b9c-0d1e2f3a4b5c', 'en', 'processing_request_message', 'Processing your request...', 'text');