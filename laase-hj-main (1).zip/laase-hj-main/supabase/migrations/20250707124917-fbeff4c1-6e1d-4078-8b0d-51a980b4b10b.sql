-- Add status column to cities table
ALTER TABLE public.cities 
ADD COLUMN status TEXT NOT NULL DEFAULT 'draft' 
CHECK (status IN ('draft', 'published'));

-- Update existing cities to published status
UPDATE public.cities SET status = 'published' WHERE is_active = true;

-- Create function to call webhook edge function
CREATE OR REPLACE FUNCTION public.notify_city_created()
RETURNS TRIGGER AS $$
BEGIN
  -- Call the edge function in background
  PERFORM
    net.http_post(
      url := 'https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/city-webhook-notification',
      headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5c21wa2lubGdwcW93bWx3dHRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEyMTk2NjMsImV4cCI6MjA2Njc5NTY2M30.qkUY2UXZp5mJp-fRwHWP_-b8kz3hvE2EUkU4kKL6sbk"}'::jsonb,
      body := json_build_object(
        'cityId', NEW.id,
        'event', 'city_created',
        'timestamp', now(),
        'marketCode', NEW.market_code
      )::jsonb
    );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for city creation
CREATE TRIGGER city_created_webhook
  AFTER INSERT ON public.cities
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_city_created();