-- Create table to log image analysis results for learning and improvement
CREATE TABLE public.image_analysis_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  image_url TEXT NOT NULL,
  analysis_result JSONB NOT NULL,
  model_used TEXT NOT NULL DEFAULT 'gpt-4o',
  user_confirmed BOOLEAN NULL, -- Will be updated when user confirms/rejects
  actual_job_type TEXT NULL, -- Updated when user selects different job type
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.image_analysis_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can read analysis logs (for improving the model)
CREATE POLICY "Admins can view image analysis logs" 
ON public.image_analysis_logs 
FOR SELECT 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Anyone can insert analysis logs (for the ML function)
CREATE POLICY "Anyone can insert image analysis logs" 
ON public.image_analysis_logs 
FOR INSERT 
WITH CHECK (true);

-- Create trigger for updating timestamp
CREATE TRIGGER update_image_analysis_logs_updated_at
BEFORE UPDATE ON public.image_analysis_logs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();