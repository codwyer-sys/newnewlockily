-- Create table for market-specific SEO metadata for global blog posts
CREATE TABLE public.blog_post_market_seo (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  post_id UUID NOT NULL,
  market_code VARCHAR NOT NULL,
  seo_title TEXT,
  seo_description TEXT,
  seo_keywords TEXT[],
  og_title TEXT,
  og_description TEXT,
  og_image_url TEXT,
  twitter_title TEXT,
  twitter_description TEXT,
  twitter_image_url TEXT,
  canonical_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT unique_post_market UNIQUE (post_id, market_code)
);

-- Enable Row Level Security
ALTER TABLE public.blog_post_market_seo ENABLE ROW LEVEL SECURITY;

-- Create policies for blog post market SEO
CREATE POLICY "Admins can manage all blog post market SEO" 
ON public.blog_post_market_seo 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Authors can manage their own blog post market SEO" 
ON public.blog_post_market_seo 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.blog_posts bp 
  WHERE bp.id = blog_post_market_seo.post_id 
  AND bp.author_id = auth.uid()
));

CREATE POLICY "Anyone can view published blog post market SEO" 
ON public.blog_post_market_seo 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.blog_posts bp 
  WHERE bp.id = blog_post_market_seo.post_id 
  AND bp.status = 'published'
));

-- Add foreign key constraint
ALTER TABLE public.blog_post_market_seo 
ADD CONSTRAINT fk_blog_post_market_seo_post_id 
FOREIGN KEY (post_id) REFERENCES public.blog_posts(id) ON DELETE CASCADE;

ALTER TABLE public.blog_post_market_seo 
ADD CONSTRAINT fk_blog_post_market_seo_market_code 
FOREIGN KEY (market_code) REFERENCES public.markets(country_code);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_blog_post_market_seo_updated_at
BEFORE UPDATE ON public.blog_post_market_seo
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_blog_post_market_seo_post_id ON public.blog_post_market_seo(post_id);
CREATE INDEX idx_blog_post_market_seo_market_code ON public.blog_post_market_seo(market_code);