-- Add call integration fields to bookings table
ALTER TABLE public.bookings 
ADD COLUMN call_id TEXT,
ADD COLUMN call_duration_seconds INTEGER,
ADD COLUMN call_transcription TEXT,
ADD COLUMN booking_source TEXT DEFAULT 'web' CHECK (booking_source IN ('web', 'phone', 'api')),
ADD COLUMN caller_phone_number TEXT,
ADD COLUMN call_metadata JSONB DEFAULT '{}';

-- Create index for call tracking
CREATE INDEX idx_bookings_call_id ON public.bookings(call_id);
CREATE INDEX idx_bookings_source ON public.bookings(booking_source);

-- Add comment for documentation
COMMENT ON COLUMN public.bookings.call_id IS 'ElevenLabs conversation ID for phone bookings';
COMMENT ON COLUMN public.bookings.call_duration_seconds IS 'Duration of the phone call in seconds';
COMMENT ON COLUMN public.bookings.call_transcription IS 'Full transcription of the phone conversation';
COMMENT ON COLUMN public.bookings.booking_source IS 'Source of the booking: web, phone, or api';
COMMENT ON COLUMN public.bookings.caller_phone_number IS 'Phone number of the caller';
COMMENT ON COLUMN public.bookings.call_metadata IS 'Additional metadata from the phone call';