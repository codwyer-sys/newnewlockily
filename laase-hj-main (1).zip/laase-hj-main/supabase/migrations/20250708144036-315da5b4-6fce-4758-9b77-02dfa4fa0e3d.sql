-- Phase 1: Simplify email brand settings to be global (not market-specific)

-- First, make market_code nullable so we can insert global settings
ALTER TABLE public.email_brand_settings ALTER COLUMN market_code DROP NOT NULL;

-- Create a single global brand settings record if none exists
INSERT INTO public.email_brand_settings (
  logo_url,
  primary_color,
  secondary_color,
  font_family,
  header_background_color,
  footer_background_color,
  border_color,
  company_name,
  contact_email
) 
SELECT 
  '/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png',
  '#155e63',
  '#f9f8eb',
  'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
  '#155e63',
  '#f9f8eb',
  '#155e63',
  'Lockily',
  'support@lockily.com'
WHERE NOT EXISTS (SELECT 1 FROM public.email_brand_settings WHERE market_code IS NULL);

-- Remove any market-specific brand settings (keep only the global one)
DELETE FROM public.email_brand_settings WHERE market_code IS NOT NULL;

-- Now remove the market_code column entirely
ALTER TABLE public.email_brand_settings DROP COLUMN market_code;

-- Update RLS policies to reflect that brand settings are now global
DROP POLICY IF EXISTS "Admins can manage email brand settings" ON public.email_brand_settings;
DROP POLICY IF EXISTS "Anyone can view email brand settings" ON public.email_brand_settings;

CREATE POLICY "Admins can manage global email brand settings" 
ON public.email_brand_settings 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view global email brand settings" 
ON public.email_brand_settings 
FOR SELECT 
USING (true);