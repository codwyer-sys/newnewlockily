-- Add tracking fields to content_translations table
ALTER TABLE public.content_translations 
ADD COLUMN IF NOT EXISTS updated_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS notes TEXT;

-- Create translation history table for change tracking
CREATE TABLE IF NOT EXISTS public.translation_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  translation_id UUID NOT NULL REFERENCES public.content_translations(id) ON DELETE CASCADE,
  old_value TEXT,
  new_value TEXT NOT NULL,
  changed_by UUID REFERENCES auth.users(id),
  changed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  change_reason TEXT
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_translation_history_translation_id ON public.translation_history(translation_id);
CREATE INDEX IF NOT EXISTS idx_translation_history_changed_at ON public.translation_history(changed_at DESC);
CREATE INDEX IF NOT EXISTS idx_content_translations_market_language ON public.content_translations(market_code, language_code);
CREATE INDEX IF NOT EXISTS idx_content_translations_updated_at ON public.content_translations(updated_at DESC);

-- Enable RLS on translation_history
ALTER TABLE public.translation_history ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for translation_history
CREATE POLICY "Admins can manage translation history" 
ON public.translation_history 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Update trigger to track changes in content_translations
CREATE OR REPLACE FUNCTION public.track_translation_changes()
RETURNS TRIGGER AS $$
BEGIN
  -- Only insert history if the content_value actually changed
  IF OLD.content_value IS DISTINCT FROM NEW.content_value THEN
    INSERT INTO public.translation_history (
      translation_id,
      old_value,
      new_value,
      changed_by,
      change_reason
    ) VALUES (
      NEW.id,
      OLD.content_value,
      NEW.content_value,
      auth.uid(),
      'Content updated'
    );
  END IF;
  
  -- Update the updated_by field
  NEW.updated_by = auth.uid();
  NEW.updated_at = now();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for tracking changes
DROP TRIGGER IF EXISTS track_translation_changes_trigger ON public.content_translations;
CREATE TRIGGER track_translation_changes_trigger
  BEFORE UPDATE ON public.content_translations
  FOR EACH ROW
  EXECUTE FUNCTION public.track_translation_changes();