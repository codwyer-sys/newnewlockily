
-- Create table for job categories
CREATE TABLE public.job_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  emoji TEXT,
  description TEXT,
  requires_image BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for follow-up questions
CREATE TABLE public.follow_up_questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_category_id UUID REFERENCES public.job_categories(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  question_key TEXT NOT NULL,
  question_type TEXT NOT NULL CHECK (question_type IN ('radio', 'number', 'text', 'checkbox')),
  options JSONB, -- For radio/checkbox options
  is_required BOOLEAN DEFAULT true,
  is_global BOOLEAN DEFAULT false, -- Shows for all categories if true
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add some default job categories
INSERT INTO public.job_categories (name, emoji, description, requires_image) VALUES
('Låst ude', '🔑', 'Kom ikke ind', true),
('Knækket nøgle', '🔨', 'Nøgle ødelagt', true),
('Skift lås', '🔒', 'Ny lås skal sættes', false),
('Andet', '❓', 'Andet problem', false);

-- Add some default follow-up questions for "Låst ude"
INSERT INTO public.follow_up_questions (job_category_id, question, question_key, question_type, options, is_required, order_index)
SELECT 
  id,
  'Hvilken type dør er det?',
  'doorType',
  'radio',
  '["Hoveddør", "Bagdør", "Altandør", "Andet"]'::jsonb,
  true,
  1
FROM public.job_categories WHERE name = 'Låst ude';

INSERT INTO public.follow_up_questions (job_category_id, question, question_key, question_type, options, is_required, order_index)
SELECT 
  id,
  'Ved du hvilken type lås det er?',
  'lockType',
  'radio',
  '["Almindelig cylinder", "Sikkerhedslås", "Elektronisk", "Ved ikke"]'::jsonb,
  true,
  2
FROM public.job_categories WHERE name = 'Låst ude';

-- Add some default follow-up questions for "Knækket nøgle"
INSERT INTO public.follow_up_questions (job_category_id, question, question_key, question_type, options, is_required, order_index)
SELECT 
  id,
  'Hvor sidder nøglen fast?',
  'keyLocation',
  'radio',
  '["Dør", "Hængelås", "Bil", "Andet"]'::jsonb,
  true,
  1
FROM public.job_categories WHERE name = 'Knækket nøgle';

-- Add some default follow-up questions for "Skift lås"
INSERT INTO public.follow_up_questions (job_category_id, question, question_key, question_type, options, is_required, order_index)
SELECT 
  id,
  'Hvor mange låse skal skiftes?',
  'lockCount',
  'number',
  null,
  true,
  1
FROM public.job_categories WHERE name = 'Skift lås';

-- Add a global question that shows for all categories
INSERT INTO public.follow_up_questions (job_category_id, question, question_key, question_type, options, is_required, is_global, order_index)
VALUES 
(null, 'Hvornår på dagen passer det bedst?', 'preferredTime', 'radio', '["Morgen", "Eftermiddag", "Aften", "Ligegyldigt"]'::jsonb, false, true, 100);

-- Enable Row Level Security (make tables public for now - in production you'd want proper auth)
ALTER TABLE public.job_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follow_up_questions ENABLE ROW LEVEL SECURITY;

-- Create policies that allow public access (for demo purposes)
CREATE POLICY "Allow public access to job_categories" ON public.job_categories FOR ALL USING (true);
CREATE POLICY "Allow public access to follow_up_questions" ON public.follow_up_questions FOR ALL USING (true);
