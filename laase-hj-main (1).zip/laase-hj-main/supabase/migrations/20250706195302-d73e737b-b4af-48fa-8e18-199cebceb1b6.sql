-- Migrate existing category slugs to translation system
-- First, get the content section ID for category management
DO $$
DECLARE
    section_uuid UUID;
BEGIN
    -- Get the section ID for category management
    SELECT id INTO section_uuid FROM content_sections WHERE section_key = 'category_management';
    
    -- Migrate existing slugs to translation system
    INSERT INTO content_translations (
        section_id,
        content_key,
        content_type,
        content_value,
        language_code,
        market_code
    )
    SELECT 
        section_uuid,
        category_key || '_slug',
        'text',
        slug,
        'en',
        NULL -- Global English version
    FROM blog_categories
    WHERE NOT EXISTS (
        SELECT 1 FROM content_translations ct 
        WHERE ct.content_key = blog_categories.category_key || '_slug'
        AND ct.section_id = section_uuid
    );
END $$;

-- Add unique constraint for slug translations per market to prevent URL conflicts
ALTER TABLE content_translations ADD CONSTRAINT unique_slug_per_market 
UNIQUE (section_id, content_key, market_code, language_code) 
WHERE content_key LIKE '%_slug';

-- Create index for efficient slug lookups
CREATE INDEX idx_content_translations_slug_lookup 
ON content_translations (content_key, market_code, language_code) 
WHERE content_key LIKE '%_slug';