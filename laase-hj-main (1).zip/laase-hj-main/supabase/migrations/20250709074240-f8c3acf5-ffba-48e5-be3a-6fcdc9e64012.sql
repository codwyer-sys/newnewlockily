
-- Create enum for promotion types
CREATE TYPE public.promotion_type AS ENUM ('percentage_on_next_jobs', 'percentage_until_date');

-- Create locksmith referral settings table
CREATE TABLE public.locksmith_referral_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  locksmith_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  default_referral_fee_percentage DECIMAL(5,2) NOT NULL DEFAULT 20.0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(locksmith_id)
);

-- Create locksmith promotions table
CREATE TABLE public.locksmith_promotions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  locksmith_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  promotion_type promotion_type NOT NULL,
  discount_percentage DECIMAL(5,2) NOT NULL,
  jobs_count INTEGER NULL,
  valid_until TIMESTAMP WITH TIME ZONE NULL,
  jobs_used INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Constraints to ensure data integrity
  CONSTRAINT valid_percentage CHECK (discount_percentage >= 0 AND discount_percentage <= 100),
  CONSTRAINT valid_jobs_count CHECK (jobs_count IS NULL OR jobs_count > 0),
  CONSTRAINT valid_promotion_data CHECK (
    (promotion_type = 'percentage_on_next_jobs' AND jobs_count IS NOT NULL AND valid_until IS NULL) OR
    (promotion_type = 'percentage_until_date' AND valid_until IS NOT NULL AND jobs_count IS NULL)
  )
);

-- Create referral fee applications table for tracking
CREATE TABLE public.referral_fee_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  locksmith_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  promotion_id UUID NULL REFERENCES public.locksmith_promotions(id) ON DELETE SET NULL,
  applied_percentage DECIMAL(5,2) NOT NULL,
  original_amount DECIMAL(10,2) NOT NULL,
  fee_amount DECIMAL(10,2) NOT NULL,
  application_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  CONSTRAINT valid_applied_percentage CHECK (applied_percentage >= 0 AND applied_percentage <= 100),
  CONSTRAINT valid_amounts CHECK (original_amount >= 0 AND fee_amount >= 0),
  UNIQUE(booking_id, locksmith_id)
);

-- Add indexes for better performance
CREATE INDEX idx_locksmith_referral_settings_locksmith_id ON public.locksmith_referral_settings(locksmith_id);
CREATE INDEX idx_locksmith_promotions_locksmith_id ON public.locksmith_promotions(locksmith_id);
CREATE INDEX idx_locksmith_promotions_active ON public.locksmith_promotions(locksmith_id, is_active);
CREATE INDEX idx_referral_fee_applications_booking ON public.referral_fee_applications(booking_id);
CREATE INDEX idx_referral_fee_applications_locksmith ON public.referral_fee_applications(locksmith_id);

-- Enable RLS on all new tables
ALTER TABLE public.locksmith_referral_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.locksmith_promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_fee_applications ENABLE ROW LEVEL SECURITY;

-- RLS Policies for locksmith_referral_settings
CREATE POLICY "Admins can manage locksmith referral settings" 
ON public.locksmith_referral_settings 
FOR ALL 
TO authenticated 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Locksmiths can view their own referral settings" 
ON public.locksmith_referral_settings 
FOR SELECT 
TO authenticated 
USING (locksmith_id = auth.uid());

-- RLS Policies for locksmith_promotions
CREATE POLICY "Admins can manage locksmith promotions" 
ON public.locksmith_promotions 
FOR ALL 
TO authenticated 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Locksmiths can view their own promotions" 
ON public.locksmith_promotions 
FOR SELECT 
TO authenticated 
USING (locksmith_id = auth.uid());

-- RLS Policies for referral_fee_applications
CREATE POLICY "Admins can view all referral fee applications" 
ON public.referral_fee_applications 
FOR SELECT 
TO authenticated 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Locksmiths can view their own fee applications" 
ON public.referral_fee_applications 
FOR SELECT 
TO authenticated 
USING (locksmith_id = auth.uid());

CREATE POLICY "System can insert referral fee applications" 
ON public.referral_fee_applications 
FOR INSERT 
TO authenticated 
WITH CHECK (true);

-- Add update trigger for locksmith_referral_settings
CREATE TRIGGER update_locksmith_referral_settings_updated_at
BEFORE UPDATE ON public.locksmith_referral_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add update trigger for locksmith_promotions
CREATE TRIGGER update_locksmith_promotions_updated_at
BEFORE UPDATE ON public.locksmith_promotions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Function to get effective referral fee for a locksmith
CREATE OR REPLACE FUNCTION public.get_effective_referral_fee(locksmith_uuid UUID)
RETURNS DECIMAL(5,2)
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
  effective_fee DECIMAL(5,2);
  active_promotion RECORD;
BEGIN
  -- Check for active promotions first
  SELECT * INTO active_promotion
  FROM public.locksmith_promotions
  WHERE locksmith_id = locksmith_uuid
    AND is_active = true
    AND (
      (promotion_type = 'percentage_until_date' AND valid_until > now()) OR
      (promotion_type = 'percentage_on_next_jobs' AND jobs_used < jobs_count)
    )
  ORDER BY created_at DESC
  LIMIT 1;
  
  -- If we have an active promotion, use its percentage
  IF active_promotion IS NOT NULL THEN
    effective_fee := active_promotion.discount_percentage;
  ELSE
    -- Otherwise, get the default referral fee
    SELECT default_referral_fee_percentage INTO effective_fee
    FROM public.locksmith_referral_settings
    WHERE locksmith_id = locksmith_uuid AND is_active = true;
    
    -- If no settings found, default to 20%
    IF effective_fee IS NULL THEN
      effective_fee := 20.0;
    END IF;
  END IF;
  
  RETURN effective_fee;
END;
$$;

-- Function to auto-create default referral settings for new locksmiths
CREATE OR REPLACE FUNCTION public.create_default_referral_settings()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Only create for locksmith users
  IF EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = NEW.id AND role = 'locksmith'::user_role
  ) THEN
    INSERT INTO public.locksmith_referral_settings (locksmith_id)
    VALUES (NEW.id)
    ON CONFLICT (locksmith_id) DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to auto-create referral settings for new locksmith profiles
CREATE TRIGGER auto_create_referral_settings
AFTER INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.create_default_referral_settings();
