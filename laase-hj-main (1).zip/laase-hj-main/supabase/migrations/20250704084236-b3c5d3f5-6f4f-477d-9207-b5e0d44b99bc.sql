-- Add pricing and exclusions to the auto-bid preferences table
ALTER TABLE public.locksmith_auto_bid_preferences 
ADD COLUMN base_price NUMERIC,
ADD COLUMN excluded_follow_up_answers JSONB DEFAULT '[]'::jsonb;

-- Create table for follow-up question exclusions
CREATE TABLE public.auto_bid_exclusions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL,
  job_category_id UUID NOT NULL,
  follow_up_question_id UUID NOT NULL,
  excluded_answer_values TEXT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(locksmith_id, job_category_id, follow_up_question_id)
);

-- Enable Row Level Security
ALTER TABLE public.auto_bid_exclusions ENABLE ROW LEVEL SECURITY;

-- Create policies for exclusions
CREATE POLICY "Locksmiths can manage their own auto-bid exclusions" 
ON public.auto_bid_exclusions 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_auto_bid_exclusions_updated_at
BEFORE UPDATE ON public.auto_bid_exclusions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();