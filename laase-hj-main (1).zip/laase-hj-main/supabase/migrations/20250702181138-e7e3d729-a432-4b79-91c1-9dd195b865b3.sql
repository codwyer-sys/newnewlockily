-- Allow anonymous bookings by updating RLS policies
DROP POLICY IF EXISTS "Customers can create bookings" ON public.bookings;

-- Create new policy that allows both authenticated and anonymous bookings
CREATE POLICY "Anyone can create bookings" 
ON public.bookings 
FOR INSERT 
WITH CHECK (true);

-- Update the view policy to allow viewing for both authenticated users and by booking ID
DROP POLICY IF EXISTS "Users can view own bookings" ON public.bookings;

CREATE POLICY "Users can view own bookings or by ID" 
ON public.bookings 
FOR SELECT 
USING (
  (auth.uid() = customer_id) OR 
  (auth.uid() = locksmith_id) OR 
  has_role(auth.uid(), 'admin'::user_role) OR
  (customer_id IS NULL)  -- Allow viewing anonymous bookings
);