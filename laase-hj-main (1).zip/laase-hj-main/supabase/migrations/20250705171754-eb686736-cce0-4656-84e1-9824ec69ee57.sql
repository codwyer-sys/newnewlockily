-- Create markets configuration table
CREATE TABLE public.markets (
  country_code VARCHAR(2) PRIMARY KEY,
  country_name VARCHAR(100) NOT NULL,
  currency_code VARCHAR(3) NOT NULL,
  currency_symbol VARCHAR(5) NOT NULL,
  distance_unit VARCHAR(10) NOT NULL DEFAULT 'km',
  business_reg_field VARCHAR(50) NOT NULL,
  business_reg_label VARCHAR(100) NOT NULL,
  emergency_number VARCHAR(20) NOT NULL,
  default_lat DECIMAL(10,8),
  default_lng DECIMAL(11,8),
  address_api_provider VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Insert initial market configurations
INSERT INTO public.markets (country_code, country_name, currency_code, currency_symbol, distance_unit, business_reg_field, business_reg_label, emergency_number, default_lat, default_lng, address_api_provider) VALUES
('DK', 'Denmark', 'DKK', 'kr', 'km', 'cvr_number', 'CVR Nummer', '112', 55.6761, 12.5683, 'dawa'),
('UK', 'United Kingdom', 'GBP', '£', 'miles', 'company_number', 'Company Number', '999', 51.5074, -0.1278, 'royal_mail'),
('US', 'United States', 'USD', '$', 'miles', 'business_license', 'Business License', '911', 39.8283, -98.5795, 'google_places'),
('DE', 'Germany', 'EUR', '€', 'km', 'handelsregister', 'Handelsregister Nr.', '112', 51.1657, 10.4515, 'google_places');

-- Add market field to existing tables
ALTER TABLE public.profiles ADD COLUMN market VARCHAR(2) DEFAULT 'DK' REFERENCES public.markets(country_code);
ALTER TABLE public.bookings ADD COLUMN market VARCHAR(2) DEFAULT 'DK' REFERENCES public.markets(country_code);
ALTER TABLE public.service_areas ADD COLUMN market VARCHAR(2) DEFAULT 'DK' REFERENCES public.markets(country_code);

-- Add market_code to content_translations for market-specific translations
ALTER TABLE public.content_translations ADD COLUMN market_code VARCHAR(2) REFERENCES public.markets(country_code);

-- Enable Row Level Security for markets table
ALTER TABLE public.markets ENABLE ROW LEVEL SECURITY;

-- Allow public read access to markets
CREATE POLICY "Anyone can read market configurations" 
ON public.markets 
FOR SELECT 
USING (true);

-- Only admins can modify markets
CREATE POLICY "Only admins can modify markets" 
ON public.markets 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Create trigger to update updated_at column
CREATE TRIGGER update_markets_updated_at
BEFORE UPDATE ON public.markets
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();