-- Add 'mapbox_native' as a valid source type for city translations
ALTER TABLE public.city_translations 
DROP CONSTRAINT IF EXISTS city_translations_source_check;

ALTER TABLE public.city_translations 
ADD CONSTRAINT city_translations_source_check 
CHECK (source IN ('wikidata', 'manual', 'ai_generated', 'mapbox_native'));

-- Add same constraint to area_translations for consistency
ALTER TABLE public.area_translations 
DROP CONSTRAINT IF EXISTS area_translations_source_check;

ALTER TABLE public.area_translations 
ADD CONSTRAINT area_translations_source_check 
CHECK (source IN ('wikidata', 'manual', 'ai_generated', 'mapbox_native'));