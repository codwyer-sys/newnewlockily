-- Create blog categories table with market support
CREATE TABLE public.blog_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL,
  description TEXT,
  market_code VARCHAR REFERENCES public.markets(country_code),
  parent_id UUID REFERENCES public.blog_categories(id),
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  seo_title TEXT,
  seo_description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(slug, market_code)
);

-- Create blog posts table with full SEO support
CREATE TABLE public.blog_posts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL,
  excerpt TEXT,
  content TEXT NOT NULL,
  featured_image_url TEXT,
  featured_image_alt TEXT,
  author_id UUID REFERENCES public.profiles(id),
  category_id UUID REFERENCES public.blog_categories(id),
  market_code VARCHAR REFERENCES public.markets(country_code),
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  published_at TIMESTAMP WITH TIME ZONE,
  
  -- SEO fields
  seo_title TEXT,
  seo_description TEXT,
  seo_keywords TEXT[],
  canonical_url TEXT,
  og_title TEXT,
  og_description TEXT,
  og_image_url TEXT,
  twitter_title TEXT,
  twitter_description TEXT,
  twitter_image_url TEXT,
  
  -- Schema.org structured data
  schema_type TEXT DEFAULT 'Article',
  schema_data JSONB DEFAULT '{}',
  
  -- Performance tracking
  view_count INTEGER DEFAULT 0,
  last_viewed_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(slug, market_code)
);

-- Create media files table for centralized media management
CREATE TABLE public.media_files (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  filename TEXT NOT NULL,
  original_filename TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  mime_type TEXT NOT NULL,
  width INTEGER,
  height INTEGER,
  alt_text TEXT,
  caption TEXT,
  market_code VARCHAR REFERENCES public.markets(country_code),
  uploaded_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create SEO redirects table for URL management
CREATE TABLE public.seo_redirects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  from_path TEXT NOT NULL,
  to_path TEXT NOT NULL,
  redirect_type INTEGER DEFAULT 301 CHECK (redirect_type IN (301, 302, 307, 308)),
  market_code VARCHAR REFERENCES public.markets(country_code),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(from_path, market_code)
);

-- Create SEO meta tags table for advanced SEO control
CREATE TABLE public.seo_meta_tags (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_path TEXT NOT NULL,
  market_code VARCHAR REFERENCES public.markets(country_code),
  meta_title TEXT,
  meta_description TEXT,
  meta_keywords TEXT[],
  canonical_url TEXT,
  robots_content TEXT DEFAULT 'index,follow',
  og_title TEXT,
  og_description TEXT,
  og_image_url TEXT,
  og_type TEXT DEFAULT 'website',
  twitter_card TEXT DEFAULT 'summary_large_image',
  twitter_title TEXT,
  twitter_description TEXT,
  twitter_image_url TEXT,
  schema_markup JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(page_path, market_code)
);

-- Enable RLS on all new tables
ALTER TABLE public.blog_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seo_redirects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seo_meta_tags ENABLE ROW LEVEL SECURITY;

-- RLS Policies for blog_categories
CREATE POLICY "Anyone can view active blog categories" ON public.blog_categories
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage blog categories" ON public.blog_categories
  FOR ALL USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS Policies for blog_posts
CREATE POLICY "Anyone can view published blog posts" ON public.blog_posts
  FOR SELECT USING (status = 'published');

CREATE POLICY "Admins can manage all blog posts" ON public.blog_posts
  FOR ALL USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Authors can manage their own blog posts" ON public.blog_posts
  FOR ALL USING (author_id = auth.uid());

-- RLS Policies for media_files
CREATE POLICY "Anyone can view media files" ON public.media_files
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage all media files" ON public.media_files
  FOR ALL USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Users can upload media files" ON public.media_files
  FOR INSERT WITH CHECK (uploaded_by = auth.uid());

-- RLS Policies for seo_redirects
CREATE POLICY "Anyone can view active redirects" ON public.seo_redirects
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage redirects" ON public.seo_redirects
  FOR ALL USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS Policies for seo_meta_tags
CREATE POLICY "Anyone can view SEO meta tags" ON public.seo_meta_tags
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage SEO meta tags" ON public.seo_meta_tags
  FOR ALL USING (has_role(auth.uid(), 'admin'::user_role));

-- Create updated_at triggers
CREATE TRIGGER update_blog_categories_updated_at
  BEFORE UPDATE ON public.blog_categories
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at
  BEFORE UPDATE ON public.blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_media_files_updated_at
  BEFORE UPDATE ON public.media_files
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_seo_redirects_updated_at
  BEFORE UPDATE ON public.seo_redirects
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_seo_meta_tags_updated_at
  BEFORE UPDATE ON public.seo_meta_tags
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for performance
CREATE INDEX idx_blog_categories_market_active ON public.blog_categories(market_code, is_active);
CREATE INDEX idx_blog_categories_parent ON public.blog_categories(parent_id);
CREATE INDEX idx_blog_posts_market_status ON public.blog_posts(market_code, status);
CREATE INDEX idx_blog_posts_category ON public.blog_posts(category_id);
CREATE INDEX idx_blog_posts_author ON public.blog_posts(author_id);
CREATE INDEX idx_blog_posts_published ON public.blog_posts(published_at DESC) WHERE status = 'published';
CREATE INDEX idx_media_files_market ON public.media_files(market_code);
CREATE INDEX idx_seo_redirects_from_path ON public.seo_redirects(from_path, market_code) WHERE is_active = true;
CREATE INDEX idx_seo_meta_tags_path ON public.seo_meta_tags(page_path, market_code);

-- Create storage bucket for blog media
INSERT INTO storage.buckets (id, name, public) VALUES ('blog-media', 'blog-media', true);

-- Create storage policies for blog media
CREATE POLICY "Blog media is publicly accessible" ON storage.objects
  FOR SELECT USING (bucket_id = 'blog-media');

CREATE POLICY "Authenticated users can upload blog media" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'blog-media' AND auth.role() = 'authenticated');

CREATE POLICY "Users can update their own blog media" ON storage.objects
  FOR UPDATE USING (bucket_id = 'blog-media' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Admins can delete blog media" ON storage.objects
  FOR DELETE USING (bucket_id = 'blog-media' AND has_role(auth.uid(), 'admin'::user_role));