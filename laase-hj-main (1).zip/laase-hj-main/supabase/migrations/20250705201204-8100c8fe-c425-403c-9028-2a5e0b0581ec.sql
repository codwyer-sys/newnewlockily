-- Delete the manually created admin user Christian ODwyer
DELETE FROM auth.users WHERE email = 'christian@lockily.eu';