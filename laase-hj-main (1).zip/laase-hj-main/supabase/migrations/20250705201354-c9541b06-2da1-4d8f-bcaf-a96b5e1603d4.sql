-- Update Christian ODwyer to admin role
UPDATE user_roles 
SET role = 'admin' 
WHERE user_id = '52ab8f3f-53e1-4e49-a1ed-179b22ac1c3c';

-- Create admin profile for Christian ODwyer
INSERT INTO admin_profiles (id, department, access_level) 
VALUES ('52ab8f3f-53e1-4e49-a1ed-179b22ac1c3c', 'general', 'standard');