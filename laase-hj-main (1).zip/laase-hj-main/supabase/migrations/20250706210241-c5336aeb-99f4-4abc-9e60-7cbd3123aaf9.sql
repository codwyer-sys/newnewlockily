-- Add blog menu item to navigation
INSERT INTO public.menu_items (menu_key, menu_name, is_visible, display_order, href) 
VALUES ('blog', 'Blog', true, 1, '/blog')
ON CONFLICT (menu_key) DO UPDATE SET
  menu_name = EXCLUDED.menu_name,
  href = EXCLUDED.href,
  is_visible = EXCLUDED.is_visible,
  display_order = EXCLUDED.display_order;