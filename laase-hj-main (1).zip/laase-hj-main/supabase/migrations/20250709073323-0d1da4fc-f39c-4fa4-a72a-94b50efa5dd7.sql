-- Add job_number column to bookings table
ALTER TABLE public.bookings ADD COLUMN job_number INTEGER;

-- Create sequence starting at 21432
CREATE SEQUENCE public.job_number_seq START 21432;

-- Create function to auto-assign job numbers
CREATE OR REPLACE FUNCTION public.assign_job_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.job_number IS NULL THEN
    NEW.job_number := nextval('job_number_seq');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to auto-assign job numbers on insert
CREATE TRIGGER auto_assign_job_number
  BEFORE INSERT ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.assign_job_number();

-- Backfill existing records with job numbers using a subquery
WITH numbered_bookings AS (
  SELECT id, 21431 + row_number() OVER (ORDER BY created_at) as new_job_number
  FROM public.bookings 
  WHERE job_number IS NULL
)
UPDATE public.bookings 
SET job_number = numbered_bookings.new_job_number
FROM numbered_bookings
WHERE public.bookings.id = numbered_bookings.id;

-- Add unique constraint to ensure job numbers are unique
ALTER TABLE public.bookings ADD CONSTRAINT unique_job_number UNIQUE (job_number);