-- Create AI translation settings table
CREATE TABLE public.ai_translation_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  prompt_template TEXT NOT NULL DEFAULT 'You are translating text for {{BUSINESS_CONTEXT}}.

TRANSLATION CONTEXT:
- Source Language: English  
- Target Language: {{TARGET_LANGUAGE}}
- Target Market: {{MARKET_NAME}} ({{MARKET_CODE}})
- UI Element: {{ELEMENT_TYPE}}
- Location: {{LOCATION}}
- Original Text: "{{ORIGINAL_TEXT}}"

{{#if CUSTOM_INSTRUCTION}}
CUSTOM INSTRUCTIONS:
{{CUSTOM_INSTRUCTION}}
{{/if}}

GUIDELINES:
- Use appropriate {{CURRENCY}} currency references
- Consider {{MARKET_NAME}} cultural context
- Match tone for {{ELEMENT_TYPE}} elements
- Provide ONLY the translation, no explanations

Translation:',
  system_message TEXT NOT NULL DEFAULT 'You are a professional translator specializing in user interface text for service platforms. Provide accurate, contextually appropriate translations.',
  temperature DECIMAL(2,1) NOT NULL DEFAULT 0.3,
  max_tokens INTEGER NOT NULL DEFAULT 200,
  model TEXT NOT NULL DEFAULT 'gpt-4o',
  business_context TEXT NOT NULL DEFAULT 'Lockily, a professional locksmith service platform that connects customers with trusted, verified locksmiths for emergency and scheduled services',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.ai_translation_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can manage AI translation settings" 
ON public.ai_translation_settings 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view AI translation settings" 
ON public.ai_translation_settings 
FOR SELECT 
USING (true);

-- Create language mappings table
CREATE TABLE public.language_mappings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  language_code TEXT NOT NULL,
  language_name TEXT NOT NULL,
  market_code TEXT REFERENCES public.markets(country_code),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(language_code, market_code)
);

-- Enable RLS
ALTER TABLE public.language_mappings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can manage language mappings" 
ON public.language_mappings 
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view language mappings" 
ON public.language_mappings 
FOR SELECT 
USING (true);

-- Insert default language mappings
INSERT INTO public.language_mappings (language_code, language_name, market_code) VALUES
('en', 'English', 'DK'),
('da', 'Danish', 'DK'),
('en', 'English', 'DE'),
('de', 'German', 'DE'),
('en', 'English', 'UK'),
('en', 'English', 'US');

-- Insert default AI translation settings
INSERT INTO public.ai_translation_settings (id) VALUES (gen_random_uuid());

-- Create update trigger
CREATE TRIGGER update_ai_translation_settings_updated_at
  BEFORE UPDATE ON public.ai_translation_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();