
-- Create enum for user roles
CREATE TYPE public.user_role AS ENUM ('customer', 'locksmith', 'admin');

-- Create locksmith profiles table
CREATE TABLE public.locksmith_profiles (
  id UUID REFERENCES auth.users NOT NULL PRIMARY KEY,
  cvr_number TEXT UNIQUE NOT NULL,
  company_name TEXT NOT NULL,
  address TEXT NOT NULL,
  postal_code TEXT NOT NULL,
  city TEXT NOT NULL,
  phone TEXT,
  contact_person TEXT NOT NULL,
  email TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'suspended')),
  specializations TEXT[],
  description TEXT,
  website TEXT,
  emergency_available BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create service areas table
CREATE TABLE public.service_areas (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID REFERENCES public.locksmith_profiles(id) ON DELETE CASCADE,
  postal_codes TEXT[],
  max_distance_km INTEGER DEFAULT 25,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create pricing configurations table
CREATE TABLE public.pricing_configs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID REFERENCES public.locksmith_profiles(id) ON DELETE CASCADE,
  job_category_id UUID REFERENCES public.job_categories(id),
  base_price DECIMAL(10,2),
  emergency_surcharge DECIMAL(10,2) DEFAULT 0,
  evening_surcharge DECIMAL(10,2) DEFAULT 0,
  weekend_surcharge DECIMAL(10,2) DEFAULT 0,
  travel_fee_per_km DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create bookings table
CREATE TABLE public.bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID REFERENCES auth.users(id),
  locksmith_id UUID REFERENCES public.locksmith_profiles(id),
  address TEXT NOT NULL,
  urgency TEXT NOT NULL,
  scheduled_date TIMESTAMPTZ,
  job_type TEXT NOT NULL,
  follow_up_answers JSONB,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'assigned', 'accepted', 'in_progress', 'completed', 'cancelled')),
  estimated_price DECIMAL(10,2),
  final_price DECIMAL(10,2),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create reviews table
CREATE TABLE public.reviews (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID REFERENCES public.bookings(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES auth.users(id),
  locksmith_id UUID REFERENCES public.locksmith_profiles(id),
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create user roles table
CREATE TABLE public.user_roles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  role user_role NOT NULL,
  UNIQUE(user_id, role)
);

-- Enable Row Level Security
ALTER TABLE public.locksmith_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.service_areas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pricing_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check user roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role user_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- RLS Policies for locksmith_profiles
CREATE POLICY "Locksmiths can view and update own profile"
ON public.locksmith_profiles FOR ALL
USING (auth.uid() = id);

CREATE POLICY "Customers can view approved locksmiths"
ON public.locksmith_profiles FOR SELECT
USING (status = 'approved');

CREATE POLICY "Admins can manage all locksmith profiles"
ON public.locksmith_profiles FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for service_areas
CREATE POLICY "Locksmiths can manage own service areas"
ON public.service_areas FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.locksmith_profiles 
    WHERE id = locksmith_id AND id = auth.uid()
  )
);

CREATE POLICY "Public can view service areas"
ON public.service_areas FOR SELECT
TO public;

-- RLS Policies for pricing_configs
CREATE POLICY "Locksmiths can manage own pricing"
ON public.pricing_configs FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.locksmith_profiles 
    WHERE id = locksmith_id AND id = auth.uid()
  )
);

CREATE POLICY "Public can view pricing configs"
ON public.pricing_configs FOR SELECT
TO public;

-- RLS Policies for bookings
CREATE POLICY "Users can view own bookings"
ON public.bookings FOR SELECT
USING (
  auth.uid() = customer_id OR 
  auth.uid() = locksmith_id OR
  public.has_role(auth.uid(), 'admin')
);

CREATE POLICY "Customers can create bookings"
ON public.bookings FOR INSERT
WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Locksmiths can update assigned bookings"
ON public.bookings FOR UPDATE
USING (auth.uid() = locksmith_id OR public.has_role(auth.uid(), 'admin'));

-- RLS Policies for reviews
CREATE POLICY "Users can view all reviews"
ON public.reviews FOR SELECT
TO public;

CREATE POLICY "Customers can create reviews for their bookings"
ON public.reviews FOR INSERT
WITH CHECK (
  auth.uid() = customer_id AND
  EXISTS (
    SELECT 1 FROM public.bookings 
    WHERE id = booking_id AND customer_id = auth.uid() AND status = 'completed'
  )
);

-- RLS Policies for user_roles
CREATE POLICY "Users can view own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles"
ON public.user_roles FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert default customer role for new users
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'customer');
  
  RETURN NEW;
END;
$$;

-- Trigger for new user registration
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create indexes for better performance
CREATE INDEX idx_locksmith_profiles_status ON public.locksmith_profiles(status);
CREATE INDEX idx_locksmith_profiles_cvr ON public.locksmith_profiles(cvr_number);
CREATE INDEX idx_bookings_customer ON public.bookings(customer_id);
CREATE INDEX idx_bookings_locksmith ON public.bookings(locksmith_id);
CREATE INDEX idx_bookings_status ON public.bookings(status);
CREATE INDEX idx_reviews_locksmith ON public.reviews(locksmith_id);
CREATE INDEX idx_service_areas_locksmith ON public.service_areas(locksmith_id);
