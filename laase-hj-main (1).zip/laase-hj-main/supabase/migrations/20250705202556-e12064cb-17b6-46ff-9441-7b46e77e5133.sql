-- Update all existing locksmith users to have Danish market
UPDATE profiles 
SET market = 'DK' 
WHERE id IN (
  SELECT user_id FROM user_roles WHERE role = 'locksmith'
);