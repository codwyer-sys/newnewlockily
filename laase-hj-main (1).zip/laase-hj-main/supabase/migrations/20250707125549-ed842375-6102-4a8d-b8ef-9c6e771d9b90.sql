-- Enable the net extension for HTTP requests
CREATE EXTENSION IF NOT EXISTS "http" WITH SCHEMA "extensions";

-- Enable pg_net extension for async HTTP requests
CREATE EXTENSION IF NOT EXISTS "pg_net" WITH SCHEMA "extensions";

-- Update the city webhook function to use the correct schema
CREATE OR REPLACE FUNCTION public.notify_city_created()
RETURNS TRIGGER AS $$
BEGIN
  -- Call the edge function in background using pg_net
  PERFORM
    net.http_post(
      url := 'https://otuv49mp.rpcld.co/webhook-test/2e60a3f2-b037-4537-a686-6ff82cf7cf79',
      headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5c21wa2lubGdwcW93bWx3dHRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEyMTk2NjMsImV4cCI6MjA2Njc5NTY2M30.qkUY2UXZp5mJp-fRwHWP_-b8kz3hvE2EUkU4kKL6sbk"}'::jsonb,
      body := json_build_object(
        'cityId', NEW.id,
        'event', 'city_created',
        'timestamp', now(),
        'marketCode', NEW.market_code
      )::jsonb
    );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;