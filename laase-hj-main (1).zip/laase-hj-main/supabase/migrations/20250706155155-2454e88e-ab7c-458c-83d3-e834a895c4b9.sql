-- Add missing translation keys for BidDialog interface
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- BidDialog interface elements
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'notes', 'Notes (optional)', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'interface' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'notes_placeholder', 'Add any notes to your bid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'sending_bid', 'Sending bid...', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'actions' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'job_cards')), 'en', 'send_bid', 'Send Bid', 'text');