-- Create content management tables for translations
CREATE TABLE public.content_pages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_key TEXT NOT NULL UNIQUE,
  page_name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE TABLE public.content_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  page_id UUID NOT NULL REFERENCES public.content_pages(id) ON DELETE CASCADE,
  section_key TEXT NOT NULL,
  section_name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(page_id, section_key)
);

CREATE TABLE public.content_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  section_id UUID NOT NULL REFERENCES public.content_sections(id) ON DELETE CASCADE,
  language_code TEXT NOT NULL CHECK (language_code IN ('da', 'en')),
  content_key TEXT NOT NULL,
  content_value TEXT NOT NULL,
  content_type TEXT NOT NULL DEFAULT 'text' CHECK (content_type IN ('text', 'html', 'markdown')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(section_id, language_code, content_key)
);

-- Enable RLS
ALTER TABLE public.content_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.content_translations ENABLE ROW LEVEL SECURITY;

-- Create policies for content management
-- Public can read all content
CREATE POLICY "Anyone can view content pages" ON public.content_pages FOR SELECT USING (true);
CREATE POLICY "Anyone can view content sections" ON public.content_sections FOR SELECT USING (true);
CREATE POLICY "Anyone can view content translations" ON public.content_translations FOR SELECT USING (true);

-- Only admins can manage content
CREATE POLICY "Admins can manage content pages" ON public.content_pages FOR ALL USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage content sections" ON public.content_sections FOR ALL USING (has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can manage content translations" ON public.content_translations FOR ALL USING (has_role(auth.uid(), 'admin'));

-- Create update timestamp trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for automatic timestamp updates
CREATE TRIGGER update_content_pages_updated_at BEFORE UPDATE ON public.content_pages FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_content_sections_updated_at BEFORE UPDATE ON public.content_sections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_content_translations_updated_at BEFORE UPDATE ON public.content_translations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert initial pages and content
INSERT INTO public.content_pages (page_key, page_name, description) VALUES
('home', 'Home Page', 'Main landing page content'),
('header', 'Header Navigation', 'Header and navigation content'),
('footer', 'Footer', 'Footer content');

-- Insert sections for home page
INSERT INTO public.content_sections (page_id, section_key, section_name, description) VALUES
((SELECT id FROM public.content_pages WHERE page_key = 'home'), 'hero', 'Hero Section', 'Main hero section content'),
((SELECT id FROM public.content_pages WHERE page_key = 'home'), 'services', 'Services Section', 'Services explanation content'),
((SELECT id FROM public.content_pages WHERE page_key = 'home'), 'trust', 'Trust Badges', 'Trust and credibility content'),
((SELECT id FROM public.content_pages WHERE page_key = 'home'), 'booking', 'Booking Form', 'Booking form related content');

-- Insert sections for header
INSERT INTO public.content_sections (page_id, section_key, section_name, description) VALUES
((SELECT id FROM public.content_pages WHERE page_key = 'header'), 'navigation', 'Navigation Menu', 'Navigation menu items'),
((SELECT id FROM public.content_pages WHERE page_key = 'header'), 'cta', 'Call to Action', 'Header CTA buttons');

-- Insert Danish translations
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value) VALUES
-- Header Navigation
((SELECT id FROM public.content_sections WHERE section_key = 'navigation'), 'da', 'services', 'Tjenester'),
((SELECT id FROM public.content_sections WHERE section_key = 'navigation'), 'da', 'how_it_works', 'Sådan fungerer det'),
((SELECT id FROM public.content_sections WHERE section_key = 'navigation'), 'da', 'security', 'Sikkerhed'),
((SELECT id FROM public.content_sections WHERE section_key = 'cta'), 'da', 'call_now', 'Ring nu'),
((SELECT id FROM public.content_sections WHERE section_key = 'cta'), 'da', 'book_now', 'Book nu'),

-- Hero Section
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'da', 'title', 'Professionel låseservice når du har brug for det'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'da', 'subtitle', 'Certificerede låsesmede i hele Danmark'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'da', 'address_label', 'Hvor har du brug for hjælp?'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'da', 'address_placeholder', 'Indtast din adresse...'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'da', 'use_location', 'Brug min lokation'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'da', 'getting_location', 'Henter lokation...'),

-- Services Section
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'title', 'Få tilbud på sekunder fra alle tilgængelige låsesmede'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'subtitle', 'Vi samler alle ledige låsesmede i dit område og giver dig øjeblikkelig adgang til de bedste priser og hurtigste ankomsttider.'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'instant_title', 'Øjeblikkelige tilbud'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'instant_desc', 'Få priser fra alle tilgængelige låsesmede på under 20 sekunder'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'price_title', 'Garanteret bedste pris'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'price_desc', 'Sammenlign priser og vælg det tilbud der passer dig bedst'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'speed_title', 'Hurtig ankomst'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'da', 'speed_desc', 'Se præcis hvornår hver låsesmed kan være hos dig'),

-- Trust Badges
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'da', 'title', 'Hvorfor vælge LåseHjælp?'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'da', 'response_time', 'Svar inden 20 sekunder'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'da', 'fixed_price', 'Fast pris – ingen overraskelser'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'da', 'quick_arrival', 'Hurtig ankomst'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'da', 'emergency', '24/7 akut hjælp'),

-- Booking Form
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'urgency_title', 'Hvornår har du brug for hjælp?'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'urgency_now', 'Nu'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'urgency_now_desc', 'Ledige låsesmede i området'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'urgency_later', 'Senere'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'urgency_later_desc', 'Book til senere'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'job_type_title', 'Vælg problem'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'follow_up_title', 'Detaljer om problemet'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'find_locksmith', 'Find låsesmed nu'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'find_locksmith_fast', 'Find låsesmed nu – få tilbud på under 20 sekunder!'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'da', 'finding', 'Finder låsesmed...');

-- Insert English translations
INSERT INTO public.content_translations (section_id, language_code, content_key, content_value) VALUES
-- Header Navigation
((SELECT id FROM public.content_sections WHERE section_key = 'navigation'), 'en', 'services', 'Services'),
((SELECT id FROM public.content_sections WHERE section_key = 'navigation'), 'en', 'how_it_works', 'How it works'),
((SELECT id FROM public.content_sections WHERE section_key = 'navigation'), 'en', 'security', 'Security'),
((SELECT id FROM public.content_sections WHERE section_key = 'cta'), 'en', 'call_now', 'Call now'),
((SELECT id FROM public.content_sections WHERE section_key = 'cta'), 'en', 'book_now', 'Book now'),

-- Hero Section
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'en', 'title', 'Professional locksmith service when you need it'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'en', 'subtitle', 'Certified locksmiths throughout Denmark'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'en', 'address_label', 'Where do you need help?'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'en', 'address_placeholder', 'Enter your address...'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'en', 'use_location', 'Use my location'),
((SELECT id FROM public.content_sections WHERE section_key = 'hero'), 'en', 'getting_location', 'Getting location...'),

-- Services Section
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'title', 'Get quotes in seconds from all available locksmiths'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'subtitle', 'We gather all available locksmiths in your area and give you instant access to the best prices and fastest arrival times.'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'instant_title', 'Instant quotes'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'instant_desc', 'Get prices from all available locksmiths in under 20 seconds'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'price_title', 'Guaranteed best price'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'price_desc', 'Compare prices and choose the offer that suits you best'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'speed_title', 'Quick arrival'),
((SELECT id FROM public.content_sections WHERE section_key = 'services'), 'en', 'speed_desc', 'See exactly when each locksmith can be with you'),

-- Trust Badges
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'en', 'title', 'Why choose LockHelp?'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'en', 'response_time', 'Response within 20 seconds'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'en', 'fixed_price', 'Fixed price – no surprises'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'en', 'quick_arrival', 'Quick arrival'),
((SELECT id FROM public.content_sections WHERE section_key = 'trust'), 'en', 'emergency', '24/7 emergency help'),

-- Booking Form
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'urgency_title', 'When do you need help?'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'urgency_now', 'Now'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'urgency_now_desc', 'Available locksmiths in the area'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'urgency_later', 'Later'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'urgency_later_desc', 'Book for later'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'job_type_title', 'Select problem'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'follow_up_title', 'Problem details'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'find_locksmith', 'Find locksmith now'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'find_locksmith_fast', 'Find locksmith now – get quotes in under 20 seconds!'),
((SELECT id FROM public.content_sections WHERE section_key = 'booking'), 'en', 'finding', 'Finding locksmith...');