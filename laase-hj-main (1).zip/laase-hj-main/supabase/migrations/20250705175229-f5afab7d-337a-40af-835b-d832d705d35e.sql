-- Address provider configurations
CREATE TABLE address_provider_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_code TEXT REFERENCES markets(country_code),
  provider_name TEXT NOT NULL,
  is_primary BOOLEAN DEFAULT false,
  is_enabled BOOLEAN DEFAULT true,
  priority INTEGER DEFAULT 0,
  config_data JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Address validation rules per market
CREATE TABLE address_validation_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  market_code TEXT REFERENCES markets(country_code),
  input_type TEXT NOT NULL, -- 'postcode', 'full_address', 'both'
  validation_regex TEXT,
  min_length INTEGER DEFAULT 3,
  placeholder_text TEXT,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE address_provider_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE address_validation_rules ENABLE ROW LEVEL SECURITY;

-- RLS policies for address_provider_configs
CREATE POLICY "Anyone can read address provider configs" 
ON address_provider_configs FOR SELECT 
USING (true);

CREATE POLICY "Only admins can modify address provider configs" 
ON address_provider_configs FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- RLS policies for address_validation_rules
CREATE POLICY "Anyone can read address validation rules" 
ON address_validation_rules FOR SELECT 
USING (true);

CREATE POLICY "Only admins can modify address validation rules" 
ON address_validation_rules FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role));

-- Insert default configurations for existing markets
INSERT INTO address_provider_configs (market_code, provider_name, is_primary, is_enabled, priority) VALUES
('DK', 'dawa', true, true, 100),
('UK', 'uk-postcode-lookup', true, true, 100),
('US', 'google-places', true, true, 100),
('DE', 'google-places', true, true, 100);

-- Insert default validation rules
INSERT INTO address_validation_rules (market_code, input_type, validation_regex, min_length, placeholder_text, error_message) VALUES
('DK', 'full_address', null, 3, 'Hvor skal du bruge en låsesmed?', 'Indtast venligst en gyldig adresse'),
('UK', 'postcode', '^[A-Z]{1,2}[0-9][A-Z0-9]?\s?[0-9][A-Z]{2}$', 4, 'Enter your postcode (e.g., SW1A 1AA)', 'Please enter a valid UK postcode'),
('US', 'full_address', null, 3, 'Enter your address', 'Please enter a valid address'),
('DE', 'full_address', null, 3, 'Geben Sie Ihre Adresse ein', 'Bitte geben Sie eine gültige Adresse ein');

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_address_provider_configs_updated_at
    BEFORE UPDATE ON address_provider_configs
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_address_validation_rules_updated_at
    BEFORE UPDATE ON address_validation_rules
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();