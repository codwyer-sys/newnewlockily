-- Create new pages for untranslated components
INSERT INTO content_pages (page_key, page_name, description) VALUES 
('locksmith_portal', 'Locksmith Portal', 'All locksmith portal interface text'),
('testimonials', 'Testimonials Section', 'Customer testimonials and reviews'),
('job_cards', 'Job Cards Interface', 'Job card displays and interactions'),
('settings', 'Settings Pages', 'Various settings and configuration pages');

-- Create sections for locksmith portal
INSERT INTO content_sections (page_id, section_key, section_name, description) VALUES
-- Locksmith Portal sections
((SELECT id FROM content_pages WHERE page_key = 'locksmith_portal'), 'sidebar', 'Sidebar Navigation', 'Main navigation menu items'),
((SELECT id FROM content_pages WHERE page_key = 'locksmith_portal'), 'dashboard', 'Dashboard Main', 'Main dashboard content and headings'),
((SELECT id FROM content_pages WHERE page_key = 'locksmith_portal'), 'status', 'Status Controls', 'Status indicators and controls'),

-- Testimonials sections  
((SELECT id FROM content_pages WHERE page_key = 'testimonials'), 'header', 'Section Header', 'Testimonials section header and title'),
((SELECT id FROM content_pages WHERE page_key = 'testimonials'), 'content', 'Testimonial Content', 'Individual testimonial content'),

-- Job Cards sections
((SELECT id FROM content_pages WHERE page_key = 'job_cards'), 'interface', 'Job Card Interface', 'Job card labels and interface elements'),
((SELECT id FROM content_pages WHERE page_key = 'job_cards'), 'actions', 'Job Actions', 'Job action buttons and controls'),

-- Settings sections
((SELECT id FROM content_pages WHERE page_key = 'settings'), 'labels', 'Form Labels', 'Form field labels and descriptions'),
((SELECT id FROM content_pages WHERE page_key = 'settings'), 'messages', 'System Messages', 'Success, error, and info messages');

-- Create English content entries for TestimonialsSection
INSERT INTO content_translations (section_id, language_code, content_key, content_value, content_type) VALUES
-- Testimonials header
((SELECT id FROM content_sections WHERE section_key = 'header' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'badge_text', 'Reviews', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'header' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'main_title', 'What our customers say', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'header' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'subtitle', 'See what our satisfied customers say about our locksmith service.', 'text'),

-- Testimonials content (converting Danish to English)
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_1_text', 'Fantastic service! The locksmith came within 20 minutes and solved my problem quickly and professionally.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_1_name', 'Maria Hansen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_1_role', 'Private Customer', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_2_text', 'Used the platform when I was locked out at 11 PM. Got quick contact with a 24-hour locksmith. Really good system!', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_2_name', 'Lars Andersen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_2_role', 'Private Customer', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_3_text', 'As a property administrator, I use this service often. Reliable craftsmen and fair prices.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_3_name', 'Anne Kristensen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_3_role', 'Property Administrator', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_4_text', 'Quick and easy booking. The locksmith was very friendly and explained everything he did. Highly recommended!', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_4_name', 'Michael Nielsen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_4_role', 'Business Owner', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_5_text', 'Needed urgent help on a Sunday morning. Got help in under 30 minutes at a reasonable price.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_5_name', 'Sofie Larsen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_5_role', 'Private Customer', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_6_text', 'Professional service from start to finish. Transparent pricing and quality work.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_6_name', 'Karen Møller', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_6_role', 'Retiree', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_7_text', 'Use the platform for our retail chain. Easy to find qualified locksmiths across the country.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_7_name', 'Thomas Pedersen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_7_role', 'Chain Director', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_8_text', 'Excellent customer service and quick response time. They found the right locksmith for my special lock.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_8_name', 'Camilla Jensen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_8_role', 'Private Customer', 'text'),

((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_9_text', 'As a locksmith, I am very satisfied with the platform. Get lots of qualified customers through the system.', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_9_name', 'Peter Olsen', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'content' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'testimonials')), 'en', 'testimonial_9_role', 'Locksmith', 'text'),

-- Create English content entries for LocksmithSidebar
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'dashboard', 'Dashboard', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'my_jobs', 'My Jobs', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'customers', 'Customers', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'auto_bid', 'AutoBid', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'service_areas', 'Service Areas', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'payments', 'Payments', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'settings', 'Settings', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'sidebar' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'account', 'Account', 'text'),

-- Create English content entries for LocksmithPortal status control
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'online', 'Online', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'offline', 'Offline', 'text'),
((SELECT id FROM content_sections WHERE section_key = 'status' AND page_id = (SELECT id FROM content_pages WHERE page_key = 'locksmith_portal')), 'en', 'busy', 'Busy', 'text');