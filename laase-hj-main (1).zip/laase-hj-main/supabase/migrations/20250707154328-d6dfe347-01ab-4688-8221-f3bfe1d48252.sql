-- Remove the global timing question "Hvornår på dagen passer det bedst?"
DELETE FROM follow_up_questions 
WHERE question_key = 'preferredTime' 
AND question = 'Hvornår på dagen passer det bedst?';