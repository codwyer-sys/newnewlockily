-- First, let's see what job_type values we have in bookings
-- and map them to proper job_category IDs

-- Add a new column for the foreign key relationship
ALTER TABLE public.bookings ADD COLUMN job_category_id UUID;

-- Update existing bookings to use proper job_category IDs based on job_type names
UPDATE public.bookings 
SET job_category_id = (
  SELECT jc.id 
  FROM public.job_categories jc 
  WHERE jc.name = public.bookings.job_type
)
WHERE job_category_id IS NULL;

-- For any remaining null values, try to match with a default category or create one
-- Let's handle the most common case first - "Låst ude" (locked out)
DO $$
BEGIN
  -- Insert a default category if it doesn't exist
  INSERT INTO public.job_categories (name, emoji, description)
  VALUES ('Låst ude', '🔐', 'Låst ude af hjem eller bil')
  ON CONFLICT (name) DO NOTHING;
  
  -- Update any remaining null job_category_id values
  UPDATE public.bookings 
  SET job_category_id = (
    SELECT id FROM public.job_categories WHERE name = 'Låst ude' LIMIT 1
  )
  WHERE job_category_id IS NULL;
END $$;

-- Now make the column NOT NULL since all bookings should have a category
ALTER TABLE public.bookings ALTER COLUMN job_category_id SET NOT NULL;

-- Add the foreign key constraint
ALTER TABLE public.bookings 
ADD CONSTRAINT fk_bookings_job_category 
FOREIGN KEY (job_category_id) REFERENCES public.job_categories(id);

-- Create an index for better query performance
CREATE INDEX idx_bookings_job_category_id ON public.bookings(job_category_id);

-- We can keep the old job_type column for now for backwards compatibility
-- but mark it as deprecated by adding a comment
COMMENT ON COLUMN public.bookings.job_type IS 'DEPRECATED: Use job_category_id instead. Will be removed in future version.';