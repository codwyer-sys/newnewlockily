-- Create unique index to handle NULL market_code values
CREATE UNIQUE INDEX content_translations_unique_idx 
ON content_translations (section_id, language_code, content_key, COALESCE(market_code, ''));

-- Function to sync job categories to content_translations
CREATE OR REPLACE FUNCTION sync_job_categories_to_content()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  category_record record;
  category_mgmt_section_id uuid := 'f964e2be-1f80-4691-84de-b38836702bf4'; -- Category Management
  category_trans_section_id uuid := '59dd53f4-c254-4e4f-9d49-4a318f0d24a7'; -- Category Translations
  category_key text;
BEGIN
  -- Sync job category names and descriptions to content_translations
  FOR category_record IN 
    SELECT id, name, description 
    FROM job_categories
  LOOP
    category_key := replace(lower(category_record.name), ' ', '_');
    
    -- Insert English name (handle potential conflicts by using INSERT...ON CONFLICT with a different approach)
    BEGIN
      INSERT INTO content_translations (
        section_id,
        language_code,
        content_key,
        content_value,
        content_type,
        market_code
      )
      VALUES (
        category_mgmt_section_id,
        'en',
        'job_category_name_' || category_key,
        category_record.name,
        'text',
        null
      );
    EXCEPTION WHEN unique_violation THEN
      UPDATE content_translations 
      SET content_value = category_record.name, updated_at = now()
      WHERE section_id = category_mgmt_section_id
        AND language_code = 'en'
        AND content_key = 'job_category_name_' || category_key
        AND market_code IS NULL;
    END;

    -- Insert English description
    BEGIN
      INSERT INTO content_translations (
        section_id,
        language_code,
        content_key,
        content_value,
        content_type,
        market_code
      )
      VALUES (
        category_trans_section_id,
        'en',
        'job_category_desc_' || category_key,
        category_record.description,
        'text',
        null
      );
    EXCEPTION WHEN unique_violation THEN
      UPDATE content_translations 
      SET content_value = category_record.description, updated_at = now()
      WHERE section_id = category_trans_section_id
        AND language_code = 'en'
        AND content_key = 'job_category_desc_' || category_key
        AND market_code IS NULL;
    END;

    -- Sync existing translations from job_category_translations
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      category_mgmt_section_id,
      jct.language_code,
      'job_category_name_' || category_key,
      jct.name,
      'text',
      jct.market_code
    FROM job_category_translations jct
    WHERE jct.job_category_id = category_record.id
    ON CONFLICT DO NOTHING;

    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      category_trans_section_id,
      jct.language_code,
      'job_category_desc_' || category_key,
      jct.description,
      'text',
      jct.market_code
    FROM job_category_translations jct
    WHERE jct.job_category_id = category_record.id
    ON CONFLICT DO NOTHING;
  END LOOP;
END;
$$;

-- Function to sync follow-up questions to content_translations
CREATE OR REPLACE FUNCTION sync_follow_up_questions_to_content()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  question_record record;
  question_mgmt_section_id uuid := '153da537-489b-4972-a999-a132e6d40c2a'; -- Question Management
  question_trans_section_id uuid := 'fd8a266b-4103-4419-b21a-16eb9dbb57ae'; -- Question Translations
BEGIN
  -- Sync follow-up questions to content_translations
  FOR question_record IN 
    SELECT id, question, question_key, options
    FROM follow_up_questions
  LOOP
    -- Insert English question
    BEGIN
      INSERT INTO content_translations (
        section_id,
        language_code,
        content_key,
        content_value,
        content_type,
        market_code
      )
      VALUES (
        question_mgmt_section_id,
        'en',
        'question_text_' || question_record.question_key,
        question_record.question,
        'text',
        null
      );
    EXCEPTION WHEN unique_violation THEN
      UPDATE content_translations 
      SET content_value = question_record.question, updated_at = now()
      WHERE section_id = question_mgmt_section_id
        AND language_code = 'en'
        AND content_key = 'question_text_' || question_record.question_key
        AND market_code IS NULL;
    END;

    -- Insert English options if they exist
    IF question_record.options IS NOT NULL THEN
      BEGIN
        INSERT INTO content_translations (
          section_id,
          language_code,
          content_key,
          content_value,
          content_type,
          market_code
        )
        VALUES (
          question_trans_section_id,
          'en',
          'question_options_' || question_record.question_key,
          array_to_string(ARRAY(SELECT jsonb_array_elements_text(question_record.options)), ', '),
          'text',
          null
        );
      EXCEPTION WHEN unique_violation THEN
        UPDATE content_translations 
        SET content_value = array_to_string(ARRAY(SELECT jsonb_array_elements_text(question_record.options)), ', '), 
            updated_at = now()
        WHERE section_id = question_trans_section_id
          AND language_code = 'en'
          AND content_key = 'question_options_' || question_record.question_key
          AND market_code IS NULL;
      END;
    END IF;

    -- Sync existing translations from follow_up_question_translations
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      question_mgmt_section_id,
      fqt.language_code,
      'question_text_' || question_record.question_key,
      fqt.question,
      'text',
      fqt.market_code
    FROM follow_up_question_translations fqt
    WHERE fqt.follow_up_question_id = question_record.id
    ON CONFLICT DO NOTHING;

    -- Sync options translations
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      question_trans_section_id,
      fqt.language_code,
      'question_options_' || question_record.question_key,
      array_to_string(ARRAY(SELECT jsonb_array_elements_text(fqt.options)), ', '),
      'text',
      fqt.market_code
    FROM follow_up_question_translations fqt
    WHERE fqt.follow_up_question_id = question_record.id
      AND fqt.options IS NOT NULL
    ON CONFLICT DO NOTHING;
  END LOOP;
END;
$$;

-- Run initial sync
SELECT sync_job_categories_to_content();
SELECT sync_follow_up_questions_to_content();