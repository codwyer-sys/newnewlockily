-- Phase 1: Email Infrastructure Database Schema

-- Create email templates table
CREATE TABLE public.email_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_key TEXT UNIQUE NOT NULL,
  template_name TEXT NOT NULL,
  description TEXT,
  category TEXT DEFAULT 'general',
  is_active BOOLEAN DEFAULT true,
  requires_variables JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create email template content table
CREATE TABLE public.email_template_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_id UUID NOT NULL REFERENCES public.email_templates(id) ON DELETE CASCADE,
  content_section TEXT NOT NULL,
  content_key TEXT NOT NULL,
  default_content TEXT NOT NULL,
  content_type TEXT DEFAULT 'html',
  is_required BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(template_id, content_section, content_key)
);

-- Create email template translations table
CREATE TABLE public.email_template_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_content_id UUID NOT NULL REFERENCES public.email_template_content(id) ON DELETE CASCADE,
  language_code TEXT NOT NULL,
  market_code TEXT,
  translated_content TEXT NOT NULL,
  ai_instruction TEXT,
  translation_status TEXT DEFAULT 'pending',
  translated_by UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(template_content_id, language_code, market_code)
);

-- Create email brand settings table
CREATE TABLE public.email_brand_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  market_code TEXT UNIQUE NOT NULL,
  logo_url TEXT,
  primary_color TEXT DEFAULT '#155e63',
  secondary_color TEXT DEFAULT '#f9f8eb',
  font_family TEXT DEFAULT 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
  header_background_color TEXT DEFAULT '#155e63',
  footer_background_color TEXT DEFAULT '#f9f8eb',
  border_color TEXT DEFAULT '#155e63',
  company_name TEXT,
  company_address TEXT,
  contact_email TEXT,
  privacy_policy_url TEXT,
  unsubscribe_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create email send log table
CREATE TABLE public.email_send_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_id UUID REFERENCES public.email_templates(id),
  recipient_email TEXT NOT NULL,
  language_code TEXT NOT NULL,
  market_code TEXT,
  subject TEXT,
  send_status TEXT DEFAULT 'pending',
  provider_response JSONB,
  variables_used JSONB,
  sent_at TIMESTAMP WITH TIME ZONE,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all email tables
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_template_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_template_translations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_brand_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_send_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies for email_templates
CREATE POLICY "Admins can manage email templates"
ON public.email_templates
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view active email templates"
ON public.email_templates
FOR SELECT
USING (is_active = true);

-- RLS Policies for email_template_content
CREATE POLICY "Admins can manage email template content"
ON public.email_template_content
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view email template content"
ON public.email_template_content
FOR SELECT
USING (true);

-- RLS Policies for email_template_translations
CREATE POLICY "Admins can manage email template translations"
ON public.email_template_translations
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view email template translations"
ON public.email_template_translations
FOR SELECT
USING (true);

-- RLS Policies for email_brand_settings
CREATE POLICY "Admins can manage email brand settings"
ON public.email_brand_settings
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "Anyone can view email brand settings"
ON public.email_brand_settings
FOR SELECT
USING (true);

-- RLS Policies for email_send_log
CREATE POLICY "Admins can view all email send logs"
ON public.email_send_log
FOR SELECT
USING (has_role(auth.uid(), 'admin'::user_role));

CREATE POLICY "System can insert email send logs"
ON public.email_send_log
FOR INSERT
WITH CHECK (true);

-- Create triggers for updated_at columns
CREATE TRIGGER update_email_templates_updated_at
BEFORE UPDATE ON public.email_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_template_content_updated_at
BEFORE UPDATE ON public.email_template_content
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_template_translations_updated_at
BEFORE UPDATE ON public.email_template_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_brand_settings_updated_at
BEFORE UPDATE ON public.email_brand_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add email templates page to content management
INSERT INTO public.content_pages (page_key, page_name, description) VALUES 
('email_templates', 'Email Templates', 'Manage email templates and translations');

-- Add content sections for email management
INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'template_management', 'Template Management', 'Create and manage email templates'
FROM public.content_pages cp WHERE cp.page_key = 'email_templates';

INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'email_translations', 'Email Translations', 'Manage email content translations'
FROM public.content_pages cp WHERE cp.page_key = 'email_templates';

-- Create function to sync email content with content_translations
CREATE OR REPLACE FUNCTION public.sync_email_content_to_translations()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.content_translations (
    section_id,
    language_code,
    content_key,
    content_value,
    content_type,
    market_code
  )
  SELECT 
    cs.id,
    'en',
    CONCAT('email_', et.template_key, '_', NEW.content_section, '_', NEW.content_key),
    NEW.default_content,
    CASE WHEN NEW.content_type = 'html' THEN 'rich_text' ELSE 'text' END,
    NULL
  FROM public.email_templates et
  JOIN public.content_pages cp ON cp.page_key = 'email_templates'
  JOIN public.content_sections cs ON cs.page_id = cp.id AND cs.section_key = 'email_translations'
  WHERE et.id = NEW.template_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to sync email content
CREATE TRIGGER sync_email_content_trigger
AFTER INSERT ON public.email_template_content
FOR EACH ROW
EXECUTE FUNCTION public.sync_email_content_to_translations();

-- Insert default brand settings for DK market
INSERT INTO public.email_brand_settings (
  market_code,
  primary_color,
  secondary_color,
  header_background_color,
  footer_background_color,
  border_color,
  company_name,
  contact_email
) VALUES (
  'DK',
  '#155e63',
  '#f9f8eb',
  '#155e63',
  '#f9f8eb',
  '#155e63',
  'Lockily',
  'support@lockily.dk'
);