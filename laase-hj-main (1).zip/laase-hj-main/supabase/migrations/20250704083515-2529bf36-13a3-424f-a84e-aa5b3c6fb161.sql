-- Create table for locksmith auto-bidding preferences
CREATE TABLE public.locksmith_auto_bid_preferences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL,
  job_category_id UUID NOT NULL,
  is_enabled BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(locksmith_id, job_category_id)
);

-- Enable Row Level Security
ALTER TABLE public.locksmith_auto_bid_preferences ENABLE ROW LEVEL SECURITY;

-- Create policies for locksmith access
CREATE POLICY "Locksmiths can view their own auto-bid preferences" 
ON public.locksmith_auto_bid_preferences 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

CREATE POLICY "Locksmiths can create their own auto-bid preferences" 
ON public.locksmith_auto_bid_preferences 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

CREATE POLICY "Locksmiths can update their own auto-bid preferences" 
ON public.locksmith_auto_bid_preferences 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

CREATE POLICY "Locksmiths can delete their own auto-bid preferences" 
ON public.locksmith_auto_bid_preferences 
FOR DELETE 
USING (EXISTS (
  SELECT 1 FROM user_roles ur 
  WHERE ur.user_id = locksmith_id 
  AND ur.user_id = auth.uid() 
  AND ur.role = 'locksmith'
));

-- Add trigger for automatic timestamp updates
CREATE TRIGGER update_locksmith_auto_bid_preferences_updated_at
BEFORE UPDATE ON public.locksmith_auto_bid_preferences
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();