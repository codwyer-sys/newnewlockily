-- Update the email template to include missing variables
UPDATE email_templates 
SET requires_variables = '[
  "locksmith_name",
  "firstname",
  "company_name", 
  "email",
  "cvr_number",
  "phone",
  "address",
  "city",
  "postal_code",
  "website",
  "support_email",
  "platform_name",
  "confirmemail_link"
]'::jsonb
WHERE id = 'ec42b1a5-41f8-4392-a201-85af5de509a3';