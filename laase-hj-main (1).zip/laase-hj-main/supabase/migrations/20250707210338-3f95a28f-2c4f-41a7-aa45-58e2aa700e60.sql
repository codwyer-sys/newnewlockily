UPDATE ai_translation_settings 
SET model = 'gpt-4o-mini'
WHERE model = 'gpt-4.1-2025-04-14';