
-- Add an icon column to the follow_up_questions table to store icons for each option
ALTER TABLE public.follow_up_questions 
ADD COLUMN option_icons JSONB;

-- Update existing questions with icons for their options
-- For "Hvilken type dør er det?" question
UPDATE public.follow_up_questions 
SET option_icons = '{"Hoveddør": "🚪", "Bagdør": "🔙", "Altandør": "🌅", "Andet": "❓"}'::jsonb
WHERE question_key = 'doorType';

-- For "Ved du hvilken type lås det er?" question
UPDATE public.follow_up_questions 
SET option_icons = '{"Almindelig cylinder": "🔑", "Sikkerhedslås": "🔒", "Elektronisk": "💳", "Ved ikke": "❓"}'::jsonb
WHERE question_key = 'lockType';

-- For "Hvor sidder nøglen fast?" question
UPDATE public.follow_up_questions 
SET option_icons = '{"Dør": "🚪", "Hængelås": "🔐", "Bil": "🚗", "Andet": "❓"}'::jsonb
WHERE question_key = 'keyLocation';

-- For the global "Hvornår på dagen passer det bedst?" question
UPDATE public.follow_up_questions 
SET option_icons = '{"Morgen": "🌅", "Eftermiddag": "☀️", "Aften": "🌙", "Ligegyldigt": "🕐"}'::jsonb
WHERE question_key = 'preferredTime';
