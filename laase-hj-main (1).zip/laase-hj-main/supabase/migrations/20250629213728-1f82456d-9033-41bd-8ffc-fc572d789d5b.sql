
-- First, let's create the profiles table and other new tables
CREATE TABLE public.profiles (
  id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  first_name TEXT,
  last_name TEXT,
  phone TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create customer_profiles table for end-client specific data
CREATE TABLE public.customer_profiles (
  id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE PRIMARY KEY,
  billing_address TEXT,
  billing_postal_code TEXT,
  billing_city TEXT,
  contact_preferences JSONB DEFAULT '{"email": true, "sms": false, "phone": true}'::jsonb,
  emergency_contact_name TEXT,
  emergency_contact_phone TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create admin_profiles table for admin-specific data
CREATE TABLE public.admin_profiles (
  id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE PRIMARY KEY,
  department TEXT,
  access_level TEXT DEFAULT 'standard' CHECK (access_level IN ('standard', 'super', 'system')),
  permissions JSONB DEFAULT '[]'::jsonb,
  last_login TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Now populate the profiles table with existing locksmith data
INSERT INTO public.profiles (id, first_name, last_name, phone)
SELECT 
  id, 
  SPLIT_PART(contact_person, ' ', 1) as first_name,
  CASE 
    WHEN ARRAY_LENGTH(STRING_TO_ARRAY(contact_person, ' '), 1) > 1 
    THEN SUBSTRING(contact_person FROM POSITION(' ' IN contact_person) + 1)
    ELSE ''
  END as last_name,
  phone
FROM public.locksmith_profiles;

-- Enable RLS on all profile tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_profiles ENABLE ROW LEVEL SECURITY;

-- RLS policies for profiles table
CREATE POLICY "Users can view their own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" 
ON public.profiles FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all profiles" 
ON public.profiles FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- RLS policies for customer_profiles table
CREATE POLICY "Customers can view their own profile" 
ON public.customer_profiles FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Customers can update their own profile" 
ON public.customer_profiles FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Customers can insert their own profile" 
ON public.customer_profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can view all customer profiles" 
ON public.customer_profiles FOR SELECT 
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all customer profiles" 
ON public.customer_profiles FOR UPDATE 
USING (public.has_role(auth.uid(), 'admin'));

-- RLS policies for admin_profiles table
CREATE POLICY "Admins can view their own admin profile" 
ON public.admin_profiles FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Admins can update their own admin profile" 
ON public.admin_profiles FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Admins can insert their own admin profile" 
ON public.admin_profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

CREATE POLICY "Super admins can view all admin profiles" 
ON public.admin_profiles FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.admin_profiles 
    WHERE id = auth.uid() AND access_level IN ('super', 'system')
  )
);

-- Create function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role TEXT;
BEGIN
  -- Get the user's role from metadata or default to customer
  user_role := COALESCE(NEW.raw_user_meta_data ->> 'role', 'customer');
  
  -- Create base profile
  INSERT INTO public.profiles (id, first_name, last_name, phone)
  VALUES (
    NEW.id, 
    NEW.raw_user_meta_data ->> 'first_name',
    NEW.raw_user_meta_data ->> 'last_name',
    NEW.raw_user_meta_data ->> 'phone'
  );
  
  -- Create role-specific profile
  CASE user_role
    WHEN 'customer' THEN
      INSERT INTO public.customer_profiles (id) VALUES (NEW.id);
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'customer');
    WHEN 'locksmith' THEN
      -- Locksmith profile will be created by the signup process
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'locksmith');
    WHEN 'admin' THEN
      INSERT INTO public.admin_profiles (id, department, access_level) 
      VALUES (NEW.id, 'general', 'standard');
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  END CASE;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user profile creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();

-- Create helper function to get user profile with role
CREATE OR REPLACE FUNCTION public.get_user_profile(user_id UUID)
RETURNS TABLE (
  id UUID,
  first_name TEXT,
  last_name TEXT,
  phone TEXT,
  email TEXT,
  role TEXT,
  profile_data JSONB
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.first_name,
    p.last_name,
    p.phone,
    au.email,
    ur.role::TEXT,
    CASE 
      WHEN ur.role = 'customer' THEN to_jsonb(cp.*)
      WHEN ur.role = 'locksmith' THEN to_jsonb(lp.*)
      WHEN ur.role = 'admin' THEN to_jsonb(ap.*)
      ELSE '{}'::jsonb
    END as profile_data
  FROM public.profiles p
  JOIN auth.users au ON au.id = p.id
  LEFT JOIN public.user_roles ur ON ur.user_id = p.id
  LEFT JOIN public.customer_profiles cp ON cp.id = p.id AND ur.role = 'customer'
  LEFT JOIN public.locksmith_profiles lp ON lp.id = p.id AND ur.role = 'locksmith'
  LEFT JOIN public.admin_profiles ap ON ap.id = p.id AND ur.role = 'admin'
  WHERE p.id = user_id;
END;
$$;
