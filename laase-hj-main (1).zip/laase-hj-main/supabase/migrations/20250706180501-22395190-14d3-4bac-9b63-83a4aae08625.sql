-- First, drop the existing check constraint on status
ALTER TABLE public.bookings DROP CONSTRAINT IF EXISTS bookings_status_check;

-- Add new check constraint with all the new status values
ALTER TABLE public.bookings 
ADD CONSTRAINT bookings_status_check 
CHECK (status IN ('waiting_for_quotes', 'quotes_received', 'order_placed', 'order_fulfilled', 'canceled', 'pending'));

-- Now add the new admin tracking fields
ALTER TABLE public.bookings 
ADD COLUMN IF NOT EXISTS admin_notes TEXT,
ADD COLUMN IF NOT EXISTS status_changed_at TIMESTAMPTZ DEFAULT now(),
ADD COLUMN IF NOT EXISTS status_changed_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS priority_level TEXT DEFAULT 'medium';

-- Update existing records from 'pending' to 'waiting_for_quotes'
UPDATE public.bookings 
SET status = 'waiting_for_quotes' 
WHERE status = 'pending';

-- Remove 'pending' from allowed statuses now that all records are updated
ALTER TABLE public.bookings DROP CONSTRAINT bookings_status_check;
ALTER TABLE public.bookings 
ADD CONSTRAINT bookings_status_check 
CHECK (status IN ('waiting_for_quotes', 'quotes_received', 'order_placed', 'order_fulfilled', 'canceled'));

-- Create trigger to update status_changed_at when status changes
CREATE OR REPLACE FUNCTION public.update_booking_status_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    NEW.status_changed_at = now();
    NEW.status_changed_by = auth.uid();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_booking_status_timestamp_trigger
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_booking_status_timestamp();

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_status_changed_at ON public.bookings(status_changed_at);