-- Step 1: Add locksmith-specific fields to profiles table
ALTER TABLE public.profiles ADD COLUMN cvr_number TEXT UNIQUE;
ALTER TABLE public.profiles ADD COLUMN company_name TEXT;
ALTER TABLE public.profiles ADD COLUMN address TEXT;
ALTER TABLE public.profiles ADD COLUMN postal_code TEXT;
ALTER TABLE public.profiles ADD COLUMN city TEXT;
ALTER TABLE public.profiles ADD COLUMN contact_person TEXT;
ALTER TABLE public.profiles ADD COLUMN status TEXT DEFAULT 'pending';
ALTER TABLE public.profiles ADD COLUMN specializations TEXT[];
ALTER TABLE public.profiles ADD COLUMN description TEXT;
ALTER TABLE public.profiles ADD COLUMN website TEXT;
ALTER TABLE public.profiles ADD COLUMN emergency_available BOOLEAN DEFAULT false;

-- Step 2: Migrate existing data from locksmith_profiles to profiles
UPDATE public.profiles 
SET 
  cvr_number = lp.cvr_number,
  company_name = lp.company_name,
  address = lp.address,
  postal_code = lp.postal_code,
  city = lp.city,
  contact_person = lp.contact_person,
  status = lp.status,
  specializations = lp.specializations,
  description = lp.description,
  website = lp.website,
  emergency_available = lp.emergency_available
FROM public.locksmith_profiles lp
WHERE profiles.id = lp.id;

-- Step 3: Populate missing locksmith profiles from raw_user_meta_data
UPDATE public.profiles
SET 
  cvr_number = (au.raw_user_meta_data ->> 'cvr_number'),
  company_name = (au.raw_user_meta_data ->> 'company_name'),
  address = (au.raw_user_meta_data ->> 'address'),
  postal_code = (au.raw_user_meta_data ->> 'postal_code'),
  city = (au.raw_user_meta_data ->> 'city'),
  contact_person = (au.raw_user_meta_data ->> 'contact_person'),
  website = (au.raw_user_meta_data ->> 'website'),
  status = 'pending'
FROM auth.users au
JOIN public.user_roles ur ON ur.user_id = au.id
WHERE profiles.id = au.id 
  AND ur.role = 'locksmith'
  AND profiles.cvr_number IS NULL
  AND au.raw_user_meta_data IS NOT NULL;

-- Step 4: Update foreign key constraints to reference profiles instead of locksmith_profiles
-- Update service_areas
ALTER TABLE public.service_areas DROP CONSTRAINT IF EXISTS service_areas_locksmith_id_fkey;
ALTER TABLE public.service_areas ADD CONSTRAINT service_areas_locksmith_id_fkey 
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update pricing_configs  
ALTER TABLE public.pricing_configs DROP CONSTRAINT IF EXISTS pricing_configs_locksmith_id_fkey;
ALTER TABLE public.pricing_configs ADD CONSTRAINT pricing_configs_locksmith_id_fkey
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update stripe_connect_accounts
ALTER TABLE public.stripe_connect_accounts DROP CONSTRAINT IF EXISTS stripe_connect_accounts_locksmith_id_fkey;
ALTER TABLE public.stripe_connect_accounts ADD CONSTRAINT stripe_connect_accounts_locksmith_id_fkey
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update payment_transactions
ALTER TABLE public.payment_transactions DROP CONSTRAINT IF EXISTS payment_transactions_locksmith_id_fkey;
ALTER TABLE public.payment_transactions ADD CONSTRAINT payment_transactions_locksmith_id_fkey
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update payout_transactions
ALTER TABLE public.payout_transactions DROP CONSTRAINT IF EXISTS payout_transactions_locksmith_id_fkey;
ALTER TABLE public.payout_transactions ADD CONSTRAINT payout_transactions_locksmith_id_fkey
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update reviews
ALTER TABLE public.reviews DROP CONSTRAINT IF EXISTS reviews_locksmith_id_fkey;
ALTER TABLE public.reviews ADD CONSTRAINT reviews_locksmith_id_fkey
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Update bookings
ALTER TABLE public.bookings DROP CONSTRAINT IF EXISTS bookings_locksmith_id_fkey;
ALTER TABLE public.bookings ADD CONSTRAINT bookings_locksmith_id_fkey
  FOREIGN KEY (locksmith_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Step 5: Update RLS policies that referenced locksmith_profiles
-- Update stripe_connect_accounts policies
DROP POLICY IF EXISTS "Locksmiths can view their own connect account" ON public.stripe_connect_accounts;
CREATE POLICY "Locksmiths can view their own connect account" 
ON public.stripe_connect_accounts 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.user_roles ur
  WHERE ur.user_id = stripe_connect_accounts.locksmith_id 
  AND ur.user_id = auth.uid()
  AND ur.role = 'locksmith'
));

DROP POLICY IF EXISTS "Locksmiths can insert their own connect account" ON public.stripe_connect_accounts;
CREATE POLICY "Locksmiths can insert their own connect account" 
ON public.stripe_connect_accounts 
FOR INSERT 
WITH CHECK (EXISTS (
  SELECT 1 FROM public.user_roles ur
  WHERE ur.user_id = stripe_connect_accounts.locksmith_id 
  AND ur.user_id = auth.uid()
  AND ur.role = 'locksmith'
));

DROP POLICY IF EXISTS "Locksmiths can update their own connect account" ON public.stripe_connect_accounts;
CREATE POLICY "Locksmiths can update their own connect account" 
ON public.stripe_connect_accounts 
FOR UPDATE 
USING (EXISTS (
  SELECT 1 FROM public.user_roles ur
  WHERE ur.user_id = stripe_connect_accounts.locksmith_id 
  AND ur.user_id = auth.uid()
  AND ur.role = 'locksmith'
));

-- Update payment_transactions policies
DROP POLICY IF EXISTS "Users can view their own payment transactions" ON public.payment_transactions;
CREATE POLICY "Users can view their own payment transactions" 
ON public.payment_transactions 
FOR SELECT 
USING (
  auth.uid() = customer_id OR 
  (EXISTS (
    SELECT 1 FROM public.user_roles ur
    WHERE ur.user_id = payment_transactions.locksmith_id 
    AND ur.user_id = auth.uid()
    AND ur.role = 'locksmith'
  )) OR
  has_role(auth.uid(), 'admin'::user_role)
);

-- Update payout_transactions policies
DROP POLICY IF EXISTS "Locksmiths can view their own payouts" ON public.payout_transactions;
CREATE POLICY "Locksmiths can view their own payouts" 
ON public.payout_transactions 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.user_roles ur
  WHERE ur.user_id = payout_transactions.locksmith_id 
  AND ur.user_id = auth.uid()
  AND ur.role = 'locksmith'
));

-- Update service_areas policies
DROP POLICY IF EXISTS "Locksmiths can manage own service areas" ON public.service_areas;
CREATE POLICY "Locksmiths can manage own service areas" 
ON public.service_areas 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.user_roles ur
  WHERE ur.user_id = service_areas.locksmith_id 
  AND ur.user_id = auth.uid()
  AND ur.role = 'locksmith'
));

-- Update pricing_configs policies
DROP POLICY IF EXISTS "Locksmiths can manage own pricing" ON public.pricing_configs;
CREATE POLICY "Locksmiths can manage own pricing" 
ON public.pricing_configs 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.user_roles ur
  WHERE ur.user_id = pricing_configs.locksmith_id 
  AND ur.user_id = auth.uid()
  AND ur.role = 'locksmith'
));

-- Step 6: Update get_user_profile function to include locksmith fields
CREATE OR REPLACE FUNCTION public.get_user_profile(user_id uuid)
 RETURNS TABLE(id uuid, first_name text, last_name text, phone text, email text, role text, profile_data jsonb)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.first_name,
    p.last_name,
    p.phone,
    au.email,
    ur.role::TEXT,
    CASE 
      WHEN ur.role = 'customer' THEN to_jsonb(cp.*)
      WHEN ur.role = 'locksmith' THEN jsonb_build_object(
        'id', p.id,
        'cvr_number', p.cvr_number,
        'company_name', p.company_name,
        'address', p.address,
        'postal_code', p.postal_code,
        'city', p.city,
        'contact_person', p.contact_person,
        'status', p.status,
        'specializations', p.specializations,
        'description', p.description,
        'website', p.website,
        'emergency_available', p.emergency_available,
        'created_at', p.created_at,
        'updated_at', p.updated_at
      )
      WHEN ur.role = 'admin' THEN to_jsonb(ap.*)
      ELSE '{}'::jsonb
    END as profile_data
  FROM public.profiles p
  JOIN auth.users au ON au.id = p.id
  LEFT JOIN public.user_roles ur ON ur.user_id = p.id
  LEFT JOIN public.customer_profiles cp ON cp.id = p.id AND ur.role = 'customer'
  LEFT JOIN public.admin_profiles ap ON ap.id = p.id AND ur.role = 'admin'
  WHERE p.id = user_id;
END;
$function$;

-- Step 7: Update the new user profile creation trigger to handle locksmith data
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  user_role TEXT;
BEGIN
  -- Get the user's role from metadata or default to customer
  user_role := COALESCE(NEW.raw_user_meta_data ->> 'role', 'customer');
  
  -- Create base profile with locksmith data if applicable
  INSERT INTO public.profiles (
    id, 
    first_name, 
    last_name, 
    phone,
    cvr_number,
    company_name,
    address,
    postal_code,
    city,
    contact_person,
    website,
    status,
    emergency_available
  )
  VALUES (
    NEW.id, 
    NEW.raw_user_meta_data ->> 'first_name',
    NEW.raw_user_meta_data ->> 'last_name',
    NEW.raw_user_meta_data ->> 'phone',
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'cvr_number' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'company_name' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'address' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'postal_code' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'city' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'contact_person' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN NEW.raw_user_meta_data ->> 'website' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN 'pending' ELSE NULL END,
    CASE WHEN user_role = 'locksmith' THEN false ELSE NULL END
  );
  
  -- Create role-specific profile
  CASE user_role
    WHEN 'customer' THEN
      INSERT INTO public.customer_profiles (id) VALUES (NEW.id);
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'customer');
    WHEN 'locksmith' THEN
      -- Locksmith data is now stored directly in profiles table
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'locksmith');
    WHEN 'admin' THEN
      INSERT INTO public.admin_profiles (id, department, access_level) 
      VALUES (NEW.id, 'general', 'standard');
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  END CASE;
  
  RETURN NEW;
END;
$function$;