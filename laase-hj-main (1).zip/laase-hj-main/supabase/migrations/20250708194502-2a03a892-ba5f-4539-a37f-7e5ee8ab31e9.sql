-- Create quotes table for locksmith bids on bookings
CREATE TABLE public.quotes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  locksmith_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  price NUMERIC(10,2) NOT NULL,
  estimated_arrival_minutes INTEGER NOT NULL,
  distance_km NUMERIC(6,2) NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'expired')),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '2 hours'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create reviews table for locksmith ratings
CREATE TABLE public.reviews (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  locksmith_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  booking_id UUID NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Add indexes for better performance
CREATE INDEX idx_quotes_booking_id ON public.quotes(booking_id);
CREATE INDEX idx_quotes_locksmith_id ON public.quotes(locksmith_id);
CREATE INDEX idx_quotes_status ON public.quotes(status);
CREATE INDEX idx_quotes_created_at ON public.quotes(created_at);

CREATE INDEX idx_reviews_locksmith_id ON public.reviews(locksmith_id);
CREATE INDEX idx_reviews_booking_id ON public.reviews(booking_id);
CREATE INDEX idx_reviews_rating ON public.reviews(rating);

-- Add triggers for updated_at
CREATE TRIGGER update_quotes_updated_at
  BEFORE UPDATE ON public.quotes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_reviews_updated_at
  BEFORE UPDATE ON public.reviews
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Enable RLS
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies for quotes
CREATE POLICY "Anyone can view quotes for public bookings" 
ON public.quotes FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.bookings b 
    WHERE b.id = quotes.booking_id 
    AND (b.customer_id IS NULL OR b.customer_id = auth.uid() OR b.locksmith_id = auth.uid())
  ) OR has_role(auth.uid(), 'admin'::user_role)
);

CREATE POLICY "Locksmiths can create quotes for their bids" 
ON public.quotes FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'locksmith'::user_role
    AND ur.user_id = quotes.locksmith_id
  )
);

CREATE POLICY "Locksmiths can update their own quotes" 
ON public.quotes FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = auth.uid() 
    AND ur.role = 'locksmith'::user_role
    AND ur.user_id = quotes.locksmith_id
  ) OR has_role(auth.uid(), 'admin'::user_role)
);

-- RLS Policies for reviews
CREATE POLICY "Anyone can view reviews" 
ON public.reviews FOR SELECT 
USING (true);

CREATE POLICY "Customers can create reviews for completed bookings" 
ON public.reviews FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.bookings b 
    WHERE b.id = reviews.booking_id 
    AND b.customer_id = auth.uid()
    AND b.job_stage = 'job_finished'::job_stage_enum
  )
);

CREATE POLICY "Customers can update their own reviews" 
ON public.reviews FOR UPDATE 
USING (customer_id = auth.uid() OR has_role(auth.uid(), 'admin'::user_role));