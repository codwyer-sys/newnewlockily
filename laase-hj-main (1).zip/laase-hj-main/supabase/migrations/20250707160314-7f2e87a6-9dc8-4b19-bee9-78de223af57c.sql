-- Phase 1: Update Job Categories to English defaults
UPDATE public.job_categories SET 
  name = 'Locked Out',
  description = 'Cannot access property'
WHERE name = 'Låst ude';

UPDATE public.job_categories SET 
  name = 'Broken Key',
  description = 'Key damaged or broken'
WHERE name = 'Knækket nøgle';

UPDATE public.job_categories SET 
  name = 'Change Lock',
  description = 'Install new lock'
WHERE name = 'Skift lås';

UPDATE public.job_categories SET 
  name = 'Other',
  description = 'Other locksmith service'
WHERE name = 'Andet';

-- Phase 1: Update Follow-up Questions to English defaults
UPDATE public.follow_up_questions SET 
  question = 'How many locks need to be changed?'
WHERE question = 'Hvor mange låse skal skiftes?';

UPDATE public.follow_up_questions SET 
  question = 'What type of door is it?',
  options = '["Front Door", "Back Door", "Patio Door", "Other"]'::jsonb
WHERE question = 'Hvilken type dør er det?';

UPDATE public.follow_up_questions SET 
  question = 'Where is the key stuck?',
  options = '["Door", "Padlock", "Car", "Other"]'::jsonb
WHERE question = 'Hvor sidder nøglen fast?';

UPDATE public.follow_up_questions SET 
  question = 'Do you know what type of lock it is?',
  options = '["Standard Cylinder", "Security Lock", "Electronic", "Don''t Know"]'::jsonb
WHERE question = 'Ved du hvilken type lås det er?';

-- Phase 2: Store the Danish translations in the translation tables
-- Job Categories
INSERT INTO public.job_category_translations (job_category_id, language_code, market_code, name, description)
SELECT 
  id,
  'da' as language_code,
  'DK' as market_code,
  CASE 
    WHEN name = 'Locked Out' THEN 'Låst ude'
    WHEN name = 'Broken Key' THEN 'Knækket nøgle'
    WHEN name = 'Change Lock' THEN 'Skift lås'
    WHEN name = 'Other' THEN 'Andet'
  END as name,
  CASE 
    WHEN name = 'Locked Out' THEN 'Kom ikke ind'
    WHEN name = 'Broken Key' THEN 'Nøgle ødelagt'
    WHEN name = 'Change Lock' THEN 'Ny lås skal sættes'
    WHEN name = 'Other' THEN 'Andet problem'
  END as description
FROM public.job_categories
ON CONFLICT (job_category_id, language_code, market_code) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description;

-- Follow-up Questions
INSERT INTO public.follow_up_question_translations (follow_up_question_id, language_code, market_code, question, options)
SELECT 
  id,
  'da' as language_code,
  'DK' as market_code,
  CASE 
    WHEN question = 'How many locks need to be changed?' THEN 'Hvor mange låse skal skiftes?'
    WHEN question = 'What type of door is it?' THEN 'Hvilken type dør er det?'
    WHEN question = 'Where is the key stuck?' THEN 'Hvor sidder nøglen fast?'
    WHEN question = 'Do you know what type of lock it is?' THEN 'Ved du hvilken type lås det er?'
  END as question,
  CASE 
    WHEN question = 'What type of door is it?' THEN '["Hoveddør", "Bagdør", "Altandør", "Andet"]'::jsonb
    WHEN question = 'Where is the key stuck?' THEN '["Dør", "Hængelås", "Bil", "Andet"]'::jsonb
    WHEN question = 'Do you know what type of lock it is?' THEN '["Almindelig cylinder", "Sikkerhedslås", "Elektronisk", "Ved ikke"]'::jsonb
    ELSE NULL
  END as options
FROM public.follow_up_questions
ON CONFLICT (follow_up_question_id, language_code, market_code) DO UPDATE SET
  question = EXCLUDED.question,
  options = EXCLUDED.options;