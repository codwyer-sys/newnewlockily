-- Sync Job Categories and Follow-up Questions to Content Management System

-- Function to sync job categories to content_translations
CREATE OR REPLACE FUNCTION sync_job_categories_to_content()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  category_record record;
  category_mgmt_section_id uuid := 'f964e2be-1f80-4691-84de-b38836702bf4'; -- Category Management
  category_trans_section_id uuid := '59dd53f4-c254-4e4f-9d49-4a318f0d24a7'; -- Category Translations
BEGIN
  -- Sync job category names and descriptions to content_translations
  FOR category_record IN 
    SELECT id, name, description 
    FROM job_categories
  LOOP
    -- Insert English name
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    VALUES (
      category_mgmt_section_id,
      'en',
      'job_category_name_' || replace(lower(category_record.name), ' ', '_'),
      category_record.name,
      'text',
      null
    )
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();

    -- Insert English description
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    VALUES (
      category_trans_section_id,
      'en',
      'job_category_desc_' || replace(lower(category_record.name), ' ', '_'),
      category_record.description,
      'text',
      null
    )
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();

    -- Sync existing translations from job_category_translations
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      category_mgmt_section_id,
      jct.language_code,
      'job_category_name_' || replace(lower(category_record.name), ' ', '_'),
      jct.name,
      'text',
      jct.market_code
    FROM job_category_translations jct
    WHERE jct.job_category_id = category_record.id
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();

    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      category_trans_section_id,
      jct.language_code,
      'job_category_desc_' || replace(lower(category_record.name), ' ', '_'),
      jct.description,
      'text',
      jct.market_code
    FROM job_category_translations jct
    WHERE jct.job_category_id = category_record.id
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();
  END LOOP;
END;
$$;

-- Function to sync follow-up questions to content_translations
CREATE OR REPLACE FUNCTION sync_follow_up_questions_to_content()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  question_record record;
  question_mgmt_section_id uuid := '153da537-489b-4972-a999-a132e6d40c2a'; -- Question Management
  question_trans_section_id uuid := 'fd8a266b-4103-4419-b21a-16eb9dbb57ae'; -- Question Translations
BEGIN
  -- Sync follow-up questions to content_translations
  FOR question_record IN 
    SELECT id, question, question_key, options
    FROM follow_up_questions
  LOOP
    -- Insert English question
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    VALUES (
      question_mgmt_section_id,
      'en',
      'question_text_' || question_record.question_key,
      question_record.question,
      'text',
      null
    )
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();

    -- Insert English options if they exist
    IF question_record.options IS NOT NULL THEN
      INSERT INTO content_translations (
        section_id,
        language_code,
        content_key,
        content_value,
        content_type,
        market_code
      )
      VALUES (
        question_trans_section_id,
        'en',
        'question_options_' || question_record.question_key,
        array_to_string(ARRAY(SELECT jsonb_array_elements_text(question_record.options)), ', '),
        'text',
        null
      )
      ON CONFLICT (section_id, language_code, content_key, market_code) 
      DO UPDATE SET 
        content_value = EXCLUDED.content_value,
        updated_at = now();
    END IF;

    -- Sync existing translations from follow_up_question_translations
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      question_mgmt_section_id,
      fqt.language_code,
      'question_text_' || question_record.question_key,
      fqt.question,
      'text',
      fqt.market_code
    FROM follow_up_question_translations fqt
    WHERE fqt.follow_up_question_id = question_record.id
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();

    -- Sync options translations
    INSERT INTO content_translations (
      section_id,
      language_code,
      content_key,
      content_value,
      content_type,
      market_code
    )
    SELECT 
      question_trans_section_id,
      fqt.language_code,
      'question_options_' || question_record.question_key,
      array_to_string(ARRAY(SELECT jsonb_array_elements_text(fqt.options)), ', '),
      'text',
      fqt.market_code
    FROM follow_up_question_translations fqt
    WHERE fqt.follow_up_question_id = question_record.id
      AND fqt.options IS NOT NULL
    ON CONFLICT (section_id, language_code, content_key, market_code) 
    DO UPDATE SET 
      content_value = EXCLUDED.content_value,
      updated_at = now();
  END LOOP;
END;
$$;

-- Function to sync content_translations back to job tables
CREATE OR REPLACE FUNCTION sync_content_to_job_tables()
RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
  translation_record record;
  category_id uuid;
  question_id uuid;
  options_array text[];
BEGIN
  -- Sync job category translations back
  FOR translation_record IN 
    SELECT ct.*, 
           replace(replace(ct.content_key, 'job_category_name_', ''), 'job_category_desc_', '') as category_key
    FROM content_translations ct
    WHERE ct.section_id IN ('f964e2be-1f80-4691-84de-b38836702bf4', '59dd53f4-c254-4e4f-9d49-4a318f0d24a7')
      AND ct.content_key LIKE 'job_category_%'
      AND ct.language_code != 'en'
  LOOP
    -- Find matching category
    SELECT id INTO category_id
    FROM job_categories 
    WHERE replace(lower(name), ' ', '_') = translation_record.category_key;

    IF category_id IS NOT NULL THEN
      -- Upsert to job_category_translations
      IF translation_record.content_key LIKE 'job_category_name_%' THEN
        INSERT INTO job_category_translations (
          job_category_id,
          language_code,
          market_code,
          name,
          description
        )
        VALUES (
          category_id,
          translation_record.language_code,
          translation_record.market_code,
          translation_record.content_value,
          ''
        )
        ON CONFLICT (job_category_id, language_code, market_code)
        DO UPDATE SET 
          name = EXCLUDED.name,
          updated_at = now();
      ELSIF translation_record.content_key LIKE 'job_category_desc_%' THEN
        INSERT INTO job_category_translations (
          job_category_id,
          language_code,
          market_code,
          name,
          description
        )
        VALUES (
          category_id,
          translation_record.language_code,
          translation_record.market_code,
          '',
          translation_record.content_value
        )
        ON CONFLICT (job_category_id, language_code, market_code)
        DO UPDATE SET 
          description = EXCLUDED.description,
          updated_at = now();
      END IF;
    END IF;
  END LOOP;

  -- Sync follow-up question translations back
  FOR translation_record IN 
    SELECT ct.*, 
           replace(replace(ct.content_key, 'question_text_', ''), 'question_options_', '') as question_key
    FROM content_translations ct
    WHERE ct.section_id IN ('153da537-489b-4972-a999-a132e6d40c2a', 'fd8a266b-4103-4419-b21a-16eb9dbb57ae')
      AND ct.content_key LIKE 'question_%'
      AND ct.language_code != 'en'
  LOOP
    -- Find matching question
    SELECT id INTO question_id
    FROM follow_up_questions 
    WHERE question_key = translation_record.question_key;

    IF question_id IS NOT NULL THEN
      -- Convert comma-separated options back to JSON array
      IF translation_record.content_key LIKE 'question_options_%' AND translation_record.content_value IS NOT NULL THEN
        SELECT array_agg(trim(option)) INTO options_array
        FROM unnest(string_to_array(translation_record.content_value, ',')) as option;
      END IF;

      -- Upsert to follow_up_question_translations
      IF translation_record.content_key LIKE 'question_text_%' THEN
        INSERT INTO follow_up_question_translations (
          follow_up_question_id,
          language_code,
          market_code,
          question,
          options
        )
        VALUES (
          question_id,
          translation_record.language_code,
          translation_record.market_code,
          translation_record.content_value,
          null
        )
        ON CONFLICT (follow_up_question_id, language_code, market_code)
        DO UPDATE SET 
          question = EXCLUDED.question,
          updated_at = now();
      ELSIF translation_record.content_key LIKE 'question_options_%' THEN
        INSERT INTO follow_up_question_translations (
          follow_up_question_id,
          language_code,
          market_code,
          question,
          options
        )
        VALUES (
          question_id,
          translation_record.language_code,
          translation_record.market_code,
          '',
          to_jsonb(options_array)
        )
        ON CONFLICT (follow_up_question_id, language_code, market_code)
        DO UPDATE SET 
          options = EXCLUDED.options,
          updated_at = now();
      END IF;
    END IF;
  END LOOP;
END;
$$;

-- Run initial sync
SELECT sync_job_categories_to_content();
SELECT sync_follow_up_questions_to_content();