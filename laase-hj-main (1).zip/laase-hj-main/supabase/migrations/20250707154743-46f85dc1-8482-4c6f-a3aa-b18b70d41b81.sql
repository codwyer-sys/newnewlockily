-- Phase 1: Database Schema Enhancement for Job Categories & Follow-up Questions Translation

-- Create job category translations table
CREATE TABLE public.job_category_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_category_id UUID NOT NULL REFERENCES public.job_categories(id) ON DELETE CASCADE,
  language_code TEXT NOT NULL,
  market_code TEXT,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(job_category_id, language_code, market_code)
);

-- Create follow-up question translations table
CREATE TABLE public.follow_up_question_translations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  follow_up_question_id UUID NOT NULL REFERENCES public.follow_up_questions(id) ON DELETE CASCADE,
  language_code TEXT NOT NULL,
  market_code TEXT,
  question TEXT NOT NULL,
  options JSONB,
  option_icons JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(follow_up_question_id, language_code, market_code)
);

-- Enable RLS on translation tables
ALTER TABLE public.job_category_translations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follow_up_question_translations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for job category translations
CREATE POLICY "Anyone can view job category translations"
ON public.job_category_translations
FOR SELECT
USING (true);

CREATE POLICY "Admins can manage job category translations"
ON public.job_category_translations
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

-- Create RLS policies for follow-up question translations
CREATE POLICY "Anyone can view follow-up question translations"
ON public.follow_up_question_translations
FOR SELECT
USING (true);

CREATE POLICY "Admins can manage follow-up question translations"
ON public.follow_up_question_translations
FOR ALL
USING (has_role(auth.uid(), 'admin'::user_role));

-- Create triggers for updated_at
CREATE TRIGGER update_job_category_translations_updated_at
BEFORE UPDATE ON public.job_category_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_follow_up_question_translations_updated_at
BEFORE UPDATE ON public.follow_up_question_translations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add content pages for job management
INSERT INTO public.content_pages (page_key, page_name, description) VALUES 
('job_categories', 'Job Categories', 'Management of job categories and their translations'),
('follow_up_questions', 'Follow-up Questions', 'Management of follow-up questions and their translations');

-- Add content sections for job categories
INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'category_management', 'Category Management', 'Job category CRUD operations'
FROM public.content_pages cp WHERE cp.page_key = 'job_categories';

INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'category_translations', 'Category Translations', 'Job category translation management'
FROM public.content_pages cp WHERE cp.page_key = 'job_categories';

-- Add content sections for follow-up questions
INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'question_management', 'Question Management', 'Follow-up question CRUD operations'
FROM public.content_pages cp WHERE cp.page_key = 'follow_up_questions';

INSERT INTO public.content_sections (page_id, section_key, section_name, description) 
SELECT cp.id, 'question_translations', 'Question Translations', 'Follow-up question translation management'
FROM public.content_pages cp WHERE cp.page_key = 'follow_up_questions';