-- Add distance pricing fields to global_pricing_settings
ALTER TABLE public.global_pricing_settings 
ADD COLUMN base_radius_km NUMERIC NOT NULL DEFAULT 0,
ADD COLUMN fee_per_km_above_radius NUMERIC NOT NULL DEFAULT 0;