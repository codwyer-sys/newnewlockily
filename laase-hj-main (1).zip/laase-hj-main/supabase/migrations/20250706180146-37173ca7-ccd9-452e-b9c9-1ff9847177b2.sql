-- Update bookings table for job management system

-- Add new admin tracking fields to bookings table
ALTER TABLE public.bookings 
ADD COLUMN IF NOT EXISTS admin_notes TEXT,
ADD COLUMN IF NOT EXISTS status_changed_at TIMESTAMPTZ DEFAULT now(),
ADD COLUMN IF NOT EXISTS status_changed_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS priority_level TEXT DEFAULT 'medium';

-- Update existing records from 'pending' to 'waiting_for_quotes'
UPDATE public.bookings 
SET status = 'waiting_for_quotes' 
WHERE status = 'pending';

-- Create trigger to update status_changed_at when status changes
CREATE OR REPLACE FUNCTION public.update_booking_status_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS DISTINCT FROM NEW.status THEN
    NEW.status_changed_at = now();
    NEW.status_changed_by = auth.uid();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_booking_status_timestamp_trigger
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_booking_status_timestamp();

-- Add index for better performance on status queries
CREATE INDEX IF NOT EXISTS idx_bookings_status ON public.bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_status_changed_at ON public.bookings(status_changed_at);

-- Update RLS policies to allow admins full access to job management
CREATE POLICY "Admins can manage all booking fields" ON public.bookings
FOR ALL 
USING (has_role(auth.uid(), 'admin'::user_role))
WITH CHECK (has_role(auth.uid(), 'admin'::user_role));