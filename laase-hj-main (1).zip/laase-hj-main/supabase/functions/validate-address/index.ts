import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface ValidateAddressRequest {
  address: string;
  market_code?: string;
}

interface AddressResult {
  fullAddress: string;
  displayText: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  postalCode?: string;
  city?: string;
}

interface ValidationResponse {
  success: boolean;
  matched: boolean;
  confidence_score: number;
  clarification_needed: boolean;
  message: string;
  follow_up_message?: string;
  address?: {
    formatted_address: string;
    display_text: string;
    postal_code?: string;
    city?: string;
    coordinates?: {
      latitude: number;
      longitude: number;
    };
  };
  suggestions?: Array<{
    formatted_address: string;
    display_text: string;
    confidence: number;
  }>;
}

// Smart Address Matching Service
class AddressMatchingService {
  private static normalizeAddress(address: string): string {
    return address
      .toLowerCase()
      .replace(/[.,]/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, ''); // Remove diacritics
  }

  private static calculateSimilarity(str1: string, str2: string): number {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    
    if (longer.length === 0) return 1.0;
    
    const editDistance = this.levenshteinDistance(longer, shorter);
    return (longer.length - editDistance) / longer.length;
  }

  private static levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));
    
    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;
    
    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + indicator
        );
      }
    }
    
    return matrix[str2.length][str1.length];
  }

  static calculateConfidence(userInput: string, results: AddressResult[]): { result: AddressResult; confidence: number; } | null {
    if (!results || results.length === 0) return null;

    const normalizedInput = this.normalizeAddress(userInput);
    let bestMatch = { result: results[0], confidence: 0 };

    for (const result of results) {
      const normalizedResult = this.normalizeAddress(result.fullAddress);
      const similarity = this.calculateSimilarity(normalizedInput, normalizedResult);
      
      // Additional scoring factors
      let confidence = similarity;
      
      // Boost confidence if postal code or city matches
      if (result.postalCode && userInput.includes(result.postalCode)) {
        confidence += 0.2;
      }
      
      if (result.city && normalizedInput.includes(this.normalizeAddress(result.city))) {
        confidence += 0.15;
      }
      
      // Penalize if the address is too different in length
      const lengthDiff = Math.abs(normalizedInput.length - normalizedResult.length);
      if (lengthDiff > normalizedInput.length * 0.5) {
        confidence -= 0.1;
      }
      
      confidence = Math.min(1.0, Math.max(0.0, confidence));
      
      if (confidence > bestMatch.confidence) {
        bestMatch = { result, confidence };
      }
    }

    return bestMatch;
  }

  static generateFollowUpMessage(userInput: string, confidence: number, marketCode: string): string {
    const messages = {
      'DK': {
        low: `Jeg fandt ikke en præcis match for "${userInput}". Kan du uddybe adressen med husnummer eller postnummer?`,
        medium: `Jeg fandt en mulig adresse, men vil gerne være sikker. Kan du bekræfte at adressen er korrekt?`,
        clarify: `Kan du gentage adressen tydeligt med husnummer og postnummer?`
      },
      'DE': {
        low: `Ich konnte keine genaue Übereinstimmung für "${userInput}" finden. Können Sie die Adresse mit Hausnummer oder Postleitzahl ergänzen?`,
        medium: `Ich habe eine mögliche Adresse gefunden, möchte aber sicher sein. Können Sie bestätigen, dass die Adresse korrekt ist?`,
        clarify: `Können Sie die Adresse bitte deutlich mit Hausnummer und Postleitzahl wiederholen?`
      },
      'default': {
        low: `I couldn't find an exact match for "${userInput}". Could you provide more details like house number or postal code?`,
        medium: `I found a possible address but want to make sure. Can you confirm the address is correct?`,
        clarify: `Could you please repeat the address clearly with house number and postal code?`
      }
    };

    const lang = messages[marketCode as keyof typeof messages] || messages.default;
    
    if (confidence < 0.3) return lang.low;
    if (confidence < 0.7) return lang.medium;
    return lang.clarify;
  }
}

serve(async (req) => {
  const startTime = Date.now();
  console.log('🔍 validate-address: Smart validation request received');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestBody: any = {};
  let responseBody: any = {};
  let statusCode = 200;
  
  try {
    requestBody = await req.json();
    const { address, market_code = 'DK' }: ValidateAddressRequest = requestBody;
    
    console.log('🔍 validate-address: Processing address:', address, 'for market:', market_code);

    if (!address || address.length < 3) {
      const response: ValidationResponse = {
        success: false,
        matched: false,
        confidence_score: 0,
        clarification_needed: true,
        message: "Adressen skal være mindst 3 tegn lang",
        follow_up_message: "Kan du give mig en komplet adresse med husnummer og postnummer?"
      };
      
      return new Response(JSON.stringify(response), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Step 1: Get address results from unified lookup
    console.log('🔍 Calling unified-address-lookup...');
    const { data, error } = await supabase.functions.invoke('unified-address-lookup', {
      body: { 
        query: address,
        marketCode: market_code
      }
    });

    if (error) {
      console.error('🔍 validate-address: Address lookup error:', error);
      const response: ValidationResponse = {
        success: false,
        matched: false,
        confidence_score: 0,
        clarification_needed: true,
        message: "Kunne ikke søge efter adressen. Prøv venligst igen.",
        follow_up_message: AddressMatchingService.generateFollowUpMessage(address, 0, market_code)
      };
      
      return new Response(JSON.stringify(response), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`🔍 Found ${data?.results?.length || 0} address results`);

    if (!data?.results || data.results.length === 0) {
      const response: ValidationResponse = {
        success: false,
        matched: false,
        confidence_score: 0,
        clarification_needed: true,
        message: "Ingen adresser fundet",
        follow_up_message: AddressMatchingService.generateFollowUpMessage(address, 0, market_code)
      };
      
      return new Response(JSON.stringify(response), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Step 2: Convert results to our format and apply smart matching
    const addressResults: AddressResult[] = data.results.map((result: any) => ({
      fullAddress: result.fullAddress || result.displayText,
      displayText: result.displayText,
      coordinates: result.coordinates,
      postalCode: extractPostalCode(result.fullAddress || result.displayText),
      city: extractCity(result.fullAddress || result.displayText, market_code)
    }));

    // Step 3: Calculate confidence and get best match
    const bestMatch = AddressMatchingService.calculateConfidence(address, addressResults);
    
    if (!bestMatch) {
      const response: ValidationResponse = {
        success: false,
        matched: false,
        confidence_score: 0,
        clarification_needed: true,
        message: "Kunne ikke analysere adressen",
        follow_up_message: AddressMatchingService.generateFollowUpMessage(address, 0, market_code)
      };
      
      return new Response(JSON.stringify(response), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const { result, confidence } = bestMatch;
    console.log(`🔍 Best match confidence: ${confidence.toFixed(3)} for: ${result.fullAddress}`);

    // Step 4: Determine thresholds and response (more forgiving for voice input)
    const isDAWA = data.provider === 'dawa';
    const HIGH_CONFIDENCE_THRESHOLD = 0.6; // More forgiving for voice input
    const MEDIUM_CONFIDENCE_THRESHOLD = 0.3; // Accept lower confidence for voice
    
    // For voice input, be more lenient with postal codes
    const hasPostalCode = result.postalCode || /\b\d{4}\b/.test(result.fullAddress);
    const multipleResults = addressResults.length > 1;
    
    const matched = confidence >= MEDIUM_CONFIDENCE_THRESHOLD;
    const clarificationNeeded = confidence < HIGH_CONFIDENCE_THRESHOLD;
    
    let message: string;
    let followUpMessage: string | undefined;

    if (confidence >= HIGH_CONFIDENCE_THRESHOLD) {
      message = `Adresse valideret: ${result.displayText}`;
      // No follow-up needed for high confidence
    } else if (confidence >= MEDIUM_CONFIDENCE_THRESHOLD) {
      message = `Fandt mulig adresse: ${result.displayText}. Er det korrekt?`;
      followUpMessage = `Kan du bekræfte at "${result.displayText}" er den rigtige adresse?`;
    } else {
      message = `Usikker på adressen. Fandt: ${result.displayText}`;
      followUpMessage = AddressMatchingService.generateFollowUpMessage(address, confidence, market_code);
    }

    // Step 5: Build response with suggestions for lower confidence
    const response: ValidationResponse = {
      success: true,
      matched,
      confidence_score: Math.round(confidence * 100) / 100, // Round to 2 decimals
      clarification_needed: clarificationNeeded,
      message,
      follow_up_message: followUpMessage,
      address: {
        formatted_address: result.fullAddress,
        display_text: result.displayText,
        postal_code: result.postalCode,
        city: result.city,
        coordinates: result.coordinates
      }
    };

    // Add suggestions if confidence is low
    if (confidence < HIGH_CONFIDENCE_THRESHOLD && addressResults.length > 1) {
      response.suggestions = addressResults
        .slice(0, 3) // Top 3 results
        .map(addr => ({
          formatted_address: addr.fullAddress,
          display_text: addr.displayText,
          confidence: AddressMatchingService.calculateConfidence(address, [addr])?.confidence || 0
        }))
        .filter(s => s.confidence > 0.2) // Only include reasonable suggestions
        .sort((a, b) => b.confidence - a.confidence);
    }

    console.log(`🔍 Returning response: matched=${matched}, confidence=${confidence}, clarification_needed=${clarificationNeeded}`);
    
    responseBody = response;
    statusCode = 200;
    
    // Log the successful request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime);
    
    return new Response(JSON.stringify(response), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('🔍 validate-address: Unexpected error:', error);
    const response: ValidationResponse = {
      success: false,
      matched: false,
      confidence_score: 0,
      clarification_needed: true,
      message: "Der opstod en fejl ved validering af adressen",
      follow_up_message: "Kan du prøve at gentage adressen?"
    };
    
    responseBody = response;
    statusCode = 500;
    
    // Log the failed request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, error.message);
    
    return new Response(JSON.stringify(response), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper function to log webhook requests
async function logWebhookRequest(
  req: Request, 
  requestBody: any, 
  responseBody: any, 
  statusCode: number, 
  executionTime: number,
  errorMessage?: string
) {
  try {
    await supabase.from('webhook_logs').insert({
      function_name: 'validate-address',
      request_method: req.method,
      request_url: req.url,
      request_headers: Object.fromEntries(req.headers.entries()),
      request_body: requestBody,
      response_status_code: statusCode,
      response_body: responseBody,
      execution_time_ms: executionTime,
      error_message: errorMessage,
      client_ip: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
      user_agent: req.headers.get('user-agent'),
      call_metadata: {}
    });
  } catch (logError) {
    console.error('Failed to log webhook request:', logError);
  }
}

// Helper functions to extract postal code and city from address strings
function extractPostalCode(address: string): string | undefined {
  const postalCodeRegex = /\b\d{4}\b/; // 4-digit postal codes for DK
  const match = address.match(postalCodeRegex);
  return match ? match[0] : undefined;
}

function extractCity(address: string, marketCode: string): string | undefined {
  // Simple city extraction - this could be enhanced with a city database
  const parts = address.split(',').map(p => p.trim());
  
  // For Danish addresses, city is usually after postal code
  if (marketCode === 'DK') {
    const postalCodeIndex = parts.findIndex(part => /\b\d{4}\b/.test(part));
    if (postalCodeIndex >= 0 && postalCodeIndex < parts.length - 1) {
      return parts[postalCodeIndex + 1] || parts[parts.length - 1];
    }
  }
  
  // Fallback: return last part if it looks like a city (contains letters)
  const lastPart = parts[parts.length - 1];
  if (lastPart && /[a-zA-ZæøåÆØÅ]/.test(lastPart)) {
    return lastPart;
  }
  
  return undefined;
}