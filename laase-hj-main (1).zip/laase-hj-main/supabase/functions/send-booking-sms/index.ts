import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface BookingNotificationRequest {
  booking_id: string
  job_number: number
  follow_up_answers: any
  market_code: string
  address: string
  created_at: string
}

interface SMSTemplate {
  message: string
  link_text: string
}

// Helper function to log webhook requests
async function logWebhookRequest(
  req: Request,
  requestBody: any,
  responseBody: any,
  statusCode: number,
  executionTimeMs: number,
  errorMessage?: string
) {
  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    await supabase.from('webhook_logs').insert({
      function_name: 'send-booking-sms',
      request_method: req.method,
      request_url: req.url,
      request_headers: Object.fromEntries(req.headers.entries()),
      request_body: requestBody,
      response_status_code: statusCode,
      response_body: responseBody,
      execution_time_ms: executionTimeMs,
      error_message: errorMessage,
      client_ip: req.headers.get('x-forwarded-for'),
      user_agent: req.headers.get('user-agent'),
      call_metadata: {
        timestamp: new Date().toISOString(),
        function_version: '1.0.0'
      }
    })
  } catch (error) {
    console.error('Failed to log webhook request:', error)
  }
}

// Helper function to get SMS template from content management
async function getSMSTemplate(
  supabase: any,
  marketCode: string,
  languageCode?: string
): Promise<SMSTemplate> {
  // Use provided language code, or fallback to market default
  const effectiveLanguageCode = languageCode || (marketCode === 'DK' ? 'da' : 'en')
  
  // Get SMS templates from content management using correct section key
  const { data: messageData } = await supabase
    .from('content_translations')
    .select(`
      content_value,
      content_sections!inner (
        section_key,
        content_pages!inner (
          page_key
        )
      )
    `)
    .eq('content_key', 'job_created_message')
    .eq('language_code', effectiveLanguageCode)
    .or(`market_code.is.null,market_code.eq.${marketCode}`)
    .eq('content_sections.section_key', 'sms_job_created')
    .eq('content_sections.content_pages.page_key', 'sms_notifications')
    .single()

  const { data: linkData } = await supabase
    .from('content_translations')
    .select(`
      content_value,
      content_sections!inner (
        section_key,
        content_pages!inner (
          page_key
        )
      )
    `)
    .eq('content_key', 'job_created_link_text')
    .eq('language_code', effectiveLanguageCode)
    .or(`market_code.is.null,market_code.eq.${marketCode}`)
    .eq('content_sections.section_key', 'sms_job_created')
    .eq('content_sections.content_pages.page_key', 'sms_notifications')
    .single()

  return {
    message: messageData?.content_value || 'Your locksmith job #{{JOB_NUMBER}} has been created! View status: {{BOOKING_LINK}} - Lockily',
    link_text: linkData?.content_value || 'Track Booking'
  }
}

// Helper function to format phone number for international SMS
function formatPhoneNumber(phone: string, marketCode: string): string {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '')
  
  // Add country code based on market if not present
  if (marketCode === 'DK' && !digits.startsWith('45') && digits.length === 8) {
    return `+45${digits}`
  } else if (marketCode === 'UK' && !digits.startsWith('44') && digits.length === 11 && digits.startsWith('0')) {
    return `+44${digits.substring(1)}`
  } else if (marketCode === 'US' && !digits.startsWith('1') && digits.length === 10) {
    return `+1${digits}`
  } else if (marketCode === 'DE' && !digits.startsWith('49') && digits.length >= 10) {
    return `+49${digits}`
  } else if (digits.startsWith('+')) {
    return digits
  } else {
    return `+${digits}`
  }
}

// Helper function to send SMS via Twilio
async function sendTwilioSMS(to: string, message: string, fromValue: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID')
  const authToken = Deno.env.get('TWILIO_AUTH_TOKEN')

  if (!accountSid || !authToken) {
    throw new Error('Twilio credentials not configured')
  }

  try {
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${accountSid}:${authToken}`)}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          To: to,
          From: fromValue,
          Body: message,
        }),
      }
    )

    const result = await response.json()

    if (response.ok) {
      return {
        success: true,
        messageId: result.sid
      }
    } else {
      return {
        success: false,
        error: result.message || 'Failed to send SMS'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

Deno.serve(async (req) => {
  const startTime = Date.now()
  let requestBody: any = {}
  let responseBody: any = {}
  let statusCode = 200

  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Parse request body
    requestBody = await req.json()
    const { booking_id, job_number, follow_up_answers, market_code, address }: BookingNotificationRequest = requestBody

    console.log('📱 send-booking-sms: Processing SMS notification for booking:', booking_id)

    // Validate required fields
    if (!booking_id || !job_number || !market_code) {
      throw new Error('Missing required fields: booking_id, job_number, market_code')
    }

    // Extract customerPhone and language preference from follow_up_answers
    const customerPhone = follow_up_answers?.customerPhone
    const preferredLanguage = follow_up_answers?.preferredLanguage
    
    if (!customerPhone) {
      console.log('📱 send-booking-sms: No customerPhone found in follow_up_answers, skipping SMS')
      responseBody = {
        success: true,
        message: 'No customerPhone provided, SMS skipped',
        booking_id
      }
      
      logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime)
      return new Response(JSON.stringify(responseBody), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    console.log('📱 send-booking-sms: Customer preferred language:', preferredLanguage, 'Market:', market_code)

    // Initialize Supabase client for database operations
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Check if SMS notifications are enabled for this market
    const { data: smsSettings } = await supabase
      .from('sms_notification_settings')
      .select('is_enabled, sender_name, daily_limit')
      .eq('market_code', market_code)
      .single()

    if (!smsSettings?.is_enabled) {
      console.log('📱 send-booking-sms: SMS notifications disabled for market:', market_code)
      responseBody = {
        success: true,
        message: 'SMS notifications disabled for this market',
        booking_id
      }
      
      logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime)
      return new Response(JSON.stringify(responseBody), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    // Get SMS template from content management with user's preferred language
    const template = await getSMSTemplate(supabase, market_code, preferredLanguage)

    // Generate booking status URL
    const bookingStatusUrl = `https://pysmpkinlgpqowmlwttr.lovable.app/${market_code.toLowerCase()}/booking-status/${booking_id}`

    // Extract customer name from follow_up_answers for new template variables
    const customerName = follow_up_answers?.customerName || 'Customer'
    
    // Replace template variables - handle both old and new template formats
    let smsMessage = template.message
    
    // New template variables (if present)
    if (template.message.includes('{{customerName}}')) {
      smsMessage = smsMessage
        .replace('{{customerName}}', customerName)
        .replace('{{bookingLink}}', bookingStatusUrl)
    }
    
    // Old template variables (fallback)
    smsMessage = smsMessage
      .replace('{{JOB_NUMBER}}', job_number.toString())
      .replace('{{BOOKING_LINK}}', bookingStatusUrl)
      .replace('{{ADDRESS}}', address || '')

    // Format phone number
    const formattedPhone = formatPhoneNumber(customerPhone, market_code)

    // Use sender name from settings, fallback to phone number if not available
    const fromValue = smsSettings?.sender_name || Deno.env.get('TWILIO_PHONE_NUMBER') || 'Lockily'

    console.log('📱 send-booking-sms: Sending SMS to:', formattedPhone, 'from:', fromValue)

    // Send SMS via Twilio
    const smsResult = await sendTwilioSMS(formattedPhone, smsMessage, fromValue)

    if (smsResult.success) {
      console.log('📱 send-booking-sms: SMS sent successfully, message ID:', smsResult.messageId)
      
      responseBody = {
        success: true,
        message: 'SMS notification sent successfully',
        booking_id,
        message_id: smsResult.messageId,
        phone_number: formattedPhone
      }
    } else {
      console.error('📱 send-booking-sms: Failed to send SMS:', smsResult.error)
      statusCode = 500
      
      responseBody = {
        success: false,
        message: 'Failed to send SMS notification',
        booking_id,
        error: smsResult.error
      }
    }

    // Log the request (fire-and-forget)
    logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime)

    return new Response(JSON.stringify(responseBody), {
      status: statusCode,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })

  } catch (error) {
    console.error('📱 send-booking-sms: Error:', error)
    
    responseBody = {
      success: false,
      message: 'Internal server error',
      error: error.message
    }
    statusCode = 500
    
    // Log the failed request (fire-and-forget)
    logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, error.message)
    
    return new Response(JSON.stringify(responseBody), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})