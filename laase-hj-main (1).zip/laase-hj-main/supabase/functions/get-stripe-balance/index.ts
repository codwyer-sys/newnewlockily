import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;

    if (!user) {
      throw new Error('Unauthorized');
    }

    // Get Stripe account from database
    const { data: connectAccount, error: dbError } = await supabaseClient
      .from('stripe_connect_accounts')
      .select('*')
      .eq('locksmith_id', user.id)
      .maybeSingle();

    if (dbError || !connectAccount?.stripe_account_id) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'No connected account found' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const stripeAccountId = connectAccount.stripe_account_id;

    // Fetch balance from Stripe
    const balanceResponse = await fetch(`https://api.stripe.com/v1/balance`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('STRIPE SECRET')}`,
        'Stripe-Account': stripeAccountId,
      },
    });

    if (!balanceResponse.ok) {
      const error = await balanceResponse.text();
      console.error('Stripe balance fetch failed:', error);
      throw new Error('Failed to fetch balance from Stripe');
    }

    const balance = await balanceResponse.json();

    // Fetch payouts from Stripe
    const payoutsResponse = await fetch(`https://api.stripe.com/v1/payouts?limit=10`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('STRIPE SECRET')}`,
        'Stripe-Account': stripeAccountId,
      },
    });

    if (!payoutsResponse.ok) {
      const error = await payoutsResponse.text();
      console.error('Stripe payouts fetch failed:', error);
      throw new Error('Failed to fetch payouts from Stripe');
    }

    const payouts = await payoutsResponse.json();

    return new Response(
      JSON.stringify({ 
        success: true,
        balance: {
          available: balance.available?.[0]?.amount || 0,
          pending: balance.pending?.[0]?.amount || 0,
          currency: balance.available?.[0]?.currency || 'dkk'
        },
        payouts: payouts.data.map((payout: any) => ({
          id: payout.id,
          amount: payout.amount,
          status: payout.status,
          arrival_date: new Date(payout.arrival_date * 1000).toISOString(),
          description: payout.description || `Udbetaling ${payout.id}`,
          created: new Date(payout.created * 1000).toISOString()
        }))
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in get-stripe-balance:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});