import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Create Supabase client with JWT authentication
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    // Get the authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Authentication failed' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Verify user has locksmith role
    const { data: userRoles, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'locksmith')
      .single()

    if (roleError || !userRoles) {
      return new Response(
        JSON.stringify({ error: 'Locksmith role not found' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Parse request body early to validate
    const { 
      booking_id, 
      price, 
      estimated_arrival_minutes, 
      distance_km, 
      message, 
      locksmith_address
      // locksmith_id is now derived from auth.uid() for security
    } = await req.json()

    // Validate required fields
    if (!booking_id || !price || !estimated_arrival_minutes) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check for existing quote (optional - for preventing duplicates)
    const { data: existingQuote } = await supabase
      .from('quotes')
      .select('id')
      .eq('booking_id', booking_id)
      .eq('locksmith_id', user.id)
      .maybeSingle()

    if (existingQuote) {
      return new Response(
        JSON.stringify({ error: 'You have already submitted a bid for this job' }),
        { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Prepare quote data
    const quoteData = {
      booking_id,
      locksmith_id: user.id, // Use authenticated user ID for security
      price: parseFloat(price),
      estimated_arrival_minutes: parseInt(estimated_arrival_minutes),
      distance_km: distance_km || 0,
      message: message || null,
      status: 'pending',
      expires_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
      locksmith_address: locksmith_address || null
    }

    console.log('Creating quote with data:', quoteData)

    // Create the quote using service role
    const { data: quote, error: insertError } = await supabase
      .from('quotes')
      .insert(quoteData)
      .select()
      .single()

    if (insertError) {
      console.error('Error creating quote:', insertError)
      return new Response(
        JSON.stringify({ error: `Failed to create quote: ${insertError.message}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Quote created successfully:', quote)

    return new Response(
      JSON.stringify({ 
        success: true, 
        quote,
        message: 'Quote created successfully' 
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Unexpected error:', error)
    return new Response(
      JSON.stringify({ error: `Unexpected error: ${error.message}` }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})