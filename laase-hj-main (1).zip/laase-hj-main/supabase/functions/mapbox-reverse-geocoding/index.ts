import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { lat, lng } = await req.json();

    if (!lat || !lng) {
      throw new Error('Latitude and longitude are required');
    }

    const mapboxToken = Deno.env.get('MAPBOX_API_KEY');
    if (!mapboxToken) {
      throw new Error('MapBox API key not configured');
    }

    console.log(`[MapBox Reverse] Reverse geocoding for coordinates: ${lat}, ${lng}`);

    const response = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${lng},${lat}.json?access_token=${mapboxToken}&types=address,poi&limit=1`
    );

    if (!response.ok) {
      console.error(`[MapBox Reverse] HTTP Error: ${response.status} ${response.statusText}`);
      throw new Error(`MapBox API error: ${response.status}`);
    }

    const data = await response.json();
    console.log(`[MapBox Reverse] Response:`, JSON.stringify(data, null, 2));

    if (!data.features?.length) {
      console.log(`[MapBox Reverse] No address found for coordinates: ${lat}, ${lng}`);
      throw new Error('No address found for these coordinates');
    }

    const address = data.features[0].place_name;
    console.log(`[MapBox Reverse] Found address: ${address}`);

    return new Response(
      JSON.stringify({
        address,
        coordinates: { lat, lng },
        raw: data.features[0]
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('[MapBox Reverse] Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});