import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { postalCode } = await req.json();

    if (!postalCode || !/^\d{4}$/.test(postalCode)) {
      throw new Error('Valid 4-digit postal code is required');
    }

    const mapboxToken = Deno.env.get('MAPBOX_API_KEY');
    if (!mapboxToken) {
      throw new Error('MapBox API key not configured');
    }

    console.log(`[MapBox Postal] Looking up postal code: ${postalCode}`);

    // Search for the postal code in Denmark using MapBox Geocoding API
    const response = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${postalCode}.json?access_token=${mapboxToken}&country=dk&types=postcode&limit=1`
    );

    if (!response.ok) {
      console.error(`[MapBox Postal] HTTP Error: ${response.status} ${response.statusText}`);
      throw new Error(`MapBox API error: ${response.status}`);
    }

    const data = await response.json();
    console.log(`[MapBox Postal] Response:`, JSON.stringify(data, null, 2));

    if (!data.features?.length) {
      console.log(`[MapBox Postal] No results found for postal code: ${postalCode}`);
      return new Response(
        JSON.stringify({ 
          error: 'Postal code not found',
          postalCode 
        }),
        {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const feature = data.features[0];
    const coordinates = feature.center; // [longitude, latitude]
    const placeName = feature.place_name;
    
    // Extract city name from place_name (usually after the postal code)
    let cityName = 'Unknown';
    if (placeName) {
      const parts = placeName.split(',');
      if (parts.length > 1) {
        // Try to find the city name - usually the part after postal code
        cityName = parts[1]?.trim() || parts[0]?.trim();
        // Remove "Denmark" if it's at the end
        cityName = cityName.replace(/,?\s*Denmark\s*$/i, '');
      }
    }

    const result = {
      code: postalCode,
      city: cityName,
      municipality: cityName, // For backward compatibility
      coordinates: {
        latitude: coordinates[1],
        longitude: coordinates[0]
      },
      raw: feature
    };

    console.log(`[MapBox Postal] Found location for ${postalCode}: ${cityName}`);

    return new Response(
      JSON.stringify(result),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('[MapBox Postal] Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});