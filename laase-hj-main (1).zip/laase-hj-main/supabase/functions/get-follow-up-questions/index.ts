import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface GetFollowUpQuestionsRequest {
  job_category_id: string;
  language_code?: string;
  market_code?: string;
}

serve(async (req) => {
  const startTime = Date.now();
  console.log('🔍 get-follow-up-questions: Request received');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestBody: any = {};
  let responseBody: any = {};
  let statusCode = 200;

  try {
    requestBody = await req.json();
    const { job_category_id, language_code = 'da', market_code = 'DK' }: GetFollowUpQuestionsRequest = requestBody;
    
    console.log('🔍 get-follow-up-questions: Fetching questions for category:', job_category_id);

    if (!job_category_id) {
      return new Response(JSON.stringify({
        success: false,
        message: "Job kategori ID er påkrævet"
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get follow-up questions for this category and global questions
    const { data: questionsData, error: questionsError } = await supabase
      .from('follow_up_questions')
      .select('*')
      .or(`job_category_id.eq.${job_category_id},is_global.eq.true`)
      .order('order_index');
    
    if (questionsError) {
      console.error('🔍 get-follow-up-questions: Questions error:', questionsError);
      throw questionsError;
    }

    if (!questionsData || questionsData.length === 0) {
      return new Response(JSON.stringify({
        success: true,
        questions: [],
        message: "Ingen opfølgende spørgsmål for denne kategori"
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get translations
    const { data: translationsData, error: translationsError } = await supabase
      .from('follow_up_question_translations')
      .select('*')
      .eq('language_code', language_code)
      .eq('market_code', market_code)
      .in('follow_up_question_id', questionsData.map(q => q.id));
    
    if (translationsError) {
      console.error('🔍 get-follow-up-questions: Translations error:', translationsError);
      // Continue with original questions if translations fail
    }

    // Merge questions with translations
    const questions = questionsData.map(question => {
      const translation = translationsData?.find(t => t.follow_up_question_id === question.id);
      
      let options = undefined;
      if (question.options || translation?.options) {
        const optionsList = translation?.options || question.options;
        options = Array.isArray(optionsList) ? optionsList : 
                 (typeof optionsList === 'object' ? Object.values(optionsList) : []);
      }

      return {
        id: question.id,
        question_key: question.question_key,
        question: translation?.question || question.question,
        question_type: question.question_type,
        options: options,
        is_required: question.is_required,
        order_index: question.order_index
      };
    });

    // Format first question for voice conversation
    const firstQuestion = questions[0];
    let conversationText = firstQuestion.question;
    
    if (firstQuestion.options && firstQuestion.options.length > 0) {
      const optionsList = firstQuestion.options.map((option, index) => 
        `${index + 1}. ${option}`
      ).join('\n');
      conversationText += `\n\nValgmuligheder:\n${optionsList}`;
    }

    responseBody = {
      success: true,
      questions: questions,
      current_question: firstQuestion,
      conversation_text: conversationText,
      message: "Opfølgende spørgsmål hentet succesfuldt"
    };

    // Log the successful request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime);

    return new Response(JSON.stringify(responseBody), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('🔍 get-follow-up-questions: Error:', error);
    
    responseBody = {
      success: false,
      message: "Kunne ikke hente opfølgende spørgsmål"
    };
    statusCode = 500;
    
    // Log the failed request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, error.message);
    
    return new Response(JSON.stringify(responseBody), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper function to log webhook requests
async function logWebhookRequest(
  req: Request, 
  requestBody: any, 
  responseBody: any, 
  statusCode: number, 
  executionTime: number,
  errorMessage?: string
) {
  try {
    await supabase.from('webhook_logs').insert({
      function_name: 'get-follow-up-questions',
      request_method: req.method,
      request_url: req.url,
      request_headers: Object.fromEntries(req.headers.entries()),
      request_body: requestBody,
      response_status_code: statusCode,
      response_body: responseBody,
      execution_time_ms: executionTime,
      error_message: errorMessage,
      client_ip: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
      user_agent: req.headers.get('user-agent'),
      call_metadata: { job_category_id: requestBody.job_category_id }
    });
  } catch (logError) {
    console.error('Failed to log webhook request:', logError);
  }
}