import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

serve(async (req) => {
  console.log('🔍 get-function-logs: Request received');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { functions = [], timeRange = '1h', limit = 100 } = await req.json();
    
    console.log('🔍 get-function-logs: Fetching logs for functions:', functions, 'timeRange:', timeRange);

    // Calculate time filter based on timeRange
    let timeFilter = new Date();
    switch (timeRange) {
      case '1h':
        timeFilter.setHours(timeFilter.getHours() - 1);
        break;
      case '6h':
        timeFilter.setHours(timeFilter.getHours() - 6);
        break;
      case '24h':
        timeFilter.setHours(timeFilter.getHours() - 24);
        break;
      case '7d':
        timeFilter.setDate(timeFilter.getDate() - 7);
        break;
      default:
        timeFilter.setHours(timeFilter.getHours() - 1);
    }

    // Query our custom webhook_logs table first (most detailed logs)
    let query = supabase
      .from('webhook_logs')
      .select('*')
      .gte('created_at', timeFilter.toISOString())
      .order('created_at', { ascending: false })
      .limit(limit);

    if (functions.length > 0) {
      query = query.in('function_name', functions);
    }

    const { data: customLogs, error: customError } = await query;

    if (customError) {
      console.error('🔍 get-function-logs: Custom logs error:', customError);
    }

    // Transform custom logs to consistent format
    const transformedCustomLogs = (customLogs || []).map(log => ({
      id: log.id,
      timestamp: log.created_at,
      function_id: log.function_name,
      status_code: log.response_status_code || 200,
      execution_time_ms: log.execution_time_ms || 0,
      event_message: log.error_message || 'Function executed',
      request_method: log.request_method,
      success: (log.response_status_code || 200) < 400,
      request_headers: log.request_headers,
      request_body: log.request_body,
      response_headers: log.response_headers,
      response_body: log.response_body,
      error_stack: log.error_stack,
      client_ip: log.client_ip,
      user_agent: log.user_agent,
      call_metadata: log.call_metadata
    }));

    // Also try to get Supabase analytics logs as fallback
    let analyticsLogs = [];
    try {
      // This would be the analytics query, but for now we'll use our custom logs
      console.log('🔍 get-function-logs: Using custom webhook logs exclusively');
    } catch (analyticsError) {
      console.log('🔍 get-function-logs: Analytics not available, using custom logs only');
    }

    // Combine and sort all logs
    const allLogs = [...transformedCustomLogs, ...analyticsLogs]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);

    console.log(`🔍 get-function-logs: Returning ${allLogs.length} logs`);

    return new Response(
      JSON.stringify({
        logs: allLogs,
        total: allLogs.length,
        timeRange,
        functions
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('🔍 get-function-logs: Error:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        logs: [],
        total: 0 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});