import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface GetAvailableTimesRequest {
  urgency: string;
  preferred_date?: string;
}

serve(async (req) => {
  const startTime = Date.now();
  console.log('🔍 get-available-times: Request received');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestBody: any = {};
  let responseBody: any = {};
  let statusCode = 200;

  try {
    requestBody = await req.json();
    const { urgency, preferred_date }: GetAvailableTimesRequest = requestBody;
    
    console.log('🔍 get-available-times: Checking availability for urgency:', urgency);

    // Handle different urgency levels
    let response;
    const now = new Date();
    
    switch (urgency) {
      case 'nu':
      case 'asap':
      case 'emergency':
        response = {
          success: true,
          urgency: urgency,
          message: "Vi kommer til dig inden for 30-60 minutter. Vores akutteam er på vej.",
          estimated_arrival: "Inden for 30-60 minutter",
          next_steps: "Ring til 112 hvis det er et sikkerhedsmæssigt nødstilfælde. Ellers er hjælp på vej."
        };
        break;
        
      case 'scheduled':
      case 'senere':
        response = {
          success: true,
          urgency: urgency,
          message: "Vi kan planlægge et tidspunkt der passer dig. Vi er tilgængelige 24/7/365 fra 1,5 time fra nu.",
          available_slots: [
            "Fra 1,5 time fra nu",
            "I dag senere", 
            "I morgen",
            "Denne uge",
            "Næste uge",
            "Vælg selv dato og tid"
          ],
          estimated_arrival: "Efter aftale",
          next_steps: "Fortæl os hvornår det passer dig bedst - vi er fleksible"
        };
        break;
        
      default:
        response = {
          success: true,
          urgency: urgency,
          message: "Vi tilbyder to muligheder: akut hjælp nu eller planlagt besøg når det passer dig.",
          available_slots: [
            "Nu/ASAP - inden for 1 time",
            "Planlagt - fra 1,5 time og fremefter 24/7/365"
          ],
          estimated_arrival: "Afhænger af dit valg",
          next_steps: "Vælg om du har brug for akut hjælp eller om vi kan planlægge et tidspunkt"
        };
    }

    responseBody = response;

    // Log the successful request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime);

    return new Response(JSON.stringify(responseBody), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('🔍 get-available-times: Error:', error);
    
    responseBody = {
      success: false,
      message: "Kunne ikke hente ledige tider"
    };
    statusCode = 500;
    
    // Log the failed request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, error.message);
    
    return new Response(JSON.stringify(responseBody), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper function to log webhook requests
async function logWebhookRequest(
  req: Request, 
  requestBody: any, 
  responseBody: any, 
  statusCode: number, 
  executionTime: number,
  errorMessage?: string
) {
  try {
    await supabase.from('webhook_logs').insert({
      function_name: 'get-available-times',
      request_method: req.method,
      request_url: req.url,
      request_headers: Object.fromEntries(req.headers.entries()),
      request_body: requestBody,
      response_status_code: statusCode,
      response_body: responseBody,
      execution_time_ms: executionTime,
      error_message: errorMessage,
      client_ip: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
      user_agent: req.headers.get('user-agent'),
      call_metadata: { urgency: requestBody.urgency }
    });
  } catch (logError) {
    console.error('Failed to log webhook request:', logError);
  }
}