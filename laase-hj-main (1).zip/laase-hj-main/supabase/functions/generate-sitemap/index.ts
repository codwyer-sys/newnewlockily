import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'
import { corsHeaders } from '../_shared/cors.ts'

interface Tables {
  blog_posts: {
    Row: {
      slug: string
      market_code: string
      status: string
      updated_at: string
    }
  }
  content_pages: {
    Row: {
      page_key: string
      updated_at: string
    }
  }
  markets: {
    Row: {
      country_code: string
      country_name: string
    }
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const url = new URL(req.url)
    const market = url.searchParams.get('market') || 'DK'

    // Get blog posts for the market
    const { data: blogPosts } = await supabaseClient
      .from('blog_posts')
      .select('slug, updated_at')
      .eq('market_code', market)
      .eq('status', 'published')
      .order('updated_at', { ascending: false })

    // Get static pages
    const { data: contentPages } = await supabaseClient
      .from('content_pages')
      .select('page_key, updated_at')
      .order('updated_at', { ascending: false })

    // Get market info
    const { data: marketInfo } = await supabaseClient
      .from('markets')
      .select('country_name')
      .eq('country_code', market)
      .single()

    const baseUrl = getBaseUrl(market)
    const currentDate = new Date().toISOString()

    // Generate XML sitemap
    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xhtml="http://www.w3.org/1999/xhtml">
  
  <!-- Homepage -->
  <url>
    <loc>${baseUrl}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>

  <!-- Static Pages -->
  ${contentPages?.map(page => `
  <url>
    <loc>${baseUrl}/${page.page_key}</loc>
    <lastmod>${page.updated_at}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`).join('') || ''}

  <!-- Blog Posts -->
  ${blogPosts?.map(post => `
  <url>
    <loc>${baseUrl}/blog/${post.slug}</loc>
    <lastmod>${post.updated_at}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.6</priority>
  </url>`).join('') || ''}

  <!-- Service Pages -->
  <url>
    <loc>${baseUrl}/locksmith-services</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>

  <url>
    <loc>${baseUrl}/emergency-locksmith</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>

  <url>
    <loc>${baseUrl}/about</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>

  <url>
    <loc>${baseUrl}/contact</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.5</priority>
  </url>

</urlset>`

    // Store sitemap in database for caching
    await supabaseClient
      .from('seo_meta_tags')
      .upsert({
        page_path: '/sitemap.xml',
        market_code: market,
        meta_title: `${marketInfo?.country_name || 'Lockily'} Sitemap`,
        schema_markup: { 
          sitemap_generated_at: currentDate,
          total_urls: (blogPosts?.length || 0) + (contentPages?.length || 0) + 4
        }
      })

    return new Response(sitemap, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600'
      }
    })

  } catch (error) {
    console.error('Error generating sitemap:', error)
    return new Response(JSON.stringify({ error: 'Failed to generate sitemap' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})

function getBaseUrl(market: string): string {
  const domainMap: Record<string, string> = {
    'DK': 'https://lockily.dk',
    'UK': 'https://lockily.co.uk', 
    'DE': 'https://lockily.de',
    'US': 'https://lockily.com'
  }
  
  return domainMap[market] || 'https://lockily.com'
}