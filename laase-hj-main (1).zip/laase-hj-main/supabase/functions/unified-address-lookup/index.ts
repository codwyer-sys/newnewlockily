import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

// MapBox address service for all markets
class MapBoxAddressService {
  private marketCode: string;

  constructor(marketCode: string) {
    this.marketCode = marketCode;
  }

  async searchAddresses(query: string): Promise<any[]> {
    try {
      const mapboxToken = Deno.env.get('MAPBOX_API_KEY');
      if (!mapboxToken) {
        throw new Error('MapBox API key not configured');
      }

      console.log(`[MapBox] Searching for: "${query}" in market: ${this.marketCode}`);
      
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?access_token=${mapboxToken}&country=${this.marketCode.toLowerCase()}&limit=5&types=address,poi`
      );

      console.log(`[MapBox] Response status: ${response.status}`);
      
      if (!response.ok) {
        console.error(`[MapBox] HTTP Error: ${response.status} ${response.statusText}`);
        return [];
      }
      
      const data = await response.json();
      console.log(`[MapBox] Raw response:`, JSON.stringify(data, null, 2));
      
      if (!data.features?.length) {
        console.log(`[MapBox] No results for query: "${query}"`);
        return [];
      }
      
      const results = data.features.map((feature: any, index: number) => ({
        id: feature.id || `mapbox-${index}`,
        displayText: feature.place_name,
        fullAddress: feature.place_name,
        coordinates: {
          latitude: feature.center[1],
          longitude: feature.center[0]
        },
        metadata: { source: 'mapbox', context: feature.context }
      }));
      
      console.log(`[MapBox] Found ${results.length} results`);
      return results;
    } catch (error) {
      console.error('[MapBox] Search failed with error:', error);
      return [];
    }
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { query, marketCode } = await req.json();

    if (!query || !marketCode) {
      throw new Error('Query and marketCode are required');
    }

    console.log(`[unified-address-lookup] Searching for "${query}" in market "${marketCode}"`);

    // Get address provider configuration from database
    const { data: providerConfig, error: configError } = await supabase
      .from('address_provider_configs')
      .select('*')
      .eq('market_code', marketCode)
      .eq('is_enabled', true)
      .order('priority', { ascending: false })
      .limit(1)
      .single();

    if (configError && configError.code !== 'PGRST116') {
      console.error(`[unified-address-lookup] Error fetching provider config:`, configError);
    }

    // Always use MapBox for all markets
    console.log(`[unified-address-lookup] Using MapBox for market: ${marketCode}`);
    const service = new MapBoxAddressService(marketCode);
    const providerName = 'mapbox';

    const results = await service.searchAddresses(query);
    
    console.log(`[unified-address-lookup] Found ${results.length} results using ${providerName}`);

    return new Response(
      JSON.stringify({
        results,
        provider: providerName,
        marketCode
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('[unified-address-lookup] Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});