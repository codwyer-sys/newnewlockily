import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface SMSRequest {
  booking_id: string;
  phone_number: string;
  message_data: any;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🚀 [send-immediate-sms] Starting immediate SMS processing');
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { booking_id, phone_number, message_data } = await req.json() as SMSRequest;
    
    console.log(`📱 [send-immediate-sms] Processing SMS for booking ${booking_id} to ${phone_number}`);
    
    // Get Twilio credentials
    const twilioAccountSid = Deno.env.get('TWILIO_ACCOUNT_SID');
    const twilioAuthToken = Deno.env.get('TWILIO_AUTH_TOKEN');
    const twilioPhoneNumber = Deno.env.get('TWILIO_PHONE_NUMBER');

    if (!twilioAccountSid || !twilioAuthToken || !twilioPhoneNumber) {
      throw new Error('Missing Twilio credentials');
    }

    // Get market-specific SMS template
    const marketCode = message_data.market_code || 'DK';
    console.log(`🌍 [send-immediate-sms] Using market: ${marketCode}`);

    // Get SMS template from content translations
    const { data: smsTemplate } = await supabase
      .from('content_translations')
      .select('content_value')
      .eq('content_key', 'booking_confirmation_sms')
      .eq('language_code', marketCode === 'DK' ? 'da' : 'en')
      .eq('market_code', marketCode)
      .single();

    let messageText = smsTemplate?.content_value || 
      `Din låsesmed-booking er modtaget! Jobnummer: ${message_data.job_number}. Du vil snart blive kontaktet af en låsesmed.`;

    // Replace placeholders
    messageText = messageText
      .replace('{{JOB_NUMBER}}', message_data.job_number)
      .replace('{{ADDRESS}}', message_data.address);

    console.log(`📝 [send-immediate-sms] Message: ${messageText}`);

    // Send SMS via Twilio
    const twilioResponse = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${twilioAccountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${twilioAccountSid}:${twilioAuthToken}`)}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: twilioPhoneNumber,
          To: phone_number,
          Body: messageText,
        }),
      }
    );

    if (!twilioResponse.ok) {
      const errorData = await twilioResponse.text();
      console.error(`❌ [send-immediate-sms] Twilio error:`, errorData);
      throw new Error(`Twilio API error: ${twilioResponse.status} - ${errorData}`);
    }

    const twilioData = await twilioResponse.json();
    console.log(`✅ [send-immediate-sms] SMS sent successfully! SID: ${twilioData.sid}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message_sid: twilioData.sid,
        message: 'SMS sent immediately'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('❌ [send-immediate-sms] Error:', error);
    
    // Return error so the caller knows to fall back to queue system
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        should_queue: true 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});