import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AnalysisResult {
  jobType: string;
  confidence: number;
  followUpAnswers: Record<string, any>;
  explanation: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageUrl } = await req.json();
    
    if (!imageUrl) {
      throw new Error('Image URL is required');
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get OpenAI API key
    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    console.log('Analyzing image:', imageUrl);

    // Call OpenAI Vision API for image analysis
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are a professional locksmith expert analyzing lock-related images. 
            
Your task is to identify the type of lock problem and provide relevant information for a locksmith service booking.

Analyze the image and respond with a JSON object containing:
1. "jobType" - One of these exact categories:
   - "Udelukket (nøgle inde)" (Locked out with key inside)
   - "Udelukket (ingen nøgle)" (Locked out without key)
   - "Defekt lås" (Broken lock)
   - "Mistet nøgler" (Lost keys)
   - "Ødelagt nøgle" (Broken key)
   - "Udskiftning af lås" (Lock replacement)
   - "Låsoplukning bil" (Car lockout)
   - "Andet" (Other)

2. "confidence" - Float between 0 and 1 indicating how confident you are
3. "explanation" - Brief explanation of what you see and why you chose this category
4. "followUpAnswers" - Object with relevant pre-filled answers based on what you can see

Be conservative with confidence scores. Only give high confidence (>0.8) if you're very certain.`
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Please analyze this lock-related image and identify the problem type.'
              },
              {
                type: 'image_url',
                image_url: {
                  url: imageUrl
                }
              }
            ]
          }
        ],
        max_tokens: 500,
        temperature: 0.1
      }),
    });

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.error('OpenAI API error:', errorText);
      throw new Error(`OpenAI API error: ${openaiResponse.status}`);
    }

    const openaiData = await openaiResponse.json();
    const analysisText = openaiData.choices[0].message.content;
    
    console.log('OpenAI analysis result:', analysisText);

    let analysisResult: AnalysisResult;
    try {
      // Try to parse the JSON response
      analysisResult = JSON.parse(analysisText);
    } catch (parseError) {
      console.error('Failed to parse OpenAI response as JSON:', analysisText);
      // Fallback response
      analysisResult = {
        jobType: "Andet",
        confidence: 0.3,
        explanation: "Could not clearly identify the lock problem from the image.",
        followUpAnswers: {}
      };
    }

    // Validate the response structure
    if (!analysisResult.jobType || typeof analysisResult.confidence !== 'number') {
      throw new Error('Invalid analysis result structure');
    }

    // Ensure confidence is between 0 and 1
    analysisResult.confidence = Math.max(0, Math.min(1, analysisResult.confidence));

    // Store the analysis result for learning purposes
    const { error: insertError } = await supabase
      .from('image_analysis_logs')
      .insert({
        image_url: imageUrl,
        analysis_result: analysisResult,
        model_used: 'gpt-4o',
        created_at: new Date().toISOString()
      });

    if (insertError) {
      console.warn('Failed to log analysis result:', insertError);
      // Don't fail the request if logging fails
    }

    return new Response(JSON.stringify(analysisResult), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in analyze-lock-image function:', error);
    
    return new Response(JSON.stringify({ 
      error: 'Failed to analyze image',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});