import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface GetJobCategoriesRequest {
  language_code?: string;
  market_code?: string;
}

serve(async (req) => {
  const startTime = Date.now();
  console.log('🔍 get-job-categories: Request received');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestBody: any = {};
  let responseBody: any = {};
  let statusCode = 200;

  try {
    requestBody = await req.json();
    const { language_code = 'da', market_code = 'DK' }: GetJobCategoriesRequest = requestBody;
    
    console.log('🔍 get-job-categories: Fetching categories for language:', language_code, 'market:', market_code);

    // Get categories with translations in a single optimized query
    const { data: categoriesWithTranslations, error: queryError } = await supabase
      .from('job_categories')
      .select(`
        id,
        name,
        description,
        emoji,
        job_category_translations!left (
          name,
          description
        )
      `)
      .eq('job_category_translations.language_code', language_code)
      .eq('job_category_translations.market_code', market_code)
      .order('name');
    
    if (queryError) {
      console.error('🔍 get-job-categories: Query error:', queryError);
      throw queryError;
    }

    // Transform the joined data
    const categories = (categoriesWithTranslations || []).map(category => {
      const translation = category.job_category_translations?.[0];
      return {
        id: category.id,
        name: translation?.name || category.name,
        description: translation?.description || category.description,
        emoji: category.emoji
      };
    });

    // Format for voice conversation - create readable list
    const categoryList = categories.map((cat, index) => 
      `${index + 1}. ${cat.name}${cat.emoji ? ` ${cat.emoji}` : ''}`
    ).join('\n');

    responseBody = {
      success: true,
      categories: categories,
      category_list: `Jeg kan hjælpe dig med følgende låsesmede-opgaver:\n\n${categoryList}\n\nHvilken type opgave har du brug for hjælp til?`,
      message: "Job kategorier hentet succesfuldt"
    };

    // Log the successful request (fire-and-forget)
    logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime);

    return new Response(JSON.stringify(responseBody), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('🔍 get-job-categories: Error:', error);
    
    responseBody = {
      success: false,
      message: "Kunne ikke hente job kategorier"
    };
    statusCode = 500;
    
    // Log the failed request (fire-and-forget)
    logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, error.message);
    
    return new Response(JSON.stringify(responseBody), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper function to log webhook requests
async function logWebhookRequest(
  req: Request, 
  requestBody: any, 
  responseBody: any, 
  statusCode: number, 
  executionTime: number,
  errorMessage?: string
) {
  try {
    await supabase.from('webhook_logs').insert({
      function_name: 'get-job-categories',
      request_method: req.method,
      request_url: req.url,
      request_headers: Object.fromEntries(req.headers.entries()),
      request_body: requestBody,
      response_status_code: statusCode,
      response_body: responseBody,
      execution_time_ms: executionTime,
      error_message: errorMessage,
      client_ip: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
      user_agent: req.headers.get('user-agent'),
      call_metadata: {}
    });
  } catch (logError) {
    console.error('Failed to log webhook request:', logError);
  }
}