import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { paymentIntentId, email } = await req.json();
    
    if (!paymentIntentId || !email) {
      throw new Error("Payment Intent ID and email are required");
    }

    console.log(`🔧 Updating payment intent ${paymentIntentId} with email ${email}`);

    const stripe = new Stripe(Deno.env.get("STRIPE SECRET") || "", {
      apiVersion: "2023-10-16",
    });

    // Update the payment intent with the real email
    await stripe.paymentIntents.update(paymentIntentId, {
      receipt_email: email,
      metadata: {
        customer_email: email,
      },
    });

    console.log(`✅ Updated payment intent ${paymentIntentId} with email ${email}`);

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error("❌ Error updating payment email:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});