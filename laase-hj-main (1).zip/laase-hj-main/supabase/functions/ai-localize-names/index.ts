import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { names, targetLanguage, marketCode } = await req.json();
    
    if (!names || !Array.isArray(names) || names.length === 0) {
      throw new Error('Names array is required');
    }
    
    if (!targetLanguage) {
      throw new Error('Target language is required');
    }

    // Get OpenAI API key
    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    // Get AI settings from Supabase
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { data: settings } = await supabase
      .from('ai_translation_settings')
      .select('*')
      .single();

    // Create specialized prompt for location name localization
    const prompt = `You are a geographical name localization expert specializing in accurate place name spellings across different languages and markets.

TASK: Provide the native/local spelling of place names in ${targetLanguage} for the ${marketCode} market.

IMPORTANT RULES:
- Provide ONLY the native/local spelling as it appears in official documents, road signs, and local usage
- DO NOT translate the meaning - provide the actual local name/spelling
- If the place name is the same in both languages, return the same name
- If uncertain, provide the most commonly accepted local spelling
- Return only the name, no explanations

Examples:
- Copenhagen → København (Danish)
- Munich → München (German)  
- Florence → Firenze (Italian)
- London → London (same in most languages)

Place names to localize:
${names.map(name => `- ${name}`).join('\n')}

Return the results in this exact JSON format:
{
  "localizedNames": [
    { "original": "Copenhagen", "localized": "København" },
    { "original": "Munich", "localized": "München" }
  ]
}`;

    console.log('🌍 [AI Localize Names] Processing request:', { names, targetLanguage, marketCode });

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: settings?.model || 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You are a geographical name localization expert. Provide accurate local spellings of place names, not translations of their meanings.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: settings?.temperature || 0.1, // Low temperature for consistency
        max_tokens: settings?.max_tokens || 500,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0]?.message?.content;

    if (!content) {
      throw new Error('No response from AI');
    }

    console.log('🤖 [AI Localize Names] Raw AI response:', content);

    // Parse the JSON response
    let localizedNames;
    try {
      const parsed = JSON.parse(content);
      localizedNames = parsed.localizedNames || [];
    } catch (error) {
      console.error('❌ [AI Localize Names] Failed to parse JSON:', error);
      // Fallback: return original names if parsing fails
      localizedNames = names.map(name => ({ original: name, localized: name }));
    }

    console.log('✅ [AI Localize Names] Processed localizations:', localizedNames);

    return new Response(JSON.stringify({ localizedNames }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ [AI Localize Names] Error:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to localize names',
      localizedNames: []
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});