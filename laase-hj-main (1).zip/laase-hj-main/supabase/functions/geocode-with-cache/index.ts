import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { address } = await req.json()

    if (!address) {
      throw new Error('Address is required')
    }

    console.log('🔍 [geocode-with-cache] Processing address:', address)

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Check cache first
    const { data: cachedResult, error: cacheError } = await supabase
      .from('geocoding_cache')
      .select('latitude, longitude, created_at')
      .eq('address', address)
      .gt('expires_at', new Date().toISOString())
      .maybeSingle()

    if (cacheError) {
      console.error('Cache lookup error:', cacheError)
    }

    if (cachedResult) {
      console.log('🎯 [geocode-with-cache] Cache hit for:', address)
      return new Response(
        JSON.stringify({
          latitude: parseFloat(cachedResult.latitude),
          longitude: parseFloat(cachedResult.longitude),
          cached: true,
          cached_at: cachedResult.created_at
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      )
    }

    console.log('🔍 [geocode-with-cache] Cache miss, calling MapBox API for:', address)

    // Not in cache or expired, call MapBox API
    const mapboxToken = Deno.env.get('MAPBOX_API_KEY')
    if (!mapboxToken) {
      throw new Error('MapBox API key not configured')
    }

    const geocodeResponse = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${mapboxToken}&country=dk&limit=1`
    )

    if (!geocodeResponse.ok) {
      throw new Error('Failed to geocode address')
    }

    const geocodeData = await geocodeResponse.json()

    if (!geocodeData.features?.length) {
      throw new Error('Could not find coordinates for address')
    }

    const [longitude, latitude] = geocodeData.features[0].center

    // Store in cache
    const { error: insertError } = await supabase
      .from('geocoding_cache')
      .insert({
        address,
        latitude,
        longitude
      })

    if (insertError) {
      console.error('Failed to cache geocoding result:', insertError)
      // Don't fail the request if caching fails
    } else {
      console.log('✅ [geocode-with-cache] Cached new result for:', address)
    }

    return new Response(
      JSON.stringify({
        latitude,
        longitude,
        cached: false
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (error) {
    console.error('Geocoding error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})