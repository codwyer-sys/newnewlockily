import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface SMSTemplate {
  message: string
  link_text: string
}

// Helper function to get SMS template from content management
async function getSMSTemplate(
  supabase: any,
  marketCode: string,
  languageCode?: string
): Promise<SMSTemplate> {
  // Use provided language code, or fallback to market default
  const effectiveLanguageCode = languageCode || (marketCode === 'DK' ? 'da' : 'en')
  
  // Get SMS templates from content management using correct section key
  const { data: messageData } = await supabase
    .from('content_translations')
    .select(`
      content_value,
      content_sections!inner (
        section_key,
        content_pages!inner (
          page_key
        )
      )
    `)
    .eq('content_key', 'job_created_message')
    .eq('language_code', effectiveLanguageCode)
    .or(`market_code.is.null,market_code.eq.${marketCode}`)
    .eq('content_sections.section_key', 'sms_job_created')
    .eq('content_sections.content_pages.page_key', 'sms_notifications')
    .single()

  const { data: linkData } = await supabase
    .from('content_translations')
    .select(`
      content_value,
      content_sections!inner (
        section_key,
        content_pages!inner (
          page_key
        )
      )
    `)
    .eq('content_key', 'job_created_link_text')
    .eq('language_code', effectiveLanguageCode)
    .or(`market_code.is.null,market_code.eq.${marketCode}`)
    .eq('content_sections.section_key', 'sms_job_created')
    .eq('content_sections.content_pages.page_key', 'sms_notifications')
    .single()

  return {
    message: messageData?.content_value || 'Your locksmith job #{{JOB_NUMBER}} has been created! View status: {{BOOKING_LINK}} - Lockily',
    link_text: linkData?.content_value || 'Track Booking'
  }
}

// Helper function to format phone number for international SMS
function formatPhoneNumber(phone: string, marketCode: string): string {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '')
  
  // Add country code based on market if not present
  if (marketCode === 'DK' && !digits.startsWith('45') && digits.length === 8) {
    return `+45${digits}`
  } else if (marketCode === 'UK' && !digits.startsWith('44') && digits.length === 11 && digits.startsWith('0')) {
    return `+44${digits.substring(1)}`
  } else if (marketCode === 'US' && !digits.startsWith('1') && digits.length === 10) {
    return `+1${digits}`
  } else if (marketCode === 'DE' && !digits.startsWith('49') && digits.length >= 10) {
    return `+49${digits}`
  } else if (digits.startsWith('+')) {
    return digits
  } else {
    return `+${digits}`
  }
}

// Helper function to send SMS via Twilio
async function sendTwilioSMS(to: string, message: string, fromValue: string): Promise<{ success: boolean; messageId?: string; error?: string }> {
  const accountSid = Deno.env.get('TWILIO_ACCOUNT_SID')
  const authToken = Deno.env.get('TWILIO_AUTH_TOKEN')

  if (!accountSid || !authToken) {
    throw new Error('Twilio credentials not configured')
  }

  try {
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${btoa(`${accountSid}:${authToken}`)}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          To: to,
          From: fromValue,
          Body: message,
        }),
      }
    )

    const result = await response.json()

    if (response.ok) {
      return {
        success: true,
        messageId: result.sid
      }
    } else {
      return {
        success: false,
        error: result.message || 'Failed to send SMS'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    console.log('📱 process-sms-queue: Starting SMS queue processing')

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Get pending SMS items from the queue
    const { data: queueItems, error: queueError } = await supabase
      .from('sms_notification_queue')
      .select('*')
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
      .limit(10) // Process up to 10 items at a time

    if (queueError) {
      console.error('📱 process-sms-queue: Error fetching queue items:', queueError)
      return new Response(JSON.stringify({ error: 'Failed to fetch queue items' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    console.log(`📱 process-sms-queue: Found ${queueItems?.length || 0} pending SMS items`)

    if (!queueItems || queueItems.length === 0) {
      return new Response(JSON.stringify({ message: 'No pending SMS items', processed: 0 }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    const results = []
    
    // Process each SMS item
    for (const item of queueItems) {
      try {
        console.log(`📱 process-sms-queue: Processing SMS for booking ${item.booking_id}`)
        
        // Mark as processing
        const { error: markError } = await supabase.rpc('mark_sms_processing', { queue_id: item.id })
        if (markError) {
          console.error('📱 process-sms-queue: Error marking as processing:', markError)
          continue
        }

        const messageData = item.message_data
        const marketCode = messageData.market_code || 'DK'
        
        // Extract language preference from follow_up_answers if available
        const preferredLanguage = messageData.follow_up_answers?.preferredLanguage
        console.log(`📱 process-sms-queue: Processing booking ${item.booking_id}, preferred language: ${preferredLanguage}, market: ${marketCode}`)
        
        // Get SMS template and settings with user's preferred language
        const template = await getSMSTemplate(supabase, marketCode, preferredLanguage)
        
        // Get SMS settings for sender name
        const { data: smsSettings } = await supabase
          .from('sms_notification_settings')
          .select('sender_name')
          .eq('market_code', marketCode)
          .single()
        
        // Generate booking status URL  
        const bookingStatusUrl = `https://pysmpkinlgpqowmlwttr.lovable.app/${marketCode.toLowerCase()}/booking-status/${messageData.booking_id}`
        
        // Extract customer name from follow_up_answers for new template variables
        const customerName = messageData.follow_up_answers?.customerName || 'Customer'
        
        // Replace template variables - handle both old and new template formats
        let smsMessage = template.message
        
        // New template variables (if present)
        if (template.message.includes('{{customerName}}')) {
          smsMessage = smsMessage
            .replace('{{customerName}}', customerName)
            .replace('{{bookingLink}}', bookingStatusUrl)
        }
        
        // Old template variables (fallback)
        smsMessage = smsMessage
          .replace('{{JOB_NUMBER}}', messageData.job_number?.toString() || 'N/A')
          .replace('{{BOOKING_LINK}}', bookingStatusUrl)
          .replace('{{ADDRESS}}', messageData.address || '')

        // Format phone number
        const formattedPhone = formatPhoneNumber(item.phone_number, marketCode)
        
        // Use sender name from settings, fallback to phone number if not available
        const fromValue = smsSettings?.sender_name || Deno.env.get('TWILIO_PHONE_NUMBER') || 'Lockily'
        
        console.log(`📱 process-sms-queue: Sending SMS to ${formattedPhone} from ${fromValue}`)
        
        // Send SMS via Twilio
        const smsResult = await sendTwilioSMS(formattedPhone, smsMessage, fromValue)
        
        if (smsResult.success) {
          // Mark as sent
          await supabase.rpc('mark_sms_sent', { queue_id: item.id })
          console.log(`📱 process-sms-queue: SMS sent successfully for booking ${item.booking_id}`)
          results.push({ booking_id: item.booking_id, status: 'sent', message_id: smsResult.messageId })
        } else {
          // Mark as failed
          await supabase.rpc('mark_sms_failed', { queue_id: item.id, error_msg: smsResult.error })
          console.error(`📱 process-sms-queue: SMS failed for booking ${item.booking_id}:`, smsResult.error)
          results.push({ booking_id: item.booking_id, status: 'failed', error: smsResult.error })
        }
        
      } catch (error) {
        console.error(`📱 process-sms-queue: Error processing SMS for item ${item.id}:`, error)
        // Mark as failed
        await supabase.rpc('mark_sms_failed', { queue_id: item.id, error_msg: error.message })
        results.push({ booking_id: item.booking_id, status: 'failed', error: error.message })
      }
    }

    console.log(`📱 process-sms-queue: Processed ${results.length} SMS items`)

    return new Response(JSON.stringify({
      message: 'SMS queue processing completed',
      processed: results.length,
      results
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })

  } catch (error) {
    console.error('📱 process-sms-queue: Error:', error)
    
    return new Response(JSON.stringify({
      success: false,
      message: 'Internal server error',
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})