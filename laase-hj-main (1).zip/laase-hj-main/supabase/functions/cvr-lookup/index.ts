
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { corsHeaders } from '../_shared/cors.ts'

interface CVRResponse {
  vat: number;
  name: string;
  address: string;
  zipcode: string;
  city: string;
  phone: string;
  email: string;
  protected: boolean;
  startdate: string;
  enddate: string | null;
  employees: number;
  addressco: string;
  industrycode: number;
  industrydesc: string;
  companycode: number;
  companydesc: string;
  creditstartdate: string | null;
  creditbankrupt: boolean;
  creditstatus: string | null;
  owners: any;
  productionunits: any[];
  t: number;
  version: number;
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { cvr } = await req.json()
    console.log('CVR lookup request:', cvr)

    if (!cvr || cvr.length !== 8) {
      console.log('Invalid CVR number:', cvr)
      return new Response(
        JSON.stringify({ error: 'CVR number must be 8 digits' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Call CVRAPI with correct parameters
    const apiUrl = `https://cvrapi.dk/api?vat=${cvr}&country=dk`
    console.log('Calling CVR API:', apiUrl)
    
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'CODwyer - LocksmithPlatform - Christian ODwyer c@codwyer.me'
      }
    })

    console.log('CVR API response status:', response.status)
    
    if (!response.ok) {
      console.error('CVR API request failed:', response.status, response.statusText)
      throw new Error(`CVR API request failed: ${response.status} ${response.statusText}`)
    }

    const data: CVRResponse = await response.json()
    console.log('CVR API response data:', JSON.stringify(data, null, 2))

    // Check if company exists and is active
    // The API returns data if company exists, no data or error if it doesn't
    if (!data.name || !data.vat) {
      console.log('Company not found - no name or VAT in response')
      return new Response(
        JSON.stringify({ error: 'Company not found' }),
        { 
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Check if company is inactive (has end date)
    if (data.enddate) {
      console.log('Company is inactive - has end date:', data.enddate)
      return new Response(
        JSON.stringify({ error: 'Company is inactive' }),
        { 
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Return formatted company data with fallback values
    const companyData = {
      company_name: data.name || '',
      address: data.address || '',
      postal_code: data.zipcode || '',
      city: data.city || '',
      phone: data.phone || '',
      email: data.email || ''
    }

    console.log('Returning company data:', companyData)

    return new Response(
      JSON.stringify(companyData),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )

  } catch (error) {
    console.error('CVR lookup error:', error)
    return new Response(
      JSON.stringify({ error: 'Failed to lookup CVR number' }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
