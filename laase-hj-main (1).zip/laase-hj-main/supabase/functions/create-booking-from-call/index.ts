import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface CreateBookingRequest {
  address: string;
  urgency: string;
  job_category_id: string;
  follow_up_answers: Record<string, any>;
  caller_phone_number: string;
  caller_name?: string;
  call_id?: string;
  call_duration_seconds?: number;
  call_transcription?: string;
  scheduled_date?: string;
  market_code?: string;
}

serve(async (req) => {
  const startTime = Date.now();
  console.log('🔍 create-booking-from-call: Request received');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestBody: any = {};
  let responseBody: any = {};
  let statusCode = 200;

  try {
    requestBody = await req.json();
    const {
      address,
      urgency,
      job_category_id,
      follow_up_answers,
      caller_phone_number,
      caller_name,
      call_id,
      call_duration_seconds,
      call_transcription,
      scheduled_date,
      market_code = 'DK'
    }: CreateBookingRequest = requestBody;
    
    console.log('🔍 create-booking-from-call: Creating booking for:', caller_phone_number);

    // Validate required fields
    if (!address || !urgency || !job_category_id || !caller_phone_number) {
      return new Response(JSON.stringify({
        success: false,
        message: "Manglende påkrævede felter: adresse, urgency, job kategori og telefonnummer"
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Validate job category exists
    const { data: jobCategory, error: categoryError } = await supabase
      .from('job_categories')
      .select('id, name')
      .eq('id', job_category_id)
      .maybeSingle();

    if (categoryError) {
      console.error('🔍 create-booking-from-call: Category error:', categoryError);
      throw categoryError;
    }

    if (!jobCategory) {
      return new Response(JSON.stringify({
        success: false,
        message: `Job kategori ikke fundet: ${job_category_id}`
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Prepare follow-up answers with caller info
    const enhancedFollowUpAnswers = {
      ...follow_up_answers,
      customerPhone: caller_phone_number,
      customerName: caller_name || 'Telefon kunde',
      callSource: true
    };

    // Create the booking
    const { data: booking, error: bookingError } = await supabase
      .from('bookings')
      .insert({
        address: address,
        urgency: urgency,
        job_category_id: job_category_id,
        job_type: jobCategory.name, // For backwards compatibility
        follow_up_answers: enhancedFollowUpAnswers,
        booking_source: 'phone',
        caller_phone_number: caller_phone_number,
        call_id: call_id,
        call_duration_seconds: call_duration_seconds,
        call_transcription: call_transcription,
        call_metadata: {
          caller_name: caller_name,
          market_code: market_code,
          created_via_ai: true
        },
        scheduled_date: scheduled_date ? new Date(scheduled_date).toISOString() : null,
        market: market_code,
        status: 'waiting_for_quotes'
      })
      .select()
      .single();

    if (bookingError) {
      console.error('🔍 create-booking-from-call: Booking error:', bookingError);
      throw bookingError;
    }

    console.log('🔍 create-booking-from-call: Booking created successfully:', booking.id);

    // Format response for voice conversation
    let responseMessage = `Perfekt! Din booking er nu oprettet med reference nummer ${booking.id.slice(-8)}.`;
    
    if (urgency === 'nu' || urgency === 'emergency') {
      responseMessage += ` Vi sender en låsesmed til ${address} inden for 30 minutter.`;
    } else if (scheduled_date) {
      const scheduledDateTime = new Date(scheduled_date);
      responseMessage += ` Vi kommer til ${address} den ${scheduledDateTime.toLocaleDateString('da-DK')} klokken ${scheduledDateTime.toLocaleTimeString('da-DK', { hour: '2-digit', minute: '2-digit' })}.`;
    } else {
      responseMessage += ` Vi kontakter dig snarest på ${caller_phone_number} for at aftale et tidspunkt.`;
    }

    responseMessage += ` Du vil modtage en SMS bekræftelse på ${caller_phone_number}. Tak for din henvendelse!`;

    responseBody = {
      success: true,
      booking: {
        id: booking.id,
        reference_number: booking.id.slice(-8),
        address: booking.address,
        urgency: booking.urgency,
        job_category: jobCategory.name,
        status: booking.status
      },
      message: responseMessage,
      next_steps: urgency === 'nu' || urgency === 'emergency' 
        ? "Hjælp er på vej inden for 30 minutter"
        : "Vi kontakter dig for at bekræfte tidspunktet"
    };
    
    // Log the successful request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, {
      booking_id: booking.id,
      caller_phone_number,
      call_id
    });

    return new Response(JSON.stringify(responseBody), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('🔍 create-booking-from-call: Error:', error);
    
    responseBody = {
      success: false,
      message: "Der opstod en fejl ved oprettelse af bookingen. Prøv venligst igen."
    };
    statusCode = 500;
    
    // Log the failed request
    await logWebhookRequest(req, requestBody, responseBody, statusCode, Date.now() - startTime, {}, error.message);
    
    return new Response(JSON.stringify(responseBody), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper function to log webhook requests
async function logWebhookRequest(
  req: Request, 
  requestBody: any, 
  responseBody: any, 
  statusCode: number, 
  executionTime: number,
  callMetadata: any = {},
  errorMessage?: string
) {
  try {
    await supabase.from('webhook_logs').insert({
      function_name: 'create-booking-from-call',
      request_method: req.method,
      request_url: req.url,
      request_headers: Object.fromEntries(req.headers.entries()),
      request_body: requestBody,
      response_status_code: statusCode,
      response_body: responseBody,
      execution_time_ms: executionTime,
      error_message: errorMessage,
      client_ip: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
      user_agent: req.headers.get('user-agent'),
      call_metadata: callMetadata
    });
  } catch (logError) {
    console.error('Failed to log webhook request:', logError);
  }
}