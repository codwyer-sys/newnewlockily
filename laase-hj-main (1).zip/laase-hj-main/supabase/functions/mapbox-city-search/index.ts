import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MapboxCity {
  id: string;
  name: string;
  country: string;
  countryCode?: string;
  population?: number;
  latitude?: number;
  longitude?: number;
  region?: string;
  administrativeLevel?: string;
  localNames?: { [languageCode: string]: string };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🚀 Mapbox city search function called');
    
    // Validate API key first
    const mapboxToken = Deno.env.get('MAPBOX_API_KEY');
    if (!mapboxToken) {
      console.error('❌ MAPBOX_API_KEY not found in environment');
      return new Response(JSON.stringify({ error: 'Mapbox API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    console.log('✅ Mapbox API key found, length:', mapboxToken.length);
    
    const { query, action, cityId, marketCode } = await req.json();
    console.log('📝 Request params:', { query, action, cityId, marketCode });

    if (action === 'search') {
      return await searchCities(query, marketCode);
    } else if (action === 'details' && cityId) {
      return await getCityDetails(cityId, marketCode);
    } else {
      console.error('❌ Invalid action or missing parameters:', { action, cityId });
      return new Response(JSON.stringify({ error: 'Invalid action or missing parameters' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  } catch (error) {
    console.error('❌ Error in mapbox-city-search:', error);
    return new Response(JSON.stringify({ 
      error: error.message || 'Unknown error occurred',
      details: error.stack 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function searchCities(query: string, marketCode?: string) {
  const mapboxToken = Deno.env.get('MAPBOX_API_KEY');
  if (!mapboxToken) {
    throw new Error('Mapbox API key not configured');
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);

  try {
    console.log(`🔍 Searching for cities with query: "${query}", market: ${marketCode}`);
    
    // Step 1: Search for cities only in English
    const encodedQuery = encodeURIComponent(query);
    const englishParams = new URLSearchParams({
      access_token: mapboxToken,
      types: 'place', // Only cities, not localities or districts
      limit: '10',
      language: 'en', // Force English for primary search
    });

    // Add country filter only if market is specified and not global search
    if (marketCode && marketCode !== 'ALL') {
      const countryCode = getCountryCodeForMarket(marketCode);
      if (countryCode) {
        englishParams.append('country', countryCode);
        console.log(`🌍 Added country filter: ${countryCode} for market: ${marketCode}`);
      }
    } else {
      console.log('🌍 Global search - no country filter applied');
    }

    const englishUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodedQuery}.json?${englishParams}`;
    console.log('📡 Making English request to:', englishUrl.replace(mapboxToken, 'TOKEN_HIDDEN'));

    const englishResponse = await fetch(englishUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Lockily-City-Search/1.0'
      }
    });

    if (!englishResponse.ok) {
      const errorText = await englishResponse.text();
      console.error('❌ Mapbox API error response:', errorText);
      
      if (englishResponse.status === 401) {
        throw new Error('Mapbox API key is invalid or expired');
      } else if (englishResponse.status === 403) {
        throw new Error('Mapbox API key does not have geocoding permissions');
      } else if (englishResponse.status === 429) {
        throw new Error('Mapbox API rate limit exceeded');
      }
      
      throw new Error(`Mapbox API error: ${englishResponse.status} ${englishResponse.statusText} - ${errorText}`);
    }

    const englishData = await englishResponse.json();
    
    if (!englishData.features) {
      console.error('❌ Invalid Mapbox response structure:', englishData);
      throw new Error('Invalid response from Mapbox - missing features array');
    }

    // Step 2: Get localized names using dual approach
    let localizedFeatures: any[] = [];
    const marketLanguage = getLanguageForMarket(marketCode);
    
    if (marketCode && marketCode !== 'ALL' && marketLanguage !== 'en') {
      console.log(`🌍 Fetching localized names in language: ${marketLanguage}`);
      
      // Approach 1: Direct search in target language for better accuracy
      try {
        const localParams = new URLSearchParams({
          access_token: mapboxToken,
          types: 'place', // Cities only
          limit: '5',
          language: marketLanguage,
        });

        if (marketCode && marketCode !== 'ALL') {
          const countryCode = getCountryCodeForMarket(marketCode);
          if (countryCode) {
            localParams.append('country', countryCode);
          }
        }

        const localUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodedQuery}.json?${localParams}`;
        const localResponse = await fetch(localUrl, {
          signal: controller.signal,
          headers: {
            'User-Agent': 'Lockily-City-Search/1.0'
          }
        });

        if (localResponse.ok) {
          const localData = await localResponse.json();
          
          // Match local results with English results by proximity
          for (const englishFeature of englishData.features) {
            const [engLng, engLat] = englishFeature.center;
            let bestMatch = null;
            let minDistance = Infinity;
            
            for (const localFeature of localData.features || []) {
              const [localLng, localLat] = localFeature.center;
              const distance = Math.sqrt(
                Math.pow(engLng - localLng, 2) + Math.pow(engLat - localLat, 2)
              );
              
              // Only consider matches within ~5km (rough approximation)
              if (distance < 0.05 && distance < minDistance) {
                minDistance = distance;
                bestMatch = localFeature;
              }
            }
            
            if (bestMatch) {
              localizedFeatures.push({
                ...bestMatch,
                _originalEnglishId: englishFeature.id
              });
              console.log(`✅ Direct match: ${bestMatch.text} for ${englishFeature.text}`);
            } else {
              localizedFeatures.push(null);
            }
          }
        } else {
          console.warn('Local search failed, falling back to reverse geocoding');
          localizedFeatures = new Array(englishData.features.length).fill(null);
        }
      } catch (error) {
        console.warn(`Direct local search failed: ${error.message}`);
        localizedFeatures = new Array(englishData.features.length).fill(null);
      }
      
      // Approach 2: Fallback to reverse geocoding for unmatched cities
      for (let i = 0; i < englishData.features.length; i++) {
        if (localizedFeatures[i] === null) {
          const englishFeature = englishData.features[i];
          const [longitude, latitude] = englishFeature.center;
          
          try {
            const reverseParams = new URLSearchParams({
              access_token: mapboxToken,
              types: 'place', // Cities only
              language: marketLanguage,
            });

            const reverseUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${longitude},${latitude}.json?${reverseParams}`;
            
            const localizedResponse = await fetch(reverseUrl, {
              signal: controller.signal,
              headers: {
                'User-Agent': 'Lockily-City-Search/1.0'
              }
            });

            if (localizedResponse.ok) {
              const localizedData = await localizedResponse.json();
              const localizedFeature = localizedData.features?.[0];
              
              // Validate the localized name isn't generic
              if (localizedFeature && isValidCityName(localizedFeature.text, englishFeature.text)) {
                localizedFeatures[i] = {
                  ...localizedFeature,
                  _originalEnglishId: englishFeature.id
                };
                console.log(`✅ Reverse geocoding: ${localizedFeature.text} for ${englishFeature.text}`);
              } else {
                console.log(`⚠️ Invalid local name rejected: ${localizedFeature?.text} for ${englishFeature.text}`);
              }
            }
          } catch (error) {
            console.warn(`⚠️ Failed reverse geocoding for ${englishFeature.text}: ${error.message}`);
          }
        }
      }
    }

    // Step 3: Filter and combine English and localized data
    const filteredFeatures = englishData.features.filter((feature: any) => {
      // Only include actual cities with reasonable population estimates
      const estimatedPop = estimatePopulation(feature);
      const isCity = feature.place_type?.[0] === 'place';
      
      return isCity && (!estimatedPop || estimatedPop >= 10000);
    });

    const cities: MapboxCity[] = filteredFeatures.map((feature: any, index: number) => {
      const [longitude, latitude] = feature.center;
      const countryContext = feature.context?.find((ctx: any) => ctx.id.startsWith('country'));
      const regionContext = feature.context?.find((ctx: any) => ctx.id.startsWith('region'));
      
      // Find corresponding localized feature
      const originalIndex = englishData.features.indexOf(feature);
      const localizedFeature = localizedFeatures[originalIndex];
      let localizedName = null;
      
      if (localizedFeature && localizedFeature.text !== feature.text) {
        localizedName = localizedFeature.text;
      }
      
      const cityData: MapboxCity = {
        id: feature.id,
        name: feature.text, // Always English name as primary
        country: countryContext?.text || 'Unknown',
        countryCode: countryContext?.short_code?.toUpperCase(),
        latitude,
        longitude,
        region: regionContext?.text,
        administrativeLevel: feature.place_type?.[0],
        population: estimatePopulation(feature),
      };

      // Add localized name if available and different
      if (localizedName && marketLanguage) {
        cityData.localNames = {
          [marketLanguage]: localizedName
        };
        console.log(`🔄 Mapped: EN:"${feature.text}" → ${marketLanguage.toUpperCase()}:"${localizedName}"`);
      } else {
        console.log(`📝 Single name: "${feature.text}" (no local variant)`);
      }

      return cityData;
    });

    console.log(`✅ Found ${cities.length} cities for query: "${query}"`);
    
    return new Response(JSON.stringify({ cities }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    clearTimeout(timeoutId);
    console.error('❌ Search cities error:', error);
    
    if (error.name === 'AbortError') {
      console.log('⏰ Request timed out after 10 seconds');
      return new Response(JSON.stringify({ 
        error: 'Search timed out - please try a shorter, more specific query',
        cities: []
      }), {
        status: 408,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to search cities',
      cities: [],
      errorType: error.name,
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function getCityDetails(cityId: string, marketCode?: string) {
  const mapboxToken = Deno.env.get('MAPBOX_API_KEY');
  if (!mapboxToken) {
    throw new Error('Mapbox API key not configured');
  }

  try {
    console.log(`🔍 Getting details for city ID: ${cityId}, market: ${marketCode}`);
    
    // Step 1: Get English details
    const englishResponse = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${cityId}.json?access_token=${mapboxToken}&language=en`);
    
    if (!englishResponse.ok) {
      throw new Error(`Mapbox details query failed: ${englishResponse.statusText}`);
    }

    const englishData = await englishResponse.json();
    const englishFeature = englishData.features?.[0];
    
    if (!englishFeature) {
      throw new Error('City not found in Mapbox');
    }

    const [longitude, latitude] = englishFeature.center;
    const countryContext = englishFeature.context?.find((ctx: any) => ctx.id.startsWith('country'));
    const regionContext = englishFeature.context?.find((ctx: any) => ctx.id.startsWith('region'));

    // Step 2: Get localized name if market language is different from English  
    let localizedName = null;
    const marketLanguage = getLanguageForMarket(marketCode);
    
    if (marketCode && marketLanguage !== 'en') {
      console.log(`🌍 Getting localized name in language: ${marketLanguage}`);
      
      try {
        // Use reverse geocoding with strict city-level filtering
        const localizedResponse = await fetch(
          `https://api.mapbox.com/geocoding/v5/mapbox.places/${longitude},${latitude}.json?access_token=${mapboxToken}&language=${marketLanguage}&types=place`
        );

        if (localizedResponse.ok) {
          const localizedData = await localizedResponse.json();
          const localizedFeature = localizedData.features?.[0];
          
          if (localizedFeature && 
              localizedFeature.text !== englishFeature.text && 
              isValidCityName(localizedFeature.text, englishFeature.text)) {
            localizedName = localizedFeature.text;
            console.log(`✅ Got localized name: ${localizedName} for ${englishFeature.text}`);
          } else if (localizedFeature) {
            console.log(`⚠️ Rejected invalid local name: ${localizedFeature.text} for ${englishFeature.text}`);
          }
        }
      } catch (error) {
        console.warn(`⚠️ Failed to get localized name: ${error.message}`);
      }
    }

    const city: MapboxCity = {
      id: englishFeature.id,
      name: englishFeature.text, // Always English name as primary
      country: countryContext?.text || 'Unknown',
      countryCode: countryContext?.short_code?.toUpperCase(),
      latitude,
      longitude,
      region: regionContext?.text,
      administrativeLevel: englishFeature.place_type?.[0],
      population: estimatePopulation(englishFeature),
    };

    // Add localized name if available and different
    if (localizedName && marketLanguage) {
      city.localNames = {
        [marketLanguage]: localizedName
      };
    }

    console.log(`✅ City details retrieved: ${city.name}${city.localNames ? ` (${Object.values(city.localNames)[0]})` : ''}`);

    return new Response(JSON.stringify({ city }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('❌ Get city details error:', error);
    throw error;
  }
}

function getLanguageForMarket(marketCode?: string): string {
  const languageMap: { [key: string]: string } = {
    'DK': 'da',
    'DE': 'de',
    'SE': 'sv',
    'NO': 'no',
    'GB': 'en',
    'UK': 'en',
    'US': 'en',
    'CA': 'en',
    'FR': 'fr',
    'ES': 'es',
    'IT': 'it',
    'PL': 'pl',
    'PT': 'pt',
    'FI': 'fi',
    'CZ': 'cs',
    'IE': 'en',
  };
  
  return languageMap[marketCode || ''] || 'en';
}

function getCountryCodeForMarket(marketCode: string): string | null {
  const countryMap: { [key: string]: string } = {
    'DK': 'dk',
    'DE': 'de', 
    'GB': 'gb',
    'UK': 'gb',
    'US': 'us',
    'SE': 'se',
    'NO': 'no',
    'IE': 'ie',
    'FR': 'fr',
    'ES': 'es',
    'PL': 'pl',
    'CA': 'ca',
    'PT': 'pt',
    'IT': 'it',
    'FI': 'fi',
    'CZ': 'cz',
  };
  
  return countryMap[marketCode] || null;
}

// Validate if a city name is reasonable (not generic terms)
function isValidCityName(localName: string, englishName: string): boolean {
  const genericTerms = [
    'altstadt', 'old town', 'city center', 'centre', 'centrum', 
    'downtown', 'historic center', 'district', 'quarter', 'neighbourhood'
  ];
  
  const localLower = localName.toLowerCase();
  const isGeneric = genericTerms.some(term => localLower.includes(term));
  
  // Also reject if it's exactly the same as English (no translation needed)
  const isSameAsEnglish = localName.toLowerCase() === englishName.toLowerCase();
  
  return !isGeneric && !isSameAsEnglish;
}

function estimatePopulation(feature: any): number | undefined {
  // Enhanced population estimation for cities only
  const placeType = feature.place_type?.[0];
  const bbox = feature.bbox;
  
  if (placeType !== 'place') return undefined; // Only estimate for actual places/cities
  
  // Calculate rough area from bounding box if available
  let estimatedSize = 0;
  if (bbox && bbox.length === 4) {
    const [minLon, minLat, maxLon, maxLat] = bbox;
    estimatedSize = Math.abs(maxLon - minLon) * Math.abs(maxLat - minLat);
  }
  
  // More conservative estimates for cities only
  if (estimatedSize > 0.1) {
    return 500000; // Large cities
  } else if (estimatedSize > 0.05) {
    return 100000; // Medium cities  
  } else if (estimatedSize > 0.01) {
    return 50000; // Small cities
  } else {
    return 25000; // Towns
  }
}