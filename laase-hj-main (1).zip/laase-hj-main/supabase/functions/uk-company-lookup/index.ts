import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { corsHeaders } from '../_shared/cors.ts'

interface CompaniesHouseResponse {
  company_name: string;
  company_number: string;
  company_status: string;
  registered_office_address: {
    address_line_1?: string;
    address_line_2?: string;
    locality?: string;
    postal_code?: string;
    country?: string;
  };
  date_of_creation: string;
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { companyNumber } = await req.json()
    console.log('UK company lookup request:', companyNumber)

    if (!companyNumber || !/^\d{8}$/.test(companyNumber)) {
      console.log('Invalid company number:', companyNumber)
      return new Response(
        JSON.stringify({ error: 'Company number must be 8 digits' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Format company number with leading zeros if needed
    const formattedNumber = companyNumber.padStart(8, '0')
    
    // Companies House API requires API key - for now, return mock data
    // In production, you would integrate with Companies House API
    console.log('Looking up UK company:', formattedNumber)

    // TODO: Integrate with Companies House API
    // For now, return a mock successful response for testing
    const mockCompanyData = {
      company_name: `Test Company ${formattedNumber}`,
      address: 'Companies House, Crown Way, Cardiff',
      postal_code: 'CF14 3UZ',
      city: 'Cardiff',
      phone: '',
      email: ''
    }

    console.log('Returning mock company data:', mockCompanyData)

    return new Response(
      JSON.stringify(mockCompanyData),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )

  } catch (error) {
    console.error('UK company lookup error:', error)
    return new Response(
      JSON.stringify({ error: 'Failed to lookup company number' }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})