import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';
import { Resend } from "npm:resend@3.0.0";
import { corsHeaders } from "../_shared/cors.ts";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

interface EmailRequest {
  templateId: string;
  recipientEmail: string;
  variables: Record<string, any>;
  languageCode?: string;
}

interface EmailBrandSettings {
  logo_url?: string;
  primary_color: string;
  secondary_color: string;
  font_family: string;
  header_background_color: string;
  footer_background_color: string;
  border_color: string;
  company_name?: string;
  company_address?: string;
  contact_email?: string;
  privacy_policy_url?: string;
  unsubscribe_url?: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { templateId, recipientEmail, variables, languageCode = 'en' }: EmailRequest = await req.json();

    console.log('📧 Starting email send process:', { templateId, recipientEmail, languageCode });

    // Get template and content
    const { data: template, error: templateError } = await supabase
      .from('email_templates')
      .select('*')
      .eq('id', templateId)
      .eq('is_active', true)
      .single();

    if (templateError || !template) {
      throw new Error(`Template not found: ${templateError?.message}`);
    }

    // Get template content
    const { data: content, error: contentError } = await supabase
      .from('email_template_content')
      .select('*')
      .eq('template_id', templateId);

    if (contentError) {
      throw new Error(`Failed to fetch template content: ${contentError.message}`);
    }

    // Get global brand settings
    const { data: brandSettings, error: brandError } = await supabase
      .from('email_brand_settings')
      .select('*')
      .single();

    const brand: EmailBrandSettings = brandSettings || {
      logo_url: '/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png',
      primary_color: '#155e63',
      secondary_color: '#f9f8eb',
      font_family: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      header_background_color: '#155e63',
      footer_background_color: '#f9f8eb',
      border_color: '#155e63',
      company_name: 'Lockily',
      contact_email: 'support@lockily.com'
    };

    // Get translations for content
    const translatedContent: Record<string, string> = {};
    
    for (const contentItem of content) {
      const { data: translation } = await supabase
        .from('email_template_translations')
        .select('translated_content')
        .eq('template_content_id', contentItem.id)
        .eq('language_code', languageCode)
        .maybeSingle();

      const finalContent = translation?.translated_content || contentItem.default_content;
      translatedContent[contentItem.content_section] = replaceVariables(finalContent, variables);
    }

    // Build HTML email
    const html = buildEmailHTML(translatedContent, brand);
    const subject = translatedContent.subject || `Message from ${brand.company_name}`;
    const preheader = translatedContent.preheader || '';

    // Send email via Resend
    const emailResponse = await resend.emails.send({
      from: `${brand.company_name} <${brand.contact_email}>`,
      to: [recipientEmail],
      subject: subject,
      html: html,
    });

    // Log the send attempt
    await supabase
      .from('email_send_log')
      .insert({
        template_id: templateId,
        recipient_email: recipientEmail,
        subject: subject,
        language_code: languageCode,
        variables_used: variables,
        send_status: emailResponse.error ? 'failed' : 'sent',
        error_message: emailResponse.error?.message,
        provider_response: emailResponse,
        sent_at: emailResponse.error ? null : new Date().toISOString()
      });

    if (emailResponse.error) {
      throw new Error(`Failed to send email: ${emailResponse.error.message}`);
    }

    console.log('✅ Email sent successfully:', emailResponse.data?.id);

    return new Response(
      JSON.stringify({ 
        success: true, 
        messageId: emailResponse.data?.id,
        templateUsed: template.template_name 
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("❌ Error sending email:", error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
};

function replaceVariables(content: string, variables: Record<string, any>): string {
  let result = content;
  
  // First replace button variables with proper HTML
  const buttonRegex = /\{\{\s*button\s*:\s*([^:]+)\s*:\s*([^}]+)\s*\}\}/g;
  result = result.replace(buttonRegex, (match, buttonText, buttonUrl) => {
    // Replace any variables in the URL first
    let finalUrl = buttonUrl;
    Object.entries(variables).forEach(([key, value]) => {
      const varRegex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
      finalUrl = finalUrl.replace(varRegex, String(value));
    });
    
    return `
      <div style="text-align: center; margin: 24px 0;">
        <a href="${finalUrl}" 
           style="display: inline-block; 
                  background-color: #155e63; 
                  color: #ffffff; 
                  padding: 12px 24px; 
                  text-decoration: none; 
                  border-radius: 6px; 
                  font-weight: 600;
                  font-size: 16px;">
          ${buttonText.trim()}
        </a>
      </div>
    `;
  });
  
  // Then replace regular variables
  Object.entries(variables).forEach(([key, value]) => {
    const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
    result = result.replace(regex, String(value));
  });
  
  return result;
}

function buildEmailHTML(content: Record<string, string>, brand: EmailBrandSettings): string {
  const body = content.body || '<p>No content available</p>';
  
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${content.subject || 'Email'}</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: ${brand.font_family};
      line-height: 1.6;
      color: #333333;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      border: 1px solid ${brand.border_color};
    }
    .header {
      background-color: ${brand.header_background_color};
      padding: 20px;
      text-align: center;
    }
    .header h1 {
      color: #ffffff;
      margin: 0;
      font-size: 24px;
    }
    .body-content {
      padding: 30px;
    }
    .footer {
      background-color: ${brand.footer_background_color};
      padding: 20px;
      text-align: center;
      font-size: 12px;
      color: #666666;
    }
    .button {
      display: inline-block;
      background-color: ${brand.primary_color};
      color: #ffffff;
      padding: 12px 24px;
      text-decoration: none;
      border-radius: 4px;
      margin: 16px 0;
    }
    @media only screen and (max-width: 600px) {
      .email-container {
        width: 100% !important;
      }
      .body-content {
        padding: 20px !important;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <div class="header">
      ${brand.logo_url ? `<img src="${brand.logo_url}" alt="${brand.company_name}" style="max-height: 40px; margin-bottom: 10px;">` : ''}
      <h1>${brand.company_name}</h1>
    </div>
    
    <div class="body-content">
      ${body}
    </div>
    
    <div class="footer">
      <p><strong>${brand.company_name}</strong></p>
      ${brand.company_address ? `<p>${brand.company_address}</p>` : ''}
      <p>${brand.contact_email}</p>
      ${brand.privacy_policy_url ? `<p><a href="${brand.privacy_policy_url}">Privacy Policy</a></p>` : ''}
      ${brand.unsubscribe_url ? `<p><a href="${brand.unsubscribe_url}">Unsubscribe</a></p>` : ''}
    </div>
  </div>
</body>
</html>`;
}

serve(handler);