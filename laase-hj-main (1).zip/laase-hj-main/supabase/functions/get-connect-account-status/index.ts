import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;

    if (!user) {
      throw new Error('Unauthorized');
    }

    // Get Connect account from database
    const { data: connectAccount, error: dbError } = await supabaseClient
      .from('stripe_connect_accounts')
      .select('*')
      .eq('locksmith_id', user.id)
      .maybeSingle();

    if (dbError) {
      console.error('Database error:', dbError);
      throw new Error('Failed to fetch account from database');
    }

    if (!connectAccount?.stripe_account_id) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          connected: false,
          account: null
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch latest status from Stripe
    const stripeResponse = await fetch(`https://api.stripe.com/v1/accounts/${connectAccount.stripe_account_id}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('STRIPE SECRET')}`,
      },
    });

    if (!stripeResponse.ok) {
      const error = await stripeResponse.text();
      console.error('Stripe account fetch failed:', error);
      throw new Error('Failed to fetch account from Stripe');
    }

    const stripeAccount = await stripeResponse.json();

    // Update database with latest info
    const { error: updateError } = await supabaseClient
      .from('stripe_connect_accounts')
      .update({
        account_status: stripeAccount.charges_enabled ? 'active' : 'pending',
        details_submitted: stripeAccount.details_submitted || false,
        payouts_enabled: stripeAccount.payouts_enabled || false,
        charges_enabled: stripeAccount.charges_enabled || false,
        requirements: stripeAccount.requirements || {},
      })
      .eq('id', connectAccount.id);

    if (updateError) {
      console.error('Database update error:', updateError);
    }

    // Create Account Link if needed for re-authentication
    let onboardingUrl = null;
    if (!stripeAccount.charges_enabled || 
        stripeAccount.requirements?.currently_due?.length > 0 ||
        stripeAccount.requirements?.eventually_due?.length > 0) {
      const accountLinkResponse = await fetch('https://api.stripe.com/v1/account_links', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${Deno.env.get('STRIPE SECRET')}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          'account': stripeAccount.id,
          'refresh_url': `${req.headers.get('origin')}/locksmith-portal/settings?tab=payments&refresh=true`,
          'return_url': `${req.headers.get('origin')}/locksmith-portal/settings?tab=payments&success=true`,
          'type': 'account_onboarding',
        }),
      });

      if (accountLinkResponse.ok) {
        const accountLink = await accountLinkResponse.json();
        onboardingUrl = accountLink.url;
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        connected: true,
        account: {
          id: stripeAccount.id,
          charges_enabled: stripeAccount.charges_enabled,
          payouts_enabled: stripeAccount.payouts_enabled,
          details_submitted: stripeAccount.details_submitted,
          requirements: stripeAccount.requirements,
          business_profile: stripeAccount.business_profile,
        },
        onboardingUrl
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in get-connect-account-status:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});