import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WikidataCity {
  id: string;
  name: string;
  country: string;
  countryCode?: string;
  population?: number;
  latitude?: number;
  longitude?: number;
  timezone?: string;
  administrativeLevel?: string;
  localNames?: { [languageCode: string]: string };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { query, action, wikidataId } = await req.json();

    if (action === 'search') {
      return await searchCities(query);
    } else if (action === 'details' && wikidataId) {
      return await getCityDetails(wikidataId);
    } else {
      return new Response(JSON.stringify({ error: 'Invalid action or missing parameters' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  } catch (error) {
    console.error('Error in wikidata-city-lookup:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function searchCities(query: string) {
  // Stage 1: Simple, fast search for basic city information with country codes
  const basicSearchQuery = `
    SELECT DISTINCT ?city ?cityLabel ?country ?countryLabel ?countryCode ?population WHERE {
      ?city wdt:P31 wd:Q515 .
      ?city wdt:P17 ?country .
      OPTIONAL { ?city wdt:P1082 ?population }
      OPTIONAL { ?country wdt:P297 ?countryCode }
      ?city rdfs:label ?cityLabel .
      ?country rdfs:label ?countryLabel .
      FILTER(LANG(?cityLabel) = "en")
      FILTER(LANG(?countryLabel) = "en")
      FILTER(STRSTARTS(LCASE(?cityLabel), LCASE("${query.replace(/"/g, '\\"')}")))
    }
    ORDER BY DESC(?population)
    LIMIT 12
  `;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout

  try {
    console.log(`🔍 Searching for cities starting with: ${query}`);
    
    const response = await fetch('https://query.wikidata.org/sparql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'User-Agent': 'LocksmithApp/1.0'
      },
      body: `query=${encodeURIComponent(basicSearchQuery)}`,
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      console.error('❌ Wikidata response error:', response.status, response.statusText);
      throw new Error(`Wikidata query failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (!data.results || !data.results.bindings) {
      console.error('❌ Invalid Wikidata response structure:', data);
      throw new Error('Invalid response from Wikidata');
    }

    // Stage 2: Fetch multilingual names for the found cities
    const cities: WikidataCity[] = await Promise.all(
      data.results.bindings.slice(0, 8).map(async (binding: any) => {
        const cityId = binding.city.value.split('/').pop();
        const localNames = await fetchCityLocalNames(cityId);
        
        return {
          id: cityId,
          name: binding.cityLabel.value,
          country: binding.countryLabel.value,
          countryCode: binding.countryCode?.value,
          population: binding.population ? parseInt(binding.population.value) : undefined,
          localNames: Object.keys(localNames).length > 0 ? localNames : undefined,
        };
      })
    );

    console.log(`✅ Found ${cities.length} cities for query: ${query}`);
    return new Response(JSON.stringify({ cities }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    clearTimeout(timeoutId);
    console.error('❌ Search cities error:', error);
    
    if (error.name === 'AbortError') {
      return new Response(JSON.stringify({ 
        error: 'Search timed out - please try a shorter, more specific query',
        cities: []
      }), {
        status: 408,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
    
    return new Response(JSON.stringify({ 
      error: error.message || 'Failed to search cities',
      cities: []
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}

async function fetchCityLocalNames(cityId: string): Promise<{ [languageCode: string]: string }> {
  const localNamesQuery = `
    SELECT ?cityLabelDa ?cityLabelDe ?cityLabelSv ?cityLabelNo WHERE {
      BIND(wd:${cityId} as ?city)
      OPTIONAL { ?city rdfs:label ?cityLabelDa . FILTER(LANG(?cityLabelDa) = "da") }
      OPTIONAL { ?city rdfs:label ?cityLabelDe . FILTER(LANG(?cityLabelDe) = "de") }
      OPTIONAL { ?city rdfs:label ?cityLabelSv . FILTER(LANG(?cityLabelSv) = "sv") }
      OPTIONAL { ?city rdfs:label ?cityLabelNo . FILTER(LANG(?cityLabelNo) = "no") }
    }
    LIMIT 1
  `;

  try {
    const response = await fetch('https://query.wikidata.org/sparql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'User-Agent': 'LocksmithApp/1.0'
      },
      body: `query=${encodeURIComponent(localNamesQuery)}`
    });

    if (!response.ok) return {};

    const data = await response.json();
    const binding = data.results?.bindings?.[0];
    
    if (!binding) return {};

    const localNames: { [languageCode: string]: string } = {};
    if (binding.cityLabelDa?.value) localNames['da'] = binding.cityLabelDa.value;
    if (binding.cityLabelDe?.value) localNames['de'] = binding.cityLabelDe.value;
    if (binding.cityLabelSv?.value) localNames['sv'] = binding.cityLabelSv.value;
    if (binding.cityLabelNo?.value) localNames['no'] = binding.cityLabelNo.value;

    return localNames;
  } catch (error) {
    console.warn(`⚠️ Failed to fetch local names for city ${cityId}:`, error);
    return {};
  }
}

async function getCityDetails(wikidataId: string) {
  const sparqlQuery = `
    SELECT ?city ?cityLabel ?country ?countryLabel ?population ?coord ?timezone ?adminLevel WHERE {
      BIND(wd:${wikidataId} as ?city)
      ?city wdt:P17 ?country .
      ?city rdfs:label ?cityLabel .
      FILTER(LANG(?cityLabel) = "en")
      OPTIONAL { ?city wdt:P1082 ?population }
      OPTIONAL { ?city wdt:P625 ?coord }
      OPTIONAL { ?city wdt:P421 ?timezone }
      OPTIONAL { ?city wdt:P131 ?adminDiv . ?adminDiv wdt:P131* ?adminLevel }
      ?country rdfs:label ?countryLabel .
      FILTER(LANG(?countryLabel) = "en")
    }
    LIMIT 1
  `;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

  try {
    const response = await fetch('https://query.wikidata.org/sparql', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'User-Agent': 'LocksmithApp/1.0'
      },
      body: `query=${encodeURIComponent(sparqlQuery)}`
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Wikidata details query failed: ${response.statusText}`);
    }

    const data = await response.json();
    const binding = data.results.bindings[0];
    
    if (!binding) {
      throw new Error('City not found in Wikidata');
    }

    const coords = binding.coord?.value;
    let latitude, longitude;
    
    if (coords) {
      const match = coords.match(/Point\(([^)]+)\)/);
      if (match) {
        const [lon, lat] = match[1].split(' ').map(Number);
        latitude = lat;
        longitude = lon;
      }
    }

    // Fetch multilingual names separately for better performance
    const localNames = await fetchCityLocalNames(wikidataId);

    const city: WikidataCity = {
      id: wikidataId,
      name: binding.cityLabel.value,
      country: binding.countryLabel.value,
      population: binding.population ? parseInt(binding.population.value) : undefined,
      latitude,
      longitude,
      timezone: binding.timezone?.value.split('/').pop(),
      administrativeLevel: binding.adminLevel?.value,
      localNames: Object.keys(localNames).length > 0 ? localNames : undefined,
    };

    return new Response(JSON.stringify({ city }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    clearTimeout(timeoutId);
    console.error('❌ Get city details error:', error);
    throw error;
  }
}