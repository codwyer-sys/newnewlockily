import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function getLanguageName(languageCode: string): string {
  const languageNames: { [key: string]: string } = {
    'da': 'Danish',
    'de': 'German', 
    'sv': 'Swedish',
    'no': 'Norwegian',
    'en': 'English',
    'fr': 'French',
    'es': 'Spanish',
    'it': 'Italian',
    'pl': 'Polish',
    'pt': 'Portuguese',
    'fi': 'Finnish',
    'cs': 'Czech',
  };
  
  return languageNames[languageCode] || languageCode;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { cityId, cityName, marketCode, coordinates, direction } = await req.json();

    if (!cityId || !cityName || !marketCode) {
      return new Response(JSON.stringify({ error: 'Missing required parameters' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`🏙️ AI translating city: "${cityName}" for market: ${marketCode}`);

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get market language mapping
    const { data: languageMapping } = await supabase
      .from('language_mappings')
      .select('language_code')
      .eq('market_code', marketCode)
      .single();

    if (!languageMapping) {
      console.log(`No language mapping found for market: ${marketCode}`);
      return new Response(JSON.stringify({ success: true, message: 'No translation needed' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get AI translation settings
    const { data: aiSettings } = await supabase
      .from('ai_translation_settings')
      .select('*')
      .single();

    if (!aiSettings) {
      throw new Error('AI translation settings not found');
    }

    // Get market info for translation context
    const { data: market } = await supabase
      .from('markets')
      .select('country_name, currency_code')
      .eq('country_code', marketCode)
      .single();

    // Create enhanced city translation prompt with validation context
    const targetLanguageName = getLanguageName(languageMapping.language_code);
    const coordinatesInfo = coordinates ? `Coordinates: ${coordinates.latitude}, ${coordinates.longitude}` : '';
    
    const cityPrompt = `You are a geographic naming expert specializing in accurate city name translations. Your task is to provide the authentic local name used by residents.

CITY TO TRANSLATE: "${cityName}"
TARGET MARKET: ${market?.country_name || marketCode} (${marketCode})
TARGET LANGUAGE: ${targetLanguageName} (${languageMapping.language_code})
${coordinatesInfo}

CRITICAL REQUIREMENTS:
1. Provide the OFFICIAL LOCAL NAME used by residents and government
2. Avoid generic terms like "Old Town", "City Center", "Altstadt", "Centre"
3. Use the most commonly recognized local spelling
4. Consider historical and cultural naming conventions
5. If the city name is already in ${targetLanguageName}, return the same name

EXAMPLES OF CORRECT TRANSLATIONS:
- "Munich" → "München" (German)
- "Rome" → "Roma" (Italian)
- "Prague" → "Praha" (Czech)  
- "Vienna" → "Wien" (German)
- "Cologne" → "Köln" (German)
- "Florence" → "Firenze" (Italian)

RESPOND WITH ONLY THE AUTHENTIC CITY NAME IN ${targetLanguageName}. NO explanations, quotes, or generic terms.`;

    // Call OpenAI API for translation
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    const openAIResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14', // Use latest model for better geographic knowledge
        messages: [
          { 
            role: 'system', 
            content: 'You are a professional geographic naming expert with deep knowledge of local city names worldwide. You provide only authentic local names used by residents, never generic terms or districts. You understand the difference between official city names and neighborhood names.' 
          },
          { role: 'user', content: cityPrompt }
        ],
        temperature: 0.05, // Very low temperature for maximum consistency
        max_tokens: 30, // City names are typically short
      }),
    });

    const aiData = await openAIResponse.json();
    const translatedName = aiData.choices?.[0]?.message?.content?.trim();

    if (!translatedName) {
      throw new Error('Failed to get translation from AI');
    }

    // Save translation to database
    const { error: saveError } = await supabase
      .from('city_translations')
      .upsert({
        city_id: cityId,
        language_code: languageMapping.language_code,
        market_code: marketCode,
        local_name: translatedName,
        is_official: false,
        source: 'ai_generated',
      }, {
        onConflict: 'city_id,language_code,market_code',
      });

    if (saveError) throw saveError;

    console.log(`✅ AI translated "${cityName}" to "${translatedName}" for ${marketCode}`);

    return new Response(JSON.stringify({ 
      success: true, 
      translatedName,
      originalName: cityName,
      marketCode,
      languageCode: languageMapping.language_code 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ AI translation error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});