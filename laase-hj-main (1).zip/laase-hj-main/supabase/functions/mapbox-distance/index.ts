import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Helper function to get coordinates with caching
async function getCachedCoordinates(address: string, supabase: any, mapboxToken: string): Promise<[number, number]> {
  console.log('🔍 [mapbox-distance] Getting coordinates for:', address)
  
  // Check cache first
  const { data: cachedResult } = await supabase
    .from('geocoding_cache')
    .select('latitude, longitude')
    .eq('address', address)
    .gt('expires_at', new Date().toISOString())
    .maybeSingle()

  if (cachedResult) {
    console.log('🎯 [mapbox-distance] Cache hit for:', address)
    return [parseFloat(cachedResult.longitude), parseFloat(cachedResult.latitude)]
  }

  console.log('🔍 [mapbox-distance] Cache miss, calling MapBox API for:', address)
  
  // Not in cache, call MapBox API
  const geocodeResponse = await fetch(
    `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${mapboxToken}&country=dk&limit=1`
  )

  if (!geocodeResponse.ok) {
    throw new Error(`Failed to geocode address: ${address}`)
  }

  const geocodeData = await geocodeResponse.json()
  
  if (!geocodeData.features?.length) {
    throw new Error(`Could not find coordinates for address: ${address}`)
  }

  const [longitude, latitude] = geocodeData.features[0].center

  // Store in cache (don't fail if caching fails)
  try {
    await supabase
      .from('geocoding_cache')
      .insert({ address, latitude, longitude })
    console.log('✅ [mapbox-distance] Cached coordinates for:', address)
  } catch (error) {
    console.error('Failed to cache coordinates:', error)
  }

  return [longitude, latitude]
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { from, to } = await req.json()

    if (!from || !to) {
      throw new Error('Both from and to addresses are required')
    }

    const mapboxToken = Deno.env.get('MAPBOX_API_KEY')
    if (!mapboxToken) {
      throw new Error('MapBox API key not configured')
    }

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get coordinates for both addresses using cache
    const fromCoords = await getCachedCoordinates(from, supabase, mapboxToken)
    const toCoords = await getCachedCoordinates(to, supabase, mapboxToken)

    // Get driving directions and distance
    const directionsUrl = `https://api.mapbox.com/directions/v5/mapbox/driving/${fromCoords[0]},${fromCoords[1]};${toCoords[0]},${toCoords[1]}?access_token=${mapboxToken}&geometries=geojson`
    
    const directionsResponse = await fetch(directionsUrl)
    if (!directionsResponse.ok) {
      throw new Error('Failed to get directions')
    }

    const directionsData = await directionsResponse.json()
    
    if (!directionsData.routes?.length) {
      throw new Error('No route found between addresses')
    }

    const route = directionsData.routes[0]
    const distanceKm = (route.distance / 1000).toFixed(1)
    const durationMinutes = Math.ceil(route.duration / 60)

    return new Response(
      JSON.stringify({
        distance: parseFloat(distanceKm),
        duration: durationMinutes,
        fromCoordinates: fromCoords,
        toCoordinates: toCoords,
        route: route.geometry
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (error) {
    console.error('Distance calculation error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})