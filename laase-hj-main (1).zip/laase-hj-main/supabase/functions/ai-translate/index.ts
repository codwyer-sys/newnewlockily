import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import "https://deno.land/x/xhr@0.1.0/mod.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { corsHeaders } from '../_shared/cors.ts'

// Helper function to get language name from code
function getLanguageName(languageCode: string): string {
  const languageMap: Record<string, string> = {
    'da': 'Danish',
    'de': 'German', 
    'en': 'English',
    'sv': 'Swedish',
    'no': 'Norwegian',
    'fi': 'Finnish',
    'fr': 'French',
    'es': 'Spanish',
    'it': 'Italian',
    'nl': 'Dutch',
    'pl': 'Polish'
  }
  return languageMap[languageCode] || languageCode.toUpperCase()
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { originalText, targetLanguage, market, placement, context, pageName, sectionName, contentKey, customInstruction } = await req.json()

    if (!originalText || !targetLanguage) {
      throw new Error('Original text and target language are required')
    }

    const openAIApiKey = Deno.env.get('OPENAI_API_KEY')
    if (!openAIApiKey) {
      throw new Error('OpenAI API key not configured')
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    console.log('🔤 [ai-translate] Translating text:', { originalText, targetLanguage, market, placement, pageName, sectionName, contentKey })

    // Fetch AI settings from database
    const { data: settings, error: settingsError } = await supabase
      .from('ai_translation_settings')
      .select('*')
      .single()

    if (settingsError) {
      console.error('Failed to fetch AI settings:', settingsError)
      throw new Error('Failed to fetch AI translation settings')
    }

    // Use language code directly - no need for mapping dependency
    const targetLanguageName = getLanguageName(targetLanguage)

    // Fetch market information
    const { data: marketInfo, error: marketError } = await supabase
      .from('markets')
      .select('*')
      .eq('country_code', market)
      .single()

    console.log('🌍 [ai-translate] Market info:', marketInfo)

    // Build context information
    const whereUsed = pageName && sectionName && contentKey 
      ? `${pageName} → ${sectionName} → ${contentKey}`
      : placement || 'general text';

    const elementType = contentKey ? (
      contentKey.includes('title') || contentKey.includes('heading') ? 'HEADING' :
      contentKey.includes('button') || contentKey.includes('cta') ? 'BUTTON' :
      contentKey.includes('error') ? 'ERROR MESSAGE' :
      contentKey.includes('label') ? 'FORM LABEL' :
      contentKey.includes('description') ? 'DESCRIPTION' :
      'TEXT'
    ) : 'TEXT';

    // Helper function to replace variables in any text
    const replaceVariables = (text: string) => {
      return text
        .replace(/{{TARGET_LANGUAGE}}/g, targetLanguageName)
        .replace(/{{TARGET_LANGUAGE_CODE}}/g, targetLanguage)
        .replace(/{{MARKET_NAME}}/g, marketInfo?.country_name || market)
        .replace(/{{MARKET_CODE}}/g, market)
        .replace(/{{CURRENCY}}/g, marketInfo?.currency_code || 'EUR')
        .replace(/{{ORIGINAL_TEXT}}/g, originalText)
        .replace(/{{CUSTOM_INSTRUCTION}}/g, customInstruction || '')
        .replace(/{{ELEMENT_TYPE}}/g, elementType)
        .replace(/{{LOCATION}}/g, whereUsed);
    }

    // Parse variables in business context
    const parsedBusinessContext = replaceVariables(settings.business_context);
    
    // Parse variables in system message  
    const parsedSystemMessage = replaceVariables(settings.system_message);

    // Replace variables in prompt template
    let translationPrompt = replaceVariables(settings.prompt_template)
      .replace(/{{BUSINESS_CONTEXT}}/g, parsedBusinessContext);

    // Handle conditional custom instruction section
    if (customInstruction) {
      translationPrompt = translationPrompt
        .replace(/{{#if CUSTOM_INSTRUCTION}}/g, '')
        .replace(/{{\/if}}/g, '');
    } else {
      // Remove the custom instruction section if no instruction provided
      translationPrompt = translationPrompt
        .replace(/{{#if CUSTOM_INSTRUCTION}}[\s\S]*?{{\/if}}/g, '');
    }

    console.log('🤖 [ai-translate] Using prompt:', translationPrompt.substring(0, 200) + '...')

    console.log('🤖 [ai-translate] Making OpenAI API request with model:', settings.model)
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: settings.model,
        messages: [
          { 
            role: 'system', 
            content: parsedSystemMessage
          },
          { role: 'user', content: translationPrompt }
        ],
        temperature: settings.temperature,
        max_tokens: settings.max_tokens
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('OpenAI API error response:', errorText)
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    
    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      console.error('Invalid OpenAI response structure:', data)
      throw new Error('Invalid response from OpenAI API')
    }
    
    let translatedText = data.choices[0].message.content.trim()

    // Remove unwanted quotation marks that OpenAI often adds around translations
    const originalResponse = translatedText
    if ((translatedText.startsWith('"') && translatedText.endsWith('"')) ||
        (translatedText.startsWith("'") && translatedText.endsWith("'"))) {
      translatedText = translatedText.slice(1, -1)
      console.log('🔧 [ai-translate] Removed wrapper quotes from response')
    }

    console.log('✅ [ai-translate] Translation completed:', translatedText)
    if (originalResponse !== translatedText) {
      console.log('📝 [ai-translate] Original response had quotes:', originalResponse)
    }

    return new Response(
      JSON.stringify({
        originalText,
        translatedText,
        targetLanguage,
        market,
        placement
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (error) {
    console.error('AI translation error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})