import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { postcode } = await req.json()

    if (!postcode) {
      throw new Error('Postcode is required')
    }

    console.log('🔍 [uk-postcode-lookup] Looking up postcode:', postcode)

    // Clean and validate UK postcode format
    const cleanPostcode = postcode.replace(/\s+/g, '').toUpperCase()
    const postcodeRegex = /^[A-Z]{1,2}\d[A-Z\d]?\d[A-Z]{2}$/
    
    if (!postcodeRegex.test(cleanPostcode)) {
      throw new Error('Invalid UK postcode format')
    }

    // Format postcode properly (add space)
    const formattedPostcode = cleanPostcode.replace(/^([A-Z]{1,2}\d[A-Z\d]?)(\d[A-Z]{2})$/, '$1 $2')

    // Use Royal Mail Postcode API or Mapbox (fallback to Mapbox for now)
    const mapboxToken = Deno.env.get('MAPBOX_API_KEY')
    if (!mapboxToken) {
      throw new Error('MapBox API key not configured')
    }

    const geocodeResponse = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(formattedPostcode)}.json?access_token=${mapboxToken}&country=gb&types=postcode&limit=5`
    )

    if (!geocodeResponse.ok) {
      throw new Error('Failed to lookup postcode')
    }

    const geocodeData = await geocodeResponse.json()

    if (!geocodeData.features?.length) {
      throw new Error('Postcode not found')
    }

    // Extract addresses from the response
    const addresses = geocodeData.features.map((feature: any) => ({
      address: feature.place_name,
      postcode: formattedPostcode,
      coordinates: {
        latitude: feature.center[1],
        longitude: feature.center[0]
      }
    }))

    console.log('✅ [uk-postcode-lookup] Found addresses:', addresses.length)

    return new Response(
      JSON.stringify({
        postcode: formattedPostcode,
        addresses: addresses
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  } catch (error) {
    console.error('UK postcode lookup error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    )
  }
})