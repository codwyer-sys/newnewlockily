import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface Market {
  country_code: string;
  country_name: string;
  currency_code: string;
  currency_symbol: string;
  distance_unit: string;
  business_reg_field: string;
  business_reg_label: string;
  emergency_number: string;
  default_lat: number;
  default_lng: number;
  address_api_provider: string;
}

interface MarketContextType {
  market: Market;
  setMarketByCode: (countryCode: string) => void;
  formatCurrency: (amount: number) => string;
  formatDistance: (km: number) => string;
  isLoading: boolean;
  initializeFromUrl: (urlMarketCode: string) => void;
}

const MarketContext = createContext<MarketContextType | undefined>(undefined);

const DEFAULT_MARKET: Market = {
  country_code: 'DK',
  country_name: 'Denmark',
  currency_code: 'DKK',
  currency_symbol: 'kr',
  distance_unit: 'km',
  business_reg_field: 'cvr_number',
  business_reg_label: 'CVR Nummer',
  emergency_number: '112',
  default_lat: 55.6761,
  default_lng: 12.5683,
  address_api_provider: 'dawa'
};

export function MarketProvider({ children }: { children: ReactNode }) {
  const [market, setMarket] = useState<Market>(DEFAULT_MARKET);
  const [availableMarkets, setAvailableMarkets] = useState<Market[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Detect market with URL priority
  const detectMarket = async (markets: Market[], urlMarketCode?: string): Promise<Market> => {
    // First priority: URL-based market detection
    if (urlMarketCode) {
      const urlMarket = markets.find(m => m.country_code === urlMarketCode.toUpperCase());
      if (urlMarket) {
        console.log('🌍 Using URL market:', urlMarketCode);
        return urlMarket;
      }
    }

    // Second priority: check localStorage for saved preference
    const savedMarket = localStorage.getItem('preferred_market');
    if (savedMarket) {
      const found = markets.find(m => m.country_code === savedMarket);
      if (found) {
        console.log('🌍 Using saved market:', savedMarket);
        return found;
      }
    }

    // Third priority: Try IP-based detection
    try {
      const response = await fetch('https://ipapi.co/json/');
      const data = await response.json();
      
      console.log('🌍 Detected location:', data);
      
      let detectedCode = 'DK'; // Default fallback
      if (data.country_code === 'GB') detectedCode = 'UK';
      else if (data.country_code === 'US') detectedCode = 'US';
      else if (data.country_code === 'DE') detectedCode = 'DE';
      else if (data.country_code === 'DK') detectedCode = 'DK';
      else if (data.country_code === 'IE') detectedCode = 'IE';
      else if (data.country_code === 'FR') detectedCode = 'FR';
      else if (data.country_code === 'ES') detectedCode = 'ES';
      else if (data.country_code === 'SE') detectedCode = 'SE';
      else if (data.country_code === 'NO') detectedCode = 'NO';
      else if (data.country_code === 'PL') detectedCode = 'PL';
      else if (data.country_code === 'CA') detectedCode = 'CA';
      else if (data.country_code === 'PT') detectedCode = 'PT';
      else if (data.country_code === 'IT') detectedCode = 'IT';
      else if (data.country_code === 'FI') detectedCode = 'FI';
      else if (data.country_code === 'CZ') detectedCode = 'CZ';
      
      const detectedMarket = markets.find(m => m.country_code === detectedCode);
      if (detectedMarket) {
        console.log('🌍 Auto-detected market:', detectedCode);
        return detectedMarket;
      }
    } catch (error) {
      console.log('🌍 IP detection failed:', error);
    }

    // Fallback to default
    return markets.find(m => m.country_code === 'DK') || markets[0];
  };

  // Load markets from database
  const loadMarkets = async (urlMarketCode?: string) => {
    try {
      const { data, error } = await supabase
        .from('markets')
        .select('*')
        .order('country_code');

      if (error) throw error;
      
      if (data && data.length > 0) {
        setAvailableMarkets(data);
        
        // Auto-detect the best market for user (with URL priority)
        const detectedMarket = await detectMarket(data, urlMarketCode);
        console.log('🌍 Setting initial market to:', detectedMarket.country_code);
        setMarket(detectedMarket);
      }
    } catch (error) {
      console.error('Failed to load markets:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMarkets();
  }, []);

  // Function to initialize market from URL
  const initializeFromUrl = (urlMarketCode: string) => {
    // Only reload if we don't have markets yet or if it's a different market
    if (availableMarkets.length === 0 || !availableMarkets.find(m => m.country_code === urlMarketCode.toUpperCase())) {
      loadMarkets(urlMarketCode);
    } else {
      // Just set the market without reloading
      setMarketByCode(urlMarketCode.toUpperCase());
    }
  };

  const setMarketByCode = (countryCode: string) => {
    const foundMarket = availableMarkets.find(m => m.country_code === countryCode);
    if (foundMarket && foundMarket.country_code !== market.country_code) {
      console.log('🌍 Setting market to:', countryCode);
      setMarket(foundMarket);
      // Save user's preference
      localStorage.setItem('preferred_market', countryCode);
    }
  };

  const formatCurrency = (amount: number): string => {
    const formatter = new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: market.currency_code,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });

    const formatted = formatter.format(amount);
    
    // For markets that prefer symbol after amount
    if (market.country_code === 'DK') {
      return formatted.replace(/DKK\s?/, '') + ' kr';
    } else if (market.country_code === 'PL') {
      return formatted.replace(/PLN\s?/, '') + ' zł';
    } else if (market.country_code === 'CZ') {
      return formatted.replace(/CZK\s?/, '') + ' Kč';
    }
    
    return formatted;
  };

  const formatDistance = (km: number): string => {
    if (market.distance_unit === 'miles') {
      const miles = km * 0.621371;
      return `${miles.toFixed(1)} miles`;
    }
    return `${km.toFixed(1)} km`;
  };

  return (
    <MarketContext.Provider value={{
      market,
      setMarketByCode,
      formatCurrency,
      formatDistance,
      isLoading,
      initializeFromUrl
    }}>
      {children}
    </MarketContext.Provider>
  );
}

export function useMarket() {
  const context = useContext(MarketContext);
  if (context === undefined) {
    throw new Error('useMarket must be used within a MarketProvider');
  }
  return context;
}