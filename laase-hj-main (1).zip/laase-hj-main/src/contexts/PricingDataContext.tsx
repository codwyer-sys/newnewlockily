import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface PricingConfiguration {
  categories: Array<{
    id: string;
    name: string;
    is_enabled: boolean;
    base_price: number | null;
    follow_up_questions: Array<{
      id: string;
      question: string;
      pricing: Array<{
        answer_value: string;
        fee_amount: number;
        fee_type: 'percentage' | 'fixed';
      }>;
    }>;
  }>;
  globalSettings: {
    base_radius_km: number;
    fee_per_km_above_radius: number;
    nighttime_start_hour: number;
    nighttime_end_hour: number;
    nighttime_fee_amount: number;
    nighttime_fee_type: 'percentage' | 'fixed';
    weekend_fee_amount: number;
    weekend_fee_type: 'percentage' | 'fixed';
    combine_nighttime_weekend_fees: boolean;
  } | null;
  referralFeePercentage: number;
  isLoading: boolean;
  error: string | null;
}

interface PricingDataContextType extends PricingConfiguration {
  refetch: () => Promise<void>;
}

const PricingDataContext = createContext<PricingDataContextType | null>(null);

export const PricingDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [data, setData] = useState<PricingConfiguration>({
    categories: [],
    globalSettings: null,
    referralFeePercentage: 20,
    isLoading: true,
    error: null,
  });

  const fetchAllPricingData = useCallback(async () => {
    if (!user?.id) {
      setData(prev => ({ ...prev, isLoading: false }));
      return;
    }

    try {
      setData(prev => ({ ...prev, isLoading: true, error: null }));

      // Parallel fetch of all pricing data
      const [autoBidResult, categoriesResult, questionsResult, pricingResult, globalResult, referralResult] = await Promise.all([
        // Auto-bid preferences
        supabase
          .from('locksmith_auto_bid_preferences')
          .select('id, job_category_id, is_enabled, base_price')
          .eq('locksmith_id', user.id),

        // Job categories  
        supabase
          .from('job_categories')
          .select('id, name'),

        // Follow-up questions
        supabase
          .from('follow_up_questions')
          .select('id, question, job_category_id'),

        // Follow-up question pricing
        supabase
          .from('follow_up_question_pricing')
          .select('follow_up_question_id, answer_value, fee_amount, fee_type')
          .eq('locksmith_id', user.id),

        // Global pricing settings
        supabase
          .from('global_pricing_settings')
          .select('*')
          .eq('locksmith_id', user.id)
          .maybeSingle(),

        // Referral fee
        supabase.rpc('get_effective_referral_fee', {
          locksmith_uuid: user.id
        }).then(result => result.data || 20)
      ]);

      if (autoBidResult.error) throw autoBidResult.error;
      if (categoriesResult.error) throw categoriesResult.error;
      if (questionsResult.error) throw questionsResult.error;
      if (pricingResult.error) throw pricingResult.error;
      if (globalResult.error) throw globalResult.error;

      // Build maps
      const categoriesMap = new Map(categoriesResult.data?.map(cat => [cat.id, cat.name]) || []);
      const pricingMap = new Map<string, Array<{
        answer_value: string;
        fee_amount: number;
        fee_type: 'percentage' | 'fixed';
      }>>();

      // Group pricing by question ID
      pricingResult.data?.forEach(p => {
        if (!pricingMap.has(p.follow_up_question_id)) {
          pricingMap.set(p.follow_up_question_id, []);
        }
        pricingMap.get(p.follow_up_question_id)!.push({
          answer_value: p.answer_value,
          fee_amount: p.fee_amount,
          fee_type: p.fee_type as 'percentage' | 'fixed'
        });
      });

      // Build questions map by category
      const questionsByCategory = new Map<string, Array<{
        id: string;
        question: string;
        pricing: Array<{
          answer_value: string;
          fee_amount: number;
          fee_type: 'percentage' | 'fixed';
        }>;
      }>>();

      questionsResult.data?.forEach(q => {
        if (!questionsByCategory.has(q.job_category_id)) {
          questionsByCategory.set(q.job_category_id, []);
        }
        questionsByCategory.get(q.job_category_id)!.push({
          id: q.id,
          question: q.question,
          pricing: pricingMap.get(q.id) || []
        });
      });

      // Transform auto-bid data
      const categories = autoBidResult.data?.map(pref => ({
        id: pref.job_category_id,
        name: categoriesMap.get(pref.job_category_id) || 'Unknown',
        is_enabled: pref.is_enabled,
        base_price: pref.base_price,
        follow_up_questions: questionsByCategory.get(pref.job_category_id) || []
      })) || [];

      setData({
        categories,
        globalSettings: globalResult.data ? {
          base_radius_km: globalResult.data.base_radius_km,
          fee_per_km_above_radius: globalResult.data.fee_per_km_above_radius,
          nighttime_start_hour: globalResult.data.nighttime_start_hour,
          nighttime_end_hour: globalResult.data.nighttime_end_hour,
          nighttime_fee_amount: globalResult.data.nighttime_fee_amount,
          nighttime_fee_type: globalResult.data.nighttime_fee_type as 'percentage' | 'fixed',
          weekend_fee_amount: globalResult.data.weekend_fee_amount,
          weekend_fee_type: globalResult.data.weekend_fee_type as 'percentage' | 'fixed',
          combine_nighttime_weekend_fees: globalResult.data.combine_nighttime_weekend_fees,
        } : null,
        referralFeePercentage: referralResult,
        isLoading: false,
        error: null,
      });

    } catch (err) {
      console.error('Failed to fetch pricing data:', err);
      setData(prev => ({
        ...prev,
        isLoading: false,
        error: 'Failed to load pricing configuration',
      }));
    }
  }, [user?.id]);

  useEffect(() => {
    fetchAllPricingData();
  }, [fetchAllPricingData]);

  const contextValue = useMemo(() => ({
    ...data,
    refetch: fetchAllPricingData,
  }), [data, fetchAllPricingData]);

  return (
    <PricingDataContext.Provider value={contextValue}>
      {children}
    </PricingDataContext.Provider>
  );
};

export const usePricingData = () => {
  const context = useContext(PricingDataContext);
  if (!context) {
    throw new Error('usePricingData must be used within a PricingDataProvider');
  }
  return context;
};