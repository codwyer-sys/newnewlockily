import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMarket } from '@/contexts/MarketContext';
import { useMarketLanguageAccess } from '@/hooks/useMarketLanguageAccess';

export type Language = 'da' | 'en' | 'de' | 'fr' | 'es' | 'sv' | 'no' | 'ga';

interface LanguageContextType {
  language: Language;
  availableLanguages: Array<{ code: string; name: string; isPrimary: boolean }>;
  setLanguage: (lang: Language) => void;
  t: (key: string, section?: string) => string;
  loading: boolean;
  canSetLanguage: (lang: Language) => boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

interface LanguageProviderProps {
  children: React.ReactNode;
}

// Fallback translations to prevent app from breaking
const fallbackTranslations: Record<Language, Record<string, string>> = {
  da: {
    'header.navigation.services': 'Tjenester',
    'header.navigation.how_it_works': 'Sådan fungerer det',
    'header.navigation.security': 'Sikkerhed',
    'header.cta.call_now': 'Ring nu',
    'header.cta.book_now': 'Book nu',
    
    // Hero Section
    'home.hero.title': 'Professionel låseservice når du har brug for det',
    'home.hero.subtitle': 'Certificerede låsesmede i hele Danmark',
    'home.hero.description': 'Få tilbud på sekunder fra alle tilgængelige låsesmede i dit område. Hurtig ankomst og fast pris.',
    'home.hero.address_label': 'Hvor har du brug for hjælp?',
    'home.hero.address_placeholder': 'Indtast din adresse...',
    'home.hero.click_to_select': 'Klik for at vælge denne adresse',
    'home.hero.or': 'eller',
    'home.hero.use_location': 'Brug min lokation',
    'home.hero.getting_location': 'Henter lokation...',
    'home.hero.prefer_call': 'Foretrækker du at ringe?',
    'home.hero.call_number': 'Ring 70 20 30 40',
    'home.hero.service_24_7': '24/7 Døgnservice',
    'home.hero.service_24_7_desc': 'Hurtig respons hele døgnet',
    'home.hero.certified_count': '500+ Certificerede',
    'home.hero.certified_desc': 'Autoriserede låsesmede',
    'home.hero.satisfied_count': '50.000+ Tilfredse',
    'home.hero.satisfied_desc': 'Kunder i hele Danmark',
    
    'home.booking.urgency_title': 'Hvornår har du brug for hjælp?',
    'home.booking.urgency_now': 'Nu',
    'home.booking.urgency_now_desc': 'Ledige låsesmede i området',
    'home.booking.urgency_now_mobile': 'Tilgængelig nu',
    'home.booking.urgency_later': 'Senere',
    'home.booking.urgency_later_desc': 'Book til senere',
    'home.booking.urgency_later_mobile': 'Planlæg',
    'home.booking.job_type_title': 'Vælg problem',
    'home.booking.follow_up_title': 'Detaljer om problemet',
    'home.booking.find_locksmith': 'Find låsesmed nu',
    'home.booking.find_locksmith_fast': 'Find låsesmed nu – få tilbud på under 20 sekunder!',
    'home.booking.finding': 'Finder låsesmed...',
    'home.services.title': 'Få tilbud på sekunder fra alle tilgængelige låsesmede',
    'home.services.subtitle': 'Vi samler alle ledige låsesmede i dit område og giver dig øjeblikkelig adgang til de bedste priser og hurtigste ankomsttider.',
    'home.services.instant_title': 'Øjeblikkelige tilbud',
    'home.services.instant_desc': 'Få priser fra alle tilgængelige låsesmede på under 20 sekunder',
    'home.services.price_title': 'Garanteret bedste pris',
    'home.services.price_desc': 'Sammenlign priser og vælg det tilbud der passer dig bedst',
    'home.services.speed_title': 'Hurtig ankomst',
    'home.services.speed_desc': 'Se præcis hvornår hver låsesmed kan være hos dig',
    'home.trust.title': 'Hvorfor vælge LåseHjælp?',
    'home.trust.response_time': 'Svar inden 20 sekunder',
    'home.trust.fixed_price': 'Fast pris – ingen overraskelser',
    'home.trust.quick_arrival': 'Hurtig ankomst',
    'home.trust.emergency': '24/7 akut hjælp',
    
    // How it works section
    'home.how_it_works.title': 'Sådan fungerer det',
    'home.how_it_works.subtitle': 'Få hjælp i 3 enkle trin',
    'home.how_it_works.step_1_title': 'Opret din opgave',
    'home.how_it_works.step_1_desc': 'Udfyld vores hurtige formular med detaljer om, hvad du har brug for. Tager mindre end 20 sekunder.',
    'home.how_it_works.step_2_title': 'Vi finder den hurtigste og billigste hjælp',
    'home.how_it_works.step_2_desc': 'Vores matchning-system forbinder dig med tilgængelige lokale låsesmede. Få tilbud på sekunder gennem automatisk budgivning.',
    'home.how_it_works.step_3_title': 'Vent på din låsesmed',
    'home.how_it_works.step_3_desc': 'Følg din låsesmed på vej til din lokation og få den hjælp, du har brug for.',
    
    // Follow up questions
    'follow_up.all_answered': 'Alle spørgsmål besvaret',
    'follow_up.answered': 'Besvaret',
    'follow_up.choose_answer': 'Vælg svar',
    'follow_up.optional': 'Valgfrit',
    
    // Calendar
    'calendar.select_date': 'Vælg dato og tidspunkt for dit møde',
    'calendar.at_time': 'kl.',
    
    // Job categories
    'job_categories.locked_out': 'Låst ude',
    'job_categories.locked_out_desc': 'Kom ikke ind',
    'job_categories.broken_key': 'Knækket nøgle',
    'job_categories.broken_key_desc': 'Nøgle ødelagt',
    'job_categories.lock_change': 'Skift lås',
    'job_categories.lock_change_desc': 'Ny lås skal sættes',
    'job_categories.other': 'Andet',
    'job_categories.other_desc': 'Andet problem',

    // Contact dialog
    'contact_dialog.title': 'Kontaktoplysninger',
    'contact_dialog.name_label': 'Navn',
    'contact_dialog.phone_label': 'Telefonnummer', 
    'contact_dialog.name_placeholder': 'Dit fulde navn',
    'contact_dialog.phone_placeholder': '12 34 56 78',
    'contact_dialog.submit_button': 'Se ledige låsesmede nu',
    'contact_dialog.submitting_button': 'Finder låsesmede...',

  },
  en: {
    'header.navigation.services': 'Services',
    'header.navigation.how_it_works': 'How it works',
    'header.navigation.security': 'Security',
    'header.cta.call_now': 'Call now',
    'header.cta.book_now': 'Book now',
    
    // Hero Section
    'home.hero.title': 'Professional locksmith service when you need it',
    'home.hero.subtitle': 'Certified locksmiths throughout Denmark',
    'home.hero.description': 'Get quotes in seconds from all available locksmiths in your area. Fast arrival and fixed price.',
    'home.hero.address_label': 'Where do you need help?',
    'home.hero.address_placeholder': 'Enter your address...',
    'home.hero.click_to_select': 'Click to select this address',
    'home.hero.or': 'or',
    'home.hero.use_location': 'Use my location',
    'home.hero.getting_location': 'Getting location...',
    'home.hero.prefer_call': 'Prefer to call?',
    'home.hero.call_number': 'Call 70 20 30 40',
    'home.hero.service_24_7': '24/7 Service',
    'home.hero.service_24_7_desc': 'Quick response all day',
    'home.hero.certified_count': '500+ Certified',
    'home.hero.certified_desc': 'Authorized locksmiths',
    'home.hero.satisfied_count': '50,000+ Satisfied',
    'home.hero.satisfied_desc': 'Customers in Denmark',
    
    'home.booking.urgency_title': 'When do you need help?',
    'home.booking.urgency_now': 'Now',
    'home.booking.urgency_now_desc': 'Available locksmiths in the area',
    'home.booking.urgency_now_mobile': 'Available now',
    'home.booking.urgency_later': 'Later',
    'home.booking.urgency_later_desc': 'Book for later',
    'home.booking.urgency_later_mobile': 'Schedule',
    'home.booking.job_type_title': 'Select problem',
    'home.booking.follow_up_title': 'Problem details',
    'home.booking.find_locksmith': 'Find locksmith now',
    'home.booking.find_locksmith_fast': 'Find locksmith now – get quotes in under 20 seconds!',
    'home.booking.finding': 'Finding locksmith...',
    'home.services.title': 'Get quotes in seconds from all available locksmiths',
    'home.services.subtitle': 'We gather all available locksmiths in your area and give you instant access to the best prices and fastest arrival times.',
    'home.services.instant_title': 'Instant quotes',
    'home.services.instant_desc': 'Get prices from all available locksmiths in under 20 seconds',
    'home.services.price_title': 'Guaranteed best price',
    'home.services.price_desc': 'Compare prices and choose the offer that suits you best',
    'home.services.speed_title': 'Quick arrival',
    'home.services.speed_desc': 'See exactly when each locksmith can be with you',
    'home.trust.title': 'Why choose LockHelp?',
    'home.trust.response_time': 'Response within 20 seconds',
    'home.trust.fixed_price': 'Fixed price – no surprises',
    'home.trust.quick_arrival': 'Quick arrival',
    'home.trust.emergency': '24/7 emergency help',
    
    // How it works section
    'home.how_it_works.title': 'How it works',
    'home.how_it_works.subtitle': 'Get help in 3 simple steps',
    'home.how_it_works.step_1_title': 'Submit your job',
    'home.how_it_works.step_1_desc': 'Fill out our quick form with details about what you need. Takes less than 20 seconds.',
    'home.how_it_works.step_2_title': 'We find the quickest and cheapest help',
    'home.how_it_works.step_2_desc': 'Our matching engine connects you with available local locksmiths. Get quotes in seconds through automated bidding.',
    'home.how_it_works.step_3_title': 'Wait for your locksmith',
    'home.how_it_works.step_3_desc': 'Track your locksmith en route to your location and get the help you need.',
    
    // Follow up questions
    'follow_up.all_answered': 'All questions answered',
    'follow_up.answered': 'Answered',
    'follow_up.choose_answer': 'Choose answer',
    'follow_up.optional': 'Optional',
    
    // Calendar
    'calendar.select_date': 'Select a date and time for your appointment',
    'calendar.at_time': 'at',
    
    // Job categories
    'job_categories.locked_out': 'Locked out',
    'job_categories.locked_out_desc': 'Cannot get in',
    'job_categories.broken_key': 'Broken key',
    'job_categories.broken_key_desc': 'Key is damaged',
    'job_categories.lock_change': 'Change lock',
    'job_categories.lock_change_desc': 'New lock needed',
    'job_categories.other': 'Other',
    'job_categories.other_desc': 'Other problem',

    // Contact dialog
    'contact_dialog.title': 'Contact Information',
    'contact_dialog.name_label': 'Name',
    'contact_dialog.phone_label': 'Phone Number',
    'contact_dialog.name_placeholder': 'Your full name',
    'contact_dialog.phone_placeholder': '12 34 56 78',
    'contact_dialog.submit_button': 'Find available locksmiths now',
    'contact_dialog.submitting_button': 'Finding locksmiths...',

  },
  // Basic fallbacks for new languages
  de: {
    'header.navigation.services': 'Dienstleistungen',
    'header.cta.book_now': 'Jetzt buchen',
    'home.hero.title': 'Professioneller Schlüsseldienst wenn Sie ihn brauchen',
  },
  fr: {
    'header.navigation.services': 'Services',
    'header.cta.book_now': 'Réserver maintenant',
    'home.hero.title': 'Service de serrurier professionnel quand vous en avez besoin',
  },
  es: {
    'header.navigation.services': 'Servicios',
    'header.cta.book_now': 'Reservar ahora',
    'home.hero.title': 'Servicio profesional de cerrajería cuando lo necesites',
  },
  sv: {
    'header.navigation.services': 'Tjänster',
    'header.cta.book_now': 'Boka nu',
    'home.hero.title': 'Professionell låssmedstjänst när du behöver det',
  },
  no: {
    'header.navigation.services': 'Tjenester',
    'header.cta.book_now': 'Bestill nå',
    'home.hero.title': 'Profesjonell låsesmedtjeneste når du trenger det',
  },
  ga: {
    'header.navigation.services': 'Seirbhísí',
    'header.cta.book_now': 'Cuir in áirithe anois',
    'home.hero.title': 'Seirbhís ghlasmhaeistir ghairmiúil nuair a theastaíonn uait é',
  }
};

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const { market } = useMarket();
  const { availableLanguages, loading: languageAccessLoading, isLanguageAvailable, getPrimaryLanguage } = useMarketLanguageAccess(market.country_code);
  
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('language') as Language;
      return saved || 'en';
    } catch {
      return 'en';
    }
  });
  const [translations, setTranslations] = useState<Record<string, string>>(fallbackTranslations[language] || fallbackTranslations.en);
  const [loading, setLoading] = useState(true);

  // Auto-switch to primary language when market changes, but respect user preference if valid
  useEffect(() => {
    if (availableLanguages.length === 0) return;
    
    const primaryLanguage = getPrimaryLanguage(market.country_code) as Language;
    const savedLanguage = localStorage.getItem('language') as Language;
    
    // Check if current language is available in new market
    const currentLanguageAvailable = isLanguageAvailable(language, market.country_code);
    
    if (!currentLanguageAvailable) {
      // If current language not available, switch to primary or saved language if valid
      const languageToUse = (savedLanguage && isLanguageAvailable(savedLanguage, market.country_code)) 
        ? savedLanguage 
        : primaryLanguage;
        
      if (languageToUse && languageToUse !== language) {
        console.log('🌍 Switching language from', language, 'to', languageToUse, 'for market', market.country_code);
        setLanguageState(languageToUse);
        localStorage.setItem('language', languageToUse);
      }
    }
  }, [market.country_code, availableLanguages, language, isLanguageAvailable, getPrimaryLanguage]);

  const setLanguage = (lang: Language) => {
    // Validate language is available for current market
    if (!isLanguageAvailable(lang, market.country_code)) {
      console.warn(`Language ${lang} not available for market ${market.country_code}`);
      return;
    }
    
    setLanguageState(lang);
    try {
      localStorage.setItem('language', lang);
    } catch {
      // Ignore localStorage errors
    }
  };

  const canSetLanguage = (lang: Language): boolean => {
    return isLanguageAvailable(lang, market.country_code);
  };

  const fetchTranslations = async () => {
    try {
      const { data, error } = await supabase
        .from('content_translations')
        .select(`
          content_key,
          content_value,
          content_sections!inner(
            section_key,
            content_pages!inner(
              page_key
            )
          )
        `)
        .eq('language_code', language)
        .or(`market_code.is.null,market_code.eq.${market.country_code}`);

      if (error) {
        console.error('Error fetching translations:', error);
        setLoading(false);
        return;
      }

      const translationMap: Record<string, string> = {};
      data?.forEach((item) => {
        const pageKey = item.content_sections.content_pages.page_key;
        const sectionKey = item.content_sections.section_key;
        const key = `${pageKey}.${sectionKey}.${item.content_key}`;
        translationMap[key] = item.content_value;
      });

      // Merge database translations with fallbacks
      setTranslations({ 
        ...fallbackTranslations.en, // Always include English as base
        ...fallbackTranslations[language], 
        ...translationMap 
      });
    } catch (error) {
      console.error('Error fetching translations:', error);
      // Use fallback on error
      setTranslations(fallbackTranslations[language] || fallbackTranslations.en);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (languageAccessLoading) return;
    
    // Use fallback immediately, then fetch from database
    setTranslations(fallbackTranslations[language] || fallbackTranslations.en);
    
    const timeout = setTimeout(() => {
      fetchTranslations();
    }, 100);
    
    return () => clearTimeout(timeout);
  }, [language, market.country_code, languageAccessLoading]);

  useEffect(() => {
    try {
      document.documentElement.lang = language;
    } catch {
      // Ignore document errors
    }
  }, [language]);

  const t = (key: string, section?: string): string => {
    // Support both formats: t('title', 'hero') and t('hero.title')
    let fullKey = key;
    if (section) {
      fullKey = `home.${section}.${key}`;
    } else if (!key.includes('.')) {
      // Legacy fallback for hardcoded keys
      return key;
    }

    return translations[fullKey] || fallbackTranslations[language]?.[fullKey] || fallbackTranslations.en?.[fullKey] || key;
  };

  return (
    <LanguageContext.Provider value={{ 
      language, 
      availableLanguages,
      setLanguage, 
      t, 
      loading: loading || languageAccessLoading,
      canSetLanguage 
    }}>
      {children}
    </LanguageContext.Provider>
  );
};