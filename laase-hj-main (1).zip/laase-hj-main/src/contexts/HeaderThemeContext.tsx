import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

export type HeaderTheme = 'light' | 'dark';

interface HeaderThemeContextValue {
  theme: HeaderTheme;
  setTheme: (theme: HeaderTheme) => void;
  registerSection: (id: string, theme: HeaderTheme, element: Element) => void;
  unregisterSection: (id: string) => void;
}

const HeaderThemeContext = createContext<HeaderThemeContextValue | undefined>(undefined);

interface SectionRegistration {
  theme: HeaderTheme;
  element: Element;
}

export const HeaderThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<HeaderTheme>('light');
  const [sections, setSections] = useState<Map<string, SectionRegistration>>(new Map());

  const updateThemeFromSections = useCallback(() => {
    const headerRect = { top: 0, bottom: 100 }; // Header height area
    let foundDarkSection = false;
    
    for (const [_, section] of sections) {
      const rect = section.element.getBoundingClientRect();
      
      // Check if this section overlaps with header area
      if (rect.top <= headerRect.bottom && rect.bottom >= headerRect.top) {
        if (section.theme === 'dark') {
          foundDarkSection = true;
          break;
        }
      }
    }
    
    setTheme(foundDarkSection ? 'dark' : 'light');
  }, [sections]);

  const registerSection = useCallback((id: string, theme: HeaderTheme, element: Element) => {
    setSections(prev => {
      const newSections = new Map(prev);
      newSections.set(id, { theme, element });
      return newSections;
    });

    // Set up intersection observer for this section
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(updateThemeFromSections, 0);
          }
        });
      },
      {
        rootMargin: '-80px 0px -80px 0px',
        threshold: [0, 0.1, 0.5]
      }
    );

    observer.observe(element);

    // Store observer for cleanup
    (element as any)._headerThemeObserver = observer;

    // Initial theme check - run immediately and after a short delay
    updateThemeFromSections();
    setTimeout(updateThemeFromSections, 100);
    
    // Also listen for scroll events as backup
    const handleScroll = () => updateThemeFromSections();
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    // Store scroll listener for cleanup
    (element as any)._headerThemeScrollHandler = handleScroll;
  }, [updateThemeFromSections]);

  const unregisterSection = useCallback((id: string) => {
    setSections(prev => {
      const newSections = new Map(prev);
      const section = newSections.get(id);
      
      if (section) {
        // Cleanup observer
        const observer = (section.element as any)._headerThemeObserver;
        if (observer) {
          observer.disconnect();
          delete (section.element as any)._headerThemeObserver;
        }
        
        // Cleanup scroll listener
        const scrollHandler = (section.element as any)._headerThemeScrollHandler;
        if (scrollHandler) {
          window.removeEventListener('scroll', scrollHandler);
          delete (section.element as any)._headerThemeScrollHandler;
        }
        
        newSections.delete(id);
      }
      
      return newSections;
    });

    setTimeout(updateThemeFromSections, 0);
  }, [updateThemeFromSections]);

  return (
    <HeaderThemeContext.Provider 
      value={{ 
        theme, 
        setTheme, 
        registerSection, 
        unregisterSection 
      }}
    >
      {children}
    </HeaderThemeContext.Provider>
  );
};

export const useHeaderTheme = () => {
  const context = useContext(HeaderThemeContext);
  if (context === undefined) {
    throw new Error('useHeaderTheme must be used within a HeaderThemeProvider');
  }
  return context;
};