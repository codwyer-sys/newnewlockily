/**
 * Utility functions for bid-related operations
 */

/**
 * Helper function to format time consistently as HH:MM
 */
export const formatTimeToHHMM = (date: Date): string => {
  const hours = date.getHours();
  const minutes = date.getMinutes();
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
};

/**
 * Helper function to parse and validate time string
 */
export const parseTimeString = (timeStr: string): { hours: number; minutes: number } | null => {
  if (!timeStr || typeof timeStr !== 'string') return null;
  
  const normalizedTime = timeStr.replace(/[.,\s]/g, ':').trim();
  const parts = normalizedTime.split(':');
  
  if (parts.length !== 2) return null;
  
  const hours = parseInt(parts[0], 10);
  const minutes = parseInt(parts[1], 10);
  
  if (isNaN(hours) || isNaN(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
    return null;
  }
  
  return { hours, minutes };
};

/**
 * Calculate estimated arrival time based on distance and duration
 */
export const calculateEstimatedArrivalTime = (localDistance?: { duration: number } | null): string => {
  const now = new Date();
  
  if (!localDistance) {
    const defaultArrival = new Date(now.getTime() + 30 * 60000);
    return formatTimeToHHMM(defaultArrival);
  }
  
  const arrivalMinutes = localDistance.duration + 10;
  const arrivalDate = new Date(now.getTime() + arrivalMinutes * 60000);
  
  return formatTimeToHHMM(arrivalDate);
};

/**
 * Adjust arrival time by adding/subtracting minutes
 */
export const adjustArrivalTime = (currentTime: string, minutes: number): string => {
  let timeToAdjust = currentTime;
  
  if (!timeToAdjust) {
    const now = new Date();
    const defaultTime = new Date(now.getTime() + 30 * 60000);
    timeToAdjust = formatTimeToHHMM(defaultTime);
  }
  
  const parsedTime = parseTimeString(timeToAdjust);
  if (!parsedTime) {
    console.error('Could not parse time:', timeToAdjust);
    const now = new Date();
    const fallbackTime = new Date(now.getTime() + 30 * 60000);
    timeToAdjust = formatTimeToHHMM(fallbackTime);
    const fallbackParsed = parseTimeString(timeToAdjust);
    if (!fallbackParsed) return timeToAdjust;
    
    const totalMinutes = fallbackParsed.hours * 60 + fallbackParsed.minutes + minutes;
    const newHours = Math.floor(totalMinutes / 60) % 24;
    const newMins = totalMinutes % 60;
    return `${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`;
  }
  
  const totalMinutes = parsedTime.hours * 60 + parsedTime.minutes + minutes;
  let newHours = Math.floor(totalMinutes / 60) % 24;
  let newMins = totalMinutes % 60;
  
  if (newHours < 0) newHours += 24;
  if (newMins < 0) {
    newMins += 60;
    newHours = (newHours - 1 + 24) % 24;
  }
  
  return `${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`;
};