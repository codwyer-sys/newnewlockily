import { supabase } from '@/integrations/supabase/client';

export const getLocalizedCityName = async (
  cityId: string,
  languageCode: string,
  marketCode?: string
): Promise<string | null> => {
  try {
    let query = supabase
      .from('city_translations')
      .select('local_name')
      .eq('city_id', cityId)
      .eq('language_code', languageCode);

    if (marketCode) {
      query = query.eq('market_code', marketCode);
    }

    const { data } = await query.single();
    return data?.local_name || null;
  } catch {
    return null;
  }
};

export const getDisplayName = (
  englishName: string,
  localName?: string | null,
  showBoth = false
): string => {
  if (!localName || localName === englishName) {
    return englishName;
  }
  
  return showBoth ? `${localName} (${englishName})` : localName;
};