export const getCountryFlag = (countryCode: string | null): string => {
  const flagMap: Record<string, string> = {
    'DK': '🇩🇰',
    'DE': '🇩🇪', 
    'GB': '🇬🇧',
    'UK': '🇬🇧',
    'US': '🇺🇸',
    'IE': '🇮🇪',
    'FR': '🇫🇷',
    'ES': '🇪🇸',
    'SE': '🇸🇪',
    'NO': '🇳🇴',
    'PL': '🇵🇱',
    'CA': '🇨🇦',
    'PT': '🇵🇹',
    'IT': '🇮🇹',
    'FI': '🇫🇮',
    'CZ': '🇨🇿'
  };

  return flagMap[countryCode || ''] || '🏳️';
};

export const getCountryName = (countryCode: string | null): string => {
  const nameMap: Record<string, string> = {
    'DK': 'Denmark',
    'DE': 'Germany',
    'GB': 'United Kingdom', 
    'UK': 'United Kingdom',
    'US': 'United States',
    'IE': 'Ireland',
    'FR': 'France',
    'ES': 'Spain',
    'SE': 'Sweden',
    'NO': 'Norway',
    'PL': 'Poland',
    'CA': 'Canada',
    'PT': 'Portugal',
    'IT': 'Italy',
    'FI': 'Finland',
    'CZ': 'Czech Republic'
  };

  return nameMap[countryCode || ''] || 'Unknown';
};