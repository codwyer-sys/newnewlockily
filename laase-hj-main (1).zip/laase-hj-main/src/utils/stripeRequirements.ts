export const getRequirementInfo = (requirement: string) => {
  const requirementMap: Record<string, { title: string; description: string; actionText: string }> = {
    'business_profile.mcc': {
      title: 'Virksomhedstype',
      description: 'Du skal angive hvilken type forretning du driver (MCC-kode)',
      actionText: 'Udfyld virksomhedstype'
    },
    'business_profile.name': {
      title: 'Virksomhedsnavn',
      description: 'Dit officielle virksomhedsnavn skal udfyldes',
      actionText: 'Udfyld virksomhedsnavn'
    },
    'business_profile.support_email': {
      title: 'Support email',
      description: 'En email-adresse hvor kunder kan kontakte dig',
      actionText: 'Udfyld support email'
    },
    'business_profile.support_phone': {
      title: 'Support telefon',
      description: 'Et telefonnummer hvor kunder kan kontakte dig',
      actionText: 'Udfyld telefonnummer'
    },
    'business_profile.url': {
      title: 'Hjemmeside',
      description: 'Din virksomheds hjemmeside (valgfrit)',
      actionText: 'Udfyld hjemmeside'
    },
    'individual.address.city': {
      title: 'By',
      description: 'Din by skal angives',
      actionText: 'Udfyld adresse'
    },
    'individual.address.line1': {
      title: 'Adresse',
      description: 'Din fulde adresse skal angives',
      actionText: 'Udfyld adresse'
    },
    'individual.address.postal_code': {
      title: 'Postnummer',
      description: 'Dit postnummer skal angives',
      actionText: 'Udfyld adresse'
    },
    'individual.dob.day': {
      title: 'Fødselsdato',
      description: 'Din fødselsdag skal angives',
      actionText: 'Udfyld personlige oplysninger'
    },
    'individual.dob.month': {
      title: 'Fødselsdato',
      description: 'Din fødselsmåned skal angives',
      actionText: 'Udfyld personlige oplysninger'
    },
    'individual.dob.year': {
      title: 'Fødselsdato',
      description: 'Dit fødselsår skal angives',
      actionText: 'Udfyld personlige oplysninger'
    },
    'individual.email': {
      title: 'Email',
      description: 'Din email-adresse skal bekræftes',
      actionText: 'Bekræft email'
    },
    'individual.first_name': {
      title: 'Fornavn',
      description: 'Dit fornavn skal angives',
      actionText: 'Udfyld personlige oplysninger'
    },
    'individual.last_name': {
      title: 'Efternavn',
      description: 'Dit efternavn skal angives',
      actionText: 'Udfyld personlige oplysninger'
    },
    'individual.phone': {
      title: 'Telefonnummer',
      description: 'Dit telefonnummer skal angives',
      actionText: 'Udfyld telefonnummer'
    },
    'individual.id_number': {
      title: 'CPR-nummer',
      description: 'Dit CPR-nummer skal angives for identifikation',
      actionText: 'Udfyld CPR-nummer'
    },
    'business_type': {
      title: 'Virksomhedsform',
      description: 'Du skal angive om du er enkeltmandsvirksomhed, ApS, A/S etc.',
      actionText: 'Vælg virksomhedsform'
    },
    'company.address.city': {
      title: 'Virksomhedens by',
      description: 'Din virksomheds by skal angives',
      actionText: 'Udfyld virksomhedsadresse'
    },
    'company.address.line1': {
      title: 'Virksomhedsadresse',
      description: 'Din virksomheds fulde adresse skal angives',
      actionText: 'Udfyld virksomhedsadresse'
    },
    'company.address.postal_code': {
      title: 'Virksomhedens postnummer',
      description: 'Din virksomheds postnummer skal angives',
      actionText: 'Udfyld virksomhedsadresse'
    },
    'company.name': {
      title: 'Virksomhedsnavn',
      description: 'Dit officielle virksomhedsnavn skal udfyldes',
      actionText: 'Udfyld virksomhedsnavn'
    },
    'company.phone': {
      title: 'Virksomhedens telefon',
      description: 'Din virksomheds telefonnummer skal angives',
      actionText: 'Udfyld telefonnummer'
    },
    'external_account': {
      title: 'Bankkonto',
      description: 'Du skal tilføje en bankkonto for at modtage udbetalinger',
      actionText: 'Tilføj bankkonto'
    },
    'tos_acceptance.date': {
      title: 'Servicevilkår',
      description: 'Du skal acceptere Stripes servicevilkår',
      actionText: 'Acceptér vilkår'
    },
    'tos_acceptance.ip': {
      title: 'Servicevilkår',
      description: 'Du skal acceptere Stripes servicevilkår',
      actionText: 'Acceptér vilkår'
    }
  };

  return requirementMap[requirement] || {
    title: requirement,
    description: 'Dette krav skal udfyldes i Stripe',
    actionText: 'Udfyld i Stripe'
  };
};

export const getRequirements = (accountStatus: any) => {
  if (!accountStatus?.account?.requirements) return [];
  
  return [
    ...(accountStatus.account.requirements.currently_due || []),
    ...(accountStatus.account.requirements.eventually_due || [])
  ];
};