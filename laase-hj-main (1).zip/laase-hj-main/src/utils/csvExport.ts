import { LocksmithTableData } from '@/hooks/useLocksmithsTable';

export const exportToCSV = (data: LocksmithTableData[], filename: string = 'locksmiths_export') => {
  if (data.length === 0) {
    console.warn('No data to export');
    return;
  }

  // Define CSV headers
  const headers = [
    'ID',
    'Business Name',
    'Contact Person',
    'City',
    'Market',
    'Contact Email',
    'Phone',
    'Status',
    'Completed Jobs',
    'Emergency Available',
    'Has Specializations',
    'Stripe Connected',
    'Date Joined'
  ];

  // Convert data to CSV rows
  const csvRows = data.map(locksmith => [
    locksmith.id,
    locksmith.company_name || `${locksmith.first_name || ''} ${locksmith.last_name || ''}`.trim() || 'N/A',
    `${locksmith.first_name || ''} ${locksmith.last_name || ''}`.trim() || 'N/A',
    locksmith.city || 'N/A',
    locksmith.market || 'N/A',
    locksmith.email,
    locksmith.phone || 'N/A',
    locksmith.status || 'N/A',
    locksmith.completed_jobs.toString(),
    locksmith.emergency_available ? 'Yes' : 'No',
    locksmith.has_specializations ? 'Yes' : 'No',
    locksmith.stripe_connected ? 'Yes' : 'No',
    new Date(locksmith.created_at).toLocaleDateString()
  ]);

  // Combine headers and rows
  const csvContent = [headers, ...csvRows]
    .map(row => row.map(field => `"${field}"`).join(','))
    .join('\n');

  // Create and download the file
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};