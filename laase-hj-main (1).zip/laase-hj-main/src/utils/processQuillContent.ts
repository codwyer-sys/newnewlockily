export function processQuillContent(content: string): string {
  if (!content) return '';
  
  // Create a temporary DOM element to manipulate the HTML
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = content;
  
  // Fix Quill lists: Convert <ol data-list="bullet"> to <ul>
  const bulletLists = tempDiv.querySelectorAll('ol[data-list="bullet"]');
  bulletLists.forEach(ol => {
    const ul = document.createElement('ul');
    ul.innerHTML = ol.innerHTML;
    // Copy any classes from the original ol
    if (ol.className) {
      ul.className = ol.className;
    }
    ol.parentNode?.replaceChild(ul, ol);
  });
  
  // Remove empty Quill UI elements
  const quillUIElements = tempDiv.querySelectorAll('span.ql-ui');
  quillUIElements.forEach(el => el.remove());
  
  // Clean up empty br tags in headings
  const headings = tempDiv.querySelectorAll('h1, h2, h3, h4, h5, h6');
  headings.forEach(heading => {
    const brTags = heading.querySelectorAll('br');
    brTags.forEach(br => {
      if (br.nextSibling === null || br.nextSibling.textContent?.trim() === '') {
        br.remove();
      }
    });
  });
  
  // Remove any empty paragraphs that only contain br tags
  const emptyParas = tempDiv.querySelectorAll('p');
  emptyParas.forEach(p => {
    if (p.innerHTML.trim() === '<br>' || p.innerHTML.trim() === '') {
      p.remove();
    }
  });
  
  return tempDiv.innerHTML;
}