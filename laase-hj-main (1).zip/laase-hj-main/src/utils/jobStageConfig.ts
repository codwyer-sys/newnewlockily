import { Clock, CheckCircle, AlertCircle, Navigation, Wrench, Star, type LucideIcon } from 'lucide-react';

export type JobStage = 
  | 'waiting_for_quotes'
  | 'awaiting_client_feedback' 
  | 'awaiting_locksmith_acceptance'
  | 'locksmith_en_route'
  | 'locksmith_on_job'
  | 'job_finished';

interface JobStageConfig {
  icon: LucideIcon;
  badgeIcon: LucideIcon;
  title: string;
  description: string;
  badgeText: string;
  bgGradient: string;
  progressPercentage: number;
  showETA: boolean;
}

export const getJobStageConfig = (stage?: JobStage, titleOverride?: string, descriptionOverride?: string, badgeTextOverride?: string): JobStageConfig => {
  const stageKey = stage || 'waiting_for_quotes';
  
  const baseConfigs: Record<JobStage, Omit<JobStageConfig, 'title' | 'description' | 'badgeText'>> = {
    waiting_for_quotes: {
      icon: Clock,
      badgeIcon: Clock,
      bgGradient: 'from-blue-600 to-blue-800',
      progressPercentage: 20,
      showETA: true
    },
    awaiting_client_feedback: {
      icon: AlertCircle,
      badgeIcon: AlertCircle,
      bgGradient: 'from-amber-600 to-orange-700',
      progressPercentage: 40,
      showETA: true
    },
    awaiting_locksmith_acceptance: {
      icon: Clock,
      badgeIcon: Clock,
      bgGradient: 'from-indigo-600 to-purple-700',
      progressPercentage: 60,
      showETA: true
    },
    locksmith_en_route: {
      icon: Navigation,
      badgeIcon: Navigation,
      bgGradient: 'from-green-600 to-emerald-700',
      progressPercentage: 80,
      showETA: true
    },
    locksmith_on_job: {
      icon: Wrench,
      badgeIcon: Wrench,
      bgGradient: 'from-teal-600 to-cyan-700',
      progressPercentage: 90,
      showETA: false
    },
    job_finished: {
      icon: Star,
      badgeIcon: CheckCircle,
      bgGradient: 'from-emerald-600 to-green-700',
      progressPercentage: 100,
      showETA: false
    }
  };

  // Default fallbacks
  const fallbacks: Record<JobStage, { title: string; description: string; badgeText: string }> = {
    waiting_for_quotes: {
      title: 'Searching for Available Locksmiths',
      description: 'We\'re connecting you with qualified locksmiths in your area',
      badgeText: 'Finding Locksmiths'
    },
    awaiting_client_feedback: {
      title: 'Choose Your Locksmith',
      description: 'Review and select from available quotes',
      badgeText: 'Select Quote'
    },
    awaiting_locksmith_acceptance: {
      title: 'Confirming Your Locksmith',
      description: 'Your selected locksmith is confirming availability',
      badgeText: 'Confirming'
    },
    locksmith_en_route: {
      title: 'Your Locksmith is on the Way',
      description: 'Track your locksmith\'s arrival in real-time',
      badgeText: 'En Route'
    },
    locksmith_on_job: {
      title: 'Service in Progress',
      description: 'Your locksmith is working on your request',
      badgeText: 'Working'
    },
    job_finished: {
      title: 'Service Completed',
      description: 'Your locksmith service has been completed successfully',
      badgeText: 'Completed'
    }
  };

  const baseConfig = baseConfigs[stageKey];
  const fallback = fallbacks[stageKey];

  return {
    ...baseConfig,
    title: titleOverride || fallback.title,
    description: descriptionOverride || fallback.description,
    badgeText: badgeTextOverride || fallback.badgeText
  };
};