import { JobCategoryWithPreference, GlobalPricingSettings, FollowUpQuestionPricing } from '@/hooks/useAutoBidPreferences';

export interface PriceCalculationInput {
  jobCategory: string;
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  followUpAnswers?: Record<string, any>;
  timeRequested?: string;
  distance?: number; // in km
  locksmithId?: string;
  chargeClientForReferral?: boolean;
}

export interface PriceBreakdown {
  basePrice: number;
  followUpFees: Array<{
    question: string;
    answer: string;
    fee: number;
    type: 'percentage' | 'fixed';
  }>;
  timeSurcharge: {
    type: 'nighttime' | 'weekend' | 'both' | null;
    amount: number;
  };
  distanceFee: number;
  referralFee: {
    percentage: number;
    amount: number;
    chargedToClient: boolean;
  };
  total: number;
  locksmithEarnings: number;
}

export class PriceCalculator {
  private category: JobCategoryWithPreference;
  private globalSettings: GlobalPricingSettings | null;
  private referralFeePercentage: number;

  constructor(category: JobCategoryWithPreference, globalSettings: GlobalPricingSettings | null, referralFeePercentage: number = 20) {
    this.category = category;
    this.globalSettings = globalSettings;
    this.referralFeePercentage = referralFeePercentage;
  }

  calculate(input: PriceCalculationInput): PriceBreakdown {
    const basePrice = this.category.base_price || 0;
    let runningTotal = basePrice;

    // Calculate follow-up question fees
    const followUpFees = this.calculateFollowUpFees(input.followUpAnswers, runningTotal);
    const followUpTotal = followUpFees.reduce((sum, fee) => sum + fee.fee, 0);
    runningTotal += followUpTotal;

    // Calculate time-based surcharges
    const timeSurcharge = this.calculateTimeSurcharge(runningTotal, input.timeRequested);
    runningTotal += timeSurcharge.amount;

    // Calculate distance fees
    const distanceFee = this.calculateDistanceFee(input.distance);
    runningTotal += distanceFee;

    // Calculate referral fee
    const referralFee = this.calculateReferralFee(runningTotal, input.chargeClientForReferral || false);
    
    // If charging client for referral fee, add it to total
    if (referralFee.chargedToClient) {
      runningTotal += referralFee.amount;
    }

    const total = Math.round(runningTotal);
    const locksmithEarnings = referralFee.chargedToClient 
      ? total 
      : Math.round(total - referralFee.amount);

    return {
      basePrice,
      followUpFees,
      timeSurcharge,
      distanceFee,
      referralFee,
      total,
      locksmithEarnings
    };
  }

  private calculateFollowUpFees(answers: Record<string, any> = {}, baseAmount: number) {
    const fees: PriceBreakdown['followUpFees'] = [];

    this.category.follow_up_questions.forEach(question => {
      const answer = answers[question.id];
      if (!answer) return;

      const pricing = question.pricing.find(p => p.answer_value === answer);
      if (!pricing) return;

      let feeAmount = 0;
      if (pricing.fee_type === 'percentage') {
        feeAmount = baseAmount * (pricing.fee_amount / 100);
      } else {
        feeAmount = pricing.fee_amount;
      }

      fees.push({
        question: question.question,
        answer: answer,
        fee: feeAmount,
        type: pricing.fee_type
      });
    });

    return fees;
  }

  private calculateTimeSurcharge(currentTotal: number, timeRequested?: string) {
    if (!this.globalSettings || !timeRequested) {
      console.log('No global settings or timeRequested:', { globalSettings: !!this.globalSettings, timeRequested });
      return { type: null, amount: 0 };
    }

    const requestTime = new Date(timeRequested);
    const hour = requestTime.getHours();
    const dayOfWeek = requestTime.getDay();
    
    console.log('Time surcharge calculation:', { 
      timeRequested, 
      requestTime: requestTime.toISOString(), 
      hour, 
      dayOfWeek,
      nighttimeHours: `${this.globalSettings.nighttime_start_hour}-${this.globalSettings.nighttime_end_hour}`,
      isWeekend: dayOfWeek === 0 || dayOfWeek === 6
    });

    const isNighttime = hour >= this.globalSettings.nighttime_start_hour || hour < this.globalSettings.nighttime_end_hour;
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    let totalSurcharge = 0;
    let surchargeType: 'nighttime' | 'weekend' | 'both' | null = null;

    if (isNighttime && isWeekend && this.globalSettings.combine_nighttime_weekend_fees) {
      // Combined fee
      const nighttimeFee = this.globalSettings.nighttime_fee_type === 'percentage' 
        ? currentTotal * (this.globalSettings.nighttime_fee_amount / 100)
        : this.globalSettings.nighttime_fee_amount;
      
      const weekendFee = this.globalSettings.weekend_fee_type === 'percentage'
        ? currentTotal * (this.globalSettings.weekend_fee_amount / 100)
        : this.globalSettings.weekend_fee_amount;

      totalSurcharge = nighttimeFee + weekendFee;
      surchargeType = 'both';
    } else if (isNighttime) {
      totalSurcharge = this.globalSettings.nighttime_fee_type === 'percentage'
        ? currentTotal * (this.globalSettings.nighttime_fee_amount / 100)
        : this.globalSettings.nighttime_fee_amount;
      surchargeType = 'nighttime';
    } else if (isWeekend) {
      totalSurcharge = this.globalSettings.weekend_fee_type === 'percentage'
        ? currentTotal * (this.globalSettings.weekend_fee_amount / 100)
        : this.globalSettings.weekend_fee_amount;
      surchargeType = 'weekend';
    }

    return {
      type: surchargeType,
      amount: totalSurcharge
    };
  }

  private calculateDistanceFee(distance?: number) {
    if (!this.globalSettings || !distance) return 0;

    const excessDistance = Math.max(0, distance - this.globalSettings.base_radius_km);
    return excessDistance * this.globalSettings.fee_per_km_above_radius;
  }


  private calculateReferralFee(currentTotal: number, chargedToClient: boolean) {
    const percentage = this.referralFeePercentage;
    const amount = currentTotal * (percentage / 100);

    return {
      percentage,
      amount,
      chargedToClient
    };
  }
}