import { supabase } from '@/integrations/supabase/client';
import { LocksmithJob, ServiceArea } from '@/types/locksmith';
import { filterJobsByServiceArea } from './serviceAreaFilter';

export interface FetchJobsResult {
  jobs: LocksmithJob[];
  error: Error | null;
}

/**
 * Transforms a booking from the database into a LocksmithJob
 */
const transformBookingToJob = (booking: any): LocksmithJob => {
  console.log('🔍 [transformBookingToJob] Raw booking data:', JSON.stringify(booking, null, 2));
  
  const followUpAnswers = booking.follow_up_answers as any || {};
  
  // Handle both nested and flattened job category structures
  let jobCategory = null;
  let categoryName = 'Ukendt kategori';
  let categoryId = booking.job_category_id || null;
  
  if (booking.job_categories) {
    // Nested structure from Supabase select
    jobCategory = booking.job_categories;
    categoryName = jobCategory?.name || 'Ukendt kategori';
  } else if (booking.category_name) {
    // Flattened structure from JOIN
    categoryName = booking.category_name;
  } else if (booking.job_category) {
    // Legacy structure
    jobCategory = booking.job_category;
    categoryName = jobCategory?.name || 'Ukendt kategori';
  }
  
  console.log('🔍 [transformBookingToJob] Processing booking:', {
    id: booking.id,
    address: booking.address,
    categoryId: categoryId,
    categoryName: categoryName,
    jobCategory: jobCategory,
    urgency: booking.urgency,
    status: booking.status,
    locksmith_id: booking.locksmith_id
  });

  if (!categoryName || categoryName === 'Ukendt kategori' || !categoryId) {
    console.warn('🔍 [transformBookingToJob] Missing or default job category for booking:', booking.id, {
      job_categories: booking.job_categories,
      category_name: booking.category_name,
      job_category: booking.job_category,
      job_category_id: booking.job_category_id,
      categoryId: categoryId
    });
  }
  
  const finalJob = {
    id: booking.id,
    jobNumber: booking.job_number || 0,
    categoryId: categoryId || '',
    categoryName: categoryName,
    category: categoryName, // Backwards compatibility
    address: booking.address,
    lockBrand: followUpAnswers.lock_brand || followUpAnswers.lockBrand,
    urgency: booking.urgency === 'nu' ? 'emergency' as const : booking.urgency as 'low' | 'medium' | 'high' | 'emergency',
    timeRequested: booking.created_at,
    customerPhone: followUpAnswers.phone || followUpAnswers.customerPhone || 'Ikke tilgængelig',
    customerName: followUpAnswers.customerName || followUpAnswers.name || 'Kunde',
    timing: followUpAnswers.timing || followUpAnswers.when_needed,
    scheduledDate: booking.scheduled_date,
    followUpAnswers: followUpAnswers // Add the missing field
  };
  
  console.log('🔍 [transformBookingToJob] Final transformed job:', finalJob);
  return finalJob;
};

/**
 * Fetches jobs for a locksmith based on their service area
 */
export const fetchJobs = async (userId: string): Promise<FetchJobsResult> => {
  try {
    if (!userId) {
      console.log('🔍 [jobFetcher] No user ID provided');
      return { jobs: [], error: null };
    }

    console.log('🔍 [jobFetcher] Starting job fetch for user:', userId);

    // Get locksmith's service area settings
    const { data: serviceArea, error: serviceAreaError } = await supabase
      .from('service_areas')
      .select('*')
      .eq('locksmith_id', userId)
      .maybeSingle();

    console.log('🔍 [jobFetcher] Service area:', serviceArea, 'Error:', serviceAreaError);

    // Try nested select first
    console.log('🔍 [jobFetcher] Attempting to fetch jobs with nested select...');
    
    let { data: bookings, error } = await supabase
      .from('bookings')
      .select(`
        *,
        job_categories (name, emoji)
      `)
      .eq('status', 'waiting_for_quotes')
      .is('locksmith_id', null) // Jobs that haven't been assigned yet
      .order('created_at', { ascending: false });

    console.log('🔍 [jobFetcher] Nested select result:', {
      bookingsCount: bookings?.length || 0,
      error: error,
      hasJobCategories: bookings?.[0]?.job_categories ? 'Yes' : 'No'
    });

    // If nested select fails or doesn't return job categories, try a different approach
    if (error || !bookings || bookings.length === 0 || !bookings[0]?.job_categories) {
      console.log('🔍 [jobFetcher] Nested select failed or incomplete, trying manual lookup...');
      
      const { data: bookingsSimple, error: simpleError } = await supabase
        .from('bookings')
        .select('*')
        .eq('status', 'waiting_for_quotes')
        .is('locksmith_id', null)
        .order('created_at', { ascending: false });

      if (simpleError) {
        console.error('🔍 [jobFetcher] Error fetching jobs (simple):', simpleError);
        return { jobs: [], error: simpleError };
      }

      console.log('🔍 [jobFetcher] Simple query result:', {
        bookingsCount: bookingsSimple?.length || 0
      });

      // For each booking, fetch the job category separately
      if (bookingsSimple && bookingsSimple.length > 0) {
        const bookingsWithCategories = await Promise.all(
          bookingsSimple.map(async (booking) => {
            const { data: category } = await supabase
              .from('job_categories')
              .select('name, emoji')
              .eq('id', booking.job_category_id)
              .maybeSingle();

            return {
              ...booking,
              job_categories: category
            };
          })
        );

        bookings = bookingsWithCategories;
        error = null;
        
        console.log('🔍 [jobFetcher] Manual lookup complete, sample booking:', JSON.stringify(bookings[0], null, 2));
      }
    } else if (bookings && bookings.length > 0) {
      console.log('🔍 [jobFetcher] Nested select successful, sample booking:', JSON.stringify(bookings[0], null, 2));
    }

    if (error) {
      console.error('🔍 [jobFetcher] Final error fetching jobs:', error);
      return { jobs: [], error };
    }

    // Transform bookings to job format
    let transformedJobs: LocksmithJob[] = bookings?.map(booking => {
      const transformed = transformBookingToJob(booking);
      
      console.log('🔍 [jobFetcher] Transformed job:', {
        id: transformed.id,
        category: transformed.category,
        address: transformed.address,
        urgency: transformed.urgency
      });
      
      return transformed;
    }) || [];

    console.log('🔍 [jobFetcher] Total jobs before filtering:', transformedJobs.length);

    // Filter jobs based on service area if configured
    const filteredJobs = filterJobsByServiceArea(transformedJobs, serviceArea);

    console.log('🔍 [jobFetcher] Final job count:', filteredJobs.length);
    return { jobs: filteredJobs, error: null };
    
  } catch (error) {
    console.error('🔍 [jobFetcher] Error in fetchJobs:', error);
    return { jobs: [], error: error as Error };
  }
};