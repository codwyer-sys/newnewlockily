import { LocksmithJob, ServiceArea } from '@/types/locksmith';

/**
 * Extracts postal code from various Danish address formats
 */
const extractPostalCode = (address: string): string | null => {
  console.log('🔍 [extractPostalCode] Processing address:', address);
  
  // Try multiple regex patterns for Danish addresses including MapBox formats
  const postalCodePatterns = [
    /,\s*(\d{4})\s+[A-Za-zÆØÅæøå]+,\s*[A-Za-z]+$/,  // MapBox format: ", 1440 København, Denmark"
    /,\s*(\d{4})\s+[A-Za-zÆØÅæøå]/,  // Most common: ", 8000 Aarhus C"
    /,\s*(\d{4})\s/,  // 4 digits after comma with space
    /\s(\d{4})\s+[A-Za-zÆØÅæøå]/,  // Space before postal code
    /(\d{4})\s*[A-Za-zÆØÅæøå]+\s*[A-Za-zÆØÅæøå]*$/,  // 4 digits at end with city
    /\b(\d{4})\b/,  // Basic 4-digit pattern (fallback)
  ];
  
  // Test the specific known address
  if (address === "Indiakaj, 2100 København, Denmark") {
    console.log('🔍 [extractPostalCode] Testing known address patterns...');
    for (let i = 0; i < postalCodePatterns.length; i++) {
      const pattern = postalCodePatterns[i];
      const match = address.match(pattern);
      console.log(`🔍 [extractPostalCode] Pattern ${i + 1} (${pattern}):`, match ? `Found ${match[1]}` : 'No match');
    }
  }
  
  for (const pattern of postalCodePatterns) {
    const match = address.match(pattern);
    if (match) {
      console.log('🔍 [extractPostalCode] Found postal code:', match[1], 'using pattern:', pattern);
      return match[1];
    }
  }
  
  console.log('🔍 [extractPostalCode] No postal code found in:', address);
  return null;
};

/**
 * Filters jobs based on service area configuration
 */
export const filterJobsByServiceArea = (
  jobs: LocksmithJob[],
  serviceArea: ServiceArea | null
): LocksmithJob[] => {
  console.log('🔍 [serviceAreaFilter] Starting filter with:', {
    jobCount: jobs.length,
    serviceArea: serviceArea,
    jobAddresses: jobs.map(j => ({ id: j.id, address: j.address }))
  });

  if (!serviceArea) {
    console.log('🔍 [serviceAreaFilter] No service area configured, showing all jobs');
    return jobs;
  }

  console.log('🔍 [serviceAreaFilter] Applying service area filter:', serviceArea.service_type);
  
  if (serviceArea.service_type === 'postal_codes' && serviceArea.postal_codes?.length > 0) {
    console.log('🔍 [serviceAreaFilter] Filtering by postal codes:', serviceArea.postal_codes);
    console.log('🔍 [serviceAreaFilter] Postal codes data types:', serviceArea.postal_codes.map(pc => typeof pc + ': ' + pc));
    
    const beforeFilterCount = jobs.length;
    const filteredJobs = jobs.filter(job => {
      try {
        const jobPostalCode = extractPostalCode(job.address);
        
        console.log('🔍 [serviceAreaFilter] Address:', job.address, '-> Postal code:', jobPostalCode, '(type:', typeof jobPostalCode + ')');
        
        if (jobPostalCode) {
          const jobPostalCodeStr = jobPostalCode.toString();
          
          // Convert service area postal codes to strings for comparison and check if job postal code is included
          const serviceAreaPostalCodesStr = serviceArea.postal_codes!.map(pc => pc.toString());
          const isIncluded = serviceAreaPostalCodesStr.includes(jobPostalCodeStr);
          
          console.log('🔍 [serviceAreaFilter] Postal code comparison:');
          console.log('  - Job postal code:', jobPostalCodeStr);
          console.log('  - Service area postal codes:', serviceAreaPostalCodesStr);
          console.log('  - Included?', isIncluded);
          
          return isIncluded;
        }
        
        console.log('🔍 [serviceAreaFilter] Could not extract postal code, including job');
        return true; // Include if we can't determine postal code
        
      } catch (error) {
        console.error('🔍 [serviceAreaFilter] Error processing job:', job.id, error);
        return true; // Include job if there's an error to avoid losing jobs
      }
    });
    
    console.log('🔍 [serviceAreaFilter] Jobs after postal code filter:', filteredJobs.length, '(was', beforeFilterCount + ')');
    return filteredJobs;
  }
  
  // Distance-based filtering would require MapBox API calls for each job
  // For now, return all jobs if distance-based filtering is configured
  return jobs;
};