/**
 * Plays a notification sound with multiple beeps for attention
 */
export const playNotificationSound = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // Create multiple beeps for attention
    for (let i = 0; i < 5; i++) {
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Alternating high and low pitch for attention
      const frequency = i % 2 === 0 ? 1000 : 800;
      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime + i * 0.4);
      
      // Louder volume
      gainNode.gain.setValueAtTime(0.6, audioContext.currentTime + i * 0.4);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + i * 0.4 + 0.3);
      
      oscillator.start(audioContext.currentTime + i * 0.4);
      oscillator.stop(audioContext.currentTime + i * 0.4 + 0.3);
    }
  } catch (error) {
    console.warn('Failed to play notification sound:', error);
  }
};