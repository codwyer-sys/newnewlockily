import { supabase } from "@/integrations/supabase/client";

export interface TranslationDetectionResult {
  enabledLanguages: string[];
  existingTranslations: Array<{ language_code: string; market_code: string | null; section_id: string }>;
  missingLanguages: string[];
  missingCount: number;
  marketLanguageAccess: Array<{ market_code: string; language_code: string; is_enabled: boolean }>;
  debugInfo: {
    contentKey: string;
    sectionId: string;
    totalEnabledLanguages: number;
    totalExistingTranslations: number;
    globalTranslations: number;
  };
}

/**
 * Standardized function to detect missing translations for a content key
 * This ensures UI calculations and bulk translation use identical logic
 */
export async function detectMissingTranslations(
  contentKey: string,
  sectionId: string
): Promise<TranslationDetectionResult> {
  console.log(`🔍 [TranslationDetection] Starting analysis for ${contentKey} in section ${sectionId}`);
  
  // Get enabled languages
  const { data: marketLanguageAccess, error: accessError } = await supabase
    .from('market_language_access')
    .select('market_code, language_code, is_enabled')
    .eq('is_enabled', true);

  if (accessError) {
    console.error('❌ [TranslationDetection] Failed to get market language access:', accessError);
    throw accessError;
  }

  // Get existing translations for this content key AND section
  const { data: existingTranslations, error: existingError } = await supabase
    .from('content_translations')
    .select('language_code, market_code, section_id')
    .eq('content_key', contentKey)
    .eq('section_id', sectionId);

  if (existingError) {
    console.error('❌ [TranslationDetection] Failed to get existing translations:', existingError);
    throw existingError;
  }

  // Get all enabled languages (exclude English)
  const enabledLanguages = [...new Set(
    marketLanguageAccess?.map(access => access.language_code) || []
  )].filter(lang => lang !== 'en');

  // Find missing languages (check only global translations with market_code = null)
  const missingLanguages = enabledLanguages.filter(language => 
    !existingTranslations?.some(existing => 
      existing.language_code === language && existing.market_code === null
    )
  );

  // Count global translations (market_code = null)
  const globalTranslations = existingTranslations?.filter(t => t.market_code === null).length || 0;

  const result: TranslationDetectionResult = {
    enabledLanguages,
    existingTranslations: existingTranslations || [],
    missingLanguages,
    missingCount: missingLanguages.length,
    marketLanguageAccess: marketLanguageAccess || [],
    debugInfo: {
      contentKey,
      sectionId,
      totalEnabledLanguages: enabledLanguages.length,
      totalExistingTranslations: existingTranslations?.length || 0,
      globalTranslations
    }
  };

  console.log(`📊 [TranslationDetection] Results for ${contentKey}:`, {
    enabledLanguages: result.enabledLanguages,
    missingLanguages: result.missingLanguages,
    missingCount: result.missingCount,
    existingGlobalTranslations: result.existingTranslations
      .filter(t => t.market_code === null)
      .map(t => t.language_code),
    debugInfo: result.debugInfo
  });

  return result;
}

/**
 * Ultra-efficient bulk detection for all content items at once
 * Eliminates redundant database queries by fetching shared data once
 */
export async function detectMissingTranslationsBulk(
  items: Array<{ content_key: string; section_id: string; id: string }>
): Promise<Map<string, TranslationDetectionResult>> {
  console.log(`🚀 [BulkTranslationDetection] Starting optimized bulk analysis for ${items.length} items`);
  
  const results = new Map<string, TranslationDetectionResult>();
  
  try {
    // PHASE 1: Fetch shared data once (eliminates 243 redundant queries)
    console.log(`📊 [BulkTranslationDetection] Fetching shared market language access data...`);
    const { data: marketLanguageAccess, error: accessError } = await supabase
      .from('market_language_access')
      .select('market_code, language_code, is_enabled')
      .eq('is_enabled', true);

    if (accessError) {
      console.error('❌ [BulkTranslationDetection] Failed to get market language access:', accessError);
      throw accessError;
    }

    // PHASE 2: Fetch all existing translations in one query (eliminates 243 individual queries)
    console.log(`📊 [BulkTranslationDetection] Fetching all existing translations...`);
    const contentKeys = items.map(item => item.content_key);
    const sectionIds = [...new Set(items.map(item => item.section_id))];
    
    const { data: allExistingTranslations, error: existingError } = await supabase
      .from('content_translations')
      .select('content_key, language_code, market_code, section_id')
      .in('content_key', contentKeys)
      .in('section_id', sectionIds);

    if (existingError) {
      console.error('❌ [BulkTranslationDetection] Failed to get existing translations:', existingError);
      throw existingError;
    }

    // PHASE 3: Process all items using shared datasets (no additional database calls)
    console.log(`⚡ [BulkTranslationDetection] Processing ${items.length} items with shared data...`);
    
    // Get enabled languages once
    const enabledLanguages = [...new Set(
      marketLanguageAccess?.map(access => access.language_code) || []
    )].filter(lang => lang !== 'en');

    // Group existing translations by content_key and section_id for fast lookup
    const existingTranslationsMap = new Map<string, Array<{ language_code: string; market_code: string | null }>>();
    allExistingTranslations?.forEach(trans => {
      const key = `${trans.content_key}:${trans.section_id}`;
      if (!existingTranslationsMap.has(key)) {
        existingTranslationsMap.set(key, []);
      }
      existingTranslationsMap.get(key)!.push({
        language_code: trans.language_code,
        market_code: trans.market_code
      });
    });

    // Process each item using shared data
    for (const item of items) {
      try {
        const lookupKey = `${item.content_key}:${item.section_id}`;
        const existingTranslations = existingTranslationsMap.get(lookupKey) || [];

        // Find missing languages (check only global translations with market_code = null)
        const missingLanguages = enabledLanguages.filter(language => 
          !existingTranslations.some(existing => 
            existing.language_code === language && existing.market_code === null
          )
        );

        // Count global translations (market_code = null)
        const globalTranslations = existingTranslations.filter(t => t.market_code === null).length;

        const result: TranslationDetectionResult = {
          enabledLanguages,
          existingTranslations: existingTranslations.map(et => ({
            language_code: et.language_code,
            market_code: et.market_code,
            section_id: item.section_id
          })),
          missingLanguages,
          missingCount: missingLanguages.length,
          marketLanguageAccess: marketLanguageAccess || [],
          debugInfo: {
            contentKey: item.content_key,
            sectionId: item.section_id,
            totalEnabledLanguages: enabledLanguages.length,
            totalExistingTranslations: existingTranslations.length,
            globalTranslations
          }
        };

        results.set(item.id, result);
        
      } catch (error) {
        console.error(`❌ [BulkTranslationDetection] Failed to process ${item.content_key}:`, error);
        // Add fallback result to prevent UI blocking
        results.set(item.id, {
          enabledLanguages,
          existingTranslations: [],
          missingLanguages: [],
          missingCount: 0,
          marketLanguageAccess: marketLanguageAccess || [],
          debugInfo: {
            contentKey: item.content_key,
            sectionId: item.section_id,
            totalEnabledLanguages: enabledLanguages.length,
            totalExistingTranslations: 0,
            globalTranslations: 0
          }
        });
      }
    }

    console.log(`✅ [BulkTranslationDetection] Bulk analysis complete: ${results.size}/${items.length} processed successfully`);
    console.log(`📊 [BulkTranslationDetection] Performance: 3 database queries instead of ${items.length * 2} individual queries`);
    
  } catch (error) {
    console.error('❌ [BulkTranslationDetection] Critical error during bulk processing:', error);
    // Return empty results to prevent UI blocking
    items.forEach(item => {
      results.set(item.id, {
        enabledLanguages: [],
        existingTranslations: [],
        missingLanguages: [],
        missingCount: 0,
        marketLanguageAccess: [],
        debugInfo: {
          contentKey: item.content_key,
          sectionId: item.section_id,
          totalEnabledLanguages: 0,
          totalExistingTranslations: 0,
          globalTranslations: 0
        }
      });
    });
  }
  
  return results;
}

/**
 * Legacy batch detection for backwards compatibility
 * @deprecated Use detectMissingTranslationsBulk for better performance
 */
export async function detectMissingTranslationsBatch(
  items: Array<{ content_key: string; section_id: string; id: string }>
): Promise<Map<string, TranslationDetectionResult>> {
  console.log(`⚠️ [TranslationDetection] Using legacy batch processing. Consider upgrading to detectMissingTranslationsBulk for better performance.`);
  return detectMissingTranslationsBulk(items);
}