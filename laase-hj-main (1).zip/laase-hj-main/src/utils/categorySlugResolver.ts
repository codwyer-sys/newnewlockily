import { supabase } from '@/integrations/supabase/client';

export interface CategorySlugData {
  category_key: string;
  slug: string;
  parent_slug?: string;
}

/**
 * Resolves category slug for a specific market context
 * @param categoryKey - The category key to resolve
 * @param marketCode - Market code (e.g., 'DK', 'UK')
 * @param languageCode - Language code (default: 'en')
 * @returns Resolved slug with fallback to English if market-specific doesn't exist
 */
export async function resolveCategorySlug(
  categoryKey: string, 
  marketCode?: string, 
  languageCode: string = 'en'
): Promise<string | null> {
  try {
    // Get the content section for blog categories
    const { data: section } = await supabase
      .from('content_sections')
      .select('id')
      .eq('section_key', 'category_management')
      .single();

    if (!section) return null;

    // Try to get market-specific slug first
    const { data: marketSlug } = await supabase
      .from('content_translations')
      .select('content_value')
      .eq('section_id', section.id)
      .eq('content_key', `${categoryKey}_slug`)
      .eq('language_code', languageCode)
      .eq('market_code', marketCode)
      .maybeSingle();

    if (marketSlug?.content_value) {
      return marketSlug.content_value;
    }

    // Fallback to global English slug
    const { data: globalSlug } = await supabase
      .from('content_translations')
      .select('content_value')
      .eq('section_id', section.id)
      .eq('content_key', `${categoryKey}_slug`)
      .eq('language_code', 'en')
      .is('market_code', null)
      .maybeSingle();

    return globalSlug?.content_value || null;
  } catch (error) {
    console.error('Error resolving category slug:', error);
    return null;
  }
}

/**
 * Builds hierarchical category URL with parent/child structure
 * @param categoryKey - The category key
 * @param marketCode - Market code
 * @param languageCode - Language code
 * @returns Full hierarchical URL path
 */
export async function buildCategoryPath(
  categoryKey: string,
  marketCode?: string,
  languageCode: string = 'en'
): Promise<string> {
  try {
    // Get category with parent info
    const { data: category } = await supabase
      .from('blog_categories')
      .select('category_key, parent_id')
      .eq('category_key', categoryKey)
      .single();

    if (!category) return '';

    const slugParts: string[] = [];
    
    // If has parent, get parent slug first
    if (category.parent_id) {
      const { data: parent } = await supabase
        .from('blog_categories')
        .select('category_key')
        .eq('id', category.parent_id)
        .single();
      
      if (parent) {
        const parentSlug = await resolveCategorySlug(parent.category_key, marketCode, languageCode);
        if (parentSlug) slugParts.push(parentSlug);
      }
    }

    // Add current category slug
    const currentSlug = await resolveCategorySlug(categoryKey, marketCode, languageCode);
    if (currentSlug) slugParts.push(currentSlug);

    return slugParts.join('/');
  } catch (error) {
    console.error('Error building category path:', error);
    return '';
  }
}

/**
 * Validates slug uniqueness within a market
 * @param slug - The slug to validate
 * @param marketCode - Market code
 * @param languageCode - Language code
 * @param excludeCategoryKey - Category key to exclude from validation (for updates)
 * @returns true if slug is unique, false otherwise
 */
export async function validateSlugUniqueness(
  slug: string,
  marketCode?: string,
  languageCode: string = 'en',
  excludeCategoryKey?: string
): Promise<boolean> {
  try {
    const { data: section } = await supabase
      .from('content_sections')
      .select('id')
      .eq('section_key', 'category_management')
      .single();

    if (!section) return false;

    let query = supabase
      .from('content_translations')
      .select('content_key')
      .eq('section_id', section.id)
      .eq('content_value', slug)
      .eq('language_code', languageCode)
      .like('content_key', '%_slug');

    if (marketCode) {
      query = query.eq('market_code', marketCode);
    } else {
      query = query.is('market_code', null);
    }

    const { data: existing } = await query;

    if (!existing || existing.length === 0) return true;

    // If excluding a category key, check if the found slug belongs to it
    if (excludeCategoryKey) {
      const excludeSlugKey = `${excludeCategoryKey}_slug`;
      return !existing.some(item => item.content_key === excludeSlugKey);
    }

    return false;
  } catch (error) {
    console.error('Error validating slug uniqueness:', error);
    return false;
  }
}

/**
 * Generates SEO-friendly slug from text
 */
export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-') // Replace spaces with hyphens
    .replace(/-+/g, '-') // Replace multiple hyphens with single
    .replace(/^-|-$/g, ''); // Remove leading/trailing hyphens
}