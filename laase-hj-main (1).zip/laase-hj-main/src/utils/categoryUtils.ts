import { supabase } from '@/integrations/supabase/client';

export interface JobCategory {
  id: string;
  name: string;
  description: string | null;
  emoji: string | null;
  requires_image: boolean | null;
  created_at: string;
  updated_at: string;
}

/**
 * Fetches job categories with consistent filtering across the application.
 * Excludes "Andet" (Other) categories to maintain consistency between
 * frontend booking form and AutoByd settings.
 */
export const fetchFilteredJobCategories = async (): Promise<JobCategory[]> => {
  const { data, error } = await supabase
    .from('job_categories')
    .select('*')
    .not('name', 'ilike', '%andet%') // Exclude "Andet" categories
    .order('name');
    
  if (error) {
    console.error('Error fetching job categories:', error);
    throw error;
  }
  
  return data || [];
};

/**
 * Checks if a category should be excluded from the filtered list
 */
export const shouldExcludeCategory = (categoryName: string): boolean => {
  return categoryName.toLowerCase().includes('andet');
};