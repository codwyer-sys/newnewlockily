/**
 * Content validation utilities for translation management
 */

export interface ContentValidationResult {
  isValid: boolean;
  warnings: string[];
  errors: string[];
}

/**
 * Validates content against its AI instruction for potential mismatches
 */
export const validateContentInstruction = (
  content: string,
  aiInstruction: string | null,
  contentKey: string
): ContentValidationResult => {
  const warnings: string[] = [];
  const errors: string[] = [];

  // Check for empty content
  if (!content?.trim()) {
    errors.push(`Empty content for key: ${contentKey}`);
  }

  // Check for missing AI instruction when content exists
  if (content?.trim() && !aiInstruction?.trim()) {
    warnings.push(`Missing AI instruction for content key: ${contentKey}`);
  }

  // Check for AI instruction without content
  if (aiInstruction?.trim() && !content?.trim()) {
    errors.push(`AI instruction exists but content is empty for key: ${contentKey}`);
  }

  // Check for potential content/instruction length mismatches
  if (aiInstruction && content) {
    const contentLength = content.trim().length;
    const instructionLength = aiInstruction.trim().length;
    
    // Very short content with very long instruction might indicate truncation
    if (contentLength < 50 && instructionLength > 200) {
      warnings.push(`Possible content truncation for key: ${contentKey} (content: ${contentLength} chars, instruction: ${instructionLength} chars)`);
    }
  }

  // Check for common truncation indicators
  if (content?.trim().endsWith('...') || content?.trim().endsWith(' process') || content?.trim().endsWith(' booking')) {
    warnings.push(`Possible truncated content detected for key: ${contentKey}`);
  }

  return {
    isValid: errors.length === 0,
    warnings,
    errors
  };
};

/**
 * Validates multiple content translations for consistency issues
 */
export const validateContentSet = (
  translations: Array<{
    content_key: string;
    content_value: string;
    ai_instruction: string | null;
    language_code: string;
  }>
): Record<string, ContentValidationResult> => {
  const results: Record<string, ContentValidationResult> = {};

  translations.forEach(translation => {
    const key = `${translation.content_key}_${translation.language_code}`;
    results[key] = validateContentInstruction(
      translation.content_value,
      translation.ai_instruction,
      translation.content_key
    );
  });

  return results;
};