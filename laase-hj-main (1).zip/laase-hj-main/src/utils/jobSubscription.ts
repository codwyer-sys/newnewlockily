import { supabase } from '@/integrations/supabase/client';

export interface JobSubscriptionOptions {
  userId: string;
  onJobChange: () => void;
  onSubscriptionStatusChange?: (status: string) => void;
}

/**
 * Sets up real-time subscription for job changes
 */
export const setupJobSubscription = ({ userId, onJobChange, onSubscriptionStatusChange }: JobSubscriptionOptions) => {
  console.log('🔔 [jobSubscription] Setting up real-time subscription for locksmith:', userId);

  const channel = supabase
    .channel('locksmith_jobs_channel')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'bookings',
        filter: 'status=eq.waiting_for_quotes'
      },
      (payload) => {
        console.log('🔔 [jobSubscription] New booking inserted:', payload);
        console.log('🔔 [jobSubscription] Booking details:', {
          id: payload.new?.id,
          status: payload.new?.status,
          address: payload.new?.address,
          job_category_id: payload.new?.job_category_id
        });
        console.log('🔔 [jobSubscription] Triggering job refresh due to new booking');
        onJobChange();
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'bookings'
      },
      (payload) => {
        console.log('🔔 [jobSubscription] Booking updated:', payload);
        console.log('🔔 [jobSubscription] Triggering job refresh due to booking update');
        onJobChange();
      }
    )
    .subscribe((status) => {
      console.log('🔔 [jobSubscription] Realtime subscription status:', status);
      
      if (onSubscriptionStatusChange) {
        onSubscriptionStatusChange(status);
      }
      
      if (status === 'SUBSCRIBED') {
        console.log('✅ [jobSubscription] Successfully subscribed to bookings changes');
      } else if (status === 'CHANNEL_ERROR') {
        console.error('❌ [jobSubscription] Error subscribing to bookings channel');
      } else if (status === 'CLOSED') {
        console.warn('⚠️ [jobSubscription] Realtime subscription closed');
      } else if (status === 'TIMED_OUT') {
        console.warn('⏱️ [jobSubscription] Realtime subscription timed out');
      }
    });

  // Test connection periodically
  const heartbeat = setInterval(() => {
    console.log('💓 [jobSubscription] Realtime heartbeat - channel state:', channel.state);
  }, 30000);

  // Return cleanup function
  return () => {
    console.log('🧹 [jobSubscription] Cleaning up realtime subscription');
    clearInterval(heartbeat);
    supabase.removeChannel(channel);
  };
};