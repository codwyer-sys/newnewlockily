import { AddressService, AddressSearchOptions, AddressSearchResult, AddressValidationResult, GeocodeResult } from './types';

export class DAWAAddressService extends AddressService {
  private readonly baseUrl = 'https://dawa.aws.dk';

  async searchAddresses(options: AddressSearchOptions): Promise<AddressSearchResult[]> {
    try {
      const url = `${this.baseUrl}/adresser/autocomplete?q=${encodeURIComponent(options.query)}&type=adresse`;
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error('DAWA API error:', response.status);
        return [];
      }
      
      const data = await response.json();
      return this.normalizeResponse(data);
    } catch (error) {
      console.error('DAWA search failed:', error);
      return [];
    }
  }

  async validateAddress(address: string): Promise<AddressValidationResult> {
    // DAWA doesn't have a dedicated validation endpoint
    // We'll use search and check if we get exact matches
    const results = await this.searchAddresses({ query: address, limit: 1 });
    
    return {
      isValid: results.length > 0,
      errors: results.length === 0 ? ['Address not found'] : [],
      suggestions: results
    };
  }

  async geocodeAddress(address: string): Promise<GeocodeResult | null> {
    try {
      const url = `${this.baseUrl}/adresser?q=${encodeURIComponent(address)}&struktur=mini`;
      const response = await fetch(url);
      
      if (!response.ok) return null;
      
      const data = await response.json();
      if (!data || data.length === 0) return null;
      
      const item = data[0];
      if (!item.adgangspunkt?.koordinater) return null;
      
      return {
        coordinates: {
          latitude: item.adgangspunkt.koordinater[1],
          longitude: item.adgangspunkt.koordinater[0]
        },
        accuracy: 'exact',
        address: {
          id: item.id,
          displayText: item.adressetekst || item.betegnelse,
          fullAddress: item.adressetekst || item.betegnelse,
          coordinates: {
            latitude: item.adgangspunkt.koordinater[1],
            longitude: item.adgangspunkt.koordinater[0]
          }
        }
      };
    } catch (error) {
      console.error('DAWA geocoding failed:', error);
      return null;
    }
  }

  async reverseGeocode(lat: number, lng: number): Promise<AddressSearchResult | null> {
    try {
      const url = `${this.baseUrl}/adresser/reverse?x=${lng}&y=${lat}&struktur=mini`;
      const response = await fetch(url);
      
      if (!response.ok) return null;
      
      const data = await response.json();
      if (!data) return null;
      
      return {
        id: data.id,
        displayText: data.adressetekst || data.betegnelse,
        fullAddress: data.adressetekst || data.betegnelse,
        coordinates: { latitude: lat, longitude: lng }
      };
    } catch (error) {
      console.error('DAWA reverse geocoding failed:', error);
      return null;
    }
  }

  protected normalizeResponse(data: any[]): AddressSearchResult[] {
    return data.map((item, index) => ({
      id: item.id || `dawa-${index}`,
      displayText: item.tekst,
      fullAddress: item.tekst,
      coordinates: item.adgangspunkt?.koordinater ? {
        latitude: item.adgangspunkt.koordinater[1],
        longitude: item.adgangspunkt.koordinater[0]
      } : undefined,
      metadata: {
        type: item.type,
        source: 'dawa'
      }
    }));
  }
}