import { AddressService } from './types';
import { DAWAAddressService } from './DAWAAddressService';
import { UKPostcodeService } from './UKPostcodeService';
import { GooglePlacesService } from './GooglePlacesService';

export interface AddressProviderConfig {
  provider_name: string;
  is_primary: boolean;
  is_enabled: boolean;
  priority: number;
  config_data: any; // Allow Json type from database
}

export interface AddressValidationRule {
  input_type: string;
  validation_regex: string | null;
  min_length: number;
  placeholder_text: string;
  error_message: string;
}

export class AddressServiceFactory {
  private static serviceCache = new Map<string, AddressService>();

  static createService(
    marketCode: string, 
    config: AddressProviderConfig
  ): AddressService {
    const cacheKey = `${marketCode}-${config.provider_name}`;
    
    if (this.serviceCache.has(cacheKey)) {
      return this.serviceCache.get(cacheKey)!;
    }

    let service: AddressService;

    switch (config.provider_name) {
      case 'dawa':
        service = new DAWAAddressService(marketCode, config.config_data);
        break;
      case 'uk-postcode-lookup':
        service = new UKPostcodeService(marketCode, config.config_data);
        break;
      case 'google-places':
        service = new GooglePlacesService(marketCode, config.config_data);
        break;
      default:
        console.warn(`Unknown address provider: ${config.provider_name}, falling back to Google Places`);
        service = new GooglePlacesService(marketCode, config.config_data);
    }

    this.serviceCache.set(cacheKey, service);
    return service;
  }

  static clearCache(): void {
    this.serviceCache.clear();
  }

  static validateInput(
    input: string, 
    rules: AddressValidationRule
  ): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Check minimum length
    if (input.length < rules.min_length) {
      errors.push(`Input must be at least ${rules.min_length} characters long`);
    }

    // Check regex pattern if provided
    if (rules.validation_regex) {
      const regex = new RegExp(rules.validation_regex, 'i');
      if (!regex.test(input)) {
        errors.push(rules.error_message || 'Invalid input format');
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}