import { AddressService, AddressSearchOptions, AddressSearchResult, AddressValidationResult, GeocodeResult } from './types';
import { supabase } from '@/integrations/supabase/client';

export class GooglePlacesService extends AddressService {
  async searchAddresses(options: AddressSearchOptions): Promise<AddressSearchResult[]> {
    try {
      const { data, error } = await supabase.functions.invoke('google-places-autocomplete', {
        body: { 
          input: options.query,
          country: options.country || this.marketCode.toLowerCase(),
          language: options.language || 'en'
        }
      });

      if (error) {
        console.error('Google Places API error:', error);
        return [];
      }
      
      if (!data?.predictions || data.predictions.length === 0) {
        return [];
      }

      return this.normalizeResponse(data.predictions);
    } catch (error) {
      console.error('Google Places search failed:', error);
      return [];
    }
  }

  async validateAddress(address: string): Promise<AddressValidationResult> {
    const results = await this.searchAddresses({ query: address, limit: 1 });
    
    return {
      isValid: results.length > 0,
      errors: results.length === 0 ? ['Address not found'] : [],
      suggestions: results
    };
  }

  async geocodeAddress(address: string): Promise<GeocodeResult | null> {
    try {
      const { data, error } = await supabase.functions.invoke('google-geocoding', {
        body: { 
          address,
          country: this.marketCode.toLowerCase()
        }
      });

      if (error || !data?.results || data.results.length === 0) {
        return null;
      }

      const result = data.results[0];
      const location = result.geometry?.location;
      
      if (!location) return null;

      return {
        coordinates: {
          latitude: location.lat,
          longitude: location.lng
        },
        accuracy: this.getAccuracyFromGeometry(result.geometry),
        address: {
          id: result.place_id,
          displayText: result.formatted_address,
          fullAddress: result.formatted_address,
          coordinates: {
            latitude: location.lat,
            longitude: location.lng
          },
          components: this.parseAddressComponents(result.address_components)
        }
      };
    } catch (error) {
      console.error('Google geocoding failed:', error);
      return null;
    }
  }

  async reverseGeocode(lat: number, lng: number): Promise<AddressSearchResult | null> {
    try {
      const { data, error } = await supabase.functions.invoke('google-geocoding', {
        body: { 
          latlng: `${lat},${lng}`,
          country: this.marketCode.toLowerCase()
        }
      });

      if (error || !data?.results || data.results.length === 0) {
        return null;
      }

      const result = data.results[0];
      return {
        id: result.place_id,
        displayText: result.formatted_address,
        fullAddress: result.formatted_address,
        coordinates: { latitude: lat, longitude: lng },
        components: this.parseAddressComponents(result.address_components)
      };
    } catch (error) {
      console.error('Google reverse geocoding failed:', error);
      return null;
    }
  }

  protected normalizeResponse(data: any[]): AddressSearchResult[] {
    return data.map((item) => ({
      id: item.place_id,
      displayText: item.description,
      fullAddress: item.description,
      metadata: {
        source: 'google-places',
        types: item.types,
        reference: item.reference
      }
    }));
  }

  private getAccuracyFromGeometry(geometry: any): 'exact' | 'approximate' | 'low' {
    if (!geometry) return 'low';
    
    const locationType = geometry.location_type;
    switch (locationType) {
      case 'ROOFTOP':
        return 'exact';
      case 'RANGE_INTERPOLATED':
      case 'GEOMETRIC_CENTER':
        return 'approximate';
      default:
        return 'low';
    }
  }

  private parseAddressComponents(components: any[]): any {
    const parsed: any = {};
    
    if (!components) return parsed;
    
    components.forEach((comp) => {
      const types = comp.types || [];
      
      if (types.includes('street_number')) {
        parsed.houseNumber = comp.long_name;
      } else if (types.includes('route')) {
        parsed.street = comp.long_name;
      } else if (types.includes('postal_code')) {
        parsed.postalCode = comp.long_name;
      } else if (types.includes('locality')) {
        parsed.city = comp.long_name;
      } else if (types.includes('administrative_area_level_1')) {
        parsed.region = comp.long_name;
      } else if (types.includes('country')) {
        parsed.country = comp.long_name;
      }
    });
    
    return parsed;
  }
}