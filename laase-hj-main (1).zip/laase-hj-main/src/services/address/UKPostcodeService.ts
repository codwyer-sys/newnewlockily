import { AddressService, AddressSearchOptions, AddressSearchResult, AddressValidationResult, GeocodeResult } from './types';
import { supabase } from '@/integrations/supabase/client';

export class UKPostcodeService extends AddressService {
  async searchAddresses(options: AddressSearchOptions): Promise<AddressSearchResult[]> {
    try {
      const { data, error } = await supabase.functions.invoke('uk-postcode-lookup', {
        body: { postcode: options.query }
      });

      if (error) {
        console.error('UK postcode lookup error:', error);
        return [];
      }
      
      if (!data?.addresses || data.addresses.length === 0) {
        console.log('No addresses found for postcode:', options.query);
        return [];
      }

      return this.normalizeResponse(data.addresses);
    } catch (error) {
      console.error('UK postcode lookup failed:', error);
      return [];
    }
  }

  async validateAddress(address: string): Promise<AddressValidationResult> {
    // UK postcode validation regex
    const postcodeRegex = /^[A-Z]{1,2}[0-9][A-Z0-9]?\s?[0-9][A-Z]{2}$/i;
    const cleanPostcode = address.replace(/\s+/g, '').toUpperCase();
    
    if (!postcodeRegex.test(cleanPostcode)) {
      return {
        isValid: false,
        errors: ['Invalid UK postcode format'],
        suggestions: []
      };
    }

    const results = await this.searchAddresses({ query: address });
    return {
      isValid: results.length > 0,
      errors: results.length === 0 ? ['Postcode not found'] : [],
      suggestions: results
    };
  }

  async geocodeAddress(address: string): Promise<GeocodeResult | null> {
    const results = await this.searchAddresses({ query: address, limit: 1 });
    if (results.length === 0 || !results[0].coordinates) return null;
    
    return {
      coordinates: results[0].coordinates,
      accuracy: 'exact',
      address: results[0]
    };
  }

  async reverseGeocode(lat: number, lng: number): Promise<AddressSearchResult | null> {
    // UK postcode service doesn't typically support reverse geocoding
    // Would need to implement with Mapbox or another service
    console.warn('Reverse geocoding not implemented for UK postcode service');
    return null;
  }

  protected normalizeResponse(data: any[]): AddressSearchResult[] {
    return data.map((item, index) => ({
      id: `uk-${index}`,
      displayText: item.address,
      fullAddress: item.address,
      coordinates: item.coordinates ? {
        latitude: item.coordinates.latitude,
        longitude: item.coordinates.longitude
      } : undefined,
      components: {
        postalCode: item.postcode
      },
      metadata: {
        source: 'uk-postcode-lookup',
        postcode: item.postcode
      }
    }));
  }
}