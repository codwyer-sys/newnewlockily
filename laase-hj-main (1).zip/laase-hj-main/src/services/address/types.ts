export interface AddressSearchResult {
  id: string;
  displayText: string;
  fullAddress: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  components?: {
    street?: string;
    houseNumber?: string;
    postalCode?: string;
    city?: string;
    region?: string;
    country?: string;
  };
  metadata?: Record<string, any>;
}

export interface AddressSearchOptions {
  query: string;
  limit?: number;
  bounds?: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
  country?: string;
  language?: string;
}

export interface AddressValidationResult {
  isValid: boolean;
  errors: string[];
  suggestions?: AddressSearchResult[];
}

export interface GeocodeResult {
  coordinates: {
    latitude: number;
    longitude: number;
  };
  accuracy: 'exact' | 'approximate' | 'low';
  address: AddressSearchResult;
}

export interface AddressServiceConfig {
  apiKey?: string;
  baseUrl?: string;
  timeout?: number;
  rateLimit?: number;
  [key: string]: any;
}

export abstract class AddressService {
  protected config: AddressServiceConfig;
  protected marketCode: string;

  constructor(marketCode: string, config: AddressServiceConfig = {}) {
    this.marketCode = marketCode;
    this.config = config;
  }

  abstract searchAddresses(options: AddressSearchOptions): Promise<AddressSearchResult[]>;
  abstract validateAddress(address: string): Promise<AddressValidationResult>;
  abstract geocodeAddress(address: string): Promise<GeocodeResult | null>;
  abstract reverseGeocode(lat: number, lng: number): Promise<AddressSearchResult | null>;
  
  protected normalizeResponse(data: any): AddressSearchResult[] {
    // To be implemented by each service
    return [];
  }
}