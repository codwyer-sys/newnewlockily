export interface LocksmithJob {
  id: string;
  jobNumber: number;
  categoryId: string;
  categoryName: string;
  category: string; // Deprecated: use categoryName for display, categoryId for logic
  address: string;
  lockBrand?: string;
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  timeRequested: string;
  customerPhone: string;
  customerName?: string;
  timing?: string;
  scheduledDate?: string;
  followUpAnswers?: Record<string, any>;
  status?: string;
  adminNotes?: string;
  priority?: string;
  statusChangedAt?: string;
  statusChangedBy?: string;
  market?: string;
}

export interface ServiceArea {
  id: string;
  locksmith_id: string;
  service_type: string; // Allow any string, will be checked at runtime
  postal_codes?: string[];
  center_address?: string;
  center_coordinates?: any;
  max_distance_km?: number;
}