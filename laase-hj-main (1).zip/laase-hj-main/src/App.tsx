
import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { MarketProvider } from "@/contexts/MarketContext";
import { HeaderThemeProvider } from "@/contexts/HeaderThemeContext";
import { PricingDataProvider } from "@/contexts/PricingDataContext";
// Stripe provider is now handled per-payment, no global provider needed
import { SimpleRouter } from "@/components/SimpleRouter";
import { MarketAwareRouter } from "@/components/MarketAwareRouter";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <HelmetProvider>
      <MarketProvider>
        <LanguageProvider>
          <HeaderThemeProvider>
            <PricingDataProvider>
              <TooltipProvider>
                <Toaster />
                <Sonner />
                <BrowserRouter>
                  <MarketAwareRouter />
                </BrowserRouter>
              </TooltipProvider>
            </PricingDataProvider>
          </HeaderThemeProvider>
        </LanguageProvider>
      </MarketProvider>
    </HelmetProvider>
  </QueryClientProvider>
);

export default App;
