import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useMarketAwareBlogPosts, MarketAwareBlogPost } from '@/hooks/useMarketAwareBlogPosts';
import { useMarket } from '@/contexts/MarketContext';
import { SEOHead } from '@/components/SEOHead';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { BlogPostLayout } from '@/components/BlogPost/BlogPostLayout';
import { MainLayout } from '@/components/MainLayout';

const BlogPost: React.FC = () => {
  const { slug, categorySlug, postSlug } = useParams<{ slug?: string; categorySlug?: string; postSlug?: string }>();
  const { getPostBySlug, getPostByCategoryAndSlug } = useMarketAwareBlogPosts();
  const { market } = useMarket();
  const { generateUrl } = useMarketUrl();
  
  const [post, setPost] = useState<MarketAwareBlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  // Calculate reading time
  const calculateReadTime = (content: string) => {
    const wordsPerMinute = 200;
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / wordsPerMinute);
  };

  useEffect(() => {
    const fetchPost = async () => {
      // Handle both new category-based URLs and legacy single-slug URLs
      if (categorySlug && postSlug) {
        // New format: /blog/category-slug/post-slug
        setLoading(true);
        try {
          const postData = await getPostByCategoryAndSlug(categorySlug, postSlug);
          if (postData) {
            setPost(postData);
            setNotFound(false);
          } else {
            setNotFound(true);
          }
        } catch (error) {
          console.error('Error fetching blog post by category and slug:', error);
          setNotFound(true);
        } finally {
          setLoading(false);
        }
      } else if (slug) {
        // Legacy format: /blog/slug (backward compatibility)
        setLoading(true);
        try {
          const postData = await getPostBySlug(slug);
          if (postData) {
            setPost(postData);
            setNotFound(false);
          } else {
            setNotFound(true);
          }
        } catch (error) {
          console.error('Error fetching blog post:', error);
          setNotFound(true);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchPost();
  }, [slug, categorySlug, postSlug]);

  if (loading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-muted rounded w-64 mx-auto mb-4"></div>
              <div className="h-4 bg-muted rounded w-32 mx-auto"></div>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (notFound || !post) {
    return (
      <MainLayout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="max-w-md mx-auto p-6 text-center">
            <SEOHead
              title="Blog Post Not Found"
              description="The blog post you're looking for doesn't exist."
            />
            <div className="text-6xl mb-4">📝</div>
            <h1 className="text-2xl font-bold text-foreground mb-4">Post Not Found</h1>
            <p className="text-muted-foreground mb-6">
              The blog post you're looking for doesn't exist or has been moved.
            </p>
            <Button onClick={() => window.location.href = generateUrl('blog')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Blog
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  const readingTime = calculateReadTime(post.market_content || post.content);

  // Enhanced structured data for the blog post
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": post.market_title || post.title,
    "description": post.market_excerpt || post.excerpt,
    "author": {
      "@type": "Person",
      "name": "Lockily Expert Team"
    },
    "publisher": {
      "@type": "Organization",
      "name": "Lockily",
      "logo": {
        "@type": "ImageObject",
        "url": `${window.location.origin}/lovable-uploads/57166235-1698-4ec1-b97a-4f4ed9310ab8.png`
      }
    },
    "datePublished": post.published_at || post.created_at,
    "dateModified": post.updated_at,
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": window.location.href
    },
    "wordCount": (post.market_content || post.content).trim().split(/\s+/).length,
    "timeRequired": `PT${readingTime}M`,
    "articleSection": "Locksmith Services",
    "keywords": (post.market_seo_keywords || post.seo_keywords || []).join(', '),
    ...(post.featured_image_url && {
      "image": {
        "@type": "ImageObject",
        "url": post.featured_image_url,
        "alt": post.featured_image_alt || post.market_title,
        "width": "1200",
        "height": "630"
      }
    })
  };

  return (
    <MainLayout>
      <SEOHead
        title={post.market_seo_title || post.market_title || post.title}
        description={post.market_seo_description || post.market_excerpt || post.excerpt}
        keywords={post.market_seo_keywords || post.seo_keywords}
        ogTitle={post.market_title || post.title}
        ogDescription={post.market_excerpt || post.excerpt}
        ogImage={post.featured_image_url}
        twitterTitle={post.market_title || post.title}
        twitterDescription={post.market_excerpt || post.excerpt}
        twitterImage={post.featured_image_url}
        isGlobalContent={post.is_global}
        contentSlug={post.market_slug || post.slug}
        structuredData={structuredData}
      />
      
      <BlogPostLayout post={post} readingTime={readingTime} />
    </MainLayout>
  );
};

export default BlogPost;