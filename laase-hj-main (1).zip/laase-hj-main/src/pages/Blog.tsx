import React, { useState, useMemo } from 'react';
import { useMarket } from '@/contexts/MarketContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useMarketAwareBlogPosts } from '@/hooks/useMarketAwareBlogPosts';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { MainLayout } from '@/components/MainLayout';
import { BlogPostCard } from '@/components/BlogPostCard';
import { BlogSidebar } from '@/components/BlogSidebar';
import { BlogHero } from '@/components/BlogHero';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

const Blog = () => {
  const { market } = useMarket();
  const { language, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  
  const { 
    posts, 
    loading: postsLoading 
  } = useMarketAwareBlogPosts();
  
  const { 
    categories, 
    loading: categoriesLoading 
  } = useBlogCategories();

  // Filter posts
  const filteredPosts = useMemo(() => {
    const allPosts = posts;
    
    let filtered = allPosts.filter(post => post.status === 'published');
    
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(post =>
        post.title.toLowerCase().includes(query) ||
        post.excerpt?.toLowerCase().includes(query) ||
        post.content.toLowerCase().includes(query)
      );
    }
    
    // Filter by categories
    if (selectedCategories.length > 0) {
      filtered = filtered.filter(post => 
        post.category_id && selectedCategories.includes(post.category_id)
      );
    }
    
    // Sort by published date, newest first
    return filtered.sort((a, b) => 
      new Date(b.published_at || b.created_at).getTime() - 
      new Date(a.published_at || a.created_at).getTime()
    );
  }, [posts, searchQuery, selectedCategories]);

  const getCategoryName = (categoryId: string) => {
    if (categoryId === 'uncategorized') return t('blog.interface.uncategorized');
    const category = categories.find(c => c.id === categoryId);
    return category?.name || t('blog.interface.unknown_category');
  };

  const isLoading = postsLoading || categoriesLoading;

  return (
    <MainLayout
      title={t('blog.seo.meta_title')}
      description={t('blog.seo.meta_description').replace('{country}', market.country_name)}
      keywords={['blog', 'locksmith', 'security', 'tips', 'news', market.country_name.toLowerCase()]}
    >
      <BlogHero />
      
      <div className="container mx-auto px-4 py-12">
        {/* 2-Column Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Left Sidebar - Filters (1/4 width on large screens) */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <BlogSidebar
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                categories={categories}
                selectedCategories={selectedCategories}
                onCategoryChange={setSelectedCategories}
                totalPosts={posts.length}
                filteredPosts={filteredPosts.length}
                loading={categoriesLoading}
              />
            </div>
          </div>

          {/* Right Content - Blog Posts (3/4 width on large screens) */}
          <div className="lg:col-span-3">
            {/* Results Header */}
            {!isLoading && (
              <div className="mb-6 flex justify-between items-center">
                <div className="text-sm text-muted-foreground">
                  {filteredPosts.length === 1 
                    ? t('blog.interface.posts_found').replace('{count}', '1')
                    : t('blog.interface.posts_found_plural').replace('{count}', filteredPosts.length.toString())
                  }
                  {searchQuery && ` ${t('blog.interface.posts_found_for').replace('{query}', searchQuery)}`}
                </div>
              </div>
            )}

            {/* Loading State */}
            {isLoading && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[...Array(6)].map((_, postIndex) => (
                    <div key={postIndex} className="space-y-4">
                      <Skeleton className="h-48 w-full rounded-lg" />
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Blog Posts Grid */}
            {!isLoading && filteredPosts.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredPosts.map((post) => (
                  <BlogPostCard
                    key={post.id}
                    post={post}
                    category={categories.find(c => c.id === post.category_id)}
                  />
                ))}
              </div>
            )}

            {/* No Results */}
            {!isLoading && filteredPosts.length === 0 && (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">📝</div>
                <h3 className="text-xl font-semibold mb-2">{t('blog.interface.no_posts_title')}</h3>
                <p className="text-muted-foreground mb-4">
                  {searchQuery || selectedCategories.length > 0
                    ? t('blog.interface.no_posts_message')
                    : t('blog.interface.no_posts_message_default')}
                </p>
                {(searchQuery || selectedCategories.length > 0) && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategories([]);
                    }}
                  >
                    {t('blog.interface.clear_filters')}
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Blog;