import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useBlogPosts } from '@/hooks/useBlogPosts';
import { useBlogPostMarketSEO } from '@/hooks/useBlogPostMarketSEO';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { validateUserForSubmission } from '@/utils/uuid';
import { Loader2, Save, ArrowLeft, Globe, Hash, Image, Calendar } from 'lucide-react';
import QuillEditor from '@/components/QuillEditor';
import { ImageUpload } from '@/components/ImageUpload';
import { MarketSEOTabs } from '@/components/MarketSEOTabs';

const blogPostEditSchema = z.object({
  title: z.string().min(1, 'Title is required').max(60, 'Title should be under 60 characters for SEO'),
  slug: z.string().min(1, 'URL slug is required').regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  excerpt: z.string().max(160, 'Excerpt should be under 160 characters').optional(),
  content: z.string().min(1, 'Content is required'),
  featured_image_url: z.string().url('Please enter a valid image URL').optional().or(z.literal('')),
  featured_image_alt: z.string().optional(),
  category_id: z.string().optional(),
  status: z.enum(['draft', 'published', 'archived']).default('draft'),
  seo_title: z.string().max(60, 'SEO title should be under 60 characters').optional(),
  seo_description: z.string().max(160, 'SEO description should be under 160 characters').optional(),
  seo_keywords: z.string().optional(),
});

type BlogPostEditForm = z.infer<typeof blogPostEditSchema>;

const generateSlug = (title: string): string => {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9 -]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
};

const BlogPostEditPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [markets, setMarkets] = useState<Array<{country_code: string, country_name: string}>>([]);
  const [currentPost, setCurrentPost] = useState<any>(null);
  const [loadingPost, setLoadingPost] = useState(true);
  
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const { updatePost, categories, loading: blogLoading } = useBlogPosts();
  const { user } = useAuth();

  const form = useForm<BlogPostEditForm>({
    resolver: zodResolver(blogPostEditSchema),
    defaultValues: {
      status: 'draft',
      content: '',
    },
  });

  const { watch, setValue, getValues } = form;
  const watchedTitle = watch('title');
  const watchedContent = watch('content');

  // Fetch post data
  useEffect(() => {
    const fetchPost = async () => {
      if (!id) return;
      
      try {
        const { data, error } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('id', id)
          .single();

        if (error) throw error;
        
        setCurrentPost(data);
        
        // Populate form with existing data
        setValue('title', data.title);
        setValue('slug', data.slug);
        setValue('excerpt', data.excerpt || '');
        setValue('content', data.content);
        setValue('featured_image_url', data.featured_image_url || '');
        setValue('featured_image_alt', data.featured_image_alt || '');
        setValue('category_id', data.category_id || '');
        setValue('status', data.status as 'draft' | 'published' | 'archived');
        setValue('seo_title', data.seo_title || '');
        setValue('seo_description', data.seo_description || '');
        setValue('seo_keywords', data.seo_keywords ? data.seo_keywords.join(', ') : '');
        
      } catch (error) {
        console.error('Error fetching blog post:', error);
        toast.error('Failed to load blog post');
        navigate('/admin-portal/blog/posts');
      } finally {
        setLoadingPost(false);
      }
    };

    fetchPost();
  }, [id, setValue, navigate]);

  // Fetch markets
  useEffect(() => {
    const fetchMarkets = async () => {
      const { data, error } = await supabase
        .from('markets')
        .select('country_code, country_name')
        .order('country_code');
      
      if (data && !error) {
        setMarkets(data);
      }
    };

    fetchMarkets();
  }, []);

  // Auto-generate slug from title
  useEffect(() => {
    if (watchedTitle && currentPost?.title !== watchedTitle) {
      const slug = generateSlug(watchedTitle);
      setValue('slug', slug);
    }
  }, [watchedTitle, setValue, currentPost?.title]);

  // Update word count
  useEffect(() => {
    if (watchedContent) {
      const text = watchedContent.replace(/<[^>]*>/g, '');
      const words = text.trim().split(/\s+/).filter(word => word.length > 0);
      setWordCount(words.length);
    } else {
      setWordCount(0);
    }
  }, [watchedContent]);

  const onSubmit = async (data: BlogPostEditForm) => {
    if (!id) return;
    
    setIsLoading(true);
    try {
      // Validate user authentication before proceeding
      const validatedUserId = validateUserForSubmission(user?.id);
      
      const keywordsArray = data.seo_keywords 
        ? data.seo_keywords.split(',').map(k => k.trim()).filter(k => k.length > 0)
        : [];

      const postData = {
        title: data.title,
        slug: data.slug,
        content: data.content,
        excerpt: data.excerpt,
        featured_image_url: data.featured_image_url,
        featured_image_alt: data.featured_image_alt,
        category_id: data.category_id,
        status: data.status,
        seo_title: data.seo_title,
        seo_description: data.seo_description,
        seo_keywords: keywordsArray,
        author_id: validatedUserId,
      };

      await updatePost(id, postData);
      toast.success('Blog post updated successfully!');
      navigate('/admin-portal/blog/posts');
    } catch (error) {
      console.error('Error updating blog post:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to update blog post';
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditorChange = (content: string) => {
    setValue('content', content);
  };

  if (loadingPost || blogLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!currentPost) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center">
          <h1 className="text-heading-lg text-foreground">Blog Post Not Found</h1>
          <p className="text-muted-foreground mt-2">The blog post you're looking for doesn't exist.</p>
          <Button 
            onClick={() => navigate('/admin-portal/blog/posts')} 
            className="mt-4"
          >
            Back to Blog Posts
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/admin-portal/blog/posts')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Posts
          </Button>
          <div>
            <h1 className="text-heading-lg text-foreground">Edit Blog Post</h1>
            <p className="text-muted-foreground">Update your blog post content and settings</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <Hash className="h-3 w-3" />
            {wordCount} words
          </Badge>
          {currentPost.is_global && (
            <Badge variant="outline" className="flex items-center gap-1">
              <Globe className="h-3 w-3" />
              Global Post
            </Badge>
          )}
        </div>
      </div>

      {currentPost.is_global ? (
        <Tabs defaultValue="content" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="content">Main Content</TabsTrigger>
            <TabsTrigger value="market-seo">Market SEO</TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="space-y-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Basic Content Card */}
                <Card>
                  <CardHeader>
                    <CardTitle>Content</CardTitle>
                    <CardDescription>
                      Main content and basic information
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter blog post title..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="slug"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>URL Slug</FormLabel>
                          <FormControl>
                            <Input placeholder="url-slug" {...field} />
                          </FormControl>
                          <p className="text-sm text-muted-foreground">
                            Preview: /blog/{field.value || 'url-slug'}
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="excerpt"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Excerpt</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Brief description of the blog post..."
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <p className="text-sm text-muted-foreground">
                            {field.value?.length || 0}/160 characters
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="content"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Content</FormLabel>
                          <FormControl>
                            <QuillEditor
                              value={field.value}
                              onChange={handleEditorChange}
                              placeholder="Write your blog post content..."
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Category Selection */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="h-5 w-5" />
                      Category
                    </CardTitle>
                    <CardDescription>
                      Select a category for this blog post (optional)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="category_id"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category (optional)" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {categories.map((category) => (
                                <SelectItem key={category.id} value={category.id}>
                                  {category.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Featured Image */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Image className="h-5 w-5" />
                      Featured Image
                    </CardTitle>
                    <CardDescription>
                      Add a featured image for your blog post
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ImageUpload
                      label="Featured Image"
                      value={form.watch('featured_image_url')}
                      onChange={(url) => form.setValue('featured_image_url', url)}
                      onAltTextChange={(altText) => form.setValue('featured_image_alt', altText)}
                      altText={form.watch('featured_image_alt')}
                      showAltText={true}
                    />
                  </CardContent>
                </Card>

                {/* Publishing Options */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5" />
                      Publishing
                    </CardTitle>
                    <CardDescription>
                      Control when and how your post is published
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Status</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger className="w-full md:w-48">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="draft">Draft</SelectItem>
                              <SelectItem value="published">Published</SelectItem>
                              <SelectItem value="archived">Archived</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex items-center justify-between pt-6 border-t border-border">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => navigate('/admin-portal/blog/posts')}
                  >
                    Cancel
                  </Button>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      type="submit"
                      disabled={isLoading}
                      className="flex items-center gap-2"
                    >
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="h-4 w-4" />
                      )}
                      Update Post
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="market-seo" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Market-Specific SEO</CardTitle>
                <CardDescription>
                  Optimize your global blog post for different markets with specific SEO settings, meta tags, and social media previews.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <MarketSEOTabs
                  postId={id}
                  markets={markets}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      ) : (
        // Market-specific post - show regular edit form
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Same form structure as above but without tabs */}
            <Card>
              <CardHeader>
                <CardTitle>Content</CardTitle>
                <CardDescription>
                  Main content and basic information for {currentPost.market_code} market
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter blog post title..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="slug"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL Slug</FormLabel>
                      <FormControl>
                        <Input placeholder="url-slug" {...field} />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        Preview: /blog/{field.value || 'url-slug'}
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="excerpt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Excerpt</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Brief description of the blog post..."
                          rows={3}
                          {...field}
                        />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        {field.value?.length || 0}/160 characters
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Content</FormLabel>
                      <FormControl>
                        <QuillEditor
                          value={field.value}
                          onChange={handleEditorChange}
                          placeholder="Write your blog post content..."
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex items-center justify-between pt-6 border-t border-border">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => navigate('/admin-portal/blog/posts')}
              >
                Cancel
              </Button>
              
              <div className="flex items-center gap-2">
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="flex items-center gap-2"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  Update Post
                </Button>
              </div>
            </div>
          </form>
        </Form>
      )}
    </div>
  );
};

export default BlogPostEditPage;
