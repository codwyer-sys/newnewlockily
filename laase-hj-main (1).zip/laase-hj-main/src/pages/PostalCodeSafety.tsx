import React, { useState } from 'react';
import { GlassCard } from '@/components/ui/glass-card';
import { GlassButton } from '@/components/ui/glass-button';
import { GlassInput } from '@/components/ui/glass-input';
import { MapPin, Shield, TrendingUp, TrendingDown, AlertTriangle, Home, Users, Clock, Award } from 'lucide-react';
import { usePostalCodeLookup } from '@/hooks/usePostalCodeLookup';

const PostalCodeSafety = () => {
  const [postalCode, setPostalCode] = useState('');
  const { 
    data, 
    isLoading, 
    error, 
    lookupPostalCode,
    validatePostalCode 
  } = usePostalCodeLookup();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validatePostalCode(postalCode)) {
      lookupPostalCode(postalCode);
    }
  };

  const getRiskLevel = (score: number) => {
    if (score <= 3) return { level: 'Lav', color: 'text-green-600', icon: Shield };
    if (score <= 7) return { level: 'Medium', color: 'text-yellow-600', icon: AlertTriangle };
    return { level: 'Høj', color: 'text-red-600', icon: AlertTriangle };
  };

  const getTrendIcon = (trend: string) => {
    return trend === 'stigende' ? TrendingUp : TrendingDown;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-apple-largetitle text-system-gray mb-6">
              Tjek sikkerhed i dit område
            </h1>
            <p className="text-apple-body text-system-gray2 mb-8 max-w-2xl mx-auto">
              Få officielle indbrudstatistikker for dit postnummer og sammenlign med resten af Danmark
            </p>
            
            {/* Search Form */}
            <GlassCard className="p-8 max-w-lg mx-auto">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="postalCode" className="block text-apple-headline text-system-gray mb-3">
                    Indtast dit postnummer
                  </label>
                  <GlassInput
                    id="postalCode"
                    type="text"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                    placeholder="f.eks. 8000"
                    className="text-center text-xl"
                    maxLength={4}
                  />
                  {postalCode && !validatePostalCode(postalCode) && (
                    <p className="text-red-500 text-apple-footnote mt-2">
                      Indtast et gyldigt 4-cifret dansk postnummer
                    </p>
                  )}
                </div>
                <GlassButton 
                  type="submit" 
                  variant="primary" 
                  size="lg"
                  disabled={!validatePostalCode(postalCode) || isLoading}
                  className="w-full"
                >
                  {isLoading ? 'Søger...' : 'Tjek sikkerhed'}
                </GlassButton>
              </form>
            </GlassCard>
          </div>
        </div>
      </div>

      {/* Results Section */}
      {data && (
        <div className="container mx-auto px-4 py-16">
          {/* Location Confirmation */}
          <GlassCard className="p-6 mb-8">
            <div className="flex items-center gap-3">
              <MapPin className="w-6 h-6 text-system-blue" />
              <div>
                <h2 className="text-apple-title3 text-system-gray">
                  {data.postalCode} {data.cityName}, {data.municipalityName}
                </h2>
                <p className="text-apple-subhead text-system-gray2">{data.regionName}</p>
              </div>
            </div>
          </GlassCard>

          {/* Safety Score Card */}
          <GlassCard className="p-8 mb-8">
            <div className="text-center">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Shield className="w-8 h-8 text-system-blue" />
                <h3 className="text-apple-title2 text-system-gray">Sikkerhedsresultat</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
                <div className="text-center">
                  <div className="text-apple-largetitle text-system-blue mb-2">
                    {data.burglariesPer1000}
                  </div>
                  <div className="text-apple-subhead text-system-gray2">
                    Indbrud per 1.000 husstande
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="text-apple-largetitle text-system-gray mb-2">
                    {data.rankingInDenmark}
                  </div>
                  <div className="text-apple-subhead text-system-gray2">
                    af 98 kommuner
                  </div>
                </div>
                
                <div className="text-center">
                  {(() => {
                    const risk = getRiskLevel(data.riskScore);
                    const Icon = risk.icon;
                    return (
                      <>
                        <div className={`text-apple-largetitle mb-2 ${risk.color}`}>
                          <Icon className="w-12 h-12 mx-auto" />
                        </div>
                        <div className="text-apple-subhead text-system-gray2">
                          {risk.level} risiko
                        </div>
                      </>
                    );
                  })()}
                </div>
                
                <div className="text-center">
                  {(() => {
                    const TrendIcon = getTrendIcon(data.trend);
                    return (
                      <>
                        <div className="text-apple-largetitle text-system-gray mb-2">
                          <TrendIcon className="w-12 h-12 mx-auto" />
                        </div>
                        <div className="text-apple-subhead text-system-gray2">
                          {data.trend} trend
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>
            </div>
          </GlassCard>

          {/* Detailed Statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <GlassCard className="p-6">
              <h4 className="text-apple-title3 text-system-gray mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Aktuelle data
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-apple-body text-system-gray2">Seneste kvartal:</span>
                  <span className="text-apple-body text-system-gray">{data.latestQuarter} indbrud</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-apple-body text-system-gray2">Samme kvartal sidste år:</span>
                  <span className="text-apple-body text-system-gray">{data.sameQuarterLastYear} indbrud</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-apple-body text-system-gray2">Ændring:</span>
                  <span className={`text-apple-body ${data.changePercentage > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {data.changePercentage > 0 ? '+' : ''}{data.changePercentage}%
                  </span>
                </div>
              </div>
            </GlassCard>

            <GlassCard className="p-6">
              <h4 className="text-apple-title3 text-system-gray mb-4 flex items-center gap-2">
                <Users className="w-5 h-5" />
                Sammenligning
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-apple-body text-system-gray2">Landsgennemsnit:</span>
                  <span className="text-apple-body text-system-gray">{data.nationalAverage} per 1.000</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-apple-body text-system-gray2">Regionsgennemsnit:</span>
                  <span className="text-apple-body text-system-gray">{data.regionalAverage} per 1.000</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-apple-body text-system-gray2">Dit område:</span>
                  <span className="text-apple-body text-system-blue font-semibold">{data.burglariesPer1000} per 1.000</span>
                </div>
              </div>
            </GlassCard>
          </div>

          {/* Information Section */}
          <GlassCard className="p-8 mb-8">
            <h4 className="text-apple-title3 text-system-gray mb-6 flex items-center gap-2">
              <Award className="w-6 h-6" />
              Hvad betyder dette?
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h5 className="text-apple-headline text-system-gray mb-3">Forklaring af statistikkerne</h5>
                <p className="text-apple-body text-system-gray2 mb-4">
                  Tallene viser antallet af anmeldte indbrud per 1.000 husstande i dit område baseret på 
                  officielle data fra Danmarks Statistik.
                </p>
                <p className="text-apple-body text-system-gray2">
                  En lav score betyder færre indbrud relativt til antallet af husstande, mens en høj score 
                  indikerer flere indbrud.
                </p>
              </div>
              <div>
                <h5 className="text-apple-headline text-system-gray mb-3">Faktorer der påvirker tendenser</h5>
                <ul className="text-apple-body text-system-gray2 space-y-2">
                  <li>• Urbane vs. rurale områder</li>
                  <li>• Sæsonudsving (vintermåneder har typisk flere indbrud)</li>
                  <li>• Lokale sikkerhedstiltag og patruljering</li>
                  <li>• Socioøkonomiske faktorer</li>
                  <li>• Tilgængelighed og synlighed af boliger</li>
                </ul>
              </div>
            </div>
          </GlassCard>

          {/* Prevention Tips & CTA */}
          <GlassCard className="p-8">
            <h4 className="text-apple-title3 text-system-gray mb-6 flex items-center gap-2">
              <Home className="w-6 h-6" />
              Forebyggelsestips for dit område
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div>
                <h5 className="text-apple-headline text-system-gray mb-3">Grundlæggende sikkerhed</h5>
                <ul className="text-apple-body text-system-gray2 space-y-2">
                  <li>• Installer sikkerhedslåse</li>
                  <li>• Brug timere på lys</li>
                  <li>• Lås altid døre og vinduer</li>
                  <li>• Undgå at vise værdigenstande</li>
                </ul>
              </div>
              <div>
                <h5 className="text-apple-headline text-system-gray mb-3">Avanceret beskyttelse</h5>
                <ul className="text-apple-body text-system-gray2 space-y-2">
                  <li>• Overvågningskameraer</li>
                  <li>• Alarm systemer</li>
                  <li>• Bevægelsessensorer</li>
                  <li>• Smart dørlåse</li>
                </ul>
              </div>
              <div>
                <h5 className="text-apple-headline text-system-gray mb-3">Nabosamarbejde</h5>
                <ul className="text-apple-body text-system-gray2 space-y-2">
                  <li>• Naboovervågning</li>
                  <li>• Del information om mistænksom adfærd</li>
                  <li>• Koordinér ferier og fravær</li>
                  <li>• Etablér lokale sikkerhedsgrupper</li>
                </ul>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-apple-body text-system-gray2 mb-6">
                Få professionel hjælp til at sikre dit hjem mod indbrud
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <GlassButton variant="primary" size="lg">
                  Book sikkerhedstjek
                </GlassButton>
                <GlassButton variant="secondary" size="lg">
                  Kontakt lokale låsesmede
                </GlassButton>
              </div>
            </div>
          </GlassCard>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="container mx-auto px-4 py-16">
          <GlassCard className="p-8 text-center">
            <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-apple-title3 text-system-gray mb-2">Der opstod en fejl</h3>
            <p className="text-apple-body text-system-gray2">{error}</p>
          </GlassCard>
        </div>
      )}

      {/* How it Works Section - shown when no search performed */}
      {!data && !isLoading && (
        <div className="container mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h2 className="text-apple-title1 text-system-gray mb-4">Sådan fungerer det</h2>
            <p className="text-apple-body text-system-gray2 max-w-2xl mx-auto">
              Vi kombinerer officielle data fra Danmarks Statistik med geografisk information for at give dig 
              det mest præcise billede af sikkerheden i dit område.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <GlassCard className="p-6 text-center">
              <MapPin className="w-12 h-12 text-system-blue mx-auto mb-4" />
              <h3 className="text-apple-headline text-system-gray mb-3">1. Indtast postnummer</h3>
              <p className="text-apple-body text-system-gray2">
                Vi identificerer din kommune og region baseret på dit postnummer
              </p>
            </GlassCard>
            
            <GlassCard className="p-6 text-center">
              <Shield className="w-12 h-12 text-system-blue mx-auto mb-4" />
              <h3 className="text-apple-headline text-system-gray mb-3">2. Hent officielle data</h3>
              <p className="text-apple-body text-system-gray2">
                Vi trækker de seneste indbrudstatistikker fra Danmarks Statistik
              </p>
            </GlassCard>
            
            <GlassCard className="p-6 text-center">
              <Home className="w-12 h-12 text-system-blue mx-auto mb-4" />
              <h3 className="text-apple-headline text-system-gray mb-3">3. Få skræddersyede råd</h3>
              <p className="text-apple-body text-system-gray2">
                Modtag sikkerhedsanbefalinger baseret på dit områdes risikoprofil
              </p>
            </GlassCard>
          </div>
        </div>
      )}
    </div>
  );
};

export default PostalCodeSafety;