import React from 'react';
import { useAutoBidPreferences } from '@/hooks/useAutoBidPreferences';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Zap, Target, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AutoBydCategoryCard } from '@/components/AutoByd/AutoBydCategoryCard';
import { AutoBydHowItWorks } from '@/components/AutoByd/AutoBydHowItWorks';
import { AutoBydGlobalSettings } from '@/components/AutoByd/AutoBydGlobalSettings';
import { useLanguage } from '@/contexts/LanguageContext';

const AutoByd = () => {
  const { 
    categories, 
    globalSettings,
    isLoading, 
    isUpdating, 
    toggleCategoryPreference, 
    updateCategoryPrice,
    updateGlobalSettings,
    updateQuestionPricing,
    toggleQuestionExclusion,
    getEnabledCategoriesCount 
  } = useAutoBidPreferences();
  const { t } = useLanguage();

  const enabledCount = getEnabledCategoriesCount();

  if (isLoading) {
    return (
      <main className="flex-1 p-6">
        <div className="max-w-4xl mx-auto flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </main>
    );
  }

  return (
    <main className="flex-1 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            {t('settings.labels.auto_bid_title')}
          </h1>
          <p className="text-muted-foreground">
            {t('settings.labels.auto_bid_description')}
          </p>
        </div>

        <Alert>
          <Zap className="h-4 w-4" />
          <AlertDescription>
            <strong>AutoBid aktiveret for {enabledCount} kategori{enabledCount !== 1 ? 'er' : ''}.</strong>
            {enabledCount === 0 && ` ${t('settings.messages.auto_bid_select_categories')}`}
          </AlertDescription>
        </Alert>

        {enabledCount > 0 && (
          <Alert>
            <Target className="h-4 w-4" />
            <AlertDescription>
              {t('settings.messages.auto_bid_active_info')}
            </AlertDescription>
          </Alert>
        )}

        <AutoBydGlobalSettings
          globalSettings={globalSettings}
          isUpdating={isUpdating}
          onUpdateGlobalSettings={updateGlobalSettings}
        />

        <Card>
          <CardHeader>
            <CardTitle>{t('settings.labels.categories_title')}</CardTitle>
            <CardDescription>
              {t('settings.labels.categories_description')}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categories.map((category) => (
                <AutoBydCategoryCard
                  key={category.id}
                  category={category}
                  isUpdating={isUpdating}
                  onTogglePreference={toggleCategoryPreference}
                  onUpdateBasePrice={updateCategoryPrice}
                  onUpdateQuestionPricing={updateQuestionPricing}
                  onToggleExclusion={toggleQuestionExclusion}
                />
              ))}
              
              {categories.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  <AlertCircle className="h-8 w-8 mx-auto mb-2" />
                  <p>{t('settings.messages.no_categories_found')}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <AutoBydHowItWorks />
      </div>
    </main>
  );
};

export default AutoByd;