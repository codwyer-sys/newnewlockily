import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassButton } from "@/components/ui/glass-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GlassCard } from "@/components/ui/glass-card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { 
  Loader2, Building, MapPin, Phone, Mail, AlertCircle, 
  ArrowRight, CheckCircle, Clock, DollarSign, Smartphone,
  Star, Users, Target, Settings, TrendingUp, Shield,
  Zap, Globe, Award, HelpCircle
} from "lucide-react";
import EmailConfirmationWaiting from "@/components/EmailConfirmationWaiting";
import { useLocksmithProfileCreation } from "@/hooks/useLocksmithProfileCreation";
import { useBusinessLookup } from "@/hooks/useBusinessLookup";
import { useMarketConfig } from "@/hooks/useMarketConfig";

const LocksmithSignup = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [showEmailConfirmation, setShowEmailConfirmation] = useState(false);
  const [showSignupForm, setShowSignupForm] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const { createLocksmithProfile, isCreating } = useLocksmithProfileCreation();
  const { lookupBusiness, isLoading: isLookingUpBusiness, error: lookupError } = useBusinessLookup();
  const { market, getBusinessFieldLabel, getBusinessValidationPattern } = useMarketConfig();
  
  const [formData, setFormData] = useState({
    business_number: '',
    company_name: '',
    address: '',
    postal_code: '',
    city: '',
    phone: '',
    email: '',
    contact_person: '',
    password: '',
    confirmPassword: '',
    website: '',
    service_areas: [] as string[]
  });

  const handleBusinessLookup = async () => {
    const pattern = getBusinessValidationPattern();
    if (!pattern.test(formData.business_number)) {
      const errorMessage = market.country_code === 'UK' ? 'Company number must be 8 digits' :
                          market.country_code === 'US' ? 'Please enter a valid business license' :
                          market.country_code === 'DE' ? 'Bitte geben Sie eine gültige Handelsregister-Nummer ein' :
                          'CVR-nummer skal være 8 cifre';
      toast.error(errorMessage);
      return;
    }
    
    const result = await lookupBusiness(formData.business_number);
    
    if (result) {
      setFormData(prev => ({
        ...prev,
        company_name: result.company_name || '',
        address: result.address || '',
        postal_code: result.postal_code || '',
        city: result.city || '',
        phone: result.phone || '',
        email: result.email || ''
      }));
      
      const successMessage = market.country_code === 'UK' ? 'Company details retrieved!' :
                           market.country_code === 'US' ? 'Business details retrieved!' :
                           market.country_code === 'DE' ? 'Firmendetails abgerufen!' :
                           'Virksomhedsoplysninger hentet!';
      toast.success(successMessage);
    } else if (lookupError) {
      toast.error(lookupError);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('Adgangskoder matcher ikke');
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Adgangskode skal være mindst 6 tegn');
      return;
    }

    setIsLoading(true);
    try {
      const nameParts = formData.contact_person.split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
            data: {
              role: 'locksmith',
              first_name: firstName,
              last_name: lastName,
              phone: formData.phone,
              company_name: formData.company_name,
              contact_person: formData.contact_person,
              market: market.country_code,
              locksmith_signup_data: {
                [market.country_code === 'DK' ? 'cvr_number' : 'business_number']: formData.business_number,
                company_name: formData.company_name,
                address: formData.address,
                postal_code: formData.postal_code,
                city: formData.city,
                phone: formData.phone,
                email: formData.email,
                contact_person: formData.contact_person,
                website: formData.website,
                service_areas: formData.service_areas,
                market: market.country_code
              }
            }
        }
      });

      if (authError) throw authError;

      if (authData.user) {
        console.log('User created successfully:', authData.user.id);
        console.log('User confirmation status:', authData.user.email_confirmed_at ? 'confirmed' : 'pending');
        
        // Send welcome email using template
        try {
          console.log('🔄 Attempting to call send-email function...');
          
          const { data: emailData, error: emailError } = await supabase.functions.invoke('send-email', {
            body: {
              templateId: 'ec42b1a5-41f8-4392-a201-85af5de509a3', // Locksmith Profil Signup Email Validation
              recipientEmail: formData.email,
              variables: {
                locksmith_name: formData.contact_person || `${firstName} ${lastName}`,
                firstname: firstName,
                company_name: formData.company_name,
                email: formData.email,
                cvr_number: formData.business_number,
                phone: formData.phone,
                address: formData.address,
                city: formData.city,
                postal_code: formData.postal_code,
                website: formData.website || '',
                support_email: 'support@lockily.com',
                platform_name: 'Lockily',
                confirmemail_link: `${window.location.origin}/auth/confirm?token_hash=${authData.user.id}&type=signup&redirect_to=${encodeURIComponent(window.location.origin)}`
              },
              languageCode: 'da'
            }
          });

          console.log('📧 Email function response:', { emailData, emailError });

          if (emailError) {
            console.error('❌ Failed to send welcome email:', emailError);
            toast.error(`Konto oprettet, men email fejlede: ${emailError.message}`);
          } else {
            console.log('✅ Welcome email sent successfully:', emailData);
            toast.success('Konto oprettet og velkommen email sendt!');
          }
        } catch (error) {
          console.error('❌ Error calling send-email function:', error);
          toast.error(`Email fejl: ${error.message}`);
        }
        
        console.log('Showing email confirmation screen');
        setUserEmail(formData.email);
        setShowEmailConfirmation(true);
        toast.success('Konto oprettet! Tjek venligst din e-mail for at bekræfte din konto.');
      }
    } catch (error: any) {
      console.error('Registration error:', error);
      toast.error(error.message || 'Registrering fejlede. Prøv venligst igen.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailConfirmed = async () => {
    console.log('Email confirmed, creating locksmith profile...');
    
    const success = await createLocksmithProfile({
      cvr_number: market.country_code === 'DK' ? formData.business_number : '',
      company_name: formData.company_name,
      address: formData.address,
      postal_code: formData.postal_code,
      city: formData.city,
      phone: formData.phone,
      email: formData.email,
      contact_person: formData.contact_person,
      website: formData.website,
      service_areas: formData.service_areas
    });

    if (success) {
      console.log('Profile created successfully, redirecting to homepage');
      navigate('/');
    }
  };

  // Show email confirmation screen if user signed up
  if (showEmailConfirmation) {
    return (
      <EmailConfirmationWaiting 
        email={userEmail}
        onConfirmed={handleEmailConfirmed}
      />
    );
  }

  // Show loading screen while creating profile
  if (isCreating) {
    return (
      <div className="min-h-screen bg-background py-12 px-4 flex items-center justify-center">
        <GlassCard className="max-w-md w-full">
          <div className="flex flex-col items-center justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin mb-4" />
            <p className="text-lg font-semibold">Opretter din profil...</p>
            <p className="text-sm text-muted-foreground mt-2">Dette kan tage et øjeblik</p>
          </div>
        </GlassCard>
      </div>
    );
  }

  // Show signup form modal
  if (showSignupForm) {
    return (
      <div className="min-h-screen bg-background py-12 px-4">
        <div className="max-w-2xl mx-auto">
          <GlassCard className="p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Bliv en Låsesmed Partner</h2>
              <p className="text-gray-600">
                Tilslut dig vores netværk af professionelle låsesmede og udvid din forretning
              </p>
            </div>
            <div>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* CVR Lookup Section */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Building className="h-5 w-5 text-muted-foreground" />
                    <Label htmlFor="business_number">{getBusinessFieldLabel()}</Label>
                  </div>
                  <div className="flex space-x-2">
                    <Input
                      id="business_number"
                      value={formData.business_number}
                      onChange={(e) => setFormData(prev => ({ ...prev, business_number: e.target.value }))}
                      placeholder={market.country_code === 'UK' ? '12345678' : 
                                  market.country_code === 'US' ? 'Business License Number' :
                                  market.country_code === 'DE' ? 'HRB 12345' : '12345678'}
                      maxLength={market.country_code === 'UK' || market.country_code === 'DK' ? 8 : undefined}
                      required
                    />
                    <GlassButton 
                      type="button" 
                      onClick={handleBusinessLookup}
                      disabled={isLookingUpBusiness || !getBusinessValidationPattern().test(formData.business_number)}
                      variant="secondary"
                    >
                      {isLookingUpBusiness ? <Loader2 className="h-4 w-4 animate-spin" /> : 
                       market.country_code === 'UK' ? 'Lookup' :
                       market.country_code === 'US' ? 'Lookup' :
                       market.country_code === 'DE' ? 'Suchen' : 'Opslag'}
                    </GlassButton>
                  </div>
                  
                  {lookupError && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3">
                      <div className="flex">
                        <AlertCircle className="h-5 w-5 text-yellow-400" />
                        <div className="ml-3">
                          <p className="text-sm text-yellow-800">
                            {lookupError}. Please fill in the business details manually below.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Company Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="company_name">Virksomhedsnavn</Label>
                    <Input
                      id="company_name"
                      value={formData.company_name}
                      onChange={(e) => setFormData(prev => ({ ...prev, company_name: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact_person">Kontaktperson</Label>
                    <Input
                      id="contact_person"
                      value={formData.contact_person}
                      onChange={(e) => setFormData(prev => ({ ...prev, contact_person: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                {/* Address Information */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <Label>Forretningsadresse</Label>
                  </div>
                  <Input
                    value={formData.address}
                    onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                    placeholder="Gadenavn og nummer"
                    required
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      value={formData.postal_code}
                      onChange={(e) => setFormData(prev => ({ ...prev, postal_code: e.target.value }))}
                      placeholder="Postnummer"
                      required
                    />
                    <Input
                      value={formData.city}
                      onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                      placeholder="By"
                      required
                    />
                  </div>
                </div>

                {/* Contact Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <Label htmlFor="phone">Telefon</Label>
                    </div>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <Label htmlFor="email">E-mail</Label>
                    </div>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                {/* Password Fields */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="password">Adgangskode</Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="confirmPassword">Bekræft adgangskode</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                {/* Optional Fields */}
                <div>
                  <Label htmlFor="website">Hjemmeside (valgfri)</Label>
                  <Input
                    id="website"
                    value={formData.website}
                    onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                    placeholder="https://dinhjemmeside.dk"
                  />
                </div>

                <div className="flex gap-4">
                  <GlassButton 
                    type="button" 
                    variant="secondary" 
                    onClick={() => setShowSignupForm(false)}
                    className="flex-1"
                  >
                    Tilbage
                  </GlassButton>
                  <GlassButton type="submit" variant="primary" className="flex-1" disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Opretter konto...
                      </>
                    ) : (
                      'Opret låsesmed-konto'
                    )}
                  </GlassButton>
                </div>
              </form>
            </div>
          </GlassCard>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-white text-gray-900 py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge variant="secondary" className="mb-6 backdrop-blur-sm bg-gray-100 border border-gray-200 text-gray-700 hover:bg-gray-200 px-4 py-2 rounded-full">
            💎 Premium Partner Program
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight">
            Få flere kunder som låsesmed
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-gray-600">
            Tilslut dig Danmarks førende platform for låsesmede og modtag flere kvalificerede opgaver hver dag
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <GlassButton 
              size="lg" 
              variant="primary"
              onClick={() => setShowSignupForm(true)}
              className="h-16 px-8 text-apple-title3 font-bold glass-thick rounded-apple-xlarge"
            >
              Tilmeld dig nu
              <ArrowRight className="ml-2 h-5 w-5" />
            </GlassButton>
            <GlassButton 
              size="lg" 
              variant="secondary"
              className="h-16 px-8 text-apple-title3 font-bold rounded-apple-xlarge"
            >
              Få gratis widget
            </GlassButton>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Sådan fungerer det</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <GlassCard className="text-center p-6 backdrop-blur-sm bg-gray-50 border border-gray-200 rounded-xl">
              <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-gray-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Kunde indsender opgave</h3>
              <p className="text-gray-600">Kunder beskriver deres låseproblem og får automatisk kontakt til dig</p>
            </GlassCard>
            <GlassCard className="text-center p-6 backdrop-blur-sm bg-gray-50 border border-gray-200 rounded-xl">
              <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Target className="h-8 w-8 text-gray-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Du vælger opgaver</h3>
              <p className="text-gray-600">Byd på opgaver der passer til dig eller sæt automatisk budgivning op</p>
            </GlassCard>
            <GlassCard className="text-center p-6 backdrop-blur-sm bg-gray-50 border border-gray-200 rounded-xl">
              <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-8 w-8 text-gray-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Bliv betalt</h3>
              <p className="text-gray-600">Udfør arbejdet, få betaling og byg din forretning op</p>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Widget Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Få en widget til din hjemmeside</h2>
              <p className="text-lg text-muted-foreground mb-6">
                Integrer vores booking-widget direkte på din hjemmeside og modtag opgaver 24/7 - selv når du sover.
              </p>
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Flere leads direkte til din forretning</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Ingen missede opkald eller henvendelser</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Højere konverteringsrate</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Nem at installere - ingen teknisk viden krævet</span>
                </div>
              </div>
              <GlassButton 
                size="lg" 
                variant="primary"
                className="h-14 px-8 text-apple-title3 font-bold glass-thick rounded-apple-xlarge"
              >
                Generer widget til min side
                <Globe className="ml-2 h-5 w-5" />
              </GlassButton>
            </div>
            <div className="bg-white rounded-lg shadow-lg p-6 border">
              <div className="bg-gradient-to-r from-primary to-primary/80 text-white p-4 rounded-t-lg">
                <h3 className="font-semibold">Låst ude? Vi hjælper dig!</h3>
              </div>
              <div className="p-4 space-y-4">
                <Input placeholder="Beskriv dit problem..." />
                <Input placeholder="Din adresse..." />
                <GlassButton variant="primary" className="w-full">Find nærmeste låsesmed</GlassButton>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bidding System */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Vælg hvordan du vil arbejde</h2>
          <div className="grid lg:grid-cols-2 gap-12">
            <GlassCard className="p-6">
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="h-6 w-6 text-gray-600" />
                  <h3 className="text-xl font-semibold">Auto-Budgivning</h3>
                </div>
                <p className="text-gray-600">Automatisk accept af opgaver der passer til dig</p>
              </div>
              <div>
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="text-sm font-medium mb-2">Eksempel på indstillinger:</p>
                    <p className="text-sm text-muted-foreground">
                      "Accepter automatisk alle 'låst ude' opgaver indenfor 15 km under 800 DKK"
                    </p>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Spar tid på manuel budgivning</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Få opgaver med det samme</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Fuld kontrol over kriterier</span>
                    </div>
                  </div>
                </div>
              </div>
            </GlassCard>

            <GlassCard className="p-6">
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="h-6 w-6 text-gray-600" />
                  <h3 className="text-xl font-semibold">Manuel Budgivning</h3>
                </div>
                <p className="text-gray-600">Se hver opgave og vælg selv hvad du vil byde på</p>
              </div>
              <div>
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg border-l-4 border-primary">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">Ny opgave: Låst ude</h4>
                      <Badge>2.500 DKK</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">Nørrebro, København • 2 km væk</p>
                    <div className="flex gap-2">
                      <GlassButton size="sm" variant="primary" className="flex-1">Accepter</GlassButton>
                      <GlassButton size="sm" variant="secondary" className="flex-1">Afslå</GlassButton>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Fuld kontrol over hver opgave</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Fleksibilitet til at vælge</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">Spring dårlige opgaver over</span>
                    </div>
                  </div>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Earnings Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">Øg din indtjening</h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-3xl mx-auto">
            Se hvordan andre låsesmede øger deres månedlige omsætning med vores platform
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <GlassCard className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">3 opgaver/dag</div>
              <div className="text-sm text-muted-foreground mb-4">Gennemsnit 900 DKK per opgave</div>
              <div className="text-2xl font-semibold">81.000 DKK/måned</div>
            </GlassCard>
            <GlassCard className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">5 opgaver/dag</div>
              <div className="text-sm text-muted-foreground mb-4">Gennemsnit 900 DKK per opgave</div>
              <div className="text-2xl font-semibold">135.000 DKK/måned</div>
            </GlassCard>
            <GlassCard className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">7 opgaver/dag</div>
              <div className="text-sm text-muted-foreground mb-4">Gennemsnit 900 DKK per opgave</div>
              <div className="text-2xl font-semibold">189.000 DKK/måned</div>
            </GlassCard>
          </div>

          <div className="bg-white rounded-lg p-8 max-w-md mx-auto">
            <h3 className="text-xl font-semibold mb-4">Transparente priser</h3>
            <div className="space-y-3 text-left">
              <div className="flex justify-between">
                <span>Kommission per opgave:</span>
                <span className="font-semibold">Kun 8%</span>
              </div>
              <div className="flex justify-between">
                <span>Månedligt abonnement:</span>
                <span className="font-semibold">0 DKK</span>
              </div>
              <div className="flex justify-between">
                <span>Opsætningsgebyr:</span>
                <span className="font-semibold">0 DKK</span>
              </div>
              <div className="flex justify-between border-t pt-3">
                <span>Du beholder:</span>
                <span className="font-semibold text-primary">92% af hver opgave</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mobile Experience */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-2xl p-8">
              <div className="bg-background rounded-xl p-4 max-w-sm mx-auto shadow-lg border">
                <div className="flex items-center gap-2 mb-4">
                  <Smartphone className="h-5 w-5 text-primary" />
                  <span className="font-medium">Ny opgave</span>
                  <Badge variant="secondary">Nørrebro</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  Kunde låst ude af lejlighed. Hurtig assistance ønskes.
                </p>
                <div className="flex gap-2">
                  <GlassButton size="sm" variant="primary" className="flex-1">Se detaljer</GlassButton>
                  <GlassButton size="sm" variant="secondary">Afvis</GlassButton>
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Modtag opgaver på farten</h2>
              <p className="text-lg text-muted-foreground mb-6">
                Få besked om nye opgaver via SMS eller push-notifikationer - selv når du er på en anden opgave.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Øjeblikkelige notifikationer</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Nem at bruge på telefonen</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span>Accepter opgaver med ét tryk</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & Proof */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Hvad siger andre låsesmede?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <GlassCard className="p-6">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="mb-4">"Jeg har øget min omsætning med 40% siden jeg tilmeldte mig. Platformen er nem at bruge og kunderne er kvalificerede."</p>
              <div className="text-sm font-medium">- Lars Nielsen, København</div>
            </GlassCard>
            <GlassCard className="p-6">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="mb-4">"Auto-budgivning funktionen er fantastisk. Jeg får opgaver uden at skulle overvåge platformen konstant."</p>
              <div className="text-sm font-medium">- Marie Andersen, Aarhus</div>
            </GlassCard>
            <GlassCard className="p-6">
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="mb-4">"Widgetten på min hjemmeside fungerer perfekt. Jeg får nu opgaver fra min egen hjemmeside også."</p>
              <div className="text-sm font-medium">- Peter Hansen, Odense</div>
            </GlassCard>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mt-16 text-center">
            <div>
              <div className="text-3xl font-bold text-primary mb-2">2.000+</div>
              <div className="text-muted-foreground">Månedlige opgaver</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">12</div>
              <div className="text-muted-foreground">Danske byer</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">300+</div>
              <div className="text-muted-foreground">Tilmeldte låsesmede</div>
            </div>
          </div>
        </div>
      </section>

      {/* Control Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-8">Du har fuld kontrol</h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-3xl mx-auto">
            Platformen tilpasser sig din måde at arbejde på - ikke omvendt
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Sæt dine priser</h3>
              <p className="text-sm text-muted-foreground">Du bestemmer hvad du vil tage for forskellige opgaver</p>
            </div>
            <div className="text-center">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Settings className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Vælg opgavetyper</h3>
              <p className="text-sm text-muted-foreground">Specialiser dig i de opgaver du er bedst til</p>
            </div>
            <div className="text-center">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Arbejdstider</h3>
              <p className="text-sm text-muted-foreground">Sæt hvornår du er tilgængelig for opgaver</p>
            </div>
            <div className="text-center">
              <div className="bg-primary/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Target className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Pause/genoptag</h3>
              <p className="text-sm text-muted-foreground">Stop og start budgivning når det passer dig</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Ofte stillede spørgsmål</h2>
          <div className="space-y-6">
            <GlassCard className="p-6">
              <div className="flex items-start gap-3">
                <HelpCircle className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Kan jeg stadig tage private kunder?</h3>
                  <p className="text-muted-foreground">Ja, selvfølgelig! Platformen er et supplement til din eksisterende forretning. Du kan stadig tage private kunder som du plejer.</p>
                </div>
              </div>
            </GlassCard>
            <GlassCard className="p-6">
              <div className="flex items-start gap-3">
                <HelpCircle className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Skal jeg betale noget på forhånd?</h3>
                  <p className="text-muted-foreground">Nej, der er ingen tilmeldingsgebyrer eller månedlige abonnementer. Du betaler kun en lille kommission når du får en opgave.</p>
                </div>
              </div>
            </GlassCard>
            <GlassCard className="p-6">
              <div className="flex items-start gap-3">
                <HelpCircle className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Hvad hvis jeg ikke er tilgængelig?</h3>
                  <p className="text-muted-foreground">Du kan pause din profil når som helst. Opgaver går automatisk til andre låsesmede når du ikke er aktiv.</p>
                </div>
              </div>
            </GlassCard>
            <GlassCard className="p-6">
              <div className="flex items-start gap-3">
                <HelpCircle className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Er det kun for nødstilfælde?</h3>
                  <p className="text-muted-foreground">Nej, vi formidler alle typer låseopgaver - fra akutte til planlagte serviceopgaver.</p>
                </div>
              </div>
            </GlassCard>
            <GlassCard className="p-6">
              <div className="flex items-start gap-3">
                <HelpCircle className="h-5 w-5 text-primary mt-1" />
                <div>
                  <h3 className="font-semibold mb-2">Hvor lang tid tager widget opsætning?</h3>
                  <p className="text-muted-foreground">Under 5 minutter. Vi giver dig en simpel kode du indsætter på din hjemmeside - ingen teknisk viden krævet.</p>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Credentials */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-8">
            <Shield className="h-8 w-8 text-primary" />
            <h2 className="text-3xl md:text-4xl font-bold">Kun godkendte partnere</h2>
          </div>
          <p className="text-lg text-muted-foreground mb-12 max-w-3xl mx-auto">
            Vi verificerer alle låsesmede for at sikre kvalitet og troværdighed for vores kunder
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Award className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Certificeret Partner</h3>
              <p className="text-sm text-muted-foreground">Alle våre partnere er verificeret og godkendt</p>
            </div>
            <div className="text-center">
              <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Forsikret</h3>
              <p className="text-sm text-muted-foreground">Krav om gyldig erhvervsforsikring</p>
            </div>
            <div className="text-center">
              <CheckCircle className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-semibold mb-2">Din Lokale Låsesmed</h3>
              <p className="text-sm text-muted-foreground">Officiel partner badge på din profil</p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Klar til at øge din omsætning?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Tilmeld dig i dag og modtag din første opgave inden for 24 timer
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <GlassButton 
              size="lg" 
              variant="primary"
              onClick={() => setShowSignupForm(true)}
              className="h-16 px-8 text-apple-title3 font-bold glass-thick rounded-apple-xlarge"
            >
              Tilmeld dig – få opgaver nu
              <ArrowRight className="ml-2 h-5 w-5" />
            </GlassButton>
            <GlassButton 
              size="lg" 
              variant="secondary"
              className="h-16 px-8 text-apple-title3 font-bold rounded-apple-xlarge"
            >
              Få gratis widget til din hjemmeside
            </GlassButton>
          </div>
        </div>
      </section>

      {/* Sticky CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-primary text-primary-foreground p-4 shadow-lg z-50 border-t">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="hidden sm:block">
            <div className="font-semibold">Klar til at komme i gang?</div>
            <div className="text-sm opacity-90">Få flere opgaver allerede i dag</div>
          </div>
          <GlassButton 
            variant="primary"
            onClick={() => setShowSignupForm(true)}
            className="w-full sm:w-auto"
          >
            Tilmeld dig nu
            <ArrowRight className="ml-2 h-4 w-4" />
          </GlassButton>
        </div>
      </div>
    </div>
  );
};

export default LocksmithSignup;
