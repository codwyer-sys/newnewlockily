import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, MapPin, Clock, Phone, AlertTriangle, User, Calendar, FileText } from 'lucide-react';
import { LocksmithJob } from '@/types/locksmith';
import { useJobsKanban } from '@/hooks/useJobsKanban';

const JobDetails = () => {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const { jobs } = useJobsKanban();
  const [job, setJob] = useState<LocksmithJob | null>(null);

  useEffect(() => {
    if (jobs && jobId) {
      const foundJob = jobs.find(j => j.id === jobId);
      if (foundJob) {
        setJob(foundJob);
      }
    }
  }, [jobs, jobId]);

  const getUrgencyConfig = (urgency: string) => {
    switch (urgency) {
      case 'emergency':
        return { label: 'Emergency', color: 'bg-red-100 text-red-800 border-red-300', icon: AlertTriangle };
      case 'high':
        return { label: 'High', color: 'bg-orange-100 text-orange-800 border-orange-300', icon: AlertTriangle };
      case 'medium':
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: Clock };
      case 'low':
        return { label: 'Low', color: 'bg-green-100 text-green-800 border-green-300', icon: Clock };
      default:
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: Clock };
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'waiting_for_quotes':
        return { label: 'Waiting for Quotes', color: 'bg-yellow-100 text-yellow-800 border-yellow-300' };
      case 'quotes_received':
        return { label: 'Quotes Received', color: 'bg-blue-100 text-blue-800 border-blue-300' };
      case 'order_placed':
        return { label: 'Order Placed', color: 'bg-purple-100 text-purple-800 border-purple-300' };
      case 'order_fulfilled':
        return { label: 'Order Fulfilled', color: 'bg-green-100 text-green-800 border-green-300' };
      case 'canceled':
        return { label: 'Canceled', color: 'bg-red-100 text-red-800 border-red-300' };
      default:
        return { label: 'Unknown', color: 'bg-gray-100 text-gray-800 border-gray-300' };
    }
  };

  if (!job) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" onClick={() => navigate('/admin-portal/jobs')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Jobs
          </Button>
        </div>
        <div className="text-center text-muted-foreground">
          {jobId ? 'Job not found' : 'Loading...'}
        </div>
      </div>
    );
  }

  const urgencyConfig = getUrgencyConfig(job.urgency);
  const statusConfig = getStatusConfig(job.status || 'waiting_for_quotes');
  const UrgencyIcon = urgencyConfig.icon;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={() => navigate('/admin-portal/jobs')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Jobs
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Job Details</h1>
          <p className="text-muted-foreground">#{job.id.slice(0, 8)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Job Information */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Job Information</span>
                <div className="flex gap-2">
                  <Badge variant="outline" className={urgencyConfig.color}>
                    <UrgencyIcon className="w-3 h-3 mr-1" />
                    {urgencyConfig.label}
                  </Badge>
                  <Badge variant="outline" className={statusConfig.color}>
                    {statusConfig.label}
                  </Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Customer</p>
                      <p className="text-sm text-muted-foreground">{job.customerName || 'Unknown Customer'}</p>
                    </div>
                  </div>
                  
                  {job.customerPhone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Phone</p>
                        <p className="text-sm text-muted-foreground">{job.customerPhone}</p>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Address</p>
                      <p className="text-sm text-muted-foreground">{job.address}</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Created</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(job.timeRequested).toLocaleDateString()} at {new Date(job.timeRequested).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  
                  {job.timing && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Timing</p>
                        <p className="text-sm text-muted-foreground">
                          {job.timing === 'nu' || job.timing === 'now' || job.timing === 'asap' ? 'ASAP' : job.timing}
                        </p>
                      </div>
                    </div>
                  )}
                  
                  <div>
                    <p className="text-sm font-medium">Category</p>
                    <p className="text-sm text-muted-foreground">{job.category}</p>
                  </div>
                </div>
              </div>
              
              {job.lockBrand && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium">Lock Brand</p>
                    <p className="text-sm text-muted-foreground">{job.lockBrand}</p>
                  </div>
                </>
              )}
              
              {job.followUpAnswers && Object.keys(job.followUpAnswers).length > 0 && (
                <>
                  <Separator />
                  <div>
                    <p className="text-sm font-medium mb-2">Additional Details</p>
                    <div className="space-y-2">
                      {Object.entries(job.followUpAnswers).map(([key, value]) => (
                        <div key={key} className="flex justify-between text-sm">
                          <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:</span>
                          <span>{String(value)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Admin Notes */}
          {job.adminNotes && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Admin Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm whitespace-pre-wrap">{job.adminNotes}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status History */}
          <Card>
            <CardHeader>
              <CardTitle>Status History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Current Status</span>
                  <Badge variant="outline" className={statusConfig.color}>
                    {statusConfig.label}
                  </Badge>
                </div>
                {job.statusChangedAt && (
                  <div className="text-xs text-muted-foreground">
                    Last updated: {new Date(job.statusChangedAt).toLocaleString()}
                  </div>
                )}
                {job.priority && (
                  <div className="flex items-center justify-between text-sm">
                    <span>Priority</span>
                    <span className="capitalize">{job.priority}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quotes Section */}
          <Card>
            <CardHeader>
              <CardTitle>Quotes</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">No quotes available yet.</p>
              {/* TODO: Add quotes functionality */}
            </CardContent>
          </Card>

          {/* Stripe Charges */}
          <Card>
            <CardHeader>
              <CardTitle>Stripe Charges</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">No charges found.</p>
              {/* TODO: Add Stripe charges functionality */}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;