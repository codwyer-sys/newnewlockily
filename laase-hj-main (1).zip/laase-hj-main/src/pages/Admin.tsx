import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit, Plus, Save, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface JobCategory {
  id: string;
  name: string;
  emoji: string;
  description: string;
  requires_image: boolean;
}

interface FollowUpQuestion {
  id: string;
  job_category_id?: string;
  question: string;
  question_key: string;
  question_type: 'radio' | 'number' | 'text' | 'checkbox';
  options?: string[];
  is_required: boolean;
  is_global: boolean;
  order_index: number;
}

const Admin = () => {
  const [categories, setCategories] = useState<JobCategory[]>([]);
  const [questions, setQuestions] = useState<FollowUpQuestion[]>([]);
  const [editingCategory, setEditingCategory] = useState<JobCategory | null>(null);
  const [editingQuestion, setEditingQuestion] = useState<FollowUpQuestion | null>(null);
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [showNewQuestion, setShowNewQuestion] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchCategories();
    fetchQuestions();
  }, []);

  const fetchCategories = async () => {
    const { data, error } = await supabase
      .from('job_categories')
      .select('*')
      .order('created_at');
    
    if (error) {
      toast({
        title: "Error",
        description: "Failed to fetch categories",
        variant: "destructive"
      });
    } else {
      setCategories(data || []);
    }
  };

  const fetchQuestions = async () => {
    const { data, error } = await supabase
      .from('follow_up_questions')
      .select('*')
      .order('order_index');
    
    if (error) {
      toast({
        title: "Error",
        description: "Failed to fetch questions",
        variant: "destructive"
      });
    } else {
      // Transform the data to match our interface
      const transformedQuestions: FollowUpQuestion[] = (data || []).map(item => ({
        id: item.id,
        job_category_id: item.job_category_id || undefined,
        question: item.question,
        question_key: item.question_key,
        question_type: item.question_type as 'radio' | 'number' | 'text' | 'checkbox',
        options: item.options ? (item.options as string[]) : undefined,
        is_required: item.is_required || false,
        is_global: item.is_global || false,
        order_index: item.order_index || 0
      }));
      setQuestions(transformedQuestions);
    }
  };

  const saveCategory = async (category: Partial<JobCategory>) => {
    if (editingCategory?.id) {
      const { error } = await supabase
        .from('job_categories')
        .update(category)
        .eq('id', editingCategory.id);
      
      if (error) {
        toast({
          title: "Error",
          description: "Failed to update category",
          variant: "destructive"
        });
      } else {
        toast({ title: "Success", description: "Category updated" });
        fetchCategories();
        setEditingCategory(null);
      }
    } else {
      // Ensure required fields are present for insert
      const categoryToInsert = {
        name: category.name || '',
        emoji: category.emoji || '',
        description: category.description || '',
        requires_image: category.requires_image || false
      };
      
      const { error } = await supabase
        .from('job_categories')
        .insert([categoryToInsert]);
      
      if (error) {
        toast({
          title: "Error",
          description: "Failed to create category",
          variant: "destructive"
        });
      } else {
        toast({ title: "Success", description: "Category created" });
        fetchCategories();
        setShowNewCategory(false);
      }
    }
  };

  const deleteCategory = async (id: string) => {
    const { error } = await supabase
      .from('job_categories')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete category",
        variant: "destructive"
      });
    } else {
      toast({ title: "Success", description: "Category deleted" });
      fetchCategories();
      fetchQuestions(); // Refresh questions as cascade delete might have removed some
    }
  };

  const saveQuestion = async (question: Partial<FollowUpQuestion>) => {
    if (editingQuestion?.id) {
      const { error } = await supabase
        .from('follow_up_questions')
        .update(question)
        .eq('id', editingQuestion.id);
      
      if (error) {
        toast({
          title: "Error",
          description: "Failed to update question",
          variant: "destructive"
        });
      } else {
        toast({ title: "Success", description: "Question updated" });
        fetchQuestions();
        setEditingQuestion(null);
      }
    } else {
      // Ensure required fields are present for insert
      const questionToInsert = {
        job_category_id: question.job_category_id || null,
        question: question.question || '',
        question_key: question.question_key || '',
        question_type: question.question_type || 'radio',
        options: question.options || null,
        is_required: question.is_required !== undefined ? question.is_required : true,
        is_global: question.is_global || false,
        order_index: question.order_index || 0
      };
      
      const { error } = await supabase
        .from('follow_up_questions')
        .insert([questionToInsert]);
      
      if (error) {
        toast({
          title: "Error",
          description: "Failed to create question",
          variant: "destructive"
        });
      } else {
        toast({ title: "Success", description: "Question created" });
        fetchQuestions();
        setShowNewQuestion(false);
      }
    }
  };

  const deleteQuestion = async (id: string) => {
    const { error } = await supabase
      .from('follow_up_questions')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete question",
        variant: "destructive"
      });
    } else {
      toast({ title: "Success", description: "Question deleted" });
      fetchQuestions();
    }
  };

  const CategoryForm = ({ category, onSave, onCancel }: {
    category?: JobCategory | null;
    onSave: (data: Partial<JobCategory>) => void;
    onCancel: () => void;
  }) => {
    const [formData, setFormData] = useState({
      name: category?.name || '',
      emoji: category?.emoji || '',
      description: category?.description || '',
      requires_image: category?.requires_image || false
    });

    return (
      <Card>
        <CardHeader>
          <CardTitle>{category ? 'Edit Category' : 'New Category'}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="emoji">Emoji</Label>
            <Input
              id="emoji"
              value={formData.emoji}
              onChange={(e) => setFormData({ ...formData, emoji: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>
          <div className="flex items-center space-x-2">
            <Switch
              id="requires_image"
              checked={formData.requires_image}
              onCheckedChange={(checked) => setFormData({ ...formData, requires_image: checked })}
            />
            <Label htmlFor="requires_image">Requires Image Upload</Label>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => onSave(formData)}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  const QuestionForm = ({ question, onSave, onCancel }: {
    question?: FollowUpQuestion | null;
    onSave: (data: Partial<FollowUpQuestion>) => void;
    onCancel: () => void;
  }) => {
    const [formData, setFormData] = useState({
      job_category_id: question?.job_category_id || '',
      question: question?.question || '',
      question_key: question?.question_key || '',
      question_type: question?.question_type || 'radio' as const,
      options: question?.options?.join(', ') || '',
      is_required: question?.is_required ?? true,
      is_global: question?.is_global || false,
      order_index: question?.order_index || 0
    });

    const handleSave = () => {
      const data: Partial<FollowUpQuestion> = {
        ...formData,
        job_category_id: formData.is_global ? undefined : formData.job_category_id || undefined,
        options: formData.question_type === 'radio' || formData.question_type === 'checkbox' 
          ? formData.options.split(',').map(s => s.trim()).filter(s => s)
          : undefined
      };
      onSave(data);
    };

    return (
      <Card>
        <CardHeader>
          <CardTitle>{question ? 'Edit Question' : 'New Question'}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="is_global"
              checked={formData.is_global}
              onCheckedChange={(checked) => setFormData({ ...formData, is_global: checked })}
            />
            <Label htmlFor="is_global">Global Question (shows for all categories)</Label>
          </div>
          
          {!formData.is_global && (
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={formData.job_category_id} onValueChange={(value) => setFormData({ ...formData, job_category_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.emoji} {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label htmlFor="question">Question</Label>
            <Input
              id="question"
              value={formData.question}
              onChange={(e) => setFormData({ ...formData, question: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="question_key">Question Key</Label>
            <Input
              id="question_key"
              value={formData.question_key}
              onChange={(e) => setFormData({ ...formData, question_key: e.target.value })}
              placeholder="camelCase key for the question"
            />
          </div>

          <div>
            <Label htmlFor="question_type">Question Type</Label>
            <Select value={formData.question_type} onValueChange={(value: any) => setFormData({ ...formData, question_type: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="radio">Radio Buttons</SelectItem>
                <SelectItem value="checkbox">Checkboxes</SelectItem>
                <SelectItem value="number">Number Input</SelectItem>
                <SelectItem value="text">Text Input</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(formData.question_type === 'radio' || formData.question_type === 'checkbox') && (
            <div>
              <Label htmlFor="options">Options (comma separated)</Label>
              <Textarea
                id="options"
                value={formData.options}
                onChange={(e) => setFormData({ ...formData, options: e.target.value })}
                placeholder="Option 1, Option 2, Option 3"
              />
            </div>
          )}

          <div>
            <Label htmlFor="order_index">Order Index</Label>
            <Input
              id="order_index"
              type="number"
              value={formData.order_index}
              onChange={(e) => setFormData({ ...formData, order_index: parseInt(e.target.value) || 0 })}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="is_required"
              checked={formData.is_required}
              onCheckedChange={(checked) => setFormData({ ...formData, is_required: checked })}
            />
            <Label htmlFor="is_required">Required</Label>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Job Categories & Questions Management</h1>
          <p className="text-slate-400">Manage job categories and their follow-up questions</p>
        </div>

        {/* Categories Section */}
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-white">Job Categories</CardTitle>
              <Button onClick={() => setShowNewCategory(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Category
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showNewCategory && (
              <CategoryForm
                onSave={saveCategory}
                onCancel={() => setShowNewCategory(false)}
              />
            )}
            
            {editingCategory && (
              <CategoryForm
                category={editingCategory}
                onSave={saveCategory}
                onCancel={() => setEditingCategory(null)}
              />
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((category) => (
                <Card key={category.id} className="bg-slate-800 border-slate-600">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{category.emoji}</span>
                        <div>
                          <h3 className="font-semibold text-white">{category.name}</h3>
                          <p className="text-sm text-slate-400">{category.description}</p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setEditingCategory(category)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteCategory(category.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    {category.requires_image && (
                      <Badge variant="secondary" className="text-xs">
                        Requires Image
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Questions Section */}
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-white">Follow-up Questions</CardTitle>
              <Button onClick={() => setShowNewQuestion(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showNewQuestion && (
              <QuestionForm
                onSave={saveQuestion}
                onCancel={() => setShowNewQuestion(false)}
              />
            )}
            
            {editingQuestion && (
              <QuestionForm
                question={editingQuestion}
                onSave={saveQuestion}
                onCancel={() => setEditingQuestion(null)}
              />
            )}

            <div className="space-y-3">
              {questions.map((question) => {
                const category = categories.find(c => c.id === question.job_category_id);
                return (
                  <Card key={question.id} className="bg-slate-800 border-slate-600">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            {question.is_global ? (
                              <Badge variant="default">Global</Badge>
                            ) : (
                              <Badge variant="secondary">
                                {category?.emoji} {category?.name}
                              </Badge>
                            )}
                            <Badge variant="outline">{question.question_type}</Badge>
                            {question.is_required && <Badge variant="destructive">Required</Badge>}
                          </div>
                          <h4 className="font-medium text-white mb-1">{question.question}</h4>
                          <p className="text-sm text-slate-400">Key: {question.question_key}</p>
                          {question.options && (
                            <p className="text-sm text-slate-400">
                              Options: {question.options.join(', ')}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setEditingQuestion(question)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => deleteQuestion(question.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Admin;
