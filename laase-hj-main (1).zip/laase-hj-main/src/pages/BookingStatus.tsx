
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { BookingStatusHero } from '@/components/BookingStatus/BookingStatusHero';
import { BookingDetailsCard } from '@/components/BookingStatus/BookingDetailsCard';
import { QuotesSection } from '@/components/BookingStatus/QuotesSection';
import { BookingStatusLoadingState } from '@/components/BookingStatus/BookingStatusLoadingState';
import { BookingStatusErrorState } from '@/components/BookingStatus/BookingStatusErrorState';
import { OverlappingETACircle } from '@/components/BookingStatus/OverlappingETACircle';
import { LocksmithProfileCard } from '@/components/BookingStatus/LocksmithProfileCard';

import { type JobStage } from '@/utils/jobStageConfig';
import { useQuotes, type Quote } from '@/hooks/useQuotes';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

interface Booking {
  id: string;
  customer_id: string | null;
  locksmith_id: string | null;
  address: string;
  urgency: string;
  scheduled_date: string | null;
  job_type: string;
  follow_up_answers: any;
  status: string | null;
  estimated_price: number | null;
  final_price: number | null;
  notes: string | null;
  created_at: string | null;
  updated_at: string | null;
  job_category_id: string;
  market: string | null;
  admin_notes: string | null;
  status_changed_at: string | null;
  status_changed_by: string | null;
  priority_level: string | null;
  city_id: string | null;
  area_id: string | null;
  call_id: string | null;
  call_duration_seconds: number | null;
  call_transcription: string | null;
  booking_source: string | null;
  caller_phone_number: string | null;
  call_metadata: any;
  job_stage: JobStage;
  job_stage_changed_at: string | null;
}


const BookingStatus = () => {
  const { bookingId } = useParams<{ bookingId: string }>();
  const translations = useBookingStatusTranslations();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedQuote, setSelectedQuote] = useState<string | null>(null);
  const [selectedLocksmith, setSelectedLocksmith] = useState<any>(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const loadingRequestRef = useRef<boolean>(false);
  
  // Always load quotes for the booking - let the hook handle conditional logic
  const { quotes, loading: quotesLoading, sortQuotes, currentSort } = useQuotes(bookingId || '');

  // Get the lowest ETA from quotes, default to 30 minutes
  const getLowestETA = useCallback(() => {
    if (quotes.length === 0) return '30 min';
    
    const etas = quotes.map(quote => {
      return quote.estimated_arrival_minutes || 30;
    });
    
    return `${Math.min(...etas)} min`;
  }, [quotes]);

  // Load booking data - removed useCallback to fix dependency cycle
  const loadBooking = async () => {
    if (!bookingId || loadingRequestRef.current) return;
    
    loadingRequestRef.current = true;
    console.log('🎯 BookingStatus: Loading booking:', bookingId);
    
    try {
      console.log('📋 Fetching booking from database...');
      
      const { data: bookingData, error: bookingError } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .maybeSingle();

      console.log('📊 Booking query result:', { bookingData, bookingError });

      if (bookingError) {
        console.error('❌ Database error:', bookingError);
        setError(`Database error: ${bookingError.message}`);
        setLoading(false);
        return;
      }

      if (!bookingData) {
        console.warn('⚠️ No booking found for ID:', bookingId);
        setError('Booking not found');
        setLoading(false);
        return;
      }

      // Validate booking data structure
      console.log('📋 Validating booking data structure...');
      if (!bookingData.address || !bookingData.urgency || !bookingData.job_category_id) {
        console.error('❌ Invalid booking data structure:', bookingData);
        setError('Invalid booking data: missing required fields');
        setLoading(false);
        return;
      }

      console.log('✅ Booking loaded successfully:', bookingData);
      setBooking(bookingData);
      setLoading(false);

      // Load selected locksmith data for stages 4-6
      if (bookingData.locksmith_id && ['locksmith_en_route', 'locksmith_on_job', 'job_finished'].includes(bookingData.job_stage)) {
        const { data: locksmithData } = await supabase
          .from('profiles')
          .select('id, first_name, last_name, company_name, phone, cvr_number')
          .eq('id', bookingData.locksmith_id)
          .maybeSingle();
        
        if (locksmithData) {
          setSelectedLocksmith(locksmithData);
        }
      }

    } catch (err) {
      console.error('💥 Unexpected error loading booking:', err);
      setError('Something went wrong loading your booking');
      setLoading(false);
    } finally {
      loadingRequestRef.current = false;
    }
  };

  // Load booking data effect with realtime updates
  useEffect(() => {
    if (!bookingId) {
      setError('No booking ID provided');
      setLoading(false);
      return;
    }
    
    console.log('🚀 BookingStatus useEffect triggered for:', bookingId);
    
    // Add timeout protection to prevent infinite loading
    const timeoutId = setTimeout(() => {
      console.error('⏰ Loading timeout after 10 seconds');
      setError('Loading timeout - please try refreshing the page');
      setLoading(false);
    }, 10000);
    
    // Initial load
    loadBooking().finally(() => {
      clearTimeout(timeoutId);
    });

    // Set up realtime subscription for booking updates
    const bookingChannel = supabase
      .channel('booking-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`
        },
        (payload) => {
          console.log('📡 Realtime booking update:', payload);
          
          if (payload.new) {
            const updatedBooking = payload.new as Booking;
            console.log('🔄 Updating booking with realtime data:', updatedBooking);
            setBooking(updatedBooking);
            
            // If locksmith was assigned and we're in a later stage, load locksmith data
            if (updatedBooking.locksmith_id && ['locksmith_en_route', 'locksmith_on_job', 'job_finished'].includes(updatedBooking.job_stage)) {
              supabase
                .from('profiles')
                .select('id, first_name, last_name, company_name, phone, cvr_number')
                .eq('id', updatedBooking.locksmith_id)
                .maybeSingle()
                .then(({ data: locksmithData }) => {
                  if (locksmithData) {
                    setSelectedLocksmith(locksmithData);
                  }
                });
            }
          }
        }
      )
      .subscribe((status) => {
        console.log('📡 Booking subscription status:', status);
      });
    
    // Cleanup timeout and subscription on unmount
    return () => {
      clearTimeout(timeoutId);
      console.log('🧹 Cleaning up booking subscription');
      supabase.removeChannel(bookingChannel);
    };
  }, [bookingId]); // Only depend on bookingId, not loadBooking


  const acceptQuote = useCallback(async (quoteId: string, email: string) => {
    const selectedQuoteData = quotes.find(q => q.id === quoteId);
    if (!selectedQuoteData || !booking) return;

    try {
      console.log('💳 Initiating payment for quote:', quoteId, 'with email:', email);
      setIsProcessingPayment(true);
      setSelectedQuote(quoteId);
      
      // Call the payment edge function with email
      const { data, error } = await supabase.functions.invoke('create-customer-payment', {
        body: { quoteId, email }
      });

      if (error) {
        console.error('❌ Payment creation failed:', error);
        setSelectedQuote(null);
        setIsProcessingPayment(false);
        // You could show a toast notification here
        return;
      }

      if (data?.checkout_url) {
        console.log('✅ Payment session created, redirecting to Stripe...');
        // Open Stripe checkout in a new tab
        window.open(data.checkout_url, '_blank');
        setIsProcessingPayment(false);
      } else {
        console.error('❌ No checkout URL received');
        setSelectedQuote(null);
        setIsProcessingPayment(false);
      }
    } catch (error) {
      console.error('💥 Error creating payment:', error);
      setSelectedQuote(null);
      setIsProcessingPayment(false);
    }
  }, [quotes, booking]);

  if (loading) {
    return <BookingStatusLoadingState />;
  }

  if (error || !booking) {
    return <BookingStatusErrorState error={error || 'Booking not found'} bookingId={bookingId} />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section - Now with dynamic content based on job stage */}
      <ErrorBoundary>
        <BookingStatusHero 
          booking={booking}
          quotes={quotes}
          getLowestETA={getLowestETA}
        />
      </ErrorBoundary>

      {/* Overlapping ETA Circle - Stage-aware */}
      <ErrorBoundary>
        <OverlappingETACircle 
          getLowestETA={getLowestETA}
          quotes={quotes}
          jobStage={booking.job_stage}
        />
      </ErrorBoundary>

      <div className="container mx-auto px-4 pt-16 md:pt-20 pb-6 md:pb-8">
        <div className="grid lg:grid-cols-3 gap-6 md:gap-8 max-w-7xl mx-auto">
          {/* Booking Details - Now more mobile-friendly */}
          <div className="lg:col-span-1 order-2 lg:order-1">
            <ErrorBoundary>
              <BookingDetailsCard booking={booking} />
            </ErrorBoundary>
          </div>

          {/* Quotes Section or Locksmith Profile - Improved mobile layout */}
          <div className="lg:col-span-2 order-1 lg:order-2">
            <ErrorBoundary>
              {booking?.job_stage && ['locksmith_en_route', 'locksmith_on_job', 'job_finished'].includes(booking.job_stage) && selectedLocksmith ? (
                <LocksmithProfileCard
                  locksmith={selectedLocksmith}
                  estimatedArrival={getLowestETA()}
                  rating={4.8}
                  reviewCount={125}
                  distance={2.3}
                  onCall={() => {
                    if (selectedLocksmith.phone) {
                      window.location.href = `tel:${selectedLocksmith.phone}`;
                    }
                  }}
                  onMessage={() => {
                    // TODO: Implement messaging
                    console.log('Message locksmith');
                  }}
                />
              ) : (
                <QuotesSection 
                  quotes={quotes}
                  selectedQuote={selectedQuote}
                  bookingId={bookingId || ''}
                  onSortQuotes={(by) => sortQuotes(by as 'price' | 'distance' | 'rating' | 'created_at')}
                  onAcceptQuote={acceptQuote}
                  isProcessingPayment={isProcessingPayment}
                />
              )}
            </ErrorBoundary>
          </div>
        </div>

        {/* Action Buttons - Improved mobile layout */}
        <div className="text-center mt-6 md:mt-8">
          <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
            <Button 
              variant="outline" 
              onClick={() => window.location.href = '/'}
              className="flex-1 sm:flex-none"
            >
              {translations.actions.backToHome()}
            </Button>
            <Button 
              onClick={() => window.location.href = 'tel:70203040'}
              className="flex-1 sm:flex-none"
            >
              {translations.actions.callUs()}
            </Button>
          </div>
        </div>
      </div>

      <LocksmithFooter />
    </div>
  );
};

export default BookingStatus;
