import React, { useEffect, useState } from 'react';
import { useNavigate, Routes, Route } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useSessionValidation } from '@/hooks/useSessionValidation';
import { useLocksmithJobs } from '@/hooks/useLocksmithJobs';
import { useActiveQuotes } from '@/hooks/useActiveQuotes';
import { useLocksmithQuoteHistory } from '@/hooks/useLocksmithQuoteHistory';
import { supabase } from '@/integrations/supabase/client';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { LocksmithSidebar } from '@/components/LocksmithSidebar';
import LocksmithJobCard from '@/components/JobCard/LocksmithJobCard';
import { ActiveQuotesSection } from '@/components/ActiveQuotes/ActiveQuotesSection';
import LocksmithSettings from '@/pages/LocksmithSettings';
import PaymentsPortal from '@/pages/PaymentsPortal';
import PaymentSettings from '@/pages/PaymentSettings';
import ServiceAreas from '@/pages/ServiceAreas';
import AutoByd from '@/pages/AutoByd';
import { DebugPanel } from '@/components/DebugPanel';
import { Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const LocksmithPortal = () => {
  const { user, isLoading } = useAuth();
  const { isValidSession, validationError, refreshSession } = useSessionValidation();
  const { jobs, isLoading: jobsLoading } = useLocksmithJobs();
  const { quotes } = useActiveQuotes();
  const { quotedJobIds } = useLocksmithQuoteHistory();
  const [dismissedJobs, setDismissedJobs] = useState<string[]>([]);
  const [isRefreshingSession, setIsRefreshingSession] = useState(false);
  const navigate = useNavigate();

  const handleSessionRefresh = async () => {
    setIsRefreshingSession(true);
    try {
      const success = await refreshSession();
      if (!success) {
        console.log('❌ Session refresh failed, redirecting to auth');
        navigate('/auth');
      }
    } finally {
      setIsRefreshingSession(false);
    }
  };

  // Load dismissed jobs from localStorage on mount
  useEffect(() => {
    const dismissed = JSON.parse(localStorage.getItem('dismissedJobs') || '[]');
    setDismissedJobs(dismissed);
  }, []);

  const handleJobDismissed = (jobId: string) => {
    setDismissedJobs(prev => [...prev, jobId]);
  };

  // Filter out dismissed jobs and jobs where locksmith has EVER submitted a quote
  const visibleJobs = jobs.filter(job => 
    !dismissedJobs.includes(job.id) && 
    !quotedJobIds.has(job.id)
  );

  useEffect(() => {
    const checkLocksmithRole = async () => {
      console.log('🔍 Authentication Diagnosis:', {
        isLoading,
        hasUser: !!user,
        userId: user?.id,
        userEmail: user?.email,
        sessionExists: !!user?.aud,
        currentPath: window.location.pathname,
        timestamp: new Date().toISOString()
      });
      
      if (!isLoading && !user) {
        console.log('❌ No user found, redirecting to auth');
        navigate('/auth');
        return;
      }

      if (user) {
        console.log('✅ User found, performing comprehensive authentication check...');
        
        try {
          // Test 1: Check current session with Supabase
          const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
          console.log('🔍 Session Check:', {
            hasSession: !!sessionData.session,
            sessionValid: !!sessionData.session?.access_token,
            userId: sessionData.session?.user?.id,
            sessionError: sessionError?.message
          });

          if (!sessionData.session || sessionError) {
            console.error('❌ Invalid session, forcing re-authentication');
            navigate('/auth');
            return;
          }

          // Test 2: Verify database connectivity with current session
          const { data: testData, error: testError } = await supabase
            .from('user_roles')
            .select('count')
            .limit(1);
          
          console.log('🔍 Database Connectivity Test:', {
            success: !testError,
            error: testError?.message,
            authUid: 'auth.uid() value will be checked in query'
          });

          if (testError) {
            console.error('❌ Database connectivity failed:', testError);
          }

          // Test 3: Check if user has locksmith role
          const { data: userRole, error: roleError } = await supabase
            .from('user_roles')
            .select('role, user_id')
            .eq('user_id', user.id)
            .eq('role', 'locksmith')
            .maybeSingle();

          console.log('🔍 Role Check Result:', {
            userRole,
            roleError: roleError?.message,
            hasLocksmithRole: !!userRole,
            searchedUserId: user.id
          });

          if (roleError) {
            console.error('❌ Error checking user role:', roleError);
            
            // If it's an auth issue, redirect to auth
            if (roleError.message?.includes('JWT') || roleError.message?.includes('auth')) {
              console.log('❌ Authentication error detected, redirecting to auth');
              navigate('/auth');
              return;
            }
          }

          if (!userRole) {
            console.log('❌ No locksmith role found, redirecting to home');
            navigate('/');
          } else {
            console.log('✅ Locksmith role confirmed, portal access granted');
          }

          // Test 4: Test quote insertion capability (simulate without actually inserting)
          const testQuoteData = {
            booking_id: '00000000-0000-0000-0000-000000000000', // Test UUID
            locksmith_id: user.id,
            price: 1,
            estimated_arrival_minutes: 30,
            distance_km: 0,
            status: 'pending',
            expires_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
            locksmith_address: 'Test Address'
          };

          console.log('🔍 Testing quote insertion capability with data:', testQuoteData);
          
          // Note: We won't actually insert this, just test the RLS policy
          const { error: insertTestError } = await supabase
            .from('quotes')
            .select('id')
            .eq('locksmith_id', user.id)
            .limit(1);

          console.log('🔍 Quote table access test:', {
            canAccessQuotes: !insertTestError,
            accessError: insertTestError?.message
          });

        } catch (error) {
          console.error('❌ Comprehensive auth check failed:', error);
          navigate('/auth');
        }
      }
    };

    checkLocksmithRole();
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  // Show session validation error if detected
  if (isValidSession === false && validationError) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-md w-full">
          <Alert variant="destructive" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Authentication Issue</AlertTitle>
            <AlertDescription className="mb-4">
              {validationError}
            </AlertDescription>
            <div className="flex gap-2">
              <Button
                onClick={handleSessionRefresh}
                disabled={isRefreshingSession}
                size="sm"
              >
                {isRefreshingSession && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Refresh Session
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate('/auth')}
                size="sm"
              >
                Login Again
              </Button>
            </div>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-muted/20 p-2 pb-2">
        <LocksmithSidebar />
        <SidebarInset className="ml-2 flex-1">
          <div className="bg-background rounded-lg min-h-full shadow-sm border border-border/50">
            <Routes>
              <Route path="/" element={
                <main className="flex-1 p-6">
                  <div className="max-w-6xl mx-auto">
                    <h1 className="text-3xl font-bold text-foreground mb-6">
                      Dashboard
                    </h1>
                    
                    {/* Debug Panel for Development */}
                    <div className="mb-4">
                      <DebugPanel />
                    </div>
                    
                    {/* Active Quotes Section */}
                    <div className="mb-8">
                      <ActiveQuotesSection />
                    </div>

                    <div className="mb-6">
                      <h2 className="text-xl font-semibold mb-4">Tilgængelige Jobs</h2>
                      {jobsLoading ? (
                        <div className="flex items-center justify-center p-8">
                          <Loader2 className="h-6 w-6 animate-spin mr-2" />
                          <span>Henter jobs...</span>
                        </div>
                      ) : (
                        <>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {visibleJobs.map(job => (
                              <LocksmithJobCard 
                                key={job.id} 
                                job={job} 
                                onJobDismissed={handleJobDismissed}
                              />
                            ))}
                          </div>
                          {visibleJobs.length === 0 && jobs.length === 0 && (
                            <div className="bg-card rounded-lg p-8 border border-border text-center">
                              <p className="text-muted-foreground">
                                Ingen tilgængelige jobs lige nu. Nye jobs vil vise sig her når de kommer ind.
                              </p>
                            </div>
                          )}
                          {visibleJobs.length === 0 && jobs.length > 0 && (
                            <div className="bg-card rounded-lg p-8 border border-border text-center">
                              <p className="text-muted-foreground">
                                Alle tilgængelige jobs er blevet afvist. Nye jobs vil vise sig her når de kommer ind.
                              </p>
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </main>
              } />
              <Route path="/settings" element={<LocksmithSettings />} />
              <Route path="/payments" element={<PaymentsPortal />} />
              <Route path="/payments/settings" element={<PaymentSettings />} />
              <Route path="/service-areas" element={<ServiceAreas />} />
              <Route path="/auto-byd" element={<AutoByd />} />
            </Routes>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default LocksmithPortal;