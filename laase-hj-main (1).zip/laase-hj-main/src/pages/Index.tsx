
import React from 'react';
import { MainLayout } from "@/components/MainLayout";
import HeroSection from "@/components/HeroSection";
import HowItWorksTimeline from "@/components/HowItWorksTimeline";
import TestimonialsSection from "@/components/TestimonialsSection";

const Index = () => {
  return (
    <MainLayout>
      {/* Hero Section with integrated booking form */}
      <HeroSection />

      {/* How It Works Timeline */}
      <HowItWorksTimeline />

      {/* Testimonials Section */}
      <TestimonialsSection />

    </MainLayout>
  );
};

export default Index;
