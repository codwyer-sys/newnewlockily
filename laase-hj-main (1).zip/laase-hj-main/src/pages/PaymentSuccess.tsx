import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, ArrowRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';

const PaymentSuccess = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [paymentStatus, setPaymentStatus] = useState<'processing' | 'confirmed' | 'error'>('processing');
  const [bookingId, setBookingId] = useState<string | null>(null);

  const sessionId = searchParams.get('session_id');
  const quoteId = searchParams.get('quote_id');

  useEffect(() => {
    const verifyPayment = async () => {
      if (!sessionId || !quoteId) {
        setPaymentStatus('error');
        setLoading(false);
        return;
      }

      try {
        console.log('🔍 Verifying payment:', { sessionId, quoteId });

        // Check payment transaction status - using quotes table since payment_transactions might not exist yet
        const { data: quote, error: quoteError } = await supabase
          .from('quotes')
          .select('*, booking_id, locksmith_id, status')
          .eq('id', quoteId)
          .single();

        if (quoteError || !quote) {
          console.error('❌ Quote not found:', quoteError);
          setPaymentStatus('error');
          setLoading(false);
          return;
        }

        setBookingId(quote.booking_id);

        // If quote is already accepted, show success
        if (quote.status === 'accepted') {
          setPaymentStatus('confirmed');
          setLoading(false);
          return;
        }

        // Update quote and booking status
        const { error: updateQuoteError } = await supabase
          .from('quotes')
          .update({ status: 'accepted' })
          .eq('id', quoteId);

        if (updateQuoteError) {
          console.error('❌ Failed to update quote:', updateQuoteError);
        }

        const { error: bookingError } = await supabase
          .from('bookings')
          .update({ 
            locksmith_id: quote.locksmith_id,
            job_stage: 'awaiting_locksmith_acceptance'
          })
          .eq('id', quote.booking_id);

        if (bookingError) {
          console.error('❌ Failed to update booking:', bookingError);
        }

        // Reject other quotes for this booking
        const { error: rejectError } = await supabase
          .from('quotes')
          .update({ status: 'rejected' })
          .eq('booking_id', quote.booking_id)
          .neq('id', quoteId);

        if (rejectError) {
          console.error('❌ Failed to reject other quotes:', rejectError);
        }

        setPaymentStatus('confirmed');

      } catch (error) {
        console.error('💥 Payment verification error:', error);
        setPaymentStatus('error');
      } finally {
        setLoading(false);
      }
    };

    verifyPayment();
  }, [sessionId, quoteId]);

  const handleViewBooking = () => {
    if (bookingId) {
      navigate(`/booking-status/${bookingId}`);
    } else {
      navigate('/');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <h1 className="text-2xl font-bold mb-2">Processing Payment</h1>
            <p className="text-muted-foreground">Please wait while we confirm your payment...</p>
          </div>
        </div>
        <LocksmithFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader className="text-center">
              {paymentStatus === 'confirmed' ? (
                <>
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="text-2xl text-green-600">Payment Successful!</CardTitle>
                </>
              ) : paymentStatus === 'error' ? (
                <>
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="w-8 h-8 text-red-600" />
                  </div>
                  <CardTitle className="text-2xl text-red-600">Payment Error</CardTitle>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="w-8 h-8 text-yellow-600" />
                  </div>
                  <CardTitle className="text-2xl text-yellow-600">Processing Payment</CardTitle>
                </>
              )}
            </CardHeader>
            <CardContent className="text-center space-y-4">
              {paymentStatus === 'confirmed' ? (
                <>
                  <p className="text-muted-foreground">
                    Your payment has been processed successfully. The locksmith has been notified and will accept your job shortly.
                  </p>
                  <div className="space-y-2">
                    <Button onClick={handleViewBooking} className="w-full">
                      <ArrowRight className="w-4 h-4 mr-2" />
                      View Booking Status
                    </Button>
                    <Button variant="outline" onClick={() => navigate('/')} className="w-full">
                      Return to Home
                    </Button>
                  </div>
                </>
              ) : paymentStatus === 'error' ? (
                <>
                  <p className="text-muted-foreground">
                    There was an issue processing your payment. Please try again or contact support.
                  </p>
                  <div className="space-y-2">
                    <Button onClick={() => navigate(-1)} className="w-full">
                      Try Again
                    </Button>
                    <Button variant="outline" onClick={() => navigate('/')} className="w-full">
                      Return to Home
                    </Button>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground">
                  Please wait while we process your payment...
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <LocksmithFooter />
    </div>
  );
};

export default PaymentSuccess;