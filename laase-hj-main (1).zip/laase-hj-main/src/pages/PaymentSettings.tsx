import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CreditCard } from 'lucide-react';
import StripeConnectSettings from '@/components/StripeConnectSettings';

const PaymentSettings = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
          <CreditCard className="h-8 w-8" />
          <span>Betalingsindstillinger</span>
        </h1>
        <p className="text-muted-foreground mt-2">
          Konfigurer din betalingskonto for at modtage betalinger fra kunder
        </p>
      </div>

      <StripeConnectSettings />
    </div>
  );
};

export default PaymentSettings;