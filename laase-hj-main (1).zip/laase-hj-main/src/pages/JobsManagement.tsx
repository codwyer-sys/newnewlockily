import React, { useState } from 'react';
import { JobsKanbanBoard } from '@/components/JobsManagement/JobsKanbanBoard';
import { JobsDataTable } from '@/components/JobsManagement/JobsDataTable';
import { useAuth } from '@/hooks/useAuth';
import { Navigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { KanbanSquare, Table } from 'lucide-react';

const JobsManagement = () => {
  const { user, isLoading } = useAuth();
  const [activeView, setActiveView] = useState<'kanban' | 'table'>('kanban');
  
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }
  
  if (!user) {
    return <Navigate to="/auth" replace />;
  }
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Jobs Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage and track all customer jobs through the pipeline
          </p>
        </div>
      </div>
      
      <Tabs value={activeView} onValueChange={(value) => setActiveView(value as 'kanban' | 'table')} className="w-full">
        <TabsList className="grid w-fit grid-cols-2">
          <TabsTrigger value="kanban" className="flex items-center gap-2">
            <KanbanSquare className="h-4 w-4" />
            Live View
          </TabsTrigger>
          <TabsTrigger value="table" className="flex items-center gap-2">
            <Table className="h-4 w-4" />
            Table View
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="kanban" className="mt-6">
          <JobsKanbanBoard />
        </TabsContent>
        
        <TabsContent value="table" className="mt-6">
          <JobsDataTable />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default JobsManagement;