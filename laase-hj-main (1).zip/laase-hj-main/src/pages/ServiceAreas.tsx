import React, { useState, useEffect } from 'react';
import { useServiceAreas } from '@/hooks/useServiceAreas';
import { useBatchPostalCodeValidation } from '@/hooks/useBatchPostalCodeValidation';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import ServiceAreaMap from '@/components/ServiceAreaMap';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Loader2, MapPin, Mail, Trash2, Plus, X } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface PostalCodeWithInfo {
  code: string;
  city: string;
}

const ServiceAreas = () => {
  const { user } = useAuth();
  const { serviceArea, isLoading, isUpdating, saveServiceArea, deleteServiceArea } = useServiceAreas();
  const { validateBatch, validateSingle, isValidating } = useBatchPostalCodeValidation();
  
  const [locksmithAddress, setLocksmithAddress] = useState('');
  const [serviceType, setServiceType] = useState<'postal_codes' | 'radius'>('postal_codes');
  const [postalCodesWithInfo, setPostalCodesWithInfo] = useState<PostalCodeWithInfo[]>([]);
  const [newPostalCode, setNewPostalCode] = useState('');
  const [postalCodeSuggestion, setPostalCodeSuggestion] = useState<string>('');
  const [radiusKm, setRadiusKm] = useState([25]);
  
  // Fetch locksmith address from profile
  useEffect(() => {
    const fetchLocksmithProfile = async () => {
      if (!user?.id) return;
      
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('address, postal_code, city')
          .eq('id', user.id)
          .single();
          
        if (error) throw error;
        
        if (data) {
          const fullAddress = [data.address, data.postal_code, data.city]
            .filter(Boolean)
            .join(', ');
          setLocksmithAddress(fullAddress);
        }
      } catch (error) {
        console.error('Error fetching locksmith profile:', error);
      }
    };
    
    fetchLocksmithProfile();
  }, [user?.id]);

  // Initialize form with existing data
  useEffect(() => {
    if (serviceArea) {
      setServiceType(serviceArea.service_type);
      if (serviceArea.postal_codes && serviceArea.postal_codes.length > 0) {
        // Validate all postal codes in batch to prevent flickering
        validateBatch(serviceArea.postal_codes).then(validatedCodes => {
          setPostalCodesWithInfo(validatedCodes);
        });
      }
      setRadiusKm([serviceArea.max_distance_km || 25]);
    }
  }, [serviceArea, validateBatch]);

  // Handle postal code input change with live validation
  useEffect(() => {
    const validateCode = async () => {
      if (newPostalCode.length === 4 && /^\d{4}$/.test(newPostalCode)) {
        try {
          const result = await validateSingle(newPostalCode);
          if (result) {
            setPostalCodeSuggestion(`${result.code} ${result.city}`);
          } else {
            setPostalCodeSuggestion('Postnummer ikke fundet');
          }
        } catch (error) {
          console.error('Error validating postal code:', error);
          setPostalCodeSuggestion('Fejl ved validering');
        }
      } else {
        setPostalCodeSuggestion('');
      }
    };

    const debounceTimer = setTimeout(validateCode, 500);
    return () => clearTimeout(debounceTimer);
  }, [newPostalCode, validateSingle]);

  const handleAddPostalCode = async () => {
    if (newPostalCode.trim() && /^\d{4}$/.test(newPostalCode.trim())) {
      const code = newPostalCode.trim();
      if (!postalCodesWithInfo.some(item => item.code === code)) {
        const result = await validateSingle(code);
        if (result) {
          setPostalCodesWithInfo([...postalCodesWithInfo, result]);
        } else {
          setPostalCodesWithInfo([...postalCodesWithInfo, { code, city: 'Ukendt by' }]);
        }
      }
      setNewPostalCode('');
      setPostalCodeSuggestion('');
    }
  };

  const handleRemovePostalCode = (code: string) => {
    setPostalCodesWithInfo(postalCodesWithInfo.filter(item => item.code !== code));
  };

  const handleSave = async () => {
    const payload = {
      service_type: serviceType,
      ...(serviceType === 'postal_codes' 
        ? { postal_codes: postalCodesWithInfo.map(item => item.code) }
        : { 
            max_distance_km: radiusKm[0],
            center_address: locksmithAddress
          }
      )
    };
    
    await saveServiceArea(payload);
  };

  const isFormValid = () => {
    if (serviceType === 'postal_codes') {
      return postalCodesWithInfo.length > 0;
    } else {
      return radiusKm[0] > 0 && locksmithAddress.trim().length > 0;
    }
  };

  if (isLoading) {
    return (
      <main className="flex-1 p-6">
        <div className="max-w-4xl mx-auto flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </main>
    );
  }

  return (
    <main className="flex-1 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Serviceområder
          </h1>
          <p className="text-muted-foreground">
            Definer hvilke områder du leverer låsesmed-service til
          </p>
        </div>

        {!serviceArea && (
          <Alert>
            <MapPin className="h-4 w-4" />
            <AlertDescription>
              Du har ikke konfigureret dine serviceområder endnu. Vælg en metode nedenfor for at komme i gang.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Konfiguration</CardTitle>
              <CardDescription>
                Vælg hvordan du vil definere dine serviceområder
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-base font-medium mb-3 block">Service metode</Label>
                <RadioGroup 
                  value={serviceType} 
                  onValueChange={(value: 'postal_codes' | 'radius') => setServiceType(value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="postal_codes" id="postal_codes" />
                    <Label htmlFor="postal_codes" className="font-normal">
                      Specifikke postnumre
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="radius" id="radius" />
                    <Label htmlFor="radius" className="font-normal">
                      Radius fra virksomhedens adresse
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {serviceType === 'postal_codes' && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="postal-code-input">Tilføj postnummer</Label>
                    <div className="flex space-x-2 mt-1">
                      <div className="flex-1">
                        <Input
                          id="postal-code-input"
                          value={newPostalCode}
                          onChange={(e) => setNewPostalCode(e.target.value)}
                          placeholder="f.eks. 2000"
                          maxLength={4}
                          onKeyPress={(e) => e.key === 'Enter' && handleAddPostalCode()}
                        />
                        {postalCodeSuggestion && (
                          <div className="text-xs text-muted-foreground mt-1">
                            {postalCodeSuggestion}
                          </div>
                        )}
                      </div>
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="icon"
                        onClick={handleAddPostalCode}
                        disabled={!newPostalCode.trim() || !/^\d{4}$/.test(newPostalCode.trim())}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {postalCodesWithInfo.length > 0 && (
                    <div>
                      <Label className="text-sm font-medium">Valgte postnumre</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {postalCodesWithInfo.map((item) => (
                          <Badge key={item.code} variant="secondary" className="flex items-center gap-1">
                            {item.code} {item.city}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-auto p-0 hover:bg-transparent"
                              onClick={() => handleRemovePostalCode(item.code)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {serviceType === 'radius' && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">Virksomhedens adresse</Label>
                    <div className="flex items-center space-x-2 mt-1 p-2 bg-muted rounded-md">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{locksmithAddress || 'Ingen adresse fundet'}</span>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium">
                      Service radius: {radiusKm[0]} km
                    </Label>
                    <Slider
                      value={radiusKm}
                      onValueChange={setRadiusKm}
                      max={100}
                      min={5}
                      step={5}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>5 km</span>
                      <span>100 km</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex space-x-3 pt-4">
                <Button 
                  onClick={handleSave} 
                  disabled={!isFormValid() || isUpdating || isValidating}
                  className="flex-1"
                >
                  {(isUpdating || isValidating) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {serviceArea ? 'Opdater' : 'Gem'} serviceområde
                </Button>
                
                {serviceArea && (
                  <Button 
                    variant="destructive" 
                    size="icon"
                    onClick={deleteServiceArea}
                    disabled={isUpdating}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Forhåndsvisning</CardTitle>
              <CardDescription>
                Se dit serviceområde på kortet
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ServiceAreaMap
                address={locksmithAddress}
                serviceType={serviceType}
                postalCodes={postalCodesWithInfo.map(item => item.code)}
                radiusKm={radiusKm[0]}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
};

export default ServiceAreas;