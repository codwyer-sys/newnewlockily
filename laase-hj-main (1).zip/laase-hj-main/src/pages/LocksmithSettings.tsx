import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload, Building, User, Lock, Mail, CreditCard } from 'lucide-react';
import StripeConnectSettings from '@/components/StripeConnectSettings';
import AddressSearchInput from '@/components/AddressSearchInput';

interface LocksmithProfile {
  id: string;
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  company_name: string | null;
  address: string | null;
  city: string | null;
  postal_code: string | null;
  contact_person: string | null;
  website: string | null;
  cvr_number: string | null;
  status: string | null;
  specializations: string[] | null;
  description: string | null;
  emergency_available: boolean | null;
  created_at: string;
  updated_at: string;
}

const LocksmithSettings = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<LocksmithProfile | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  
  // Form states
  const [businessForm, setBusinessForm] = useState({
    company_name: '',
    address: '',
    city: '',
    postal_code: '',
    phone: '',
    website: '',
    address_latitude: null as number | null,
    address_longitude: null as number | null
  });
  
  const [accountForm, setAccountForm] = useState({
    email: '',
    contact_person: ''
  });
  
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  // Handle URL parameters for tab switching and Stripe callbacks
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    const successParam = urlParams.get('success');
    const refreshParam = urlParams.get('refresh');
    
    if (tabParam === 'payments') {
      // Scroll to payments section
      setTimeout(() => {
        const paymentsSection = document.querySelector('#payments-section');
        if (paymentsSection) {
          paymentsSection.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
    
    if (successParam === 'true') {
      toast({
        title: "Stripe konto oprettet",
        description: "Din Stripe Connect-konto er blevet oprettet. Vent venligst på behandling."
      });
      // Clean up URL and scroll to payments
      window.history.replaceState({}, '', '/locksmith-portal/settings');
      setTimeout(() => {
        const paymentsSection = document.querySelector('#payments-section');
        if (paymentsSection) {
          paymentsSection.scrollIntoView({ behavior: 'smooth' });
        }
      }, 500);
    }
    
    if (refreshParam === 'true') {
      // Refresh account status when returning from Stripe
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  }, [toast]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (error) throw error;

      setProfile(data);
      setBusinessForm({
        company_name: data.company_name || '',
        address: data.address || '',
        city: data.city || '',
        postal_code: data.postal_code || '',
        phone: data.phone || '',
        website: data.website || '',
        address_latitude: data.address_latitude || null,
        address_longitude: data.address_longitude || null
      });
      setAccountForm({
        email: user?.email || '',
        contact_person: data.contact_person || ''
      });
    } catch (error: any) {
      toast({
        title: "Fejl",
        description: "Kunne ikke hente profil data.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast({
          title: "Fejl",
          description: "Logo må ikke være større end 2MB.",
          variant: "destructive"
        });
        return;
      }
      
      setLogoFile(file);
      const reader = new FileReader();
      reader.onload = () => setLogoPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const updateBusinessInfo = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update(businessForm)
        .eq('id', user?.id);

      if (error) throw error;

      toast({
        title: "Succes",
        description: "Virksomhedsoplysninger opdateret."
      });
    } catch (error: any) {
      toast({
        title: "Fejl",
        description: "Kunne ikke opdatere virksomhedsoplysninger.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const updateAccountInfo = async () => {
    setSaving(true);
    try {
      // Update profile table
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          contact_person: accountForm.contact_person
        })
        .eq('id', user?.id);

      if (profileError) throw profileError;

      // Update auth email if changed
      if (accountForm.email !== user?.email) {
        const { error: authError } = await supabase.auth.updateUser({
          email: accountForm.email
        });
        
        if (authError) throw authError;
        
        toast({
          title: "Email opdateret",
          description: "Tjek din nye email for bekræftelse."
        });
      } else {
        toast({
          title: "Succes",
          description: "Kontooplysninger opdateret."
        });
      }
    } catch (error: any) {
      toast({
        title: "Fejl",
        description: error.message || "Kunne ikke opdatere kontooplysninger.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const updatePassword = async () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "Fejl",
        description: "Nye adgangskoder matcher ikke.",
        variant: "destructive"
      });
      return;
    }

    if (passwordForm.newPassword.length < 6) {
      toast({
        title: "Fejl",
        description: "Adgangskode skal være mindst 6 tegn.",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordForm.newPassword
      });

      if (error) throw error;

      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });

      toast({
        title: "Succes",
        description: "Adgangskode opdateret."
      });
    } catch (error: any) {
      toast({
        title: "Fejl",
        description: error.message || "Kunne ikke opdatere adgangskode.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Indstillinger</h1>
        <p className="text-muted-foreground mt-2">
          Administrer din virksomhedsprofil og kontoindstillinger
        </p>
      </div>

      <Tabs defaultValue="business" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="business" className="flex items-center space-x-2">
            <Building className="h-4 w-4" />
            <span>Virksomhed</span>
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center space-x-2">
            <User className="h-4 w-4" />
            <span>Konto</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-2">
            <Lock className="h-4 w-4" />
            <span>Sikkerhed</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="business" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Virksomhedsoplysninger</CardTitle>
              <CardDescription>
                Opdater din virksomheds grundlæggende oplysninger
              </CardDescription>
            </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="company_name">Virksomhedsnavn</Label>
              <Input
                id="company_name"
                value={businessForm.company_name}
                onChange={(e) => setBusinessForm(prev => ({ ...prev, company_name: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="phone">Telefon</Label>
              <Input
                id="phone"
                value={businessForm.phone}
                onChange={(e) => setBusinessForm(prev => ({ ...prev, phone: e.target.value }))}
              />
            </div>
          </div>
          
          <AddressSearchInput
            label="Adresse"
            value={businessForm.address}
            onChange={(address, coordinates) => {
              setBusinessForm(prev => ({ 
                ...prev, 
                address,
                address_latitude: coordinates?.lat || null,
                address_longitude: coordinates?.lng || null
              }));
            }}
            placeholder="Indtast din virksomhedsadresse"
            required
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="postal_code">Postnummer</Label>
              <Input
                id="postal_code"
                value={businessForm.postal_code}
                onChange={(e) => setBusinessForm(prev => ({ ...prev, postal_code: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="city">By</Label>
              <Input
                id="city"
                value={businessForm.city}
                onChange={(e) => setBusinessForm(prev => ({ ...prev, city: e.target.value }))}
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="website">Hjemmeside</Label>
            <Input
              id="website"
              value={businessForm.website}
              onChange={(e) => setBusinessForm(prev => ({ ...prev, website: e.target.value }))}
              placeholder="https://dinhjemmeside.dk"
            />
          </div>

          {/* Logo Upload */}
          <div>
            <Label>Virksomhedslogo</Label>
            <div className="mt-2 flex items-center space-x-4">
              <div className="flex-1">
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleLogoChange}
                  className="cursor-pointer"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Upload et logo (maks 2MB, PNG/JPG)
                </p>
              </div>
              {logoPreview && (
                <div className="w-16 h-16 border border-border rounded-lg overflow-hidden">
                  <img src={logoPreview} alt="Logo preview" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
          </div>

            <Button onClick={updateBusinessInfo} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Gem ændringer
            </Button>
          </CardContent>
        </Card>
        </TabsContent>

        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Kontooplysninger</CardTitle>
              <CardDescription>
                Opdater din kontakt information og email
              </CardDescription>
            </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="contact_person">Kontaktperson</Label>
            <Input
              id="contact_person"
              value={accountForm.contact_person}
              onChange={(e) => setAccountForm(prev => ({ ...prev, contact_person: e.target.value }))}
            />
          </div>
          
          <div>
            <Label htmlFor="email">Email adresse</Label>
            <Input
              id="email"
              type="email"
              value={accountForm.email}
              onChange={(e) => setAccountForm(prev => ({ ...prev, email: e.target.value }))}
            />
            <p className="text-sm text-muted-foreground mt-1">
              Ved ændring af email skal du bekræfte den nye adresse
            </p>
          </div>

            <Button onClick={updateAccountInfo} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Gem ændringer
            </Button>
          </CardContent>
        </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Skift adgangskode</CardTitle>
              <CardDescription>
                Opdater din adgangskode for øget sikkerhed
              </CardDescription>
            </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="newPassword">Ny adgangskode</Label>
            <Input
              id="newPassword"
              type="password"
              value={passwordForm.newPassword}
              onChange={(e) => setPasswordForm(prev => ({ ...prev, newPassword: e.target.value }))}
            />
          </div>
          
          <div>
            <Label htmlFor="confirmPassword">Bekræft ny adgangskode</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={passwordForm.confirmPassword}
              onChange={(e) => setPasswordForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
            />
          </div>

            <Button onClick={updatePassword} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Opdater adgangskode
            </Button>
          </CardContent>
        </Card>
        </TabsContent>

      </Tabs>
    </div>
  );
};

export default LocksmithSettings;