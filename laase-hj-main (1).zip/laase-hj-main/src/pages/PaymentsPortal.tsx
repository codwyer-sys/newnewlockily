import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CreditCard, RefreshCw, TrendingUp, Clock, CheckCircle } from 'lucide-react';

interface PayoutInfo {
  id: string;
  amount: number;
  status: string;
  arrival_date: string;
  description: string;
}

interface BalanceInfo {
  available: number;
  pending: number;
  currency: string;
}

const PaymentsPortal = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [balance, setBalance] = useState<BalanceInfo | null>(null);
  const [payouts, setPayouts] = useState<PayoutInfo[]>([]);
  const [accountConnected, setAccountConnected] = useState(false);

  useEffect(() => {
    if (user) {
      fetchPaymentData();
    }
  }, [user]);

  const fetchPaymentData = async () => {
    try {
      setLoading(true);
      
      // Check if account is connected and get real balance/payout data
      const { data: balanceData, error: balanceError } = await supabase.functions.invoke('get-stripe-balance');
      
      if (balanceError) throw balanceError;
      
      if (balanceData.success) {
        setAccountConnected(true);
        setBalance(balanceData.balance);
        setPayouts(balanceData.payouts);
      } else {
        setAccountConnected(false);
      }
    } catch (error: any) {
      console.error('Error fetching payment data:', error);
      // Try to check if account exists at all
      const { data: accountStatus } = await supabase.functions.invoke('get-connect-account-status');
      if (accountStatus?.success && accountStatus?.connected) {
        setAccountConnected(true);
        // Set fallback data if API fails
        setBalance({ available: 0, pending: 0, currency: 'dkk' });
        setPayouts([]);
      } else {
        setAccountConnected(false);
      }
      toast({
        title: "Advarsel",
        description: "Kunne ikke hente de seneste betalingsdata.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const refreshData = async () => {
    setRefreshing(true);
    await fetchPaymentData();
    setRefreshing(false);
    toast({
      title: "Opdateret",
      description: "Betalingsdata er blevet opdateret."
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge variant="default" className="bg-green-600">Betalt</Badge>;
      case 'in_transit':
        return <Badge variant="outline">På vej</Badge>;
      case 'pending':
        return <Badge variant="secondary">Afventer</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatAmount = (amount: number, currency: string) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: currency
    }).format(amount / 100);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!accountConnected) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <CreditCard className="h-8 w-8" />
            <span>Betalinger</span>
          </h1>
          <p className="text-muted-foreground mt-2">
            Oversigt over din saldo og udbetalinger
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Betalingskonto ikke tilsluttet</CardTitle>
            <CardDescription>
              Du skal først oprette en betalingskonto for at se saldo og udbetalinger.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.href = '/locksmith-portal/payments/settings'}>
              Opsæt betalingskonto
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center space-x-3">
            <CreditCard className="h-8 w-8" />
            <span>Betalinger</span>
          </h1>
          <p className="text-muted-foreground mt-2">
            Oversigt over din saldo og udbetalinger
          </p>
        </div>
        <Button 
          variant="outline" 
          onClick={refreshData} 
          disabled={refreshing}
          className="flex items-center space-x-2"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          <span>Opdater</span>
        </Button>
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tilgængelig saldo</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {balance ? formatAmount(balance.available, balance.currency) : '0,00 kr'}
            </div>
            <p className="text-xs text-muted-foreground">
              Klar til udbetaling
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Afventende saldo</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {balance ? formatAmount(balance.pending, balance.currency) : '0,00 kr'}
            </div>
            <p className="text-xs text-muted-foreground">
              Bliver tilgængelig snart
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Payouts */}
      <Card>
        <CardHeader>
          <CardTitle>Udbetalinger</CardTitle>
          <CardDescription>
            Oversigt over dine seneste og kommende udbetalinger
          </CardDescription>
        </CardHeader>
        <CardContent>
          {payouts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>Ingen udbetalinger endnu.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {payouts.map((payout) => (
                <div key={payout.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <CheckCircle className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{payout.description}</p>
                      <p className="text-sm text-muted-foreground">
                        Ankommer: {new Date(payout.arrival_date).toLocaleDateString('da-DK')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="font-semibold">
                      {formatAmount(payout.amount, balance?.currency || 'DKK')}
                    </span>
                    {getStatusBadge(payout.status)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentsPortal;