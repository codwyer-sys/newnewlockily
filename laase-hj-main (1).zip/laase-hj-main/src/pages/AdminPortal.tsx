import React, { useEffect } from 'react';
import { useNavigate, Routes, Route } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { AdminSidebar } from '@/components/AdminSidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Users, Briefcase, FileText, BarChart3 } from 'lucide-react';
import CreateLocksmithForm from '@/components/CreateLocksmithForm';
import LocksmithsTable from '@/components/LocksmithsTable';
import ContentManagementAdmin from '@/components/ContentManagementAdmin';
import BlogPostEditor from '@/components/BlogPostEditor';
import BlogPostsTable from '@/components/BlogPostsTable/BlogPostsTable';
import BlogCategoryManager from '@/components/BlogCategoryManager';
import TranslationDashboard from '@/components/TranslationManagement/TranslationDashboard';
import BlogPostEditPage from './BlogPostEdit';
import JobsManagement from '@/pages/JobsManagement';
import JobDetails from '@/pages/JobDetails';
import { CitiesManager } from '@/components/CitiesManager';
import { AreasManager } from '@/components/AreasManager';
import JobCategoriesManager from '@/components/JobManagement/JobCategoriesManager';
import FollowUpQuestionsManager from '@/components/JobManagement/FollowUpQuestionsManager';
import { WebhookManagement } from '@/components/VoiceAI/WebhookManagement';

const AdminDashboard = () => {
  return (
    <main className="flex-1 p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-foreground mb-6">
          Admin Dashboard
        </h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Jobs</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">245</div>
              <p className="text-xs text-muted-foreground">
                +12% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Locksmiths</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">18</div>
              <p className="text-xs text-muted-foreground">
                +2 new this week
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Content Pages</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">32</div>
              <p className="text-xs text-muted-foreground">
                5 pending review
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenue</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24,567 kr</div>
              <p className="text-xs text-muted-foreground">
                +8% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">New job created</p>
                    <p className="text-xs text-muted-foreground">Emergency lockout in Copenhagen</p>
                  </div>
                  <span className="text-xs text-muted-foreground">2m ago</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Locksmith approved</p>
                    <p className="text-xs text-muted-foreground">Henrik Nielsen completed verification</p>
                  </div>
                  <span className="text-xs text-muted-foreground">15m ago</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Content updated</p>
                    <p className="text-xs text-muted-foreground">Homepage translations updated</p>
                  </div>
                  <span className="text-xs text-muted-foreground">1h ago</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <button className="w-full text-left p-3 rounded-lg border border-border hover:bg-muted transition-colors">
                  <div className="font-medium">Create new job category</div>
                  <div className="text-sm text-muted-foreground">Add a new service type</div>
                </button>
                <button className="w-full text-left p-3 rounded-lg border border-border hover:bg-muted transition-colors">
                  <div className="font-medium">Approve pending locksmith</div>
                  <div className="text-sm text-muted-foreground">Review applications</div>
                </button>
                <button className="w-full text-left p-3 rounded-lg border border-border hover:bg-muted transition-colors">
                  <div className="font-medium">Update translations</div>
                  <div className="text-sm text-muted-foreground">Manage content translations</div>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
};

const AdminPortal = () => {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const checkAdminRole = async () => {
      if (!isLoading && !user) {
        navigate('/auth');
        return;
      }

      if (user) {
        console.log('Checking admin role for user:', user.id);
        
        // Check if user has admin role
        const { data: userRole, error } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .eq('role', 'admin')
          .maybeSingle();

        console.log('Admin role check result:', { userRole, error });

        if (!userRole) {
          console.log('No admin role found, redirecting to home');
          navigate('/');
        } else {
          console.log('Admin role confirmed, staying on portal');
        }
      }
    };

    checkAdminRole();
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-muted/20 p-2 pb-2">
        <AdminSidebar />
        <SidebarInset className="ml-2 flex-1">
          <div className="bg-background rounded-lg min-h-full shadow-sm border border-border/50">
            <Routes>
              <Route path="/" element={<AdminDashboard />} />
              <Route path="/content" element={
                <div className="p-6">
                  <ContentManagementAdmin />
                </div>
              } />
              <Route path="/blog/posts" element={
                <div className="p-6 h-full">
                  <BlogPostsTable />
                </div>
              } />
              <Route path="/blog/create" element={
                <BlogPostEditor />
              } />
              <Route path="/blog/edit/:id" element={
                <BlogPostEditPage />
              } />
              <Route path="/blog/categories" element={
                <div className="p-6">
                  <BlogCategoryManager />
                </div>
              } />
              <Route path="/blog/media" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Media Library</h1>
                  <p className="text-muted-foreground">Media management features coming soon...</p>
                </div>
              } />
              <Route path="/seo/meta-tags" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">SEO Meta Tags</h1>
                  <p className="text-muted-foreground">SEO meta tag management features coming soon...</p>
                </div>
              } />
              <Route path="/seo/redirects" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">SEO Redirects</h1>
                  <p className="text-muted-foreground">Redirect management features coming soon...</p>
                </div>
              } />
              <Route path="/seo/sitemaps" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Sitemaps</h1>
                  <p className="text-muted-foreground">Sitemap management features coming soon...</p>
                </div>
              } />
              <Route path="/translations" element={
                <TranslationDashboard />
              } />
              <Route path="/order-form/categories" element={
                <div className="p-6">
                  <JobCategoriesManager />
                </div>
              } />
              <Route path="/order-form/questions" element={
                <div className="p-6">
                  <FollowUpQuestionsManager />
                </div>
              } />
              <Route path="/jobs" element={<JobsManagement />} />
              <Route path="/jobs/:jobId" element={<JobDetails />} />
              <Route path="/locksmiths" element={
                <div className="p-6">
                  <LocksmithsTable />
                </div>
              } />
              <Route path="/locksmiths/create" element={
                <div className="p-6">
                  <CreateLocksmithForm />
                </div>
              } />
              <Route path="/analytics" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Analytics</h1>
                  <p className="text-muted-foreground">Analytics features coming soon...</p>
                </div>
              } />
              <Route path="/settings" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">System Settings</h1>
                  <p className="text-muted-foreground">System settings coming soon...</p>
                </div>
              } />
              <Route path="/settings/users" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">User Management</h1>
                  <p className="text-muted-foreground">User management features coming soon...</p>
                </div>
              } />
              <Route path="/locations/cities" element={
                <div className="p-6">
                  <CitiesManager />
                </div>
              } />
              <Route path="/locations/areas" element={
                <div className="p-6">
                  <AreasManager />
                </div>
              } />
              <Route path="/voice-ai/calls" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Call Management</h1>
                  <p className="text-muted-foreground">Phone booking analytics and call monitoring coming soon...</p>
                </div>
              } />
              <Route path="/voice-ai/agent" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Agent Configuration</h1>
                  <p className="text-muted-foreground">AI agent prompt and conversation flow management coming soon...</p>
                </div>
              } />
              <Route path="/voice-ai/webhooks" element={
                <div className="p-6">
                  <WebhookManagement />
                </div>
              } />
              <Route path="/voice-ai/performance" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Performance Monitor</h1>
                  <p className="text-muted-foreground">Call success rates and conversion analytics coming soon...</p>
                </div>
              } />
              <Route path="/voice-ai/settings" element={
                <div className="p-6">
                  <h1 className="text-2xl font-bold mb-4">Integration Settings</h1>
                  <p className="text-muted-foreground">ElevenLabs API configuration and voice settings coming soon...</p>
                </div>
              } />
            </Routes>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default AdminPortal;