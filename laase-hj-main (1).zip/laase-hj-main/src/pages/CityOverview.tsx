import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Users, Building2 } from 'lucide-react';
import { useCities } from '@/hooks/useCities';
import { useMarket } from '@/contexts/MarketContext';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { MainLayout } from '@/components/MainLayout';
import { SEOHead } from '@/components/SEOHead';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const CityOverview: React.FC = () => {
  const { market } = useMarket();
  const { cities, loading } = useCities(market.country_code);
  const { generateCityUrl } = useMarketUrl();

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-64"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-48 bg-muted rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <SEOHead
        title={`Cities - ${market.country_name}`}
        description={`Explore cities in ${market.country_name} where our locksmith services are available.`}
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4">Cities in {market.country_name}</h1>
          <p className="text-muted-foreground text-lg">
            Professional locksmith services available in {cities.length} cities across {market.country_name}.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cities.map((city) => (
            <Link key={city.id} to={generateCityUrl(city.slug)}>
              <Card className="h-full hover:shadow-lg transition-all duration-300 group">
                <CardHeader className="pb-4">
                  {city.featured_image_url && (
                    <div className="aspect-video rounded-lg overflow-hidden mb-4">
                      <img
                        src={city.featured_image_url}
                        alt={city.featured_image_alt || city.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl group-hover:text-primary transition-colors">
                      {city.name}
                    </CardTitle>
                    {city.is_metropolitan && (
                      <Badge variant="secondary">
                        <Building2 className="h-3 w-3 mr-1" />
                        Metro
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 mr-2" />
                    {city.latitude && city.longitude ? (
                      <span>{city.latitude.toFixed(2)}, {city.longitude.toFixed(2)}</span>
                    ) : (
                      <span>Location available</span>
                    )}
                  </div>
                  
                  {city.population && (
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Users className="h-4 w-4 mr-2" />
                      <span>{city.population.toLocaleString()} residents</span>
                    </div>
                  )}
                  
                  {city.seo_description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {city.seo_description}
                    </p>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {cities.length === 0 && (
          <div className="text-center py-12">
            <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No cities found</h3>
            <p className="text-muted-foreground">
              Cities will appear here once they are added to the system.
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default CityOverview;