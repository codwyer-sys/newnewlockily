import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { XCircle, ArrowLeft, CreditCard } from 'lucide-react';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';

const PaymentCancel = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  
  const quoteId = searchParams.get('quote_id');

  const handleTryAgain = () => {
    // Navigate back to the booking status page where they can retry payment
    navigate(-1);
  };

  const handleViewOtherQuotes = () => {
    // Go back to view other available quotes
    navigate(-1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
              <CardTitle className="text-2xl text-red-600">Payment Cancelled</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-muted-foreground">
                Your payment was cancelled and no charges were made. The quote is still available if you'd like to try again.
              </p>
              
              <div className="bg-muted/50 rounded-lg p-4">
                <h3 className="font-semibold mb-2">What happens next?</h3>
                <ul className="text-sm text-muted-foreground space-y-1 text-left">
                  <li>• Your quote is still available for 15 minutes</li>
                  <li>• You can try payment again</li>
                  <li>• Or choose a different quote</li>
                  <li>• No charges were made to your account</li>
                </ul>
              </div>

              <div className="space-y-2">
                <Button onClick={handleTryAgain} className="w-full">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Try Payment Again
                </Button>
                <Button variant="outline" onClick={handleViewOtherQuotes} className="w-full">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  View Other Quotes
                </Button>
                <Button variant="ghost" onClick={() => navigate('/')} className="w-full">
                  Return to Home
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <LocksmithFooter />
    </div>
  );
};

export default PaymentCancel;