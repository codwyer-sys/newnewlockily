import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, MessageSquare, ArrowLeft, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";

import { PriceBreakdownSection } from "@/components/JobCard/PriceBreakdownSection";
import { ArrivalTimeSection } from "@/components/JobCard/ArrivalTimeSection";
import { OrderDetailsSection } from "@/components/JobCard/OrderDetailsSection";
import { LocksmithJob } from '@/types/locksmith';
import { useBidForm } from "@/hooks/useBidForm";
import { useJobBidding } from "@/hooks/useJobBidding";
import { useQuoteSubmission } from "@/hooks/useQuoteSubmission";
import { calculateEstimatedArrivalTime, adjustArrivalTime } from "@/utils/bidHelpers";

const PlaceBid = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { job } = location.state as { job: LocksmithJob } || {};
  const { toast } = useToast();
  
  // Redirect if no job data
  useEffect(() => {
    if (!job) {
      navigate('/locksmith-portal');
    }
  }, [job, navigate]);

  const [arrivalTime, setArrivalTime] = useState('');
  
  const { user } = useAuth();
  const { t } = useLanguage();

  // Initialize bid form early to get default values
  const bidForm = useBidForm({ job, finalPrices: null, priceBreakdown: null });

  // Unified job bidding hook that manages address, distance, and pricing
  const jobBidding = useJobBidding({
    job,
    chargeClientForReferral: bidForm.chargeClientForReferral,
    customPrices: bidForm.customPrices,
    materialEnabled: bidForm.materialEnabled,
  });

  const quoteSubmission = useQuoteSubmission({ job, localDistance: jobBidding.distance });

  // Update bid amount when price changes
  useEffect(() => {
    if (jobBidding.finalPrices && jobBidding.finalPrices.total > 0) {
      bidForm.setBidAmount(jobBidding.finalPrices.total.toString());
    } else if (!jobBidding.priceBreakdown) {
      bidForm.setBidAmount('');
    }
  }, [jobBidding.finalPrices?.total, jobBidding.priceBreakdown, bidForm]);

  const isASAPJob = job?.urgency === 'emergency';

  const handleArrivalTimeAdjustment = (minutes: number) => {
    const newTime = adjustArrivalTime(arrivalTime, minutes);
    setArrivalTime(newTime);
  };

  // Initialize arrival time when distance is calculated
  useEffect(() => {
    if (jobBidding.distance) {
      const estimatedArrival = calculateEstimatedArrivalTime(jobBidding.distance);
      setArrivalTime(estimatedArrival);
    } else {
      // Set default arrival time for immediate jobs
      const estimatedArrival = calculateEstimatedArrivalTime(null);
      setArrivalTime(estimatedArrival);
    }
  }, [jobBidding.distance]);


  const handleSubmit = async () => {
    if (!user || !job) return;

    quoteSubmission.setIsSubmittingBid(true);
    
    try {
      // Calculate final amount from custom prices if no auto-pricing
      let finalAmount = jobBidding.finalPrices?.total.toString() || bidForm.bidAmount;
      
      // If we have custom prices but no finalPrices (manual mode), calculate total
      if (!jobBidding.finalPrices && (bidForm.customPrices.basePrice || bidForm.customPrices.timeSurcharge || bidForm.customPrices.distanceFee || (bidForm.materialEnabled && bidForm.customPrices.materials))) {
        const basePrice = bidForm.customPrices.basePrice || 0;
        const timeSurcharge = bidForm.customPrices.timeSurcharge || 0;
        const distanceFee = bidForm.customPrices.distanceFee || 0;
        const materials = bidForm.materialEnabled ? (bidForm.customPrices.materials || 0) : 0;
        const manualTotal = basePrice + timeSurcharge + distanceFee + materials;
        finalAmount = manualTotal.toString();
      }
      
      if (!finalAmount || finalAmount === '0') {
        return;
      }
      
      const result = await quoteSubmission.handleSubmitBid(finalAmount, bidForm.bidNotes, arrivalTime, jobBidding.address);
      
      if (result?.success) {
        // Navigate back to jobs list
        navigate('/locksmith-portal');
      }
    } catch (error) {
      console.error('Bid submission failed:', error);
    } finally {
      quoteSubmission.setIsSubmittingBid(false);
    }
  };

  const handleGoBack = () => {
    navigate('/locksmith-portal');
  };

  if (!job) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleGoBack}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Jobs
          </Button>
          <h1 className="text-2xl font-bold">{t('job_cards.actions.place_bid')} - {job.category}</h1>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Bidding Form */}
          <div className="space-y-6">
            {/* Business Address Display */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Din virksomheds adresse</CardTitle>
              </CardHeader>
              <CardContent>
                {jobBidding.isLoadingAddress ? (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Henter adresse...
                  </div>
                ) : jobBidding.addressError ? (
                  <p className="text-destructive text-sm">{jobBidding.addressError}</p>
                ) : (
                  <p className="text-sm text-foreground">{jobBidding.address || 'Ingen adresse angivet'}</p>
                )}
              </CardContent>
            </Card>

            {/* Price Breakdown Section */}
            <PriceBreakdownSection
              priceBreakdown={jobBidding.priceBreakdown}
              finalPrices={jobBidding.finalPrices}
              editingPriceComponent={bidForm.editingPriceComponent}
              onPriceEdit={bidForm.handlePriceEdit}
              onSetEditingComponent={bidForm.setEditingPriceComponent}
              chargeClientForReferral={bidForm.chargeClientForReferral}
              onToggleReferralCharge={bidForm.setChargeClientForReferral}
              materialEnabled={bidForm.materialEnabled}
              onToggleMaterials={bidForm.setMaterialEnabled}
            />

            {/* Arrival Time Section */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Ankomst tid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ArrivalTimeSection
                  isASAPJob={isASAPJob}
                  arrivalTime={arrivalTime}
                  onArrivalTimeChange={setArrivalTime}
                  onAdjustArrivalTime={handleArrivalTimeAdjustment}
                  distance={jobBidding.distance}
                  scheduledDate={job.scheduledDate}
                  locksmithAddress={jobBidding.address}
                />
              </CardContent>
            </Card>

            {/* Notes */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  {t('job_cards.interface.notes')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  id="bidNotes"
                  placeholder={t('job_cards.interface.notes_placeholder')}
                  value={bidForm.bidNotes}
                  onChange={(e) => bidForm.setBidNotes(e.target.value)}
                  rows={3}
                  className="w-full"
                />
              </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="space-y-4">
            <Button 
              onClick={handleSubmit}
              disabled={quoteSubmission.isSubmittingBid || (!jobBidding.finalPrices?.total && !bidForm.bidAmount)}
              className="w-full h-12 text-base"
              size="lg"
            >
              {quoteSubmission.isSubmittingBid ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {t('job_cards.actions.sending_bid')}
                </div>
              ) : (
                t('job_cards.actions.send_bid')
              )}
            </Button>
              
              <Button 
                variant="outline" 
                onClick={handleGoBack}
                className="w-full"
              >
                Back to All Jobs
              </Button>
            </div>
          </div>

          {/* Right Column: Order Details */}
          <div className="lg:border-l lg:border-border lg:pl-6">
            <OrderDetailsSection job={job} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlaceBid;