import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, User, Phone, Star, Navigation } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';

interface Booking {
  id: string;
  address: string;
  urgency: string;
  job_type: string;
  follow_up_answers: any;
  created_at: string;
  status: string;
}

interface Quote {
  id: string;
  locksmith_id: string;
  price: number;
  estimated_arrival: string;
  distance_km: number;
  locksmith_name: string;
  locksmith_rating: number;
  locksmith_reviews: number;
  created_at: string;
}

const WaitingForQuotes = () => {
  const { bookingId } = useParams<{ bookingId: string }>();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadBooking = async () => {
      console.log('🎯 Loading booking:', bookingId);
      
      if (!bookingId) {
        setError('No booking ID provided');
        setLoading(false);
        return;
      }

      try {
        const { data: bookingData, error: bookingError } = await supabase
          .from('bookings')
          .select('*')
          .eq('id', bookingId)
          .maybeSingle();

        if (bookingError) {
          console.error('❌ Booking error:', bookingError);
          setError('Failed to load booking');
          setLoading(false);
          return;
        }

        if (!bookingData) {
          console.warn('⚠️ No booking found');
          setError('Booking not found');
          setLoading(false);
          return;
        }

        console.log('✅ Booking loaded:', bookingData);
        setBooking(bookingData);
        setLoading(false);

        // Simulate quotes coming in after booking is loaded
        const mockQuotes: Quote[] = [
          {
            id: '1',
            locksmith_id: 'locksmith-1',
            price: 450,
            estimated_arrival: '15-20 min',
            distance_km: 2.3,
            locksmith_name: 'John\'s Låsesmed',
            locksmith_rating: 4.8,
            locksmith_reviews: 142,
            created_at: new Date().toISOString()
          },
          {
            id: '2',
            locksmith_id: 'locksmith-2',
            price: 520,
            estimated_arrival: '10-15 min',
            distance_km: 1.8,
            locksmith_name: 'Quick Lock Service',
            locksmith_rating: 4.6,
            locksmith_reviews: 89,
            created_at: new Date().toISOString()
          }
        ];

        setTimeout(() => {
          console.log('📊 Adding mock quotes');
          setQuotes(mockQuotes);
        }, 2000);

      } catch (err) {
        console.error('💥 Unexpected error:', err);
        setError('Something went wrong');
        setLoading(false);
      }
    };

    loadBooking();
  }, [bookingId]);

  const sortQuotes = (by: 'price' | 'distance' | 'rating') => {
    const sorted = [...quotes].sort((a, b) => {
      switch (by) {
        case 'price':
          return a.price - b.price;
        case 'distance':
          return a.distance_km - b.distance_km;
        case 'rating':
          return b.locksmith_rating - a.locksmith_rating;
        default:
          return 0;
      }
    });
    setQuotes(sorted);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading booking details...</p>
          </div>
        </div>
        <LocksmithFooter />
      </div>
    );
  }

  if (error || !booking) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-destructive mb-4">Error</h1>
            <p className="text-muted-foreground mb-4">{error || 'Booking not found'}</p>
            <Button onClick={() => window.location.href = '/'}>Return Home</Button>
          </div>
        </div>
        <LocksmithFooter />
      </div>
    );
  }

  const customerName = booking.follow_up_answers?.customerName || 'Not provided';
  const customerPhone = booking.follow_up_answers?.customerPhone || 'Not provided';

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        {/* Status Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-card border border-border text-card-foreground text-sm font-medium mb-4">
            <Clock className="w-4 h-4 mr-2" />
            Booking Created
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-4">
            Waiting for Quotes from Locksmiths
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your booking has been sent to locksmiths in the area. You will receive quotes with prices and arrival times.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto mb-8">
          {/* Booking Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary" />
                Booking Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-muted-foreground mt-1" />
                <div>
                  <p className="font-medium">Address</p>
                  <p className="text-muted-foreground">{booking.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-muted-foreground mt-1" />
                <div>
                  <p className="font-medium">Urgency</p>
                  <Badge variant={booking.urgency === 'nu' ? 'destructive' : 'secondary'}>
                    {booking.urgency === 'nu' ? 'Urgent - Now' : 'Can Wait'}
                  </Badge>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <User className="w-5 h-5 text-muted-foreground mt-1" />
                <div>
                  <p className="font-medium">Contact</p>
                  <p className="text-muted-foreground">{customerName}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-muted-foreground mt-1" />
                <div>
                  <p className="font-medium">Phone</p>
                  <p className="text-muted-foreground">{customerPhone}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Status */}
          <Card>
            <CardHeader>
              <CardTitle>Quote Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                {quotes.length === 0 ? (
                  <>
                    <div className="animate-pulse mb-4">
                      <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                        <Clock className="w-8 h-8 text-primary" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Finding Locksmiths...</h3>
                    <p className="text-muted-foreground">
                      We're sending your booking to available locksmiths. You'll typically receive quotes within 5-10 minutes.
                    </p>
                  </>
                ) : (
                  <>
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Star className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Quotes Received!</h3>
                    <p className="text-muted-foreground">
                      {quotes.length} locksmith{quotes.length > 1 ? 's have' : ' has'} sent you quotes.
                    </p>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quotes Table */}
        {quotes.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Available Quotes</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => sortQuotes('price')}>
                  Sort by Price
                </Button>
                <Button variant="outline" size="sm" onClick={() => sortQuotes('distance')}>
                  Sort by Distance
                </Button>
                <Button variant="outline" size="sm" onClick={() => sortQuotes('rating')}>
                  Sort by Rating
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {quotes.map((quote) => (
                  <div key={quote.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-lg">{quote.locksmith_name}</h3>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">{quote.price} kr</div>
                        <div className="text-sm text-muted-foreground">Total price</div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{quote.estimated_arrival}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Navigation className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{quote.distance_km} km away</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm">{quote.locksmith_rating} ({quote.locksmith_reviews} reviews)</span>
                      </div>
                    </div>

                    <Button className="w-full">
                      Accept Quote - {quote.price} kr
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="text-center mt-8">
          <Button variant="outline" onClick={() => window.location.href = '/'} className="mr-4">
            Back to Home
          </Button>
          <Button onClick={() => window.location.href = 'tel:70203040'}>
            Call Us: 70 20 30 40
          </Button>
        </div>
      </div>

      <LocksmithFooter />
    </div>
  );
};

export default WaitingForQuotes;