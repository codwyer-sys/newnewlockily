import React from 'react';
import ContentManagementAdmin from '@/components/ContentManagementAdmin';

const ContentAdmin = () => {
  return (
    <div className="min-h-screen bg-background">
      <ContentManagementAdmin />
    </div>
  );
};

export default ContentAdmin;