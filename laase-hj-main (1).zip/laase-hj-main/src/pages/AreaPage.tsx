import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, ArrowLeft, Hash } from 'lucide-react';
import { useCities, City } from '@/hooks/useCities';
import { useAreas, Area } from '@/hooks/useAreas';
import { useMarket } from '@/contexts/MarketContext';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { MainLayout } from '@/components/MainLayout';
import { SEOHead } from '@/components/SEOHead';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';

const AreaPage: React.FC = () => {
  const { citySlug, areaSlug } = useParams<{ citySlug: string; areaSlug: string }>();
  const { market } = useMarket();
  const { getCityBySlug } = useCities();
  const { getAreaBySlug } = useAreas();
  const { generateUrl, generateCityUrl } = useMarketUrl();
  
  const [city, setCity] = useState<City | null>(null);
  const [area, setArea] = useState<Area | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!citySlug || !areaSlug) return;
      
      setLoading(true);
      try {
        const cityData = await getCityBySlug(citySlug, market.country_code);
        if (!cityData) {
          setNotFound(true);
          return;
        }
        
        setCity(cityData);
        
        const areaData = await getAreaBySlug(areaSlug, cityData.id);
        if (areaData) {
          setArea(areaData);
          setNotFound(false);
        } else {
          setNotFound(true);
        }
      } catch (error) {
        console.error('Error fetching area:', error);
        setNotFound(true);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [citySlug, areaSlug, market.country_code, getCityBySlug, getAreaBySlug]);

  if (loading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-64"></div>
            <div className="h-64 bg-muted rounded-lg"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="h-48 bg-muted rounded-lg"></div>
              <div className="h-48 bg-muted rounded-lg"></div>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (notFound || !city || !area) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <SEOHead
              title="Area Not Found"
              description="The area you're looking for doesn't exist."
            />
            <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h1 className="text-2xl font-bold mb-4">Area Not Found</h1>
            <p className="text-muted-foreground mb-6">
              The area you're looking for doesn't exist or is not available.
            </p>
            <Button asChild>
              <Link to={generateUrl('cities')}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Cities
              </Link>
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <SEOHead
        title={area.seo_title || `${area.name}, ${city.name} - Locksmith Services`}
        description={area.seo_description || `Professional locksmith services in ${area.name}, ${city.name}. Local expertise in your neighborhood.`}
        keywords={area.seo_keywords}
        ogTitle={area.seo_title || `${area.name}, ${city.name}`}
        ogDescription={area.seo_description}
        ogImage={area.featured_image_url}
      />
      
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to={generateUrl('cities')}>Cities</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink asChild>
                <Link to={generateCityUrl(city.slug)}>{city.name}</Link>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{area.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        {/* Hero Section */}
        <section className="mb-12">
          <div className="relative bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl p-8 md:p-12">
            {area.featured_image_url && (
              <div className="absolute inset-0 rounded-xl overflow-hidden">
                <img
                  src={area.featured_image_url}
                  alt={area.featured_image_alt || area.name}
                  className="w-full h-full object-cover opacity-20"
                />
              </div>
            )}
            
            <div className="relative max-w-3xl">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                {area.name}
                <span className="text-muted-foreground font-normal">, {city.name}</span>
              </h1>
              
              <div className="flex items-center gap-6 text-muted-foreground mb-6">
                {area.latitude && area.longitude && (
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-2" />
                    <span>{area.latitude.toFixed(2)}, {area.longitude.toFixed(2)}</span>
                  </div>
                )}
                
                {area.postal_codes && area.postal_codes.length > 0 && (
                  <div className="flex items-center">
                    <Hash className="h-4 w-4 mr-2" />
                    <span>{area.postal_codes.length} postal codes</span>
                  </div>
                )}
              </div>
              
              {area.seo_description && (
                <p className="text-lg text-muted-foreground leading-relaxed">
                  {area.seo_description}
                </p>
              )}
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Service Information */}
            <Card>
              <CardHeader>
                <CardTitle>Locksmith Services in {area.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">
                  Professional locksmith services available 24/7 in the {area.name} area of {city.name}. 
                  Our local experts know the neighborhood and provide fast, reliable service.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-2">Residential Services</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Home lockouts</li>
                      <li>• Lock installation</li>
                      <li>• Key duplication</li>
                      <li>• Security upgrades</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">Commercial Services</h4>
                    <ul className="space-y-1 text-sm text-muted-foreground">
                      <li>• Office lockouts</li>
                      <li>• Access control</li>
                      <li>• Master key systems</li>
                      <li>• Security audits</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Local Expertise */}
            <Card>
              <CardHeader>
                <CardTitle>Local Expertise in {area.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  Our team knows {area.name} inside and out. We understand the unique characteristics 
                  of this neighborhood and can provide tailored security solutions for local residents and businesses.
                </p>
                
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Local Knowledge</Badge>
                  <Badge variant="secondary">Fast Response</Badge>
                  <Badge variant="secondary">Neighborhood Trusted</Badge>
                  <Badge variant="secondary">Available 24/7</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Postal Codes */}
            {area.postal_codes && area.postal_codes.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Postal Codes Served</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {area.postal_codes.map((code) => (
                      <Badge key={code} variant="outline">
                        {code}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Quick Contact */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Need Service in {area.name}?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Get connected with local locksmith professionals in {area.name}.
                </p>
                <Button className="w-full">
                  Get Quote
                </Button>
              </CardContent>
            </Card>

            {/* Area Navigation */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Explore {city.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full" asChild>
                  <Link to={generateCityUrl(city.slug)}>
                    View All Areas in {city.name}
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default AreaPage;