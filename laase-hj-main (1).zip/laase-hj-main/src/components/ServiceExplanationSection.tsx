
import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useHeaderThemeSection } from '@/hooks/useHeaderThemeSection';

const ServiceExplanationSection = () => {
  const { t } = useLanguage();
  const sectionRef = useHeaderThemeSection('dark', 'service-explanation');
  
  return (
    <section ref={sectionRef} className="py-16 bg-slate-900 relative z-10">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-headline font-bold text-white mb-6">
            {t('home.services.title')}
          </h2>
          <p className="text-xl text-slate-300 mb-8">
            {t('home.services.subtitle')}
          </p>
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="text-center">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-xl font-headline font-semibold text-white mb-2">{t('home.services.instant_title')}</h3>
              <p className="text-slate-400">{t('home.services.instant_desc')}</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-4">💰</div>
              <h3 className="text-xl font-headline font-semibold text-white mb-2">{t('home.services.price_title')}</h3>
              <p className="text-slate-400">{t('home.services.price_desc')}</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-4">🚀</div>
              <h3 className="text-xl font-headline font-semibold text-white mb-2">{t('home.services.speed_title')}</h3>
              <p className="text-slate-400">{t('home.services.speed_desc')}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceExplanationSection;
