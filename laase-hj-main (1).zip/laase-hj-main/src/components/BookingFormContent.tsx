
import React from 'react';
import BookingFormAddressSection from "@/components/BookingFormAddressSection";
import UrgencySelector from "@/components/UrgencySelector";
import JobTypeSelector from "@/components/JobTypeSelector";
import FollowUpQuestions from "@/components/FollowUpQuestions";

interface BookingFormContentProps {
  // Address props
  address: string;
  setAddress: (address: string) => void;
  skipAddressSearch: boolean;
  setSkipAddressSearch: (skip: boolean) => void;
  showSuggestions: boolean;
  setShowSuggestions: (show: boolean) => void;
  hasSelectedSuggestion: boolean;
  setHasSelectedSuggestion: (selected: boolean) => void;
  
  // Urgency props
  urgency: string;
  selectedDate: string;
  onUrgencySelect: (urgency: string) => void;
  onDateChange: (date: string) => void;
  showUrgency: boolean;
  
  // Job type props
  jobType: string | { selection: string; details: string };
  onJobTypeSelect: (type: string | { selection: string; details: string }) => void;
  showJobType: boolean;
  
  // Follow up props
  followUpAnswers: Record<string, any>;
  onFollowUpAnswer: (questionKey: string, answer: any) => void;
  showFollowUp: boolean;
}

const BookingFormContent: React.FC<BookingFormContentProps> = ({
  address,
  setAddress,
  skipAddressSearch,
  setSkipAddressSearch,
  showSuggestions,
  setShowSuggestions,
  hasSelectedSuggestion,
  setHasSelectedSuggestion,
  urgency,
  selectedDate,
  onUrgencySelect,
  onDateChange,
  showUrgency,
  jobType,
  onJobTypeSelect,
  showJobType,
  followUpAnswers,
  onFollowUpAnswer,
  showFollowUp
}) => {
  return (
    <div className="space-y-apple-8">
      <BookingFormAddressSection
        address={address}
        setAddress={setAddress}
        setHasSelectedSuggestion={setHasSelectedSuggestion}
      />

      <UrgencySelector
        urgency={urgency}
        selectedDate={selectedDate}
        onUrgencySelect={onUrgencySelect}
        onDateChange={onDateChange}
        showUrgency={showUrgency}
      />

      {showJobType && (
        <JobTypeSelector
          jobType={jobType}
          onJobTypeSelect={onJobTypeSelect}
        />
      )}

      {showFollowUp && jobType && (
        <FollowUpQuestions
          jobType={typeof jobType === 'object' ? jobType.selection : jobType}
          answers={followUpAnswers}
          onAnswerChange={onFollowUpAnswer}
        />
      )}
    </div>
  );
};

export default BookingFormContent;
