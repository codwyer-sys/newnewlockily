import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

interface CityMapCircleProps {
  cityName: string;
  latitude: number;
  longitude: number;
  radiusKm?: number;
  className?: string;
}

export const CityMapCircle: React.FC<CityMapCircleProps> = ({
  cityName,
  latitude,
  longitude,
  radiusKm = 15,
  className = ""
}) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);

  useEffect(() => {
    if (!mapContainer.current) return;

    // Use a public token - in production this should come from environment
    mapboxgl.accessToken = 'pk.eyJ1IjoibG92YWJsZSIsImEiOiJjbTNieXNsdmYwZGVtMmpzOXVja3JjbWFiIn0.0cKr8GgqHFWbRyuKkAUr8Q';
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [longitude, latitude],
      zoom: 11,
      interactive: false, // Disable interaction for hero display
    });

    map.current.on('load', () => {
      if (!map.current) return;

      // Create a circle around the city
      const center: [number, number] = [longitude, latitude];
      const radius = radiusKm;
      const options = { steps: 80, units: 'kilometers' as const };
      
      // Calculate circle coordinates
      const circle = turf.circle(center, radius, options);

      // Add circle source
      map.current.addSource('city-coverage', {
        type: 'geojson',
        data: circle
      });

      // Add circle fill layer
      map.current.addLayer({
        id: 'city-coverage-fill',
        type: 'fill',
        source: 'city-coverage',
        paint: {
          'fill-color': '#10b981', // Green color for coverage
          'fill-opacity': 0.2
        }
      });

      // Add circle border layer
      map.current.addLayer({
        id: 'city-coverage-border',
        type: 'line',
        source: 'city-coverage',
        paint: {
          'line-color': '#10b981',
          'line-width': 3
        }
      });

      // Add center marker
      new mapboxgl.Marker({
        color: '#10b981',
        scale: 0.8
      })
        .setLngLat([longitude, latitude])
        .addTo(map.current);
    });

    return () => {
      map.current?.remove();
    };
  }, [latitude, longitude, radiusKm]);

  return (
    <div className={`relative rounded-lg overflow-hidden shadow-lg ${className}`}>
      <div ref={mapContainer} className="w-full h-full" />
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-md">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-sm font-medium text-gray-800">
            Vi dækker hele {cityName}
          </span>
        </div>
      </div>
    </div>
  );
};

// Simple turf.js circle implementation to avoid dependency
const turf = {
  circle: (center: [number, number], radius: number, options: { steps: number; units: string }) => {
    const steps = options.steps;
    const coordinates: [number, number][] = [];
    
    for (let i = 0; i < steps; i++) {
      const angle = (i * 2 * Math.PI) / steps;
      // Rough conversion: 1 degree ≈ 111 km
      const radiusInDegrees = radius / 111;
      const x = center[0] + radiusInDegrees * Math.cos(angle);
      const y = center[1] + radiusInDegrees * Math.sin(angle);
      coordinates.push([x, y]);
    }
    
    // Close the circle
    coordinates.push(coordinates[0]);
    
    return {
      type: 'Feature' as const,
      properties: {},
      geometry: {
        type: 'Polygon' as const,
        coordinates: [coordinates]
      }
    };
  }
};