import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { JobCategoryWithPreference } from '@/hooks/useAutoBidPreferences';
import { AutoBydQuestionPricing } from './AutoBydQuestionPricing';

interface AutoBydFollowUpQuestionsProps {
  category: JobCategoryWithPreference;
  isUpdating: boolean;
  onToggleExclusion: (categoryId: string, questionId: string, answerValue: string, isExcluded: boolean) => Promise<boolean>;
  onUpdateQuestionPricing: (
    categoryId: string, 
    questionId: string, 
    answerValue: string, 
    feeType: 'percentage' | 'fixed', 
    feeAmount: number
  ) => Promise<boolean>;
}

export const AutoBydFollowUpQuestions: React.FC<AutoBydFollowUpQuestionsProps> = ({
  category,
  isUpdating,
  onToggleExclusion,
  onUpdateQuestionPricing,
}) => {
  if (category.follow_up_questions.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <div className="bg-background rounded-lg p-4 border">
        <h4 className="font-medium mb-3">Ekskluder bestemte typer</h4>
        <p className="text-sm text-muted-foreground mb-4">
          Vælg hvilke svar der skal udelukke automatisk budgivning
        </p>
        <div className="space-y-4">
          {category.follow_up_questions.map((question) => (
            <div key={question.id} className="border rounded p-3">
              <h5 className="font-medium text-sm mb-2">{question.question}</h5>
              {question.options && Array.isArray(question.options) && (
                <div className="space-y-2">
                  {question.options.map((option: string) => (
                    <div key={option} className="flex items-center space-x-2">
                      <Checkbox
                        id={`${question.id}-${option}`}
                        checked={question.excluded_answers.includes(option)}
                        onCheckedChange={(checked) =>
                          onToggleExclusion(
                            category.id,
                            question.id,
                            option,
                            checked as boolean
                          )
                        }
                        disabled={isUpdating}
                      />
                      <Label 
                        htmlFor={`${question.id}-${option}`}
                        className="text-sm cursor-pointer"
                      >
                        {option}
                      </Label>
                    </div>
                  ))}
                </div>
              )}
              {question.excluded_answers.length > 0 && (
                <p className="text-xs text-muted-foreground mt-2">
                  Ekskluderet: {question.excluded_answers.join(', ')}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {/* Question Pricing */}
      {category.follow_up_questions.map((question) => (
        <AutoBydQuestionPricing
          key={`pricing-${question.id}`}
          categoryId={category.id}
          question={question}
          isUpdating={isUpdating}
          onUpdateQuestionPricing={onUpdateQuestionPricing}
        />
      ))}
    </div>
  );
};