import React from 'react';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Settings, DollarSign, Clock, MapPin, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { JobCategoryWithPreference } from '@/hooks/useAutoBidPreferences';
import { AutoBydCategoryPricing } from './AutoBydCategoryPricing';
import { AutoBydFollowUpQuestions } from './AutoBydFollowUpQuestions';

interface AutoBydCategoryCardProps {
  category: JobCategoryWithPreference;
  isUpdating: boolean;
  onTogglePreference: (categoryId: string, isEnabled: boolean) => Promise<boolean>;
  onUpdateBasePrice: (categoryId: string, price: number) => Promise<boolean>;
  onUpdateQuestionPricing: (
    categoryId: string, 
    questionId: string, 
    answerValue: string, 
    feeType: 'percentage' | 'fixed', 
    feeAmount: number
  ) => Promise<boolean>;
  onToggleExclusion: (categoryId: string, questionId: string, answerValue: string, isExcluded: boolean) => Promise<boolean>;
}

export const AutoBydCategoryCard: React.FC<AutoBydCategoryCardProps> = ({
  category,
  isUpdating,
  onTogglePreference,
  onUpdateBasePrice,
  onUpdateQuestionPricing,
  onToggleExclusion,
}) => {
  const hasBasePrice = category.base_price && category.base_price > 0;
  const hasExclusions = category.follow_up_questions.some(q => q.excluded_answers.length > 0);
  const hasPricing = category.follow_up_questions.some(q => q.pricing.length > 0);
  
  const generateQuotePreview = () => {
    if (!category.is_enabled || !hasBasePrice) return null;
    
    const basePrice = category.base_price || 0;
    const examplePrice = basePrice + (basePrice * 0.25); // Example with some surcharges
    
    return (
      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
        <DollarSign className="h-3 w-3" />
        <span>Eksempel kunde pris: {Math.round(examplePrice)} DKK</span>
      </div>
    );
  };

  const renderSummaryBadges = () => {
    const badges = [];
    
    if (hasBasePrice) {
      badges.push(
        <Badge key="price" variant="secondary" className="text-xs">
          <DollarSign className="h-3 w-3 mr-1" />
          {category.base_price} DKK basis
        </Badge>
      );
    }
    
    if (hasExclusions) {
      const exclusionCount = category.follow_up_questions.reduce(
        (count, q) => count + q.excluded_answers.length, 
        0
      );
      badges.push(
        <Badge key="exclusions" variant="outline" className="text-xs">
          <AlertTriangle className="h-3 w-3 mr-1" />
          {exclusionCount} eksklusioner
        </Badge>
      );
    }
    
    if (hasPricing) {
      const pricingCount = category.follow_up_questions.reduce(
        (count, q) => count + q.pricing.length, 
        0
      );
      badges.push(
        <Badge key="pricing" variant="outline" className="text-xs">
          <Settings className="h-3 w-3 mr-1" />
          {pricingCount} pristillæg
        </Badge>
      );
    }
    
    return badges;
  };

  return (
    <Card className={`transition-all duration-200 ${category.is_enabled ? 'ring-2 ring-primary/20 bg-primary/5' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl flex-shrink-0">
              {category.emoji || '🔧'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <Label 
                  htmlFor={`category-${category.id}`}
                  className="text-base font-semibold cursor-pointer truncate"
                >
                  {category.name}
                </Label>
                {category.is_enabled && (
                  <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
                )}
              </div>
              {category.description && (
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                  {category.description}
                </p>
              )}
              
              {/* Summary badges for enabled categories */}
              {category.is_enabled && (
                <div className="flex flex-wrap gap-1 mt-2">
                  {renderSummaryBadges()}
                </div>
              )}
              
              {/* Quote preview */}
              {category.is_enabled && generateQuotePreview()}
            </div>
          </div>
          
          <div className="flex items-center space-x-3 flex-shrink-0">
            <Switch
              id={`category-${category.id}`}
              checked={category.is_enabled}
              onCheckedChange={(checked) => 
                onTogglePreference(category.id, checked)
              }
              disabled={isUpdating}
            />
          </div>
        </div>
      </CardHeader>

      {category.is_enabled && (
        <CardContent className="pt-0">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="settings" className="border-0">
              <AccordionTrigger className="hover:no-underline py-2">
                <div className="flex items-center space-x-2 text-sm font-medium">
                  <Settings className="h-4 w-4" />
                  <span>Konfigurer prisindstillinger</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-4">
                <div className="space-y-6 bg-muted/30 rounded-lg p-4">
                  <AutoBydCategoryPricing
                    category={category}
                    isUpdating={isUpdating}
                    onUpdateBasePrice={onUpdateBasePrice}
                  />

                  <AutoBydFollowUpQuestions
                    category={category}
                    isUpdating={isUpdating}
                    onToggleExclusion={onToggleExclusion}
                    onUpdateQuestionPricing={onUpdateQuestionPricing}
                  />
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      )}
    </Card>
  );
};