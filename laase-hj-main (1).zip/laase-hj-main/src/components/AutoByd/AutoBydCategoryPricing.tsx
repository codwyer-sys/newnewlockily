import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { DollarSign } from 'lucide-react';
import { JobCategoryWithPreference } from '@/hooks/useAutoBidPreferences';

interface AutoBydCategoryPricingProps {
  category: JobCategoryWithPreference;
  isUpdating: boolean;
  onUpdateBasePrice: (categoryId: string, price: number) => Promise<boolean>;
}

export const AutoBydCategoryPricing: React.FC<AutoBydCategoryPricingProps> = ({
  category,
  isUpdating,
  onUpdateBasePrice,
}) => {
  const [basePriceInput, setBasePriceInput] = useState('');

  const handleBasePriceSubmit = async () => {
    if (basePriceInput && !isNaN(Number(basePriceInput))) {
      await onUpdateBasePrice(category.id, Number(basePriceInput));
      setBasePriceInput('');
    }
  };

  return (
    <div className="bg-background rounded-lg p-4 border">
      <h4 className="font-medium flex items-center space-x-2 mb-4">
        <DollarSign className="h-4 w-4" />
        <span>Basispris for {category.name}</span>
      </h4>
      
      <div className="space-y-4">
        <div>
          <Label className="text-sm font-medium mb-2 block">Basispris</Label>
          <div className="flex items-center space-x-2">
            <div className="flex-1 max-w-xs">
              <div className="relative">
                <Input
                  type="number"
                  placeholder={category.base_price ? category.base_price.toString() : "0"}
                  value={basePriceInput}
                  onChange={(e) => setBasePriceInput(e.target.value)}
                  className="pr-12"
                />
                <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground text-sm">
                  DKK
                </span>
              </div>
            </div>
            <Button 
              onClick={handleBasePriceSubmit}
              disabled={!basePriceInput || isUpdating}
              size="sm"
            >
              Gem
            </Button>
          </div>
          {category.base_price && (
            <p className="text-xs text-muted-foreground mt-1">
              Nuværende: {category.base_price} DKK
            </p>
          )}
        </div>
      </div>
    </div>
  );
};