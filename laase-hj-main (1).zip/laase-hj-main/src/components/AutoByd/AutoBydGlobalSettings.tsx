import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Clock, Globe, MapPin } from 'lucide-react';
import { GlobalPricingSettings } from '@/hooks/useAutoBidPreferences';

interface AutoBydGlobalSettingsProps {
  globalSettings: GlobalPricingSettings | null;
  isUpdating: boolean;
  onUpdateGlobalSettings: (settings: Partial<GlobalPricingSettings>) => Promise<boolean>;
}

export const AutoBydGlobalSettings: React.FC<AutoBydGlobalSettingsProps> = ({
  globalSettings,
  isUpdating,
  onUpdateGlobalSettings,
}) => {
  const [settings, setSettings] = useState({
    nighttime_fee_type: '',
    nighttime_fee_amount: '',
    weekend_fee_type: '',
    weekend_fee_amount: '',
    nighttime_start_hour: '',
    nighttime_end_hour: '',
    base_radius_km: '',
    fee_per_km_above_radius: '',
  });

  const handleSettingUpdate = async (field: keyof GlobalPricingSettings, value: any) => {
    await onUpdateGlobalSettings({ [field]: value });
  };

  const handleNumericSettingUpdate = async (field: string) => {
    const value = settings[field as keyof typeof settings];
    if (value && !isNaN(Number(value))) {
      await onUpdateGlobalSettings({ [field]: Number(value) });
      setSettings(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Globe className="h-5 w-5" />
          <span>Globale prisindstillinger</span>
        </CardTitle>
        <CardDescription>
          Indstil generelle tillæg der anvendes på tværs af alle kategorier
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs className="w-full">
          <TabsList className="grid w-full grid-cols-2 h-auto p-0 bg-transparent gap-6 mb-8">
            <TabsTrigger 
              value="nighttime-weekend" 
              className="flex items-center space-x-3 p-6 rounded-lg border-2 border-muted bg-background hover:border-primary/50 hover:bg-muted/50 data-[state=active]:border-primary data-[state=active]:bg-primary/5 transition-all duration-200 hover:scale-105 h-auto justify-start"
            >
              <Clock className="h-6 w-6 text-primary" />
              <div className="text-left">
                <div className="font-medium text-base">Nat & Weekend</div>
                <p className="text-xs text-muted-foreground font-normal">
                  Indstil tillæg for arbejde uden for normal arbejdstid
                </p>
              </div>
            </TabsTrigger>
            <TabsTrigger 
              value="distance" 
              className="flex items-center space-x-3 p-6 rounded-lg border-2 border-muted bg-background hover:border-primary/50 hover:bg-muted/50 data-[state=active]:border-primary data-[state=active]:bg-primary/5 transition-all duration-200 hover:scale-105 h-auto justify-start"
            >
              <MapPin className="h-6 w-6 text-primary" />
              <div className="text-left">
                <div className="font-medium text-base">Distance</div>
                <p className="text-xs text-muted-foreground font-normal">
                  Konfigurer afstandstillæg og inkluderet radius
                </p>
              </div>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="nighttime-weekend" className="space-y-4 mt-6">
            <p className="text-sm text-muted-foreground mb-6">
              Indstil tillæg for arbejde uden for normal arbejdstid - herunder nat- og weekendtimer.
            </p>
            
            {/* Nighttime Settings */}
            <div className="space-y-4">
              <h4 className="font-medium flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <span>Nattillæg</span>
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm">Type</Label>
                  <Select
                    value={globalSettings?.nighttime_fee_type || ''}
                    onValueChange={(value) => handleSettingUpdate('nighttime_fee_type', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Vælg type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Procent (%)</SelectItem>
                      <SelectItem value="fixed">Fast beløb (DKK)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-sm">Beløb</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      placeholder={globalSettings?.nighttime_fee_amount?.toString() || "0"}
                      value={settings.nighttime_fee_amount}
                      onChange={(e) => setSettings(prev => ({ ...prev, nighttime_fee_amount: e.target.value }))}
                    />
                    <Button 
                      onClick={() => handleNumericSettingUpdate('nighttime_fee_amount')}
                      disabled={!settings.nighttime_fee_amount || isUpdating}
                      size="sm"
                    >
                      Gem
                    </Button>
                  </div>
                  {globalSettings?.nighttime_fee_amount && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Nuværende: {globalSettings.nighttime_fee_amount} {globalSettings.nighttime_fee_type === 'percentage' ? '%' : 'DKK'}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm">Nat starter (time)</Label>
                  <div className="flex items-center space-x-2">
                    <Select
                      value={settings.nighttime_start_hour || globalSettings?.nighttime_start_hour?.toString() || ''}
                      onValueChange={(value) => handleSettingUpdate('nighttime_start_hour', Number(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg time" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 24 }, (_, i) => (
                          <SelectItem key={i} value={i.toString()}>
                            {i.toString().padStart(2, '0')}:00
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm">Nat slutter (time)</Label>
                  <div className="flex items-center space-x-2">
                    <Select
                      value={settings.nighttime_end_hour || globalSettings?.nighttime_end_hour?.toString() || ''}
                      onValueChange={(value) => handleSettingUpdate('nighttime_end_hour', Number(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg time" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 24 }, (_, i) => (
                          <SelectItem key={i} value={i.toString()}>
                            {i.toString().padStart(2, '0')}:00
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </div>

            {/* Weekend Settings */}
            <div className="space-y-4">
              <h4 className="font-medium">Weekendtillæg</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm">Type</Label>
                  <Select
                    value={globalSettings?.weekend_fee_type || ''}
                    onValueChange={(value) => handleSettingUpdate('weekend_fee_type', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Vælg type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Procent (%)</SelectItem>
                      <SelectItem value="fixed">Fast beløb (DKK)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-sm">Beløb</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      placeholder={globalSettings?.weekend_fee_amount?.toString() || "0"}
                      value={settings.weekend_fee_amount}
                      onChange={(e) => setSettings(prev => ({ ...prev, weekend_fee_amount: e.target.value }))}
                    />
                    <Button 
                      onClick={() => handleNumericSettingUpdate('weekend_fee_amount')}
                      disabled={!settings.weekend_fee_amount || isUpdating}
                      size="sm"
                    >
                      Gem
                    </Button>
                  </div>
                  {globalSettings?.weekend_fee_amount && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Nuværende: {globalSettings.weekend_fee_amount} {globalSettings.weekend_fee_type === 'percentage' ? '%' : 'DKK'}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Combination Settings */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Kombiner nat- og weekendtillæg</Label>
                  <p className="text-xs text-muted-foreground">
                    Hvis deaktiveret: Kun det højeste tillæg anvendes når en ordre falder i både nat- og weekendkategori.<br/>
                    Hvis aktiveret: Både nat- og weekendtillæg lægges sammen.
                  </p>
                </div>
                <Switch
                  checked={globalSettings?.combine_nighttime_weekend_fees || false}
                  onCheckedChange={(checked) => handleSettingUpdate('combine_nighttime_weekend_fees', checked)}
                  disabled={isUpdating}
                />
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="distance" className="space-y-4 mt-6">
            <p className="text-sm text-muted-foreground mb-6">
              Indstil hvordan afstand påvirker dine automatiske bud og prissætning.
            </p>
            
            {/* Distance Settings */}
            <div className="space-y-4">
              <h4 className="font-medium flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span>Afstandspriser</span>
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm">Inkluderet radius (km)</Label>
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      placeholder={globalSettings?.base_radius_km?.toString() || "0"}
                      value={settings.base_radius_km}
                      onChange={(e) => setSettings(prev => ({ ...prev, base_radius_km: e.target.value }))}
                    />
                    <Button 
                      onClick={() => handleNumericSettingUpdate('base_radius_km')}
                      disabled={!settings.base_radius_km || isUpdating}
                      size="sm"
                    >
                      Gem
                    </Button>
                  </div>
                  {globalSettings?.base_radius_km && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Nuværende: {globalSettings.base_radius_km} km
                    </p>
                  )}
                </div>
                
                <div>
                  <Label className="text-sm">Pris pr. km udover radius</Label>
                  <div className="flex items-center space-x-2">
                    <div className="relative flex-1">
                      <Input
                        type="number"
                        step="0.01"
                        placeholder={globalSettings?.fee_per_km_above_radius?.toString() || "0"}
                        value={settings.fee_per_km_above_radius}
                        onChange={(e) => setSettings(prev => ({ ...prev, fee_per_km_above_radius: e.target.value }))}
                        className="pr-16"
                      />
                      <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground text-sm">
                        DKK/km
                      </span>
                    </div>
                    <Button 
                      onClick={() => handleNumericSettingUpdate('fee_per_km_above_radius')}
                      disabled={!settings.fee_per_km_above_radius || isUpdating}
                      size="sm"
                    >
                      Gem
                    </Button>
                  </div>
                  {globalSettings?.fee_per_km_above_radius && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Nuværende: {globalSettings.fee_per_km_above_radius} DKK/km
                    </p>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};