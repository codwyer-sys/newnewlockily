import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export const AutoBydHowItWorks: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Sådan fungerer AutoByd</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm flex items-center justify-center font-medium">
            1
          </div>
          <div>
            <h4 className="font-medium">Automatisk scanning</h4>
            <p className="text-sm text-muted-foreground">
              Systemet scanner kontinuerligt for nye opgaver i dine valgte kategorier
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm flex items-center justify-center font-medium">
            2
          </div>
          <div>
            <h4 className="font-medium">Serviceområde & eksklusion check</h4>
            <p className="text-sm text-muted-foreground">
              Kun opgaver inden for dine serviceområder og uden ekskluderede svar bliver overvejet
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-sm flex items-center justify-center font-medium">
            3
          </div>
          <div>
            <h4 className="font-medium">Automatisk bud</h4>
            <p className="text-sm text-muted-foreground">
              Systemet afgiver bud baseret på dine konfigurerede priser for hver kategori
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};