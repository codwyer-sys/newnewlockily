import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, DollarSign } from 'lucide-react';
import { FollowUpQuestionWithExclusions } from '@/hooks/useAutoBidPreferences';

interface AutoBydQuestionPricingProps {
  categoryId: string;
  question: FollowUpQuestionWithExclusions;
  isUpdating: boolean;
  onUpdateQuestionPricing: (
    categoryId: string, 
    questionId: string, 
    answerValue: string, 
    feeType: 'percentage' | 'fixed', 
    feeAmount: number
  ) => Promise<boolean>;
}

export const AutoBydQuestionPricing: React.FC<AutoBydQuestionPricingProps> = ({
  categoryId,
  question,
  isUpdating,
  onUpdateQuestionPricing,
}) => {
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [feeType, setFeeType] = useState<'percentage' | 'fixed'>('fixed');
  const [feeAmount, setFeeAmount] = useState('');

  const handleAddPricing = async () => {
    if (selectedAnswer && feeAmount && !isNaN(Number(feeAmount))) {
      const success = await onUpdateQuestionPricing(
        categoryId,
        question.id,
        selectedAnswer,
        feeType,
        Number(feeAmount)
      );
      
      if (success) {
        setSelectedAnswer('');
        setFeeAmount('');
      }
    }
  };

  const availableOptions = question.options && Array.isArray(question.options) 
    ? question.options.filter(option => 
        !question.pricing.some(p => p.answer_value === option)
      )
    : [];

  if (!question.options || !Array.isArray(question.options)) {
    return null;
  }

  return (
    <div className="bg-background rounded-lg p-4 border">
      <h5 className="font-medium flex items-center space-x-2 mb-3">
        <DollarSign className="h-4 w-4" />
        <span>Pristillæg for: {question.question}</span>
      </h5>
      
      {/* Existing pricing */}
      {question.pricing.length > 0 && (
        <div className="mb-4">
          <Label className="text-sm font-medium mb-2 block">Aktuelle pristillæg</Label>
          <div className="space-y-2">
            {question.pricing.map((pricing) => (
              <div key={`${pricing.answer_value}-${pricing.fee_type}`} className="flex items-center justify-between p-2 bg-muted rounded">
                <span className="text-sm">{pricing.answer_value}</span>
                <Badge variant="secondary">
                  +{pricing.fee_amount} {pricing.fee_type === 'percentage' ? '%' : 'DKK'}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add new pricing */}
      {availableOptions.length > 0 && (
        <div className="space-y-3">
          <Label className="text-sm font-medium">Tilføj pristillæg</Label>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
            <Select value={selectedAnswer} onValueChange={setSelectedAnswer}>
              <SelectTrigger>
                <SelectValue placeholder="Vælg svar" />
              </SelectTrigger>
              <SelectContent>
                {availableOptions.map((option: string) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={feeType} onValueChange={(value: 'percentage' | 'fixed') => setFeeType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fixed">Fast beløb</SelectItem>
                <SelectItem value="percentage">Procent</SelectItem>
              </SelectContent>
            </Select>

            <Input
              type="number"
              placeholder="Beløb"
              value={feeAmount}
              onChange={(e) => setFeeAmount(e.target.value)}
            />

            <Button 
              onClick={handleAddPricing}
              disabled={!selectedAnswer || !feeAmount || isUpdating}
              size="sm"
              className="flex items-center space-x-1"
            >
              <Plus className="h-3 w-3" />
              <span>Tilføj</span>
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};
