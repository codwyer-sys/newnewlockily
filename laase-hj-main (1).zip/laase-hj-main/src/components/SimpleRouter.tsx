import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Index from '@/pages/Index';
import Admin from '@/pages/Admin';
import AdminPortal from '@/pages/AdminPortal';
import LocksmithSignup from '@/pages/LocksmithSignup';
import LocksmithPortal from '@/pages/LocksmithPortal';
import Auth from '@/pages/Auth';
import PostalCodeSafety from '@/pages/PostalCodeSafety';
import ContentAdmin from '@/pages/ContentAdmin';
import WaitingForQuotes from '@/pages/WaitingForQuotes';
import BookingStatus from '@/pages/BookingStatus';
import JobsManagement from '@/pages/JobsManagement';
import NotFound from '@/pages/NotFound';

export const SimpleRouter = () => {
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="/admin-portal/*" element={<AdminPortal />} />
      <Route path="/locksmith-signup" element={<LocksmithSignup />} />
      <Route path="/locksmith-portal/*" element={<LocksmithPortal />} />
      <Route path="/auth" element={<Auth />} />
      <Route path="/content-admin" element={<ContentAdmin />} />
      <Route path="/waiting-for-quotes/:bookingId" element={<WaitingForQuotes />} />
      <Route path="/booking-status/:bookingId" element={<BookingStatus />} />
      <Route path="/postnummer-sikkerhed" element={<PostalCodeSafety />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};