import React, { useState, useEffect } from 'react';
import { SimpleStripeProvider } from './SimpleStripeProvider';
import { SimplePaymentFlow } from './SimplePaymentFlow';
import { supabase } from '@/integrations/supabase/client';

interface PaymentContainerProps {
  quoteId: string;
  bookingId: string;
  onSuccess: () => void;
  onClose: () => void;
}

export const PaymentContainer: React.FC<PaymentContainerProps> = (props) => {
  const [clientSecret, setClientSecret] = useState<string>('');
  const [paymentData, setPaymentData] = useState<{ amount: number; locksmithId: string } | null>(null);
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    createPaymentIntent();
  }, [props.quoteId]);

  const createPaymentIntent = async () => {
    console.log('💳 PaymentContainer creating intent for quote:', props.quoteId);
    setLoading(true);
    setError('');
    
    try {
      const { data, error: invokeError } = await supabase.functions.invoke('create-customer-payment', {
        body: { 
          quoteId: props.quoteId, 
          email: 'pending@payment.com' // Placeholder email
        }
      });

      if (invokeError || !data?.client_secret) {
        console.error('💥 Payment intent creation failed:', invokeError);
        setError('Failed to initialize payment. Please try again.');
        setLoading(false);
        return;
      }

      console.log('✅ Payment intent created, rendering Stripe provider');
      setClientSecret(data.client_secret);
      setPaymentData({
        amount: data.amount || 0,
        locksmithId: data.locksmith_id || ''
      });
      setLoading(false);
    } catch (error) {
      console.error('💥 Unexpected error creating payment intent:', error);
      setError('An unexpected error occurred. Please try again.');
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Preparing payment...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="space-y-4">
          <div className="p-4 border border-destructive rounded-lg bg-destructive/10">
            <p className="text-destructive text-sm">{error}</p>
          </div>
          <button 
            onClick={createPaymentIntent}
            className="w-full py-2 px-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Initializing payment...</p>
        </div>
      </div>
    );
  }

  // Only render Stripe provider when we have clientSecret and payment data
  return (
    <SimpleStripeProvider clientSecret={clientSecret}>
      <SimplePaymentFlow 
        {...props} 
        clientSecret={clientSecret}
        amount={paymentData?.amount || 0}
        locksmithId={paymentData?.locksmithId || ''}
      />
    </SimpleStripeProvider>
  );
};