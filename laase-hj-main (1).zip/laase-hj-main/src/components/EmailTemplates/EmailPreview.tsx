import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { 
  Eye, 
  Send, 
  Smartphone, 
  Monitor, 
  Tablet,
  Code,
  Mail
} from 'lucide-react';

interface EmailTemplateContent {
  id: string;
  template_id: string;
  content_section: string;
  content_key: string;
  default_content: string;
  content_type: string;
  is_required: boolean;
}

interface EmailPreviewProps {
  templateId: string;
  content: EmailTemplateContent[];
}

interface EmailBrandSetting {
  id: string;
  logo_url?: string;
  primary_color: string;
  secondary_color: string;
  font_family: string;
  header_background_color: string;
  footer_background_color: string;
  border_color: string;
  company_name?: string;
  company_address?: string;
  contact_email?: string;
}

export const EmailPreview: React.FC<EmailPreviewProps> = ({
  templateId,
  content
}) => {
  const [brandSettings, setBrandSettings] = useState<EmailBrandSetting | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en');
  const [viewMode, setViewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [testEmail, setTestEmail] = useState<string>('');
  const [testVariables, setTestVariables] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);
  const { toast } = useToast();
  const { sendEmail } = useEmailTemplates();

  useEffect(() => {
    fetchBrandSettings();
  }, []);

  const fetchBrandSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('email_brand_settings')
        .select('*')
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }
      
      setBrandSettings(data || getDefaultBrandSettings());
    } catch (error) {
      console.error('Error fetching brand settings:', error);
      setBrandSettings(getDefaultBrandSettings());
    }
  };

  const getDefaultBrandSettings = (): EmailBrandSetting => ({
    id: '',
    logo_url: '/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png',
    primary_color: '#155e63',
    secondary_color: '#f9f8eb',
    font_family: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
    header_background_color: '#155e63',
    footer_background_color: '#f9f8eb',
    border_color: '#155e63',
    company_name: 'Lockily',
    contact_email: 'support@lockily.com'
  });

  const getContentBySection = (section: string): string => {
    const contentItem = content.find(c => c.content_section === section);
    return contentItem?.default_content || '';
  };

  const processVariables = (text: string): string => {
    let processed = text;
    Object.entries(testVariables).forEach(([key, value]) => {
      processed = processed.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    return processed;
  };

  const generateEmailHTML = (): string => {
    if (!brandSettings) return '';

    const subject = processVariables(getContentBySection('subject'));
    const preheader = processVariables(getContentBySection('preheader'));
    const body = processVariables(getContentBySection('body'));

    return `
<!DOCTYPE html>
<html lang="${selectedLanguage}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${subject}</title>
    <style>
        body {
            font-family: ${brandSettings.font_family};
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: white;
            border: 2px solid ${brandSettings.border_color};
            border-radius: 8px;
            overflow: hidden;
        }
        .email-header {
            background-color: ${brandSettings.header_background_color};
            color: white;
            text-align: center;
            padding: 20px;
        }
        .email-body {
            padding: 30px;
            line-height: 1.6;
        }
        .email-footer {
            background-color: ${brandSettings.footer_background_color};
            padding: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        .preheader {
            display: none;
            font-size: 1px;
            color: transparent;
            line-height: 1px;
            max-height: 0;
            max-width: 0;
            opacity: 0;
            overflow: hidden;
        }
        .button {
            display: inline-block;
            background-color: ${brandSettings.primary_color};
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            margin: 10px 0;
        }
        h1, h2, h3 {
            color: ${brandSettings.primary_color};
        }
        @media only screen and (max-width: 600px) {
            .email-container {
                width: 100% !important;
                border-radius: 0 !important;
            }
            .email-body {
                padding: 20px !important;
            }
        }
    </style>
</head>
<body>
    <div class="preheader">${preheader}</div>
    <div class="email-container">
        <div class="email-header">
            ${brandSettings.logo_url ? 
              `<img src="${brandSettings.logo_url}" alt="${brandSettings.company_name}" style="max-height: 50px; margin-bottom: 10px;">` : 
              `<h1 style="margin: 0; color: white;">${brandSettings.company_name || 'Lockily'}</h1>`
            }
        </div>
        <div class="email-body">
            ${body}
        </div>
        <div class="email-footer">
            <p><strong>${brandSettings.company_name || 'Lockily'}</strong></p>
            ${brandSettings.company_address ? `<p>${brandSettings.company_address}</p>` : ''}
            <p>${brandSettings.contact_email}</p>
            <p style="font-size: 12px; margin-top: 15px;">
                <a href="#" style="color: #666; text-decoration: none;">Unsubscribe</a> | 
                <a href="#" style="color: #666; text-decoration: none;">Privacy Policy</a>
            </p>
        </div>
    </div>
</body>
</html>`;
  };

  const sendTestEmail = async () => {
    if (!testEmail) {
      toast({
        title: 'Error',
        description: 'Please enter a test email address',
        variant: 'destructive',
      });
      return;
    }

    setSending(true);
    try {
      const success = await sendEmail({
        templateId,
        recipientEmail: testEmail,
        variables: {
          ...testVariables,
          customer_name: testVariables.customer_name || 'Test User',
          booking_date: testVariables.service_date || new Date().toLocaleDateString(),
          locksmith_name: testVariables.locksmith_name || 'Test Locksmith',
          test_mode: true
        },
        languageCode: selectedLanguage
      });

      if (success) {
        setTestEmail('');
        toast({
          title: 'Success',
          description: 'Test email sent successfully',
        });
      }
    } catch (error) {
      console.error('Error sending test email:', error);
      toast({
        title: 'Error',
        description: 'Failed to send test email',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const getViewModeStyles = () => {
    switch (viewMode) {
      case 'mobile':
        return { maxWidth: '375px', margin: '0 auto' };
      case 'tablet':
        return { maxWidth: '768px', margin: '0 auto' };
      default:
        return { maxWidth: '100%' };
    }
  };

  const languages = [
    { code: 'en', name: 'English', flag: 'GB' },
    { code: 'da', name: 'Danish', flag: 'DK' },
  ];


  // Sample variables for testing
  const sampleVariables = [
    'customer_name',
    'booking_id',
    'service_date',
    'locksmith_name',
    'price',
    'address'
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Email Preview & Test</h2>
          <p className="text-muted-foreground">
            Preview and test your email templates across different devices and languages
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === 'desktop' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('desktop')}
          >
            <Monitor className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === 'tablet' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('tablet')}
          >
            <Tablet className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === 'mobile' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('mobile')}
          >
            <Smartphone className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="preview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="preview">Visual Preview</TabsTrigger>
          <TabsTrigger value="code">HTML Source</TabsTrigger>
          <TabsTrigger value="test">Send Test</TabsTrigger>
        </TabsList>

        <TabsContent value="preview" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Controls */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Preview Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Language</Label>
                    <div className="grid grid-cols-1 gap-2 mt-2">
                      {languages.map((lang) => (
                        <Button
                          key={lang.code}
                          variant={selectedLanguage === lang.code ? 'default' : 'outline'}
                          size="sm"
                          className="justify-start"
                          onClick={() => setSelectedLanguage(lang.code)}
                        >
                          <CountryFlag code={lang.flag} size="sm" className="mr-2" />
                          {lang.name}
                        </Button>
                      ))}
                    </div>
                  </div>


                  <div>
                    <Label>Test Variables</Label>
                    <div className="space-y-2 mt-2">
                      {sampleVariables.map((variable) => (
                        <div key={variable} className="space-y-1">
                          <Label className="text-xs">{`{{${variable}}}`}</Label>
                          <Input
                            placeholder={`Test ${variable}`}
                            value={testVariables[variable] || ''}
                            onChange={(e) => setTestVariables(prev => ({
                              ...prev,
                              [variable]: e.target.value
                            }))}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Preview */}
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Eye className="w-5 h-5" />
                      Email Preview
                    </span>
                    <Badge variant="outline">
                      {viewMode.charAt(0).toUpperCase() + viewMode.slice(1)} View
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div 
                    className="border rounded-lg overflow-hidden bg-gray-100 p-4"
                    style={getViewModeStyles()}
                  >
                    <div 
                      dangerouslySetInnerHTML={{ __html: generateEmailHTML() }}
                      className="email-preview"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="code" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                HTML Source Code
              </CardTitle>
              <CardDescription>
                Raw HTML code for the email template
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-muted p-4 rounded-lg overflow-auto text-sm">
                <code>{generateEmailHTML()}</code>
              </pre>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="test" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="w-5 h-5" />
                Send Test Email
              </CardTitle>
              <CardDescription>
                Send a test email to verify how it looks in real email clients
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Test Email Address</Label>
                  <Input
                    type="email"
                    value={testEmail}
                    onChange={(e) => setTestEmail(e.target.value)}
                    placeholder="test@example.com"
                    className="mt-1"
                  />
                </div>
                <div className="flex items-end">
                  <Button onClick={sendTestEmail} disabled={sending} className="w-full">
                    <Mail className="w-4 h-4 mr-2" />
                    {sending ? 'Sending...' : 'Send Test Email'}
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">Test Email Details</h4>
                <div className="space-y-1 text-sm">
                  <p><strong>Subject:</strong> {processVariables(getContentBySection('subject'))}</p>
                  <p><strong>Language:</strong> {languages.find(l => l.code === selectedLanguage)?.name}</p>
                  <p><strong>Variables:</strong> {Object.keys(testVariables).length} defined</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};