import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  Plus, 
  Mail, 
  Edit2, 
  Save, 
  Eye, 
  Palette,
  Settings,
  Languages,
  Send,
  X,
  Check
} from 'lucide-react';
import { EmailTemplateEditor } from './EmailTemplateEditor';
import { EmailBrandSettings } from './EmailBrandSettings';
import { EmailPreview } from './EmailPreview';
import EmailTemplateSimpleEditor from './EmailTemplateSimpleEditor';

interface EmailTemplate {
  id: string;
  template_key: string;
  template_name: string;
  description?: string;
  category: string;
  is_active: boolean;
  requires_variables: any; // JSON type from database
}

interface EmailTemplateContent {
  id: string;
  template_id: string;
  content_section: string;
  content_key: string;
  default_content: string;
  content_type: string;
  is_required: boolean;
}

const EmailTemplateManager: React.FC = () => {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [templateContent, setTemplateContent] = useState<EmailTemplateContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [activeTab, setActiveTab] = useState('templates');
  const [newVariable, setNewVariable] = useState('');
  const [showRichEditor, setShowRichEditor] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchTemplates();
  }, []);

  useEffect(() => {
    if (selectedTemplate) {
      fetchTemplateContent(selectedTemplate);
    }
  }, [selectedTemplate]);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .order('template_name');

      if (error) throw error;
      setTemplates(data || []);
      
      if (data && data.length > 0 && !selectedTemplate) {
        setSelectedTemplate(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching email templates:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch email templates',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchTemplateContent = async (templateId: string) => {
    try {
      const { data, error } = await supabase
        .from('email_template_content')
        .select('*')
        .eq('template_id', templateId)
        .order('content_section');

      if (error) throw error;
      setTemplateContent(data || []);
    } catch (error) {
      console.error('Error fetching template content:', error);
    }
  };

  const saveTemplate = async (templateData: Partial<EmailTemplate>) => {
    if (!selectedTemplate) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('email_templates')
        .update(templateData)
        .eq('id', selectedTemplate);

      if (error) throw error;

      await fetchTemplates();
      setEditingTemplate(null);
      
      toast({
        title: 'Success',
        description: 'Template updated successfully',
      });
    } catch (error) {
      console.error('Error updating template:', error);
      toast({
        title: 'Error',
        description: 'Failed to update template',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const addVariable = async () => {
    if (!newVariable.trim() || !selectedTemplateData) return;
    
    const currentVariables = selectedTemplateData.requires_variables || [];
    if (currentVariables.includes(newVariable.trim())) {
      toast({
        title: 'Error',
        description: 'Variable already exists',
        variant: 'destructive',
      });
      return;
    }

    const updatedVariables = [...currentVariables, newVariable.trim()];
    await saveTemplate({ requires_variables: updatedVariables });
    setNewVariable('');
  };

  const removeVariable = async (variableToRemove: string) => {
    if (!selectedTemplateData) return;
    
    const currentVariables = selectedTemplateData.requires_variables || [];
    const updatedVariables = currentVariables.filter((v: string) => v !== variableToRemove);
    await saveTemplate({ requires_variables: updatedVariables });
  };

  const handleEditTemplate = () => {
    if (!selectedTemplateData) return;
    setShowRichEditor(true);
  };

  const handleSaveEdit = () => {
    if (!editingTemplate) return;
    saveTemplate({
      template_name: editingTemplate.template_name,
      description: editingTemplate.description,
      category: editingTemplate.category,
      is_active: editingTemplate.is_active
    });
  };

  const handleCancelEdit = () => {
    setEditingTemplate(null);
  };

  const handlePreview = () => {
    setActiveTab('preview');
  };

  const createNewTemplate = async () => {
    const templateName = prompt('Enter template name:');
    const templateKey = prompt('Enter template key (e.g., welcome_email):');
    
    if (!templateName || !templateKey) return;

    setSaving(true);
    try {
      const { data: templateData, error: templateError } = await supabase
        .from('email_templates')
        .insert({
          template_key: templateKey,
          template_name: templateName,
          description: '',
          category: 'general',
          is_active: true,
          requires_variables: []
        })
        .select()
        .single();

      if (templateError) throw templateError;

      // Create default content sections
      const defaultContent = [
        {
          template_id: templateData.id,
          content_section: 'subject',
          content_key: 'email_subject',
          default_content: `Welcome to Lockily`,
          content_type: 'text',
          is_required: true
        },
        {
          template_id: templateData.id,
          content_section: 'preheader',
          content_key: 'email_preheader',
          default_content: 'Your trusted locksmith service',
          content_type: 'text',
          is_required: false
        },
        {
          template_id: templateData.id,
          content_section: 'body',
          content_key: 'email_body',
          default_content: '<h1>Welcome!</h1><p>Thank you for choosing Lockily.</p>',
          content_type: 'html',
          is_required: true
        }
      ];

      const { error: contentError } = await supabase
        .from('email_template_content')
        .insert(defaultContent);

      if (contentError) throw contentError;

      await fetchTemplates();
      setSelectedTemplate(templateData.id);
      
      toast({
        title: 'Success',
        description: 'Email template created successfully',
      });
    } catch (error) {
      console.error('Error creating template:', error);
      toast({
        title: 'Error',
        description: 'Failed to create email template',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-lg">Loading email templates...</div>
      </div>
    );
  }

  const selectedTemplateData = templates.find(t => t.id === selectedTemplate);

  // Show rich editor when editing
  if (showRichEditor && selectedTemplateData) {
    return (
      <EmailTemplateSimpleEditor
        template={selectedTemplateData}
        content={templateContent}
        onClose={() => setShowRichEditor(false)}
        onSave={() => {
          fetchTemplates();
          fetchTemplateContent(selectedTemplate);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Email Templates</h2>
          <p className="text-muted-foreground">
            Manage email templates with full translation support
          </p>
        </div>
        <Button onClick={createNewTemplate} disabled={saving}>
          <Plus className="w-4 h-4 mr-2" />
          New Template
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="content">Content Editor</TabsTrigger>
          <TabsTrigger value="brand">Brand Settings</TabsTrigger>
          <TabsTrigger value="preview">Preview & Test</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Templates Sidebar */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Templates
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {templates.map((template) => (
                      <Button
                        key={template.id}
                        variant={selectedTemplate === template.id ? 'default' : 'ghost'}
                        className="w-full justify-start"
                        onClick={() => setSelectedTemplate(template.id)}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span>{template.template_name}</span>
                          <Badge 
                            variant={template.is_active ? 'default' : 'secondary'}
                            className="ml-2"
                          >
                            {template.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Template Details */}
            <div className="lg:col-span-3">
              {selectedTemplateData ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{editingTemplate ? editingTemplate.template_name : selectedTemplateData.template_name}</span>
                      <div className="flex gap-2">
                        {editingTemplate ? (
                          <>
                            <Button variant="outline" size="sm" onClick={handleSaveEdit} disabled={saving}>
                              <Check className="w-4 h-4 mr-2" />
                              Save
                            </Button>
                            <Button variant="outline" size="sm" onClick={handleCancelEdit}>
                              <X className="w-4 h-4 mr-2" />
                              Cancel
                            </Button>
                          </>
                        ) : (
                          <>
                            <Button variant="outline" size="sm" onClick={handleEditTemplate}>
                              <Edit2 className="w-4 h-4 mr-2" />
                              Edit Template
                            </Button>
                            <Button variant="outline" size="sm" onClick={handlePreview}>
                              <Eye className="w-4 h-4 mr-2" />
                              Preview
                            </Button>
                          </>
                        )}
                      </div>
                    </CardTitle>
                    <CardDescription>
                      Key: {selectedTemplateData.template_key} • Category: {editingTemplate ? editingTemplate.category : selectedTemplateData.category}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <Label>Template Name</Label>
                        <Input 
                          value={editingTemplate ? editingTemplate.template_name : selectedTemplateData.template_name}
                          onChange={(e) => editingTemplate && setEditingTemplate({...editingTemplate, template_name: e.target.value})}
                          disabled={!editingTemplate}
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label>Description</Label>
                        <Textarea 
                          value={editingTemplate ? (editingTemplate.description || '') : (selectedTemplateData.description || '')}
                          onChange={(e) => editingTemplate && setEditingTemplate({...editingTemplate, description: e.target.value})}
                          disabled={!editingTemplate}
                          placeholder="Template description..."
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label>Required Variables</Label>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {selectedTemplateData.requires_variables?.map((variable: string, index: number) => (
                            <Badge key={index} variant="outline" className="flex items-center gap-1">
                              {`{{${variable}}}`}
                              {editingTemplate && (
                                <button 
                                  onClick={() => removeVariable(variable)}
                                  className="ml-1 hover:text-destructive"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                              )}
                            </Badge>
                          ))}
                          {editingTemplate && (
                            <div className="flex items-center gap-2">
                              <Input
                                placeholder="variable_name"
                                value={newVariable}
                                onChange={(e) => setNewVariable(e.target.value)}
                                className="w-32"
                                onKeyPress={(e) => e.key === 'Enter' && addVariable()}
                              />
                              <Button variant="outline" size="sm" onClick={addVariable}>
                                <Plus className="w-3 h-3 mr-1" />
                                Add
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Category</Label>
                          <Input 
                            value={editingTemplate ? editingTemplate.category : selectedTemplateData.category}
                            onChange={(e) => editingTemplate && setEditingTemplate({...editingTemplate, category: e.target.value})}
                            disabled={!editingTemplate}
                            className="mt-1" 
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Label>Active</Label>
                          {editingTemplate ? (
                            <input
                              type="checkbox"
                              checked={editingTemplate.is_active}
                              onChange={(e) => setEditingTemplate({...editingTemplate, is_active: e.target.checked})}
                              className="ml-2"
                            />
                          ) : (
                            <Badge variant={selectedTemplateData.is_active ? 'default' : 'secondary'}>
                              {selectedTemplateData.is_active ? 'Yes' : 'No'}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="py-12">
                    <div className="text-center text-muted-foreground">
                      Select a template to view details
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="content" className="mt-6">
          {selectedTemplate ? (
            <EmailTemplateEditor 
              templateId={selectedTemplate}
              content={templateContent}
              onContentUpdate={fetchTemplateContent}
            />
          ) : (
            <Card>
              <CardContent className="py-12">
                <div className="text-center text-muted-foreground">
                  Select a template to edit content
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="brand" className="mt-6">
          <EmailBrandSettings />
        </TabsContent>

        <TabsContent value="preview" className="mt-6">
          {selectedTemplate ? (
            <EmailPreview 
              templateId={selectedTemplate}
              content={templateContent}
            />
          ) : (
            <Card>
              <CardContent className="py-12">
                <div className="text-center text-muted-foreground">
                  Select a template to preview
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EmailTemplateManager;