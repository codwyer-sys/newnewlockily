import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Palette, Upload } from 'lucide-react';

interface EmailBrandSetting {
  id: string;
  logo_url?: string;
  primary_color: string;
  secondary_color: string;
  font_family: string;
  header_background_color: string;
  footer_background_color: string;
  border_color: string;
  company_name?: string;
  company_address?: string;
  contact_email?: string;
  privacy_policy_url?: string;
  unsubscribe_url?: string;
}

export const EmailBrandSettings: React.FC = () => {
  const [settings, setSettings] = useState<EmailBrandSetting | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('email_brand_settings')
        .select('*')
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setSettings(data || null);
    } catch (error) {
      console.error('Error fetching brand settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch brand settings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async (updatedSettings: Partial<EmailBrandSetting>) => {
    setSaving(true);
    try {
      if (settings?.id) {
        const { error } = await supabase
          .from('email_brand_settings')
          .update(updatedSettings)
          .eq('id', settings.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('email_brand_settings')
          .insert(updatedSettings);

        if (error) throw error;
      }

      await fetchSettings();
      toast({
        title: 'Success',
        description: 'Brand settings saved successfully',
      });
    } catch (error) {
      console.error('Error saving brand settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to save brand settings',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const currentSettings = settings || {
    logo_url: '/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png',
    primary_color: '#155e63',
    secondary_color: '#f9f8eb',
    font_family: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
    header_background_color: '#155e63',
    footer_background_color: '#f9f8eb',
    border_color: '#155e63',
    company_name: 'Lockily',
    contact_email: 'support@lockily.com'
  } as EmailBrandSetting;

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-lg">Loading brand settings...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Email Brand Settings</h2>
        <p className="text-muted-foreground">
          Customize your global email branding and design
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5" />
            Brand Settings
          </CardTitle>
          <CardDescription>
            Configure the visual branding for all emails
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Logo */}
          <div>
            <Label>Logo URL</Label>
            <div className="flex gap-2 mt-1">
              <Input
                value={currentSettings.logo_url || ''}
                onChange={(e) => saveSettings({ 
                  ...currentSettings, 
                  logo_url: e.target.value 
                })}
                placeholder="https://..."
              />
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => saveSettings({ 
                  ...currentSettings, 
                  logo_url: currentSettings.logo_url 
                })}
              >
                <Upload className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Colors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Primary Color</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  type="color"
                  value={currentSettings.primary_color}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    primary_color: e.target.value 
                  })}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={currentSettings.primary_color}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    primary_color: e.target.value 
                  })}
                  placeholder="#155e63"
                />
              </div>
            </div>

            <div>
              <Label>Secondary Color</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  type="color"
                  value={currentSettings.secondary_color}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    secondary_color: e.target.value 
                  })}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={currentSettings.secondary_color}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    secondary_color: e.target.value 
                  })}
                  placeholder="#f9f8eb"
                />
              </div>
            </div>

            <div>
              <Label>Border Color</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  type="color"
                  value={currentSettings.border_color}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    border_color: e.target.value 
                  })}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={currentSettings.border_color}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    border_color: e.target.value 
                  })}
                  placeholder="#155e63"
                />
              </div>
            </div>

            <div>
              <Label>Font Family</Label>
              <Input
                value={currentSettings.font_family}
                onChange={(e) => saveSettings({ 
                  ...currentSettings, 
                  font_family: e.target.value 
                })}
                className="mt-1"
                placeholder="Inter, sans-serif"
              />
            </div>
          </div>

          {/* Company Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Company Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Company Name</Label>
                <Input
                  value={currentSettings.company_name || ''}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    company_name: e.target.value 
                  })}
                  placeholder="Lockily"
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Contact Email</Label>
                <Input
                  type="email"
                  value={currentSettings.contact_email || ''}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    contact_email: e.target.value 
                  })}
                  placeholder="support@lockily.com"
                  className="mt-1"
                />
              </div>

              <div className="md:col-span-2">
                <Label>Company Address</Label>
                <Textarea
                  value={currentSettings.company_address || ''}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    company_address: e.target.value 
                  })}
                  placeholder="Company address for footer"
                  className="mt-1"
                  rows={3}
                />
              </div>

              <div>
                <Label>Privacy Policy URL</Label>
                <Input
                  type="url"
                  value={currentSettings.privacy_policy_url || ''}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    privacy_policy_url: e.target.value 
                  })}
                  placeholder="https://..."
                  className="mt-1"
                />
              </div>

              <div>
                <Label>Unsubscribe URL</Label>
                <Input
                  type="url"
                  value={currentSettings.unsubscribe_url || ''}
                  onChange={(e) => saveSettings({ 
                    ...currentSettings, 
                    unsubscribe_url: e.target.value 
                  })}
                  placeholder="https://..."
                  className="mt-1"
                />
              </div>
            </div>
          </div>

          {/* Preview */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Preview</h3>
            <div 
              className="border rounded-lg overflow-hidden"
              style={{ 
                fontFamily: currentSettings.font_family,
                borderColor: currentSettings.border_color 
              }}
            >
              {/* Header */}
              <div 
                className="p-4 text-white text-center"
                style={{ backgroundColor: currentSettings.header_background_color }}
              >
                {currentSettings.logo_url && (
                  <img 
                    src={currentSettings.logo_url} 
                    alt={currentSettings.company_name} 
                    className="mx-auto mb-2 max-h-10"
                  />
                )}
                <h3 className="text-lg font-bold">
                  {currentSettings.company_name || 'Lockily'}
                </h3>
              </div>
              
              {/* Body */}
              <div className="p-6 bg-white">
                <h2 className="text-xl font-bold mb-4" style={{ color: currentSettings.primary_color }}>
                  Welcome Email Preview
                </h2>
                <p className="text-gray-700 mb-4">
                  This is how your emails will look with the current brand settings.
                </p>
                <button 
                  className="px-4 py-2 text-white rounded"
                  style={{ backgroundColor: currentSettings.primary_color }}
                >
                  Call to Action
                </button>
              </div>
              
              {/* Footer */}
              <div 
                className="p-4 text-center text-sm"
                style={{ 
                  backgroundColor: currentSettings.footer_background_color,
                  color: '#6b7280'
                }}
              >
                <p><strong>{currentSettings.company_name}</strong></p>
                {currentSettings.company_address && (
                  <p>{currentSettings.company_address}</p>
                )}
                <p>{currentSettings.contact_email}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};