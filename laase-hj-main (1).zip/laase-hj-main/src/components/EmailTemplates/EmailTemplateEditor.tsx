import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { Save, Languages, Type, Code, Sparkles } from 'lucide-react';
import QuillEditor from '@/components/QuillEditor';
import { useEmailTranslation } from '@/hooks/useEmailTranslation';

interface EmailTemplateContent {
  id: string;
  template_id: string;
  content_section: string;
  content_key: string;
  default_content: string;
  content_type: string;
  is_required: boolean;
}

interface EmailTemplateTranslation {
  id: string;
  template_content_id: string;
  language_code: string;
  market_code?: string;
  translated_content: string;
  ai_instruction?: string;
  translation_status: string;
}

interface EmailTemplateEditorProps {
  templateId: string;
  content: EmailTemplateContent[];
  onContentUpdate: (templateId: string) => void;
}

export const EmailTemplateEditor: React.FC<EmailTemplateEditorProps> = ({
  templateId,
  content,
  onContentUpdate
}) => {
  const [translations, setTranslations] = useState<EmailTemplateTranslation[]>([]);
  const [selectedContent, setSelectedContent] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const { translateEmailContent, translating } = useEmailTranslation();

  useEffect(() => {
    if (content.length > 0 && !selectedContent) {
      setSelectedContent(content[0].id);
    }
  }, [content]);

  useEffect(() => {
    if (selectedContent) {
      fetchTranslations(selectedContent);
    }
  }, [selectedContent]);

  const fetchTranslations = async (contentId: string) => {
    try {
      const { data, error } = await supabase
        .from('email_template_translations')
        .select('*')
        .eq('template_content_id', contentId)
        .order('language_code');

      if (error) throw error;
      setTranslations(data || []);
    } catch (error) {
      console.error('Error fetching translations:', error);
    }
  };

  const saveTranslation = async (translationId: string, value: string) => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('email_template_translations')
        .update({ 
          translated_content: value,
          translation_status: 'translated'
        })
        .eq('id', translationId);

      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Translation saved successfully',
      });
    } catch (error) {
      console.error('Error saving translation:', error);
      toast({
        title: 'Error',
        description: 'Failed to save translation',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const saveDefaultContent = async (contentId: string, value: string) => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('email_template_content')
        .update({ default_content: value })
        .eq('id', contentId);

      if (error) throw error;
      
      onContentUpdate(templateId);
      toast({
        title: 'Success',
        description: 'Content updated successfully',
      });
    } catch (error) {
      console.error('Error saving content:', error);
      toast({
        title: 'Error',
        description: 'Failed to save content',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const createTranslationIfNotExists = async (contentId: string, languageCode: string, marketCode?: string) => {
    try {
      const contentItem = content.find(c => c.id === contentId);
      if (!contentItem) return;

      const { error } = await supabase
        .from('email_template_translations')
        .insert({
          template_content_id: contentId,
          language_code: languageCode,
          market_code: marketCode,
          translated_content: contentItem.default_content,
          translation_status: 'pending'
        });

      if (error) throw error;
      await fetchTranslations(contentId);
    } catch (error) {
      console.error('Error creating translation:', error);
    }
  };

  const handleAITranslate = async (contentId: string, languageCode: string) => {
    await translateEmailContent({
      templateContentId: contentId,
      targetLanguage: languageCode,
      marketCode: undefined // Will use default market behavior
    });
    
    // Refresh translations after AI translation
    await fetchTranslations(contentId);
  };

  const selectedContentItem = content.find(c => c.id === selectedContent);

  const groupedTranslations = translations.reduce((acc, translation) => {
    const key = translation.market_code ? 
      `${translation.language_code}_${translation.market_code}` : 
      translation.language_code;
    acc[key] = translation;
    return acc;
  }, {} as Record<string, EmailTemplateTranslation>);

  // Default language options
  const languages = [
    { code: 'en', name: 'English', flag: 'GB' },
    { code: 'da', name: 'Danish', flag: 'DK' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Content Sections Sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Content Sections</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {content.map((item) => (
                  <Button
                    key={item.id}
                    variant={selectedContent === item.id ? 'default' : 'ghost'}
                    className="w-full justify-start"
                    onClick={() => setSelectedContent(item.id)}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className="capitalize">{item.content_section}</span>
                      <div className="flex items-center gap-1">
                        {item.content_type === 'html' ? (
                          <Code className="w-3 h-3" />
                        ) : (
                          <Type className="w-3 h-3" />
                        )}
                        {item.is_required && (
                          <Badge variant="secondary" className="text-xs">
                            Required
                          </Badge>
                        )}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Content Editor */}
        <div className="lg:col-span-3">
          {selectedContentItem ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="capitalize">{selectedContentItem.content_section}</span>
                  <Badge variant="outline">
                    {selectedContentItem.content_type.toUpperCase()}
                  </Badge>
                </CardTitle>
                <CardDescription>
                  Key: {selectedContentItem.content_key}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="default" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="default">Default Content</TabsTrigger>
                    <TabsTrigger value="translations" className="flex items-center gap-2">
                      <Languages className="w-4 h-4" />
                      Translations
                    </TabsTrigger>
                    <TabsTrigger value="settings">Settings</TabsTrigger>
                  </TabsList>

                  <TabsContent value="default" className="mt-6">
                    <div className="space-y-4">
                      <Label>Default Content (English)</Label>
                      {selectedContentItem.content_type === 'html' ? (
                        <QuillEditor
                          value={selectedContentItem.default_content}
                          onChange={(value) => saveDefaultContent(selectedContentItem.id, value)}
                          placeholder="Enter email content..."
                        />
                      ) : (
                        <ContentTextEditor
                          value={selectedContentItem.default_content}
                          onSave={(value) => saveDefaultContent(selectedContentItem.id, value)}
                          saving={saving}
                        />
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="translations" className="mt-6">
                    <div className="space-y-6">
                      {languages.map((lang) => {
                        const translation = groupedTranslations[lang.code];
                        
                        return (
                          <div key={lang.code} className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center gap-2">
                                <CountryFlag code={lang.flag} size="sm" />
                                <h3 className="font-medium">{lang.name}</h3>
                                <Badge variant={translation ? 'default' : 'secondary'}>
                                  {translation?.translation_status || 'Not translated'}
                                </Badge>
                              </div>
                              {!translation && (
                                <div className="flex gap-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => createTranslationIfNotExists(selectedContentItem.id, lang.code)}
                                  >
                                    Create Translation
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleAITranslate(selectedContentItem.id, lang.code)}
                                    disabled={translating}
                                  >
                                    <Sparkles className="w-3 h-3 mr-1" />
                                    {translating ? 'Translating...' : 'AI Translate'}
                                  </Button>
                                </div>
                              )}
                            </div>
                            
                            {translation && (
                              <div className="space-y-2">
                                {selectedContentItem.content_type === 'html' ? (
                                  <QuillEditor
                                    value={translation.translated_content}
                                    onChange={(value) => saveTranslation(translation.id, value)}
                                    placeholder={`Enter ${lang.name} content...`}
                                  />
                                ) : (
                                  <ContentTextEditor
                                    value={translation.translated_content}
                                    onSave={(value) => saveTranslation(translation.id, value)}
                                    saving={saving}
                                    placeholder={`Enter ${lang.name} content...`}
                                  />
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </TabsContent>

                  <TabsContent value="settings" className="mt-6">
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Content Key</Label>
                          <Input value={selectedContentItem.content_key} disabled />
                        </div>
                        <div>
                          <Label>Content Type</Label>
                          <Input value={selectedContentItem.content_type} disabled />
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Label>Required Content</Label>
                        <Badge variant={selectedContentItem.is_required ? 'destructive' : 'secondary'}>
                          {selectedContentItem.is_required ? 'Required' : 'Optional'}
                        </Badge>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12">
                <div className="text-center text-muted-foreground">
                  Select a content section to edit
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

interface ContentTextEditorProps {
  value: string;
  onSave: (value: string) => void;
  saving: boolean;
  placeholder?: string;
}

const ContentTextEditor: React.FC<ContentTextEditorProps> = ({
  value,
  onSave,
  saving,
  placeholder = "Enter content..."
}) => {
  const [editValue, setEditValue] = useState(value);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = () => {
    onSave(editValue);
    setIsEditing(false);
  };

  if (!isEditing) {
    return (
      <div className="space-y-2">
        <div className="p-3 bg-muted rounded-md min-h-[100px] cursor-pointer" onClick={() => setIsEditing(true)}>
          {value || <span className="text-muted-foreground">{placeholder}</span>}
        </div>
        <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
          Edit Content
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <textarea
        value={editValue}
        onChange={(e) => setEditValue(e.target.value)}
        placeholder={placeholder}
        rows={6}
        className="w-full p-3 border rounded-md resize-y"
      />
      <div className="flex gap-2">
        <Button onClick={handleSave} disabled={saving}>
          <Save className="w-4 h-4 mr-2" />
          {saving ? 'Saving...' : 'Save'}
        </Button>
        <Button variant="ghost" onClick={() => {
          setEditValue(value);
          setIsEditing(false);
        }}>
          Cancel
        </Button>
      </div>
    </div>
  );
};