import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Save, X, Plus, Copy } from 'lucide-react';

interface EmailTemplate {
  id: string;
  template_key: string;
  template_name: string;
  description?: string;
  category: string;
  is_active: boolean;
  requires_variables: any;
}

interface EmailTemplateContent {
  id: string;
  template_id: string;
  content_section: string;
  content_key: string;
  default_content: string;
  content_type: string;
  is_required: boolean;
}

interface EmailTemplateSimpleEditorProps {
  template: EmailTemplate;
  content: EmailTemplateContent[];
  onClose: () => void;
  onSave: () => void;
}

const EmailTemplateSimpleEditor: React.FC<EmailTemplateSimpleEditorProps> = ({
  template,
  content,
  onClose,
  onSave
}) => {
  const [saving, setSaving] = useState(false);
  const [variables, setVariables] = useState<string[]>(template.requires_variables || []);
  const [newVariable, setNewVariable] = useState('');
  const [sections, setSections] = useState<{[key: string]: string}>({});
  const { toast } = useToast();

  // Initialize sections from content
  useEffect(() => {
    const initialSections: {[key: string]: string} = {};
    content.forEach(item => {
      // Convert HTML bold tags to [b] format for display
      const displayContent = item.default_content
        .replace(/<strong>(.*?)<\/strong>/g, '[b]$1[/b]')
        .replace(/<b>(.*?)<\/b>/g, '[b]$1[/b]');
      initialSections[item.content_section] = displayContent;
    });
    setSections(initialSections);
  }, [content]);

  const addVariable = () => {
    if (!newVariable.trim()) return;
    
    if (variables.includes(newVariable.trim())) {
      toast({
        title: 'Error',
        description: 'Variable already exists',
        variant: 'destructive',
      });
      return;
    }

    setVariables([...variables, newVariable.trim()]);
    setNewVariable('');
  };

  const removeVariable = (variableToRemove: string) => {
    setVariables(variables.filter(v => v !== variableToRemove));
  };

  const insertVariable = (variable: string, sectionType: string) => {
    const variableText = `{{${variable}}}`;
    const currentContent = sections[sectionType] || '';
    setSections({
      ...sections,
      [sectionType]: currentContent + variableText
    });
  };

  const copyVariable = (variable: string) => {
    const variableText = `{{${variable}}}`;
    navigator.clipboard.writeText(variableText);
    toast({
      title: 'Variable Copied',
      description: `{{${variable}}} copied to clipboard`,
    });
  };

  const handleSectionChange = (sectionType: string, value: string) => {
    setSections({
      ...sections,
      [sectionType]: value
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Update template variables
      const { error: templateError } = await supabase
        .from('email_templates')
        .update({ requires_variables: variables })
        .eq('id', template.id);

      if (templateError) throw templateError;

      // Update each content section
      for (const [sectionType, sectionContent] of Object.entries(sections)) {
        const existingContent = content.find(c => c.content_section === sectionType);
        
        if (existingContent) {
          // Convert [b] format back to HTML for storage
          const htmlContent = sectionContent
            .replace(/\[b\](.*?)\[\/b\]/g, '<strong>$1</strong>');
          
          const { error } = await supabase
            .from('email_template_content')
            .update({ default_content: htmlContent })
            .eq('id', existingContent.id);
          
          if (error) throw error;
        }
      }

      toast({
        title: 'Success',
        description: 'Email template updated successfully',
      });
      
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving template:', error);
      toast({
        title: 'Error',
        description: 'Failed to save template',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col">
      {/* Header */}
      <div className="border-b p-4 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">Edit Template: {template.template_name}</h2>
          <p className="text-sm text-muted-foreground">
            Use [b]text[/b] for bold formatting and click variables to insert them
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save Template'}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - Variables */}
        <div className="w-80 border-r bg-muted/20 p-4 overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Template Variables</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Existing Variables */}
                <div>
                  <Label className="text-xs font-medium">Available Variables</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {variables.map((variable) => (
                      <Badge 
                        key={variable} 
                        variant="outline" 
                        className="cursor-pointer hover:bg-accent group"
                        onClick={() => copyVariable(variable)}
                      >
                        <span className="text-xs">{`{{${variable}}}`}</span>
                        <Copy className="w-3 h-3 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            removeVariable(variable);
                          }}
                          className="ml-1 hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Add New Variable */}
                <div>
                  <Label className="text-xs font-medium">Add Variable</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="variable_name"
                      value={newVariable}
                      onChange={(e) => setNewVariable(e.target.value)}
                      className="text-xs"
                      onKeyPress={(e) => e.key === 'Enter' && addVariable()}
                    />
                    <Button size="sm" onClick={addVariable}>
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {/* Quick Insert Buttons */}
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Quick Insert</Label>
                  <div className="grid grid-cols-3 gap-1">
                    {['subject', 'preheader', 'body'].map(section => (
                      <div key={section} className="space-y-1">
                        <Label className="text-xs capitalize">{section}</Label>
                        {variables.map((variable) => (
                          <Button
                            key={variable}
                            variant="outline"
                            size="sm"
                            className="w-full text-xs h-6"
                            onClick={() => insertVariable(variable, section)}
                          >
                            {variable}
                          </Button>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Instructions */}
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Use [b]text[/b] for bold formatting</p>
                  <p>• Click variables to copy them</p>
                  <p>• Use "Quick Insert" to add to specific sections</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Content Editor */}
        <div className="flex-1 p-4 overflow-y-auto">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Subject Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Email Subject</CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  value={sections.subject || ''}
                  onChange={(e) => handleSectionChange('subject', e.target.value)}
                  placeholder="Enter email subject..."
                  className="w-full"
                />
              </CardContent>
            </Card>

            {/* Preheader Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Email Preheader</CardTitle>
              </CardHeader>
              <CardContent>
                <Input
                  value={sections.preheader || ''}
                  onChange={(e) => handleSectionChange('preheader', e.target.value)}
                  placeholder="Enter email preheader..."
                  className="w-full"
                />
              </CardContent>
            </Card>

            {/* Body Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Email Body</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={sections.body || ''}
                  onChange={(e) => handleSectionChange('body', e.target.value)}
                  placeholder="Enter email body content... Use [b]text[/b] for bold formatting"
                  rows={12}
                  className="w-full"
                />
              </CardContent>
            </Card>

            {/* Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Live Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-4 bg-white">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium">Subject:</Label>
                      <div className="mt-1 font-medium">
                        {sections.subject?.replace(/\[b\](.*?)\[\/b\]/g, '<strong>$1</strong>') || 'No subject'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Preheader:</Label>
                      <div className="mt-1 text-sm text-muted-foreground">
                        {sections.preheader?.replace(/\[b\](.*?)\[\/b\]/g, '<strong>$1</strong>') || 'No preheader'}
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Body:</Label>
                      <div 
                        className="mt-1 prose prose-sm max-w-none"
                        dangerouslySetInnerHTML={{
                          __html: sections.body?.replace(/\[b\](.*?)\[\/b\]/g, '<strong>$1</strong>').replace(/\n/g, '<br>') || 'No body content'
                        }}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailTemplateSimpleEditor;
