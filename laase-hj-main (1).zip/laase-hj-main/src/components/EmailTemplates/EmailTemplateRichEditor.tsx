import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Save, X, Plus, Copy } from 'lucide-react';
import QuillEditor from '@/components/QuillEditor';

interface EmailTemplate {
  id: string;
  template_key: string;
  template_name: string;
  description?: string;
  category: string;
  is_active: boolean;
  requires_variables: any;
}

interface EmailTemplateContent {
  id: string;
  template_id: string;
  content_section: string;
  content_key: string;
  default_content: string;
  content_type: string;
  is_required: boolean;
}

interface EmailTemplateRichEditorProps {
  template: EmailTemplate;
  content: EmailTemplateContent[];
  onClose: () => void;
  onSave: () => void;
}

const EmailTemplateRichEditor: React.FC<EmailTemplateRichEditorProps> = ({
  template,
  content,
  onClose,
  onSave
}) => {
  const [saving, setSaving] = useState(false);
  const [variables, setVariables] = useState<string[]>(template.requires_variables || []);
  const [newVariable, setNewVariable] = useState('');
  const [unifiedContent, setUnifiedContent] = useState('');
  const [showDebug, setShowDebug] = useState(false);
  const { toast } = useToast();

  // Initialize unified content from sections
  useEffect(() => {
    const subjectContent = content.find(c => c.content_section === 'subject')?.default_content || '';
    const preheaderContent = content.find(c => c.content_section === 'preheader')?.default_content || '';
    const bodyContent = content.find(c => c.content_section === 'body')?.default_content || '';

    console.log('Loading content:', { subjectContent, preheaderContent, bodyContent });

    // Robust HTML structure with multiple identification methods
    const unified = `
<!-- SECTION:SUBJECT:START -->
<div data-section="subject" id="email-subject-section" class="email-section" style="border: 3px solid #4f46e5; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
  <h3 style="color: #333; margin: 0 0 8px 0; font-size: 16px; font-weight: 600; background: #f3f4f6; padding: 8px; border-radius: 4px;">
    <span style="font-size: 18px;">📧</span> EMAIL SUBJECT
  </h3>
  <div data-content="subject" id="email-subject-content" style="min-height: 40px; padding: 10px; border: 1px dashed #94a3b8; border-radius: 4px; background: #ffffff;">
    ${subjectContent}
  </div>
</div>
<!-- SECTION:SUBJECT:END -->

<!-- SECTION:PREHEADER:START -->
<div data-section="preheader" id="email-preheader-section" class="email-section" style="border: 3px solid #10b981; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
  <h3 style="color: #333; margin: 0 0 8px 0; font-size: 16px; font-weight: 600; background: #f3f4f6; padding: 8px; border-radius: 4px;">
    <span style="font-size: 18px;">👁️</span> EMAIL PREHEADER
  </h3>
  <div data-content="preheader" id="email-preheader-content" style="min-height: 40px; padding: 10px; border: 1px dashed #94a3b8; border-radius: 4px; background: #ffffff;">
    ${preheaderContent}
  </div>
</div>
<!-- SECTION:PREHEADER:END -->

<!-- SECTION:BODY:START -->
<div data-section="body" id="email-body-section" class="email-section" style="border: 3px solid #f59e0b; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
  <h3 style="color: #333; margin: 0 0 8px 0; font-size: 16px; font-weight: 600; background: #f3f4f6; padding: 8px; border-radius: 4px;">
    <span style="font-size: 18px;">📝</span> EMAIL BODY
  </h3>
  <div data-content="body" id="email-body-content" style="min-height: 100px; padding: 10px; border: 1px dashed #94a3b8; border-radius: 4px; background: #ffffff;">
    ${bodyContent}
  </div>
</div>
<!-- SECTION:BODY:END -->
    `.trim();

    setUnifiedContent(unified);
  }, [content]);

  const addVariable = () => {
    if (!newVariable.trim()) return;
    
    if (variables.includes(newVariable.trim())) {
      toast({
        title: 'Error',
        description: 'Variable already exists',
        variant: 'destructive',
      });
      return;
    }

    setVariables([...variables, newVariable.trim()]);
    setNewVariable('');
  };

  const removeVariable = (variableToRemove: string) => {
    setVariables(variables.filter(v => v !== variableToRemove));
  };

  const insertVariable = (variable: string) => {
    // This will be handled by the QuillEditor's focus and insert logic
    const variableText = `{{${variable}}}`;
    
    // For now, we'll let the user manually copy-paste
    navigator.clipboard.writeText(variableText);
    toast({
      title: 'Variable Copied',
      description: `{{${variable}}} copied to clipboard. Paste it in the editor.`,
    });
  };

  const parseContentSections = (htmlContent: string) => {
    const sections: { [key: string]: string } = {};
    console.log('Starting content parsing with multi-strategy approach');
    
    // Strategy 1: HTML Comment Markers
    try {
      console.log('Trying HTML comment parsing strategy');
      const subjectMatch = htmlContent.match(/<!-- SECTION:SUBJECT:START -->([\s\S]*?)<!-- SECTION:SUBJECT:END -->/);
      const preheaderMatch = htmlContent.match(/<!-- SECTION:PREHEADER:START -->([\s\S]*?)<!-- SECTION:PREHEADER:END -->/);
      const bodyMatch = htmlContent.match(/<!-- SECTION:BODY:START -->([\s\S]*?)<!-- SECTION:BODY:END -->/);
      
      if (subjectMatch) {
        const contentMatch = subjectMatch[1].match(/data-content="subject"[^>]*>([\s\S]*?)<\/div>/);
        if (contentMatch) sections.subject = contentMatch[1].trim();
      }
      
      if (preheaderMatch) {
        const contentMatch = preheaderMatch[1].match(/data-content="preheader"[^>]*>([\s\S]*?)<\/div>/);
        if (contentMatch) sections.preheader = contentMatch[1].trim();
      }
      
      if (bodyMatch) {
        const contentMatch = bodyMatch[1].match(/data-content="body"[^>]*>([\s\S]*?)<\/div>/);
        if (contentMatch) sections.body = contentMatch[1].trim();
      }
    } catch (error) {
      console.error('HTML comment parsing strategy failed:', error);
    }
    
    // Strategy 2: Data Attributes
    if (!sections.subject || !sections.preheader || !sections.body) {
      try {
        console.log('Trying data attribute parsing strategy');
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlContent, 'text/html');
        
        const subjectContent = doc.querySelector('[data-content="subject"]');
        const preheaderContent = doc.querySelector('[data-content="preheader"]');
        const bodyContent = doc.querySelector('[data-content="body"]');
        
        if (subjectContent && !sections.subject) sections.subject = subjectContent.innerHTML.trim();
        if (preheaderContent && !sections.preheader) sections.preheader = preheaderContent.innerHTML.trim();
        if (bodyContent && !sections.body) sections.body = bodyContent.innerHTML.trim();
      } catch (error) {
        console.error('Data attribute parsing strategy failed:', error);
      }
    }
    
    // Strategy 3: Visual Markers
    if (!sections.subject || !sections.preheader || !sections.body) {
      try {
        console.log('Trying visual marker parsing strategy');
        const subjectMatch = htmlContent.match(/📧 EMAIL SUBJECT[\s\S]*?<div[^>]*>([\s\S]*?)<\/div>/);
        const preheaderMatch = htmlContent.match(/👁️ EMAIL PREHEADER[\s\S]*?<div[^>]*>([\s\S]*?)<\/div>/);
        const bodyMatch = htmlContent.match(/📝 EMAIL BODY[\s\S]*?<div[^>]*>([\s\S]*?)<\/div>/);
        
        if (subjectMatch && !sections.subject) sections.subject = subjectMatch[1].trim();
        if (preheaderMatch && !sections.preheader) sections.preheader = preheaderMatch[1].trim();
        if (bodyMatch && !sections.body) sections.body = bodyMatch[1].trim();
      } catch (error) {
        console.error('Visual marker parsing strategy failed:', error);
      }
    }
    
    // Strategy 4: Regex-based content extraction (last resort)
    if (!sections.subject || !sections.preheader || !sections.body) {
      try {
        console.log('Trying regex-based content extraction (last resort)');
        const lines = htmlContent.split('\n');
        let currentSection = null;
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          
          if (line.includes('EMAIL SUBJECT') || line.includes('📧')) {
            currentSection = 'subject';
            continue;
          } else if (line.includes('EMAIL PREHEADER') || line.includes('👁️')) {
            currentSection = 'preheader';
            continue;
          } else if (line.includes('EMAIL BODY') || line.includes('📝')) {
            currentSection = 'body';
            continue;
          }
          
          if (currentSection && !sections[currentSection] && line.trim()) {
            const contentMatch = line.match(/<div[^>]*>(.*?)<\/div>/);
            if (contentMatch) {
              sections[currentSection] = contentMatch[1].trim();
            }
          }
        }
      } catch (error) {
        console.error('Regex-based content extraction failed:', error);
      }
    }
    
    console.log('Final parsed sections:', sections);
    return sections;
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      console.log('Saving template with unified content:', unifiedContent);
      
      // Update template variables
      const { error: templateError } = await supabase
        .from('email_templates')
        .update({ requires_variables: variables })
        .eq('id', template.id);

      if (templateError) throw templateError;

      // Parse content sections from unified editor
      const sections = parseContentSections(unifiedContent);
      console.log('Sections to save:', sections);

      // Verify we have all required sections
      const requiredSections = ['subject', 'preheader', 'body'];
      const missingSections = requiredSections.filter(section => !sections[section]);
      
      if (missingSections.length > 0) {
        console.warn('Missing sections:', missingSections);
        
        // Use fallback values from original content if sections are missing
        missingSections.forEach(section => {
          const originalContent = content.find(c => c.content_section === section);
          if (originalContent) {
            console.log(`Using original content for missing section: ${section}`);
            sections[section] = originalContent.default_content;
          }
        });
      }

      // Update each content section
      for (const [sectionType, sectionContent] of Object.entries(sections)) {
        const existingContent = content.find(c => c.content_section === sectionType);
        
        if (existingContent) {
          console.log(`Updating ${sectionType} with content:`, sectionContent);
          const { error } = await supabase
            .from('email_template_content')
            .update({ default_content: sectionContent })
            .eq('id', existingContent.id);
          
          if (error) throw error;
        } else {
          console.warn(`No existing content found for section: ${sectionType}`);
        }
      }

      toast({
        title: 'Success',
        description: 'Email template updated successfully',
      });
      
      onSave();
      onClose();
    } catch (error) {
      console.error('Error saving template:', error);
      toast({
        title: 'Error',
        description: 'Failed to save template',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col">
      {/* Header */}
      <div className="border-b p-4 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold">Edit Template: {template.template_name}</h2>
          <p className="text-sm text-muted-foreground">Use the variables panel to insert dynamic content</p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => setShowDebug(!showDebug)}>
            {showDebug ? 'Hide Debug' : 'Show Debug'}
          </Button>
          <Button variant="outline" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save Template'}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - Variables */}
        <div className="w-80 border-r bg-muted/20 p-4 overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Template Variables</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Existing Variables */}
                <div>
                  <Label className="text-xs font-medium">Available Variables</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {variables.map((variable) => (
                      <Badge 
                        key={variable} 
                        variant="outline" 
                        className="cursor-pointer hover:bg-accent group"
                        onClick={() => insertVariable(variable)}
                      >
                        <span className="text-xs">{`{{${variable}}}`}</span>
                        <Copy className="w-3 h-3 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            removeVariable(variable);
                          }}
                          className="ml-1 hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Add New Variable */}
                <div>
                  <Label className="text-xs font-medium">Add Variable</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      placeholder="variable_name"
                      value={newVariable}
                      onChange={(e) => setNewVariable(e.target.value)}
                      className="text-xs"
                      onKeyPress={(e) => e.key === 'Enter' && addVariable()}
                    />
                    <Button size="sm" onClick={addVariable}>
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {/* Button Helper */}
                <div className="space-y-2">
                  <Label className="text-xs font-medium">Quick Buttons</Label>
                  <div className="space-y-2">
                    <Badge 
                      variant="outline" 
                      className="cursor-pointer hover:bg-accent w-full justify-start"
                      onClick={() => navigator.clipboard.writeText('{{button:Bekræft Email:{{confirmemail_link}}}}')}
                    >
                      <span className="text-xs">Confirm Email Button</span>
                    </Badge>
                    <Badge 
                      variant="outline" 
                      className="cursor-pointer hover:bg-accent w-full justify-start"
                      onClick={() => navigator.clipboard.writeText('{{button:Besøg Platform:https://lockily.com}}')}
                    >
                      <span className="text-xs">Visit Platform Button</span>
                    </Badge>
                  </div>
                </div>

                  {/* Instructions */}
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Click variables to copy them</p>
                  <p>• Paste in editor with Ctrl+V</p>
                  <p>• Variables use {"{{name}}"} format</p>
                  <p>• Buttons use {"{{button:Text:URL}}"} format</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Content Editor */}
        <div className="flex-1 p-4 overflow-hidden">
          <Card className="h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-sm">Email Content</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-hidden">
              <QuillEditor
                value={unifiedContent}
                onChange={setUnifiedContent}
                placeholder="Start writing your email content..."
                className="h-full"
              />
              
              {/* Debug Panel */}
              {showDebug && (
                <div className="mt-4 p-4 bg-gray-100 rounded border text-xs overflow-auto max-h-60">
                  <h4 className="font-bold mb-2">Debug Information</h4>
                  <div className="space-y-2">
                    <div>
                      <div className="font-semibold">Current Content Structure:</div>
                      <pre>{JSON.stringify(parseContentSections(unifiedContent), null, 2)}</pre>
                    </div>
                    <div>
                      <div className="font-semibold">Raw HTML (truncated):</div>
                      <pre>{unifiedContent.substring(0, 500)}...</pre>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default EmailTemplateRichEditor;
