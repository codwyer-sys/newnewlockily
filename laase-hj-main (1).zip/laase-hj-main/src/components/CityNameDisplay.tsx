import React from 'react';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { Badge } from '@/components/ui/badge';
import { Globe, Sparkles } from 'lucide-react';
import { getDisplayName } from '@/utils/locationTranslations';

interface CityNameDisplayProps {
  englishName: string;
  localName?: string | null;
  marketCode: string;
  translationSource?: 'wikidata' | 'manual' | 'ai_generated' | 'mapbox_native';
  showSourceBadge?: boolean;
  showFlag?: boolean;
  className?: string;
}

export const CityNameDisplay: React.FC<CityNameDisplayProps> = ({
  englishName,
  localName,
  marketCode,
  translationSource,
  showSourceBadge = false,
  showFlag = true,
  className = '',
}) => {
  const hasLocalName = localName && localName !== englishName;
  
  const getSourceIcon = () => {
    switch (translationSource) {
      case 'mapbox_native':
        return <Globe className="h-3 w-3" />;
      case 'ai_generated':
        return <Sparkles className="h-3 w-3" />;
      default:
        return null;
    }
  };

  const getSourceLabel = () => {
    switch (translationSource) {
      case 'mapbox_native':
        return 'Mapbox';
      case 'ai_generated':
        return 'AI';
      case 'wikidata':
        return 'Wikidata';
      case 'manual':
        return 'Manual';
      default:
        return null;
    }
  };

  return (
    <div className={`flex flex-col ${className}`}>
      <div className="flex items-center gap-2">
        {showFlag && <CountryFlag code={marketCode} size="sm" />}
        
        {hasLocalName ? (
          <div className="flex flex-col">
            <span className="font-semibold">{englishName}</span>
            <span className="text-sm text-muted-foreground ml-2">{localName}</span>
          </div>
        ) : (
          <span className="font-semibold">{englishName}</span>
        )}
        
        {showSourceBadge && translationSource && hasLocalName && (
          <Badge variant="outline" className="text-xs">
            {getSourceIcon()}
            <span className="ml-1">{getSourceLabel()}</span>
          </Badge>
        )}
      </div>
    </div>
  );
};