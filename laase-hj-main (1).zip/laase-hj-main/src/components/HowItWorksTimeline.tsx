import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent } from '@/components/ui/card';
import { FileText, Search, Clock } from 'lucide-react';

const HowItWorksTimeline = () => {
  const { t } = useLanguage();

  const steps = [
    {
      icon: FileText,
      title: t('home.how_it_works.step_1_title'),
      description: t('home.how_it_works.step_1_desc'),
      number: '01',
      color: 'primary',
      isHighlighted: false
    },
    {
      icon: Search,
      title: t('home.how_it_works.step_2_title'),
      description: t('home.how_it_works.step_2_desc'),
      number: '02',
      color: 'primary',
      isHighlighted: true
    },
    {
      icon: Clock,
      title: t('home.how_it_works.step_3_title'),
      description: t('home.how_it_works.step_3_desc'),
      number: '03',
      color: 'primary',
      isHighlighted: false
    }
  ];

  return (
    <section className="py-24 section-soft relative overflow-hidden">
      <div className="container mx-auto px-4">
        {/* Enhanced Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          viewport={{ once: true }}
          className="text-center mb-16 max-w-3xl mx-auto"
        >
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary text-white text-sm font-semibold mb-6">
            {t('home.how_it_works.subtitle')}
          </div>
          <h2 className="text-heading-lg font-headline font-bold text-foreground mb-6">
            {t('home.how_it_works.title')}
          </h2>
          <p className="text-body-lg text-muted-foreground max-w-2xl mx-auto">
            Få professionel låsehjælp på rekordtid med vores enkle proces
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Desktop Timeline Line - Positioned to accommodate larger middle box */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-0.5 bg-border mx-[10%]">
            <motion.div
              initial={{ width: '0%' }}
              whileInView={{ width: '100%' }}
              transition={{ duration: 1.5, delay: 0.5, ease: "easeInOut" }}
              viewport={{ once: true }}
              className="h-full bg-primary"
            />
          </div>

          {/* Mobile Timeline Line */}
          <div className="lg:hidden absolute left-8 top-0 bottom-0 w-0.5 bg-border">
            <motion.div
              initial={{ height: '0%' }}
              whileInView={{ height: '100%' }}
              transition={{ duration: 1.5, delay: 0.5, ease: "easeInOut" }}
              viewport={{ once: true }}
              className="w-full bg-primary"
            />
          </div>

          {/* Steps - Asymmetric Grid Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.5fr_1fr] gap-8 lg:gap-16 lg:items-start">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: step.isHighlighted ? 40 : 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: step.isHighlighted ? 0.8 : 0.6, 
                  delay: index * 0.2 + 0.3,
                  ease: [0.16, 1, 0.3, 1] 
                }}
                viewport={{ once: true }}
                className={`
                  relative h-full
                  ${step.isHighlighted ? 'lg:transform lg:scale-105' : ''}
                `}
                whileHover={step.isHighlighted ? { scale: 1.02 } : { scale: 1.01 }}
              >
                <Card className={`
                  group transition-all duration-500 border-2 h-full flex flex-col
                  ${step.isHighlighted 
                    ? `bg-primary text-primary-foreground border-primary hover:border-primary/80 shadow-2xl hover:shadow-primary/20 lg:py-8` 
                    : `bg-card hover:border-primary/30 hover:shadow-xl hover:shadow-primary/10`
                  }
                `}>
                  {/* Step Number Circle - Larger for middle box */}
                  <div className={`
                    absolute -top-6 left-6 lg:left-1/2 lg:transform lg:-translate-x-1/2 rounded-full flex items-center justify-center font-bold shadow-lg transition-all duration-300
                    ${step.isHighlighted 
                      ? 'w-16 h-16 text-lg bg-white text-primary' 
                      : 'w-12 h-12 text-sm bg-primary text-primary-foreground'
                    }
                  `}>
                    {step.number}
                  </div>

                  <CardContent className={`
                    pt-10 pb-6 flex-1 flex flex-col
                    ${step.isHighlighted ? 'px-8 lg:px-10' : 'px-6'}
                  `}>
                    {/* Icon - Larger for middle box */}
                    <div className="flex justify-center mb-6">
                      <div className={`
                        rounded-full flex items-center justify-center transition-all duration-300
                        ${step.isHighlighted 
                          ? 'w-24 h-24 lg:w-28 lg:h-28 bg-white/20 group-hover:bg-white/30 group-hover:scale-110' 
                          : 'w-16 h-16 bg-primary/10 group-hover:bg-primary/20 group-hover:scale-105'
                        }
                      `}>
                        <step.icon className={`
                          transition-all duration-300
                          ${step.isHighlighted 
                            ? 'w-12 h-12 lg:w-14 lg:h-14 text-white' 
                            : 'w-8 h-8 text-primary'
                          }
                        `} />
                      </div>
                    </div>

                    {/* Content - Enhanced for middle box */}
                    <div className="text-center flex-1 flex flex-col">
                      <h3 className={`
                        font-semibold mb-4 transition-colors duration-300
                        ${step.isHighlighted 
                          ? 'text-2xl lg:text-3xl text-white group-hover:text-white/90' 
                          : 'text-xl group-hover:text-primary'
                        }
                      `}>
                        {step.title}
                      </h3>
                      <p className={`
                        leading-relaxed flex-1
                        ${step.isHighlighted 
                          ? 'text-lg text-white/90' 
                          : 'text-muted-foreground'
                        }
                      `}>
                        {step.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksTimeline;