
import React from 'react';
import { Camera } from "lucide-react";
import { Label } from "@/components/ui/label";

const ImageUploadPrompt: React.FC = () => {
  return (
    <div className="glass rounded-apple-xlarge p-apple-6">
      <div className="flex items-center gap-apple-3 mb-apple-4">
        <Camera className="w-5 h-5 text-system-blue" />
        <Label className="text-black font-semibold text-apple-headline text-left block">
          Upload billede af problemet (anbefalet)
        </Label>
      </div>
      <div className="glass-thick rounded-apple-large p-apple-6 text-center hover:bg-system-blue/5 transition-all duration-200 cursor-pointer border-2 border-dashed border-gray-300">
        <div className="text-gray-600">
          <div className="text-4xl mb-apple-2">📷</div>
          <p className="text-apple-body font-apple">Klik for at uploade billede</p>
          <p className="text-apple-footnote mt-apple-1">Hjælper låsesmeden med at forberede sig</p>
        </div>
      </div>
    </div>
  );
};

export default ImageUploadPrompt;
