
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, CheckCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface EmailConfirmationWaitingProps {
  email: string;
  onConfirmed: () => void;
}

const EmailConfirmationWaiting: React.FC<EmailConfirmationWaitingProps> = ({ email, onConfirmed }) => {
  const [isResending, setIsResending] = useState(false);

  useEffect(() => {
    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('Auth event:', event, 'Session:', session);
        if (event === 'SIGNED_IN' && session?.user?.email_confirmed_at) {
          console.log('User confirmed email, calling onConfirmed');
          onConfirmed();
        }
      }
    );

    return () => subscription.unsubscribe();
  }, [onConfirmed]);

  const handleResendEmail = async () => {
    setIsResending(true);
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email,
        options: {
          emailRedirectTo: `${window.location.origin}/`
        }
      });

      if (error) throw error;
      toast.success('Bekræftelses-email sendt igen');
    } catch (error: any) {
      console.error('Error resending email:', error);
      toast.error('Kunne ikke sende email igen. Prøv venligst senere.');
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 flex items-center justify-center">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
            <Mail className="w-8 h-8 text-blue-600" />
          </div>
          <CardTitle className="text-xl">Bekræft din e-mail</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">
            Vi har sendt en bekræftelses-email til:
          </p>
          <p className="font-semibold text-gray-900">{email}</p>
          <p className="text-sm text-gray-500">
            Klik på linket i emailen for at bekræfte din konto. Siden vil automatisk opdateres når du har bekræftet.
          </p>
          
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-500 mt-6">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Venter på bekræftelse...</span>
          </div>

          <div className="pt-4 border-t">
            <p className="text-sm text-gray-500 mb-3">
              Har du ikke modtaget emailen?
            </p>
            <Button 
              variant="outline" 
              onClick={handleResendEmail}
              disabled={isResending}
              className="w-full"
            >
              {isResending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sender...
                </>
              ) : (
                'Send email igen'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default EmailConfirmationWaiting;
