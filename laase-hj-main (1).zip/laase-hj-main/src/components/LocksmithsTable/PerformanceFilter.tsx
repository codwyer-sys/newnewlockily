import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ChevronDown, TrendingUp } from 'lucide-react';
import { LocksmithFilters } from '@/hooks/useLocksmithsTable';

interface PerformanceFilterProps {
  filters: LocksmithFilters;
  onFiltersChange: (filters: Partial<LocksmithFilters>) => void;
}

export const PerformanceFilter: React.FC<PerformanceFilterProps> = ({
  filters,
  onFiltersChange
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const activeFiltersCount = 
    (filters.minJobs !== null || filters.maxJobs !== null ? 1 : 0) +
    (filters.emergencyAvailable !== null ? 1 : 0);

  const getDisplayText = () => {
    if (activeFiltersCount === 0) return 'Performance';
    return `Performance (${activeFiltersCount})`;
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className="justify-between h-9 bg-background hover:bg-muted/50"
        >
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            <span>{getDisplayText()}</span>
          </div>
          <ChevronDown className="h-4 w-4 shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4 bg-background border shadow-lg z-50" align="start">
        <div className="space-y-4">
          {/* Jobs Range */}
          <div>
            <h4 className="font-medium text-sm mb-3">Completed Jobs Range</h4>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                placeholder="Min"
                value={filters.minJobs?.toString() || ''}
                onChange={(e) => onFiltersChange({ 
                  minJobs: e.target.value ? parseInt(e.target.value) : null 
                })}
                className="w-20"
                min="0"
              />
              <span className="text-muted-foreground text-sm">to</span>
              <Input
                type="number"
                placeholder="Max"
                value={filters.maxJobs?.toString() || ''}
                onChange={(e) => onFiltersChange({ 
                  maxJobs: e.target.value ? parseInt(e.target.value) : null 
                })}
                className="w-20"
                min="0"
              />
            </div>
          </div>

          {/* Emergency Available */}
          <div>
            <h4 className="font-medium text-sm mb-3">Emergency Service</h4>
            <div className="flex gap-2">
              <Button
                variant={filters.emergencyAvailable === true ? "default" : "outline"}
                size="sm"
                onClick={() => onFiltersChange({ 
                  emergencyAvailable: filters.emergencyAvailable === true ? null : true 
                })}
              >
                Available
              </Button>
              <Button
                variant={filters.emergencyAvailable === false ? "default" : "outline"}
                size="sm"
                onClick={() => onFiltersChange({ 
                  emergencyAvailable: filters.emergencyAvailable === false ? null : false 
                })}
              >
                Not Available
              </Button>
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};