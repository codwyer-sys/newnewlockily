import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, X, MapPin } from 'lucide-react';
import { MultiSelectDropdown } from './MultiSelectDropdown';
import { LocksmithFilters } from '@/hooks/useLocksmithsTable';
import { CountryFlag } from '@/components/ui/CountryFlag';

interface LocationFilterProps {
  filters: LocksmithFilters;
  onFiltersChange: (filters: Partial<LocksmithFilters>) => void;
}

const markets = [
  { value: 'DK', label: 'Denmark' },
  { value: 'DE', label: 'Germany' },
  { value: 'GB', label: 'United Kingdom' },
  { value: 'US', label: 'United States' },
  { value: 'IE', label: 'Ireland' },
  { value: 'FR', label: 'France' },
  { value: 'ES', label: 'Spain' },
  { value: 'SE', label: 'Sweden' },
  { value: 'NO', label: 'Norway' },
  { value: 'PL', label: 'Poland' },
  { value: 'CA', label: 'Canada' },
  { value: 'PT', label: 'Portugal' },
  { value: 'IT', label: 'Italy' },
  { value: 'FI', label: 'Finland' },
  { value: 'CZ', label: 'Czech Republic' }
];

export const LocationFilter: React.FC<LocationFilterProps> = ({
  filters,
  onFiltersChange
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [cityInput, setCityInput] = useState('');

  const addCity = () => {
    if (cityInput.trim() && !filters.cities.includes(cityInput.trim())) {
      onFiltersChange({ 
        cities: [...filters.cities, cityInput.trim()] 
      });
      setCityInput('');
    }
  };

  const removeCity = (city: string) => {
    onFiltersChange({
      cities: filters.cities.filter(c => c !== city)
    });
  };

  const activeFiltersCount = filters.markets.length + filters.cities.length;

  const getDisplayText = () => {
    if (activeFiltersCount === 0) return 'Location';
    return `Location (${activeFiltersCount})`;
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className="justify-between h-9 bg-background hover:bg-muted/50"
        >
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span>{getDisplayText()}</span>
          </div>
          <ChevronDown className="h-4 w-4 shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4 bg-background border shadow-lg z-50" align="start">
        <div className="space-y-4">
          <div>
            <h4 className="font-medium text-sm mb-2">Markets</h4>
            <MultiSelectDropdown
              options={markets}
              selectedValues={filters.markets}
              onSelectionChange={(values) => onFiltersChange({ markets: values })}
              placeholder="Select markets"
              label=""
            />
          </div>

          <div>
            <h4 className="font-medium text-sm mb-2">Cities</h4>
            <div className="flex gap-2 mb-2">
              <Input
                placeholder="Add city..."
                value={cityInput}
                onChange={(e) => setCityInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addCity()}
                className="flex-1"
              />
              <Button 
                onClick={addCity} 
                disabled={!cityInput.trim()}
                size="sm"
              >
                Add
              </Button>
            </div>
            {filters.cities.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {filters.cities.map(city => (
                  <Badge key={city} variant="secondary" className="flex items-center gap-1">
                    {city}
                    <X 
                      className="h-3 w-3 cursor-pointer" 
                      onClick={() => removeCity(city)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};