import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Download, X } from 'lucide-react';
import { LocksmithFilters } from '@/hooks/useLocksmithsTable';
import { LocationFilter } from './LocationFilter';
import { PerformanceFilter } from './PerformanceFilter';
import { MultiSelectDropdown } from './MultiSelectDropdown';

interface InlineFiltersProps {
  filters: LocksmithFilters;
  onFiltersChange: (filters: Partial<LocksmithFilters>) => void;
  onClearFilters: () => void;
  onExport: () => void;
  totalCount: number;
}

const statuses = [
  { value: 'pending', label: 'Onboarding' },
  { value: 'active', label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'suspended', label: 'Suspended' }
];

export const InlineFilters: React.FC<InlineFiltersProps> = ({
  filters,
  onFiltersChange,
  onClearFilters,
  onExport,
  totalCount
}) => {
  const activeFiltersCount = 
    (filters.search ? 1 : 0) +
    filters.markets.length +
    filters.statuses.length +
    filters.cities.length +
    (filters.minJobs !== null || filters.maxJobs !== null ? 1 : 0) +
    (filters.emergencyAvailable !== null ? 1 : 0);

  return (
    <div className="space-y-4">
      {/* Main filter row */}
      <div className="flex items-center gap-4 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 min-w-[300px]">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search by name, company, or city..."
            value={filters.search}
            onChange={(e) => onFiltersChange({ search: e.target.value })}
            className="pl-10 h-9"
          />
        </div>

        {/* Location Filter */}
        <LocationFilter
          filters={filters}
          onFiltersChange={onFiltersChange}
        />

        {/* Status Filter */}
        <MultiSelectDropdown
          options={statuses}
          selectedValues={filters.statuses}
          onSelectionChange={(values) => onFiltersChange({ statuses: values })}
          placeholder="Status"
          label=""
        />

        {/* Performance Filter */}
        <PerformanceFilter
          filters={filters}
          onFiltersChange={onFiltersChange}
        />

        {/* Actions */}
        <div className="flex items-center gap-2">
          {activeFiltersCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              className="flex items-center gap-2 h-9"
            >
              <X className="h-4 w-4" />
              Clear ({activeFiltersCount})
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={onExport}
            className="flex items-center gap-2 h-9"
          >
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Results count */}
      <div className="text-sm text-muted-foreground">
        {totalCount} result{totalCount !== 1 ? 's' : ''} found
      </div>
    </div>
  );
};