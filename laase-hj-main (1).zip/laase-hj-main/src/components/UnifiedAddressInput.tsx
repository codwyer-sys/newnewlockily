import React, { useState, useRef } from 'react';
import { GlassInput } from "@/components/ui/glass-input";
import { GlassButton } from "@/components/ui/glass-button";
import { GlassCard } from "@/components/ui/glass-card";
import { MapPin } from "lucide-react";
import { useMarket } from '@/contexts/MarketContext';
import { useMarketAddressSearch } from '@/hooks/useMarketAddressSearch';
import { useGeolocation } from "@/hooks/useGeolocation";
import { AddressSearchResult } from '@/services/address/types';

interface UnifiedAddressInputProps {
  address: string;
  onAddressChange: (address: string) => void;
  onLocationClick?: () => void;
  className?: string;
}

const UnifiedAddressInput: React.FC<UnifiedAddressInputProps> = ({
  address,
  onAddressChange,
  onLocationClick,
  className
}) => {
  const { market } = useMarket();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const addressInputRef = useRef<HTMLInputElement>(null);
  
  const { 
    suggestions, 
    isLoading, 
    error, 
    validationRules, 
    clearSuggestions 
  } = useMarketAddressSearch(address);
  
  const { getCurrentLocation, isLoadingLocation } = useGeolocation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onAddressChange(value);
    
    if (value.length >= (validationRules?.min_length || 3)) {
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSuggestionSelect = (suggestion: AddressSearchResult) => {
    onAddressChange(suggestion.fullAddress);
    setShowSuggestions(false);
    clearSuggestions();
    if (addressInputRef.current) {
      addressInputRef.current.blur();
    }
  };

  const handleLocationClick = async () => {
    if (onLocationClick) {
      onLocationClick();
    } else {
      const location = await getCurrentLocation();
      if (location) {
        onAddressChange(location);
        setShowSuggestions(false);
        clearSuggestions();
      }
    }
  };

  const getPlaceholder = () => {
    return validationRules?.placeholder_text || 'Enter your address';
  };

  const getLocationButtonText = () => {
    switch (market.country_code) {
      case 'UK':
        return 'My Location';
      case 'US':
        return 'My Location';
      case 'DE':
        return 'Mein Standort';
      default:
        return 'Min lokation';
    }
  };

  return (
    <div className={`space-y-apple-4 relative ${className}`}>
      <div className="flex gap-apple-3">
        <div className="relative flex-1">
          <div className="relative">
            <GlassInput
              ref={addressInputRef}
              placeholder={getPlaceholder()}
              value={address}
              onChange={handleInputChange}
              onFocus={() => {
                if (suggestions.length > 0 && address.length >= (validationRules?.min_length || 3)) {
                  setShowSuggestions(true);
                }
              }}
              onBlur={() => {
                setTimeout(() => {
                  setShowSuggestions(false);
                }, 150);
              }}
              variant="capsule"
              className="pl-12 h-14 text-apple-body placeholder:text-system-gray2"
              autoFocus
            />
            <MapPin className="absolute left-apple-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-system-gray2" />
          </div>
          
          {/* Address Suggestions */}
          {showSuggestions && suggestions.length > 0 && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-2 max-h-60 overflow-y-auto"
            >
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion.id}
                  className="w-full text-left px-apple-4 py-apple-3 hover:bg-system-blue/10 active:bg-system-blue/20 transition-colors text-apple-body font-apple border-b border-system-gray6 last:border-b-0 rounded-none first:rounded-t-apple-large last:rounded-b-apple-large"
                  onClick={() => handleSuggestionSelect(suggestion)}
                >
                  {suggestion.displayText}
                </button>
              ))}
            </GlassCard>
          )}

          {/* Loading indicator */}
          {isLoading && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-4 text-center"
            >
              <div className="text-system-gray2">Searching addresses...</div>
            </GlassCard>
          )}

          {/* Error display */}
          {error && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-4 text-center"
            >
              <div className="text-system-red">{error}</div>
            </GlassCard>
          )}
        </div>
        
        <GlassButton
          type="button"
          variant="primary"
          size="capsule"
          onClick={handleLocationClick}
          disabled={isLoadingLocation}
          className="h-14 px-apple-6 min-w-[140px] text-apple-callout font-semibold text-white"
        >
          <MapPin className={`w-5 h-5 ${isLoadingLocation ? 'animate-spin' : ''}`} />
          {getLocationButtonText()}
        </GlassButton>
      </div>
    </div>
  );
};

export default UnifiedAddressInput;