import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Save, Plus, MessageSquare, Settings, Eye, Edit2, Copy, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';

interface SMSTemplateType {
  id: string;
  template_key: string;
  template_name: string;
  description: string;
  required_variables: any; // Json from database
  is_active: boolean;
}

interface ContentSection {
  id: string;
  section_key: string;
  section_name: string;
  description: string;
}

interface ContentTranslation {
  id: string;
  section_id: string;
  content_key: string;
  content_value: string;
  content_type: string;
}

const SMSTemplateManager: React.FC = () => {
  const [templateTypes, setTemplateTypes] = useState<SMSTemplateType[]>([]);
  const [sections, setSections] = useState<ContentSection[]>([]);
  const [translations, setTranslations] = useState<ContentTranslation[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    fetchTemplateTypes();
    fetchSMSSections();
  }, []);

  useEffect(() => {
    if (selectedTemplate) {
      fetchTemplateContent(selectedTemplate);
    }
  }, [selectedTemplate]);

  const fetchTemplateTypes = async () => {
    try {
      const { data, error } = await supabase
        .from('sms_template_types')
        .select('*')
        .eq('is_active', true)
        .order('template_name');

      if (error) throw error;
      setTemplateTypes(data || []);
      
      if (data && data.length > 0 && !selectedTemplate) {
        setSelectedTemplate(data[0].template_key);
      }
    } catch (error) {
      console.error('Error fetching template types:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch SMS template types',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchSMSSections = async () => {
    try {
      const { data: smsPage } = await supabase
        .from('content_pages')
        .select('id')
        .eq('page_key', 'sms_notifications')
        .single();

      if (!smsPage) return;

      const { data, error } = await supabase
        .from('content_sections')
        .select('*')
        .eq('page_id', smsPage.id)
        .order('section_name');

      if (error) throw error;
      setSections(data || []);
    } catch (error) {
      console.error('Error fetching SMS sections:', error);
    }
  };

  const fetchTemplateContent = async (templateKey: string) => {
    try {
      const section = sections.find(s => s.section_key === `sms_${templateKey}`);
      if (!section) return;

      const { data, error } = await supabase
        .from('content_translations')
        .select('*')
        .eq('section_id', section.id)
        .eq('language_code', 'en')
        .is('market_code', null)
        .order('content_key');

      if (error) throw error;
      setTranslations(data || []);
    } catch (error) {
      console.error('Error fetching template content:', error);
    }
  };

  const saveTemplate = async (contentKey: string, value: string) => {
    setSaving(true);
    try {
      const translation = translations.find(t => t.content_key === contentKey);
      if (!translation) return;

      const { error } = await supabase
        .from('content_translations')
        .update({ content_value: value })
        .eq('id', translation.id);

      if (error) throw error;
      
      // Refresh content
      await fetchTemplateContent(selectedTemplate);
      
      toast({
        title: 'Success',
        description: 'SMS template updated successfully',
      });
      
      setEditingTemplate('');
    } catch (error) {
      console.error('Error saving template:', error);
      toast({
        title: 'Error',
        description: 'Failed to update SMS template',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const addNewTemplate = async () => {
    const templateName = prompt('Enter template name:');
    const templateKey = prompt('Enter template key (e.g., job_reminder):');
    const description = prompt('Enter template description:');
    
    if (!templateName || !templateKey || !description) return;

    setSaving(true);
    try {
      // Create template type
      const { error: templateError } = await supabase
        .from('sms_template_types')
        .insert({
          template_key: templateKey,
          template_name: templateName,
          description: description,
          required_variables: ['customerName', 'jobNumber'],
          is_active: true
        });

      if (templateError) throw templateError;

      // Create content section
      const { data: smsPage } = await supabase
        .from('content_pages')
        .select('id')
        .eq('page_key', 'sms_notifications')
        .single();

      if (smsPage) {
        const { data: newSection, error: sectionError } = await supabase
          .from('content_sections')
          .insert({
            page_id: smsPage.id,
            section_key: `sms_${templateKey}`,
            section_name: `${templateName} SMS`,
            description: `SMS template for ${description}`
          })
          .select()
          .single();

        if (sectionError) throw sectionError;

        // Create default content translations
        const { error: contentError } = await supabase
          .from('content_translations')
          .insert([
            {
              section_id: newSection.id,
              language_code: 'en',
              content_key: `${templateKey}_message`,
              content_value: `Hi {{customerName}}! This is a message about your job #{{jobNumber}}.`,
              content_type: 'text',
              market_code: null
            },
            {
              section_id: newSection.id,
              language_code: 'en',
              content_key: `${templateKey}_link_text`,
              content_value: 'View Details',
              content_type: 'text',
              market_code: null
            }
          ]);

        if (contentError) throw contentError;
      }

      await fetchTemplateTypes();
      await fetchSMSSections();
      setSelectedTemplate(templateKey);
      
      toast({
        title: 'Success',
        description: 'New SMS template created successfully',
      });
    } catch (error) {
      console.error('Error creating template:', error);
      toast({
        title: 'Error',
        description: 'Failed to create SMS template',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const getVariablesForTemplate = (templateKey: string) => {
    const template = templateTypes.find(t => t.template_key === templateKey);
    return template?.required_variables || [];
  };

  const getCharacterCount = (text: string) => {
    return text.length;
  };

  const getSMSSegments = (text: string) => {
    return Math.ceil(text.length / 160);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-6 h-6 animate-spin mr-2" />
        <span>Loading SMS templates...</span>
      </div>
    );
  }

  const selectedTemplateData = templateTypes.find(t => t.template_key === selectedTemplate);
  const messageTranslation = translations.find(t => t.content_key === `${selectedTemplate}_message`);
  const linkTextTranslation = translations.find(t => t.content_key === `${selectedTemplate}_link_text`);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Template Sidebar */}
      <div className="lg:col-span-1">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>SMS Templates</span>
              <Button size="sm" variant="outline" onClick={addNewTemplate} disabled={saving}>
                <Plus className="w-4 h-4" />
              </Button>
            </CardTitle>
            <CardDescription>
              Manage SMS notification templates
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {templateTypes.map((template) => (
                <Button
                  key={template.id}
                  variant={selectedTemplate === template.template_key ? 'default' : 'ghost'}
                  className="w-full justify-start"
                  onClick={() => setSelectedTemplate(template.template_key)}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  {template.template_name}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Template Info */}
        {selectedTemplateData && (
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-sm">Template Info</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Key</Label>
                  <p className="text-sm font-mono">{selectedTemplateData.template_key}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Description</Label>
                  <p className="text-sm">{selectedTemplateData.description}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Variables</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedTemplateData.required_variables.map((variable) => (
                      <Badge key={variable} variant="outline" className="text-xs">
                        {`{{${variable}}}`}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Content Editor */}
      <div className="lg:col-span-3">
        {selectedTemplateData ? (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{selectedTemplateData.template_name}</span>
                <Badge variant="secondary">Global English</Badge>
              </CardTitle>
              <CardDescription>
                Edit the Global English template - translations are managed in Translation Management
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Main Message */}
              {messageTranslation && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">SMS Message</Label>
                    <div className="flex items-center gap-2">
                      {messageTranslation.content_value && (
                        <div className="text-xs text-muted-foreground">
                          {getCharacterCount(messageTranslation.content_value)} chars • {getSMSSegments(messageTranslation.content_value)} SMS
                        </div>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setEditingTemplate(editingTemplate === 'message' ? '' : 'message')}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {editingTemplate === 'message' ? (
                    <SMSTemplateEditor
                      initialValue={messageTranslation.content_value}
                      onSave={(value) => saveTemplate(messageTranslation.content_key, value)}
                      onCancel={() => setEditingTemplate('')}
                      saving={saving}
                      variables={getVariablesForTemplate(selectedTemplate)}
                    />
                  ) : (
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="whitespace-pre-wrap">{messageTranslation.content_value || 'No content set'}</p>
                    </div>
                  )}
                </div>
              )}

              <Separator />

              {/* Link Text */}
              {linkTextTranslation && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">Link Text</Label>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditingTemplate(editingTemplate === 'link' ? '' : 'link')}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </div>

                  {editingTemplate === 'link' ? (
                    <div className="space-y-4">
                      <Input
                        defaultValue={linkTextTranslation.content_value}
                        placeholder="Enter link text..."
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            saveTemplate(linkTextTranslation.content_key, e.currentTarget.value);
                          }
                        }}
                      />
                      <div className="flex gap-2">
                        <Button 
                          size="sm"
                          onClick={(e) => {
                            const input = e.currentTarget.parentElement?.parentElement?.querySelector('input');
                            if (input) {
                              saveTemplate(linkTextTranslation.content_key, input.value);
                            }
                          }}
                          disabled={saving}
                        >
                          <Save className="w-4 h-4 mr-2" />
                          Save
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditingTemplate('')}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-muted rounded-lg">
                      <span className="text-sm">{linkTextTranslation.content_value || 'No text set'}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Usage Information */}
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Note:</strong> Changes here only affect the Global English template. 
                  To manage translations for other languages and markets, use the Translation Management tab.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-12">
              <div className="text-center text-muted-foreground">
                Select a template to edit its content
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

interface SMSTemplateEditorProps {
  initialValue: string;
  onSave: (value: string) => void;
  onCancel: () => void;
  saving: boolean;
  variables: string[];
}

const SMSTemplateEditor: React.FC<SMSTemplateEditorProps> = ({
  initialValue,
  onSave,
  onCancel,
  saving,
  variables
}) => {
  const [value, setValue] = useState(initialValue);

  const insertVariable = (variable: string) => {
    setValue(prev => prev + `{{${variable}}}`);
  };

  const getCharacterCount = () => value.length;
  const getSMSSegments = () => Math.ceil(value.length / 160);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Message Content</Label>
        <Textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Enter SMS message template..."
          rows={4}
          className="resize-none"
        />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{getCharacterCount()} characters</span>
          <span>{getSMSSegments()} SMS segment{getSMSSegments() !== 1 ? 's' : ''}</span>
        </div>
      </div>

      {/* Variable Buttons */}
      <div className="space-y-2">
        <Label>Insert Variables</Label>
        <div className="flex flex-wrap gap-2">
          {variables.map((variable) => (
            <Button
              key={variable}
              size="sm"
              variant="outline"
              onClick={() => insertVariable(variable)}
              className="text-xs"
            >
              <Copy className="w-3 h-3 mr-1" />
              {`{{${variable}}}`}
            </Button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2">
        <Button onClick={() => onSave(value)} disabled={saving}>
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Template
            </>
          )}
        </Button>
        <Button variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default SMSTemplateManager;