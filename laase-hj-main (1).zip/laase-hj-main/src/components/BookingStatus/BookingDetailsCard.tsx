import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, User, Phone } from 'lucide-react';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

interface BookingDetailsCardProps {
  booking: {
    address: string;
    urgency: string;
    follow_up_answers?: any;
  };
}

export const BookingDetailsCard: React.FC<BookingDetailsCardProps> = ({ booking }) => {
  const translations = useBookingStatusTranslations();
  const customerName = booking?.follow_up_answers?.customerName || 'Not provided';
  const customerPhone = booking?.follow_up_answers?.customerPhone || 'Not provided';

  const getUrgencyText = (urgency: string) => {
    switch (urgency) {
      case 'nu':
        return translations.bookingDetails.urgencyNow();
      case 'soon':
        return 'Within 1 hour';
      default:
        return translations.bookingDetails.urgencyCanWait();
    }
  };

  return (
    <Card className="h-fit">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <MapPin className="w-5 h-5 text-primary" />
          {translations.bookingDetails.title()}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
           <div className="min-w-0 flex-1">
             <p className="font-medium text-sm">{translations.bookingDetails.addressLabel()}</p>
             <p className="text-muted-foreground text-sm break-words">{booking.address}</p>
           </div>
        </div>

        <div className="flex items-start gap-3">
          <Clock className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
           <div className="min-w-0 flex-1">
             <p className="font-medium text-sm">{translations.bookingDetails.urgencyLabel()}</p>
            <Badge 
              variant={booking.urgency === 'nu' ? 'destructive' : 'secondary'}
              className="mt-1"
            >
              {getUrgencyText(booking.urgency)}
            </Badge>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <User className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
           <div className="min-w-0 flex-1">
             <p className="font-medium text-sm">Contact</p>
             <p className="text-muted-foreground text-sm break-words">{customerName}</p>
           </div>
        </div>

        <div className="flex items-start gap-3">
          <Phone className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
           <div className="min-w-0 flex-1">
             <p className="font-medium text-sm">Phone</p>
             <p className="text-muted-foreground text-sm break-words">{customerPhone}</p>
           </div>
        </div>
      </CardContent>
    </Card>
  );
};