import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Phone, MessageCircle, Star, MapPin, Clock, User } from 'lucide-react';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

interface LocksmithProfile {
  id: string;
  first_name?: string;
  last_name?: string;
  company_name?: string;
  phone?: string;
  cvr_number?: string;
}

interface LocksmithProfileCardProps {
  locksmith: LocksmithProfile;
  estimatedArrival?: string;
  rating?: number;
  reviewCount?: number;
  distance?: number;
  onCall: () => void;
  onMessage: () => void;
}

export const LocksmithProfileCard: React.FC<LocksmithProfileCardProps> = ({
  locksmith,
  estimatedArrival = "15-20 min",
  rating = 4.8,
  reviewCount = 125,
  distance = 2.3,
  onCall,
  onMessage
}) => {
  const translations = useBookingStatusTranslations();
  const displayName = locksmith.company_name || 
    `${locksmith.first_name || ''} ${locksmith.last_name || ''}`.trim() || 
    translations.locksmithProfile.professionalFallback();

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardContent className="p-6">
        {/* Header with locksmith info */}
        <div className="flex items-start gap-4 mb-6">
          {/* Avatar */}
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/70 rounded-full flex items-center justify-center flex-shrink-0">
            <User className="w-8 h-8 text-white" />
          </div>
          
          {/* Info */}
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold text-foreground mb-1">
              {displayName}
            </h2>
            
            {/* Rating */}
            <div className="flex items-center gap-2 mb-2">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <span className="font-medium text-foreground">{rating}</span>
              </div>
               <span className="text-muted-foreground text-sm">
                 ({reviewCount} {translations.quotes.reviewsLabel()})
               </span>
            </div>

            {/* Contact info */}
            {locksmith.phone && (
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Phone className="w-4 h-4" />
                <span>{locksmith.phone}</span>
              </div>
            )}
          </div>
        </div>

        {/* Service details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6 p-4 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-primary" />
             <div>
               <div className="text-sm font-medium">{translations.locksmithProfile.arrivalLabel()}</div>
               <div className="text-xs text-muted-foreground">{estimatedArrival}</div>
             </div>
          </div>
          
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
             <div>
               <div className="text-sm font-medium">{translations.locksmithProfile.distanceLabel()}</div>
               <div className="text-xs text-muted-foreground">{distance} {translations.quotes.kmAwayLabel()}</div>
             </div>
          </div>

          <div className="flex items-center gap-2">
            <Star className="w-4 h-4 text-primary" />
             <div>
               <div className="text-sm font-medium">{translations.locksmithProfile.ratingLabel()}</div>
               <div className="text-xs text-muted-foreground">{rating}/5</div>
             </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            onClick={onCall}
            className="flex-1 flex items-center justify-center gap-2"
          >
             <Phone className="w-4 h-4" />
             {translations.locksmithProfile.callButton()}
          </Button>
          
          <Button 
            variant="outline"
            onClick={onMessage}
            className="flex-1 flex items-center justify-center gap-2"
          >
             <MessageCircle className="w-4 h-4" />
             {translations.locksmithProfile.messageButton()}
          </Button>
        </div>

        {/* Status message */}
        <div className="mt-4 p-3 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg">
          <p className="text-sm text-green-700 dark:text-green-300 text-center font-medium">
            {translations.locksmithProfile.confirmedMessage()}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};