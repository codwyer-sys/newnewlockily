import React, { useState } from 'react';
import { PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield } from 'lucide-react';
import { useJobStatusUpdate } from '@/hooks/useJobStatusUpdate';

interface EmbeddedPaymentFormProps {
  amount: number;
  email: string;
  bookingId: string;
  locksmithId: string;
  clientSecret: string;
  onSuccess: () => void;
  onError: (error: string) => void;
  isProcessing: boolean;
  setIsProcessing: (processing: boolean) => void;
}

export const EmbeddedPaymentForm: React.FC<EmbeddedPaymentFormProps> = ({
  amount,
  email,
  bookingId,
  locksmithId,
  clientSecret,
  onSuccess,
  onError,
  isProcessing,
  setIsProcessing
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState<string>('');
  const [elementMounted, setElementMounted] = useState<boolean>(false);
  const [elementError, setElementError] = useState<string>('');
  const { updateJobStage, isUpdating } = useJobStatusUpdate();

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!stripe || !elements) {
      console.error('💥 Stripe or Elements not ready');
      return;
    }

    if (!elementMounted) {
      console.error('💥 PaymentElement not mounted yet');
      setError('Payment form is not ready. Please wait a moment and try again.');
      return;
    }

    if (elementError) {
      console.error('💥 PaymentElement has errors:', elementError);
      setError('Payment form has errors. Please refresh and try again.');
      return;
    }

    setIsProcessing(true);
    setError('');

    try {
      console.log('💳 Confirming payment...');
      
      // Validate payment element before confirmation
      const { error: submitError } = await elements.submit();
      if (submitError) {
        console.error('💥 Payment element submission error:', submitError);
        setError(submitError.message || 'Please check your payment details');
        setIsProcessing(false);
        return;
      }

      const { error: paymentError, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: 'if_required', // Removed problematic return_url and receipt_email
      });

      console.log('💳 Payment confirmation result:', { paymentError, status: paymentIntent?.status });

      if (paymentError) {
        console.error('💥 Payment error:', paymentError);
        setError(paymentError.message || 'Payment failed');
        onError(paymentError.message || 'Payment failed');
        setIsProcessing(false);
        return;
      }

      // Check payment status
      if (paymentIntent) {
        switch (paymentIntent.status) {
          case 'succeeded':
            console.log('✅ Payment succeeded!');
            // Update job stage to awaiting locksmith acceptance
            try {
              await updateJobStage(bookingId, 'awaiting_locksmith_acceptance', locksmithId);
              console.log('✅ Job stage updated to awaiting locksmith acceptance');
            } catch (stageError) {
              console.error('💥 Failed to update job stage:', stageError);
              // Don't fail the whole payment flow for this
            }
            onSuccess();
            break;
          case 'processing':
            console.log('⏳ Payment is processing...');
            setError('Payment is being processed. Please wait...');
            setIsProcessing(false);
            break;
          case 'requires_action':
            console.log('🔐 Payment requires additional action');
            setError('Payment requires additional verification. Please try again.');
            setIsProcessing(false);
            break;
          default:
            console.log('❓ Unexpected payment status:', paymentIntent.status);
            setError('Payment status unclear. Please contact support.');
            setIsProcessing(false);
            break;
        }
      } else {
        console.warn('⚠️ No payment intent returned');
        setError('Payment confirmation failed. Please try again.');
        setIsProcessing(false);
      }
    } catch (error) {
      console.error('💥 Unexpected error during payment:', error);
      setError('An unexpected error occurred. Please try again.');
      onError('An unexpected error occurred. Please try again.');
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-muted/30 rounded-lg p-4">
        {!elementMounted && (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mr-3"></div>
            <span className="text-muted-foreground">Preparing secure payment form...</span>
          </div>
        )}
        <PaymentElement 
          options={{
            layout: "tabs",
            paymentMethodOrder: ['card'],
          }}
          onReady={() => {
            console.log('✅ PaymentElement mounted and ready');
            setElementMounted(true);
            setElementError('');
          }}
          onLoadError={(error) => {
            console.error('💥 PaymentElement load error:', error);
            setElementError('Failed to load payment form. Please refresh and try again.');
            setError('Failed to load payment form. Please refresh and try again.');
          }}
        />
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <Shield className="w-4 h-4" />
        <span>Secured by Stripe</span>
      </div>

      <Button 
        type="submit" 
        disabled={!stripe || !elements || !elementMounted || !!elementError || isProcessing || isUpdating} 
        className="w-full"
        size="lg"
      >
        {isProcessing || isUpdating ? 'Processing...' : 
         !elementMounted ? 'Loading payment form...' : 
         elementError ? 'Payment form error' :
         `Pay ${amount} kr`}
      </Button>
    </form>
  );
};