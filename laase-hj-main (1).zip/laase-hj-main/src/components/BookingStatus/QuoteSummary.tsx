import React from 'react';
import { Clock, Star, Navigation } from 'lucide-react';

interface Quote {
  id: string;
  booking_id: string;
  locksmith_id: string;
  price: number;
  estimated_arrival_minutes: number;
  distance_km: number;
  message?: string;
  status: string;
  created_at: string;
  locksmith: {
    id: string;
    first_name?: string;
    last_name?: string;
    company_name?: string;
    phone?: string;
    cvr_number?: string;
  };
  locksmith_rating: number;
  locksmith_reviews: number;
}

interface QuoteSummaryProps {
  quote: Quote;
}

export const QuoteSummary: React.FC<QuoteSummaryProps> = ({ quote }) => {
  // Helper function to get locksmith display name
  const getLocksmithName = (locksmith?: Quote['locksmith']): string => {
    if (!locksmith) return 'Professional Locksmith';
    if (locksmith.company_name) return locksmith.company_name;
    const firstName = locksmith.first_name || '';
    const lastName = locksmith.last_name || '';
    const fullName = `${firstName} ${lastName}`.trim();
    return fullName || 'Professional Locksmith';
  };

  // Helper function to format arrival time
  const formatArrivalTime = (minutes: number | undefined): string => {
    if (!minutes || minutes < 60) {
      return `${minutes || 30} min`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMins = minutes % 60;
    if (remainingMins === 0) {
      return `${hours}h`;
    }
    return `${hours}h ${remainingMins}min`;
  };

  return (
    <div className="bg-muted/50 rounded-lg p-4 space-y-3">
      <div className="font-semibold text-lg">
        {getLocksmithName(quote.locksmith)}
      </div>
      
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-muted-foreground" />
          <span>{formatArrivalTime(quote.estimated_arrival_minutes)}</span>
        </div>
        <div className="flex items-center gap-2">
          <Navigation className="w-4 h-4 text-muted-foreground" />
          <span>{quote.distance_km} km away</span>
        </div>
        <div className="flex items-center gap-2">
          <Star className="w-4 h-4 text-yellow-500" />
          <span>{quote.locksmith_rating} ({quote.locksmith_reviews} reviews)</span>
        </div>
      </div>

      <div className="pt-2 border-t border-border">
        <div className="flex justify-between items-center">
          <span className="font-medium">Total Amount:</span>
          <span className="text-xl font-bold text-primary">{quote.price} kr</span>
        </div>
      </div>
    </div>
  );
};