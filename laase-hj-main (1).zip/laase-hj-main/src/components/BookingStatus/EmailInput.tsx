import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail } from 'lucide-react';

interface EmailInputProps {
  email: string;
  onChange: (value: string) => void;
  error?: string;
  disabled?: boolean;
}

export const EmailInput: React.FC<EmailInputProps> = ({
  email,
  onChange,
  error,
  disabled = false
}) => {
  return (
    <div className="space-y-2">
      <Label htmlFor="email" className="flex items-center gap-2">
        <Mail className="w-4 h-4" />
        Email for receipt
      </Label>
      <Input
        id="email"
        type="email"
        placeholder="your@email.com"
        value={email}
        onChange={(e) => onChange(e.target.value)}
        className={error ? "border-destructive" : ""}
        disabled={disabled}
      />
      {error && (
        <p className="text-sm text-destructive">{error}</p>
      )}
    </div>
  );
};