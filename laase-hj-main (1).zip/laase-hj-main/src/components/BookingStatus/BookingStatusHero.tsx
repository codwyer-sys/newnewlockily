
import React from 'react';
import BookingBackgroundMap from '@/components/BookingBackgroundMap';
import { useHeaderThemeSection } from '@/hooks/useHeaderThemeSection';
import { getJobStageConfig, type JobStage } from '@/utils/jobStageConfig';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

interface BookingStatusHeroProps {
  booking: {
    address: string;
    job_stage?: JobStage;
  };
  quotes: any[];
  getLowestETA: () => string;
}

export const BookingStatusHero: React.FC<BookingStatusHeroProps> = ({
  booking,
  quotes,
  getLowestETA
}) => {
  // Register this section as dark theme for the header
  const heroRef = useHeaderThemeSection('dark', 'booking-hero');
  const translations = useBookingStatusTranslations();
  
  // Get job stage configuration with translations
  const stageConfig = getJobStageConfig(
    booking.job_stage, 
    translations.jobStages.getTitle(booking.job_stage || 'waiting_for_quotes'),
    translations.jobStages.getDescription(booking.job_stage || 'waiting_for_quotes'),
    translations.jobStages.getBadgeText(booking.job_stage || 'waiting_for_quotes')
  );
  const BadgeIcon = stageConfig.badgeIcon;

  return (
    <div 
      ref={heroRef as React.RefObject<HTMLDivElement>}
      className={`relative bg-gradient-to-br ${stageConfig.bgGradient} text-white pt-20 min-h-[400px] md:min-h-[500px]`}
    >
      {/* Background Map - Improved visibility */}
      <div className="absolute inset-0 overflow-hidden opacity-65">
        <BookingBackgroundMap address={booking.address} />
      </div>
      
      {/* Overlay for Better Readability - Reduced opacity */}
      <div className={`absolute inset-0 bg-gradient-to-br ${stageConfig.bgGradient.replace('from-', 'from-').replace('to-', 'to-')}/65`}></div>
      
      <div className="relative container mx-auto px-4 py-8 md:py-12 pb-12 md:pb-16">
        <div className="text-center space-y-6 md:space-y-8">
          {/* Dynamic Status Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white text-sm font-medium">
            <BadgeIcon className="w-4 h-4 mr-2" />
            {stageConfig.badgeText}
          </div>
          
          {/* Dynamic Main Heading */}
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">
              {stageConfig.title}
            </h1>
            <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
              {stageConfig.description}
            </p>
          </div>

          {/* Dynamic Status Text */}
          <div className="text-center">
            <p className="text-white/80 text-sm md:text-base">
              {booking.job_stage === 'waiting_for_quotes' ? (
                quotes.length === 0 
                  ? translations.hero.searchingLocksmiths()
                  : translations.hero.quotesCount(quotes.length)
              ) : booking.job_stage === 'awaiting_client_feedback' ? (
                translations.hero.locksmithsReady(quotes.length)
              ) : booking.job_stage === 'awaiting_locksmith_acceptance' ? (
                translations.hero.waitingConfirmation()
              ) : booking.job_stage === 'locksmith_en_route' ? (
                translations.hero.locksmithOnWay()
              ) : booking.job_stage === 'locksmith_on_job' ? (
                translations.hero.workInProgress()
              ) : booking.job_stage === 'job_finished' ? (
                translations.hero.serviceCompleted()
              ) : (
                translations.hero.processingRequest()
              )}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
