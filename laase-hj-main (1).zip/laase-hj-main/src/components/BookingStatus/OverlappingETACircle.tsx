
import React from 'react';
import { getJobStageConfig, type JobStage } from '@/utils/jobStageConfig';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

interface OverlappingETACircleProps {
  getLowestETA: () => string;
  quotes: any[];
  jobStage?: JobStage;
}

export const OverlappingETACircle: React.FC<OverlappingETACircleProps> = ({
  getLowestETA,
  quotes,
  jobStage
}) => {
  const translations = useBookingStatusTranslations();
  const stageConfig = getJobStageConfig(jobStage);
  
  // Don't show ETA circle for stages where it's not relevant
  if (!stageConfig.showETA) {
    return null;
  }

  return (
    <div className="relative -mt-16 md:-mt-20 mb-8 md:mb-12 flex justify-center z-10">
      <div className="relative group">
        {/* Progress Ring Background */}
        <div className="w-40 h-40 md:w-44 md:h-44">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 176 176">
            {/* Background circle */}
            <circle
              cx="88"
              cy="88"
              r="76"
              fill="none"
              stroke="rgb(226 232 240)"
              strokeWidth="10"
            />
            {/* Progress circle with gradient - Stage-aware progress */}
            <circle
              cx="88"
              cy="88"
              r="76"
              fill="none"
              stroke="url(#progressGradient)"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={`${(stageConfig.progressPercentage / 100) * 477} 477`}
              className="transition-all duration-1000 ease-in-out"
            />
            {/* Gradient definition */}
            <defs>
              <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgb(34 197 94)" />
                <stop offset="100%" stopColor="rgb(22 163 74)" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        
        {/* Center Content with Glass Effect */}
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/95 backdrop-blur-sm rounded-full border border-white/20 m-2 transition-transform duration-300 group-hover:scale-105" 
             style={{
               boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.1), 0 0 40px rgba(34, 197, 94, 0.1)'
             }}>
          <div className="text-2xl md:text-3xl font-bold text-foreground">
            {getLowestETA()}
          </div>
          <div className="text-xs md:text-sm text-muted-foreground font-medium">
            {translations.etaCircle.etaLabel()}
          </div>
        </div>

      </div>
      
      {/* Stage-aware status message */}
      <div className="absolute top-full mt-4 text-center">
        <div className="px-4 py-2 bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-full">
          <p className="text-sm font-medium text-green-700 dark:text-green-300">
            {jobStage === 'waiting_for_quotes' ? (
              quotes.length === 0 
                ? translations.etaCircle.almostThere()
                : translations.etaCircle.quotesReceived(quotes.length)
            ) : jobStage === 'awaiting_locksmith_acceptance' ? (
              translations.etaCircle.confirmingAvailability()
            ) : jobStage === 'locksmith_en_route' ? (
              translations.etaCircle.locksmithOnWay()
            ) : jobStage === 'locksmith_on_job' ? (
              translations.etaCircle.workInProgress()
            ) : (
              translations.etaCircle.processing()
            )}
          </p>
        </div>
      </div>
    </div>
  );
};
