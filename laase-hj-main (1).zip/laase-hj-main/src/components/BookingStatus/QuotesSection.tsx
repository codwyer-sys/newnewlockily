import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Clock, Star, Navigation, CheckCircle, Phone } from 'lucide-react';
import { UltraSimplePayment } from '../UltraSimplePayment';

interface Quote {
  id: string;
  booking_id: string;
  locksmith_id: string;
  price: number;
  estimated_arrival_minutes: number;
  distance_km: number;
  message?: string;
  status: string;
  created_at: string;
  locksmith: {
    id: string;
    first_name?: string;
    last_name?: string;
    company_name?: string;
    phone?: string;
    cvr_number?: string;
  };
  locksmith_rating: number;
  locksmith_reviews: number;
}

interface QuotesSectionProps {
  quotes: Quote[];
  selectedQuote: string | null;
  bookingId: string;
  onSortQuotes: (by: 'price' | 'distance' | 'rating' | 'created_at') => void;
  onAcceptQuote: (quoteId: string, email: string) => void;
  isProcessingPayment: boolean;
}

export const QuotesSection: React.FC<QuotesSectionProps> = ({
  quotes,
  selectedQuote,
  bookingId,
  onSortQuotes,
  onAcceptQuote,
  isProcessingPayment
}) => {
  const [expandedQuoteId, setExpandedQuoteId] = useState<string | null>(null);

  // Static translations with fallbacks - no external dependencies
  const t = {
    quotesReceived: (count: number) => count === 0 ? "Finding Locksmiths" : `${count} quotes received`,
    sortByPrice: "Sort by Price",
    sortByDistance: "Sort by Distance", 
    sortByRating: "Sort by Rating",
    findingTitle: "Finding Locksmiths",
    findingDescription: "We are finding available locksmiths in your area.",
    totalPriceLabel: "Total price",
    arrivesInLabel: "Arrives in",
    kmAwayLabel: "km away",
    reviewsLabel: "reviews",
    acceptQuoteButton: (price: number) => `Accept Quote - ${price} kr`,
    quoteAcceptedLabel: "Quote Accepted",
    callLocksmith: "Call locksmith"
  };
  
  // Helper function to format arrival time with error handling
  const formatArrivalTime = (minutes: number | undefined): string => {
    try {
      if (!minutes || minutes < 60) {
        return `${minutes || 30} min`;
      }
      const hours = Math.floor(minutes / 60);
      const remainingMins = minutes % 60;
      if (remainingMins === 0) {
        return `${hours}h`;
      }
      return `${hours}h ${remainingMins}min`;
    } catch (error) {
      return "30 min";
    }
  };
  
  // Helper function to get locksmith display name with null checks
  const getLocksmithName = (locksmith?: Quote['locksmith']): string => {
    try {
      if (!locksmith) return 'Professional Locksmith';
      if (locksmith.company_name) return locksmith.company_name;
      const firstName = locksmith.first_name || '';
      const lastName = locksmith.last_name || '';
      const fullName = `${firstName} ${lastName}`.trim();
      return fullName || 'Professional Locksmith';
    } catch (error) {
      return 'Professional Locksmith';
    }
  };
  

  const handleQuoteClick = (quote: Quote) => {
    console.log('🎯 Quote clicked:', quote.id);
    setExpandedQuoteId(quote.id);
  };

  const handlePaymentSuccess = () => {
    console.log('💳 Payment successful, accepting quote');
    const expandedQuote = quotes.find(q => q.id === expandedQuoteId);
    if (expandedQuote) {
      onAcceptQuote(expandedQuote.id, 'payment@completed.com'); // Email handled in PaymentFlow
      handleCloseExpanded();
    }
  };

  const handleCloseExpanded = () => {
    if (!isProcessingPayment) {
      setExpandedQuoteId(null);
    }
  };

  return (
    <div className={`relative ${expandedQuoteId ? 'overflow-hidden' : ''}`}>
      {/* Backdrop blur overlay */}
      {expandedQuoteId && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40" 
          onClick={handleCloseExpanded}
        />
      )}
      
      <Card className="relative z-50">
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <CardTitle className="text-lg">
              {t.quotesReceived(quotes?.length || 0)}
            </CardTitle>
            {(quotes?.length || 0) > 0 && (
              <div className="flex flex-wrap gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => onSortQuotes('price')}
                  className="text-xs"
                >
                  {t.sortByPrice}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => onSortQuotes('distance')}
                  className="text-xs"
                >
                  {t.sortByDistance}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => onSortQuotes('rating')}
                  className="text-xs"
                >
                  {t.sortByRating}
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {(quotes?.length || 0) === 0 ? (
            <div className="text-center py-8 md:py-12">
              <div className="animate-pulse mb-4">
                <div className="w-12 h-12 md:w-16 md:h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto">
                  <Clock className="w-6 h-6 md:w-8 md:h-8 text-primary" />
                </div>
              </div>
              <h3 className="text-base md:text-lg font-semibold mb-2">{t.findingTitle}</h3>
              <p className="text-muted-foreground text-sm md:text-base max-w-md mx-auto">
                {t.findingDescription}
              </p>
            </div>
          ) : (
            <div 
              className="space-y-3 transition-all duration-300" 
              onClick={(e) => e.stopPropagation()}
            >
              {(quotes || []).map((quote) => {
                if (!quote?.id) return null;
                const isExpanded = expandedQuoteId === quote.id;
                return (
                  <div 
                    key={quote.id} 
                    className={`border rounded-lg transition-all duration-300 shadow-sm relative z-50 ${
                      selectedQuote === quote.id 
                        ? 'border-green-500 bg-green-50/50 dark:bg-green-950/50 shadow-green-100 dark:shadow-green-900/20' 
                        : isExpanded
                        ? 'border-primary bg-card shadow-2xl scale-105 blur-none'
                        : expandedQuoteId 
                        ? 'border-border bg-card blur-sm opacity-50'
                        : 'border-border hover:shadow-md hover:border-border/80 bg-card'
                    } ${isExpanded ? 'p-0' : 'p-5'}`}
                  >
                    {/* Quote content wrapper */}
                    <div className={isExpanded ? 'p-5 pb-0' : ''}>
                      {/* Two-column layout */}
                      <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                        {/* Left column - Locksmith info */}
                        <div className="flex-1 space-y-3">
                          <div className="flex items-start justify-between lg:block">
                            <h3 className="font-semibold text-lg text-foreground">{getLocksmithName(quote.locksmith)}</h3>
                            {/* Mobile price display */}
                            <div className="lg:hidden text-right">
                              <div className="text-xl font-bold text-primary">{quote.price || 0} kr</div>
                              <div className="text-xs text-muted-foreground">{t.totalPriceLabel}</div>
                            </div>
                          </div>
                          
                          {/* Quote details */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                            <div className="flex items-center gap-2">
                              <Navigation className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                              <span>{quote.distance_km || 0} {t.kmAwayLabel}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Star className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                              <span>{quote.locksmith_rating || 4.5} ({quote.locksmith_reviews || 0} {t.reviewsLabel})</span>
                            </div>
                          </div>
                        </div>
                        
                        {/* Right column - Price and timing */}
                        <div className="lg:w-48 lg:flex-shrink-0">
                          {/* Desktop price and timing display */}
                          <div className="hidden lg:block text-right space-y-3">
                            <div>
                              <div className="text-2xl font-bold text-primary">{quote.price || 0} kr</div>
                              <div className="text-xs text-muted-foreground">{t.totalPriceLabel}</div>
                            </div>
                            
                            <div>
                              <div className="flex items-center justify-end gap-2 text-primary font-medium">
                                <Clock className="w-4 h-4" />
                                <span className="text-lg">{formatArrivalTime(quote.estimated_arrival_minutes)}</span>
                              </div>
                              <div className="text-xs text-muted-foreground text-right">{t.arrivesInLabel}</div>
                            </div>
                          </div>
                          
                          {/* Mobile timing display */}
                          <div className="lg:hidden">
                            <div className="flex items-center gap-2 text-primary font-medium">
                              <Clock className="w-4 h-4" />
                              <span>{formatArrivalTime(quote.estimated_arrival_minutes)} {t.arrivesInLabel}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className={`mt-4 pt-4 border-t border-border ${isExpanded ? 'px-5' : ''}`}>
                      {selectedQuote === quote.id ? (
                        <div className="flex items-center gap-2 text-green-600 font-medium">
                          <CheckCircle className="w-5 h-5" />
                          {t.quoteAcceptedLabel}
                        </div>
                      ) : (
                        <div className="flex flex-col sm:flex-row gap-2">
                          <Button 
                            className="flex-1"
                            onClick={() => handleQuoteClick(quote)}
                            disabled={selectedQuote === quote.id || isProcessingPayment || expandedQuoteId === quote.id}
                          >
                            {selectedQuote === quote.id ? 'Processing Payment...' : 
                             `Accept Quote - ${quote.price || 0} kr`}
                          </Button>
                          {quote.locksmith?.phone && (
                            <Button 
                              variant="outline"
                              className="sm:w-auto"
                              asChild
                            >
                              <a href={`tel:${quote.locksmith.phone}`} className="flex items-center gap-2">
                                <Phone className="w-4 h-4" />
                                {t.callLocksmith}
                              </a>
                            </Button>
                          )}
                        </div>
                      )}
                    </div>

                     {/* Expanded Payment Section */}
                     {isExpanded && (
                       <UltraSimplePayment
                         quoteId={quote.id}
                         bookingId={bookingId}
                         onSuccess={handlePaymentSuccess}
                         onClose={handleCloseExpanded}
                       />
                     )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default QuotesSection;