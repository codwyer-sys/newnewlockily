import React from 'react';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

export const BookingStatusLoadingState: React.FC = () => {
  const translations = useBookingStatusTranslations();
  
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">{translations.loadingStates.loadingBooking()}</p>
        </div>
      </div>
      <LocksmithFooter />
    </div>
  );
};