import React from 'react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';
import { useBookingStatusTranslations } from '@/hooks/useBookingStatusTranslations';

interface BookingStatusErrorStateProps {
  error: string;
  bookingId?: string;
}

export const BookingStatusErrorState: React.FC<BookingStatusErrorStateProps> = ({ 
  error, 
  bookingId 
}) => {
  const translations = useBookingStatusTranslations();
  
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <div className="text-center max-w-md mx-auto">
          <h1 className="text-2xl font-bold text-destructive mb-4">{translations.loadingStates.errorTitle()}</h1>
          <p className="text-muted-foreground mb-4">{error}</p>
          {bookingId && (
            <p className="text-sm text-muted-foreground mb-4">Booking ID: {bookingId}</p>
          )}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button 
              variant="outline"
              onClick={() => window.location.reload()}
            >
              Try Again
            </Button>
            <Button onClick={() => window.location.href = '/'}>
              {translations.loadingStates.returnHome()}
            </Button>
          </div>
        </div>
      </div>
      <LocksmithFooter />
    </div>
  );
};