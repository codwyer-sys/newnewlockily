import React from 'react';
import Header from '@/components/Header';
import LocksmithFooter from '@/components/LocksmithFooter';
import { SEOHead } from '@/components/SEOHead';

interface MainLayoutProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  keywords?: string[];
}

export const MainLayout: React.FC<MainLayoutProps> = ({ 
  children, 
  title, 
  description, 
  keywords 
}) => {
  return (
    <div className="min-h-screen bg-background">
      {title && (
        <SEOHead
          title={title}
          description={description}
          keywords={keywords}
        />
      )}
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <LocksmithFooter />
    </div>
  );
};