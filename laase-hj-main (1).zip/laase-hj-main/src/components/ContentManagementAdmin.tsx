import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, Save, Plus, Eye, Calendar, BarChart3, TrendingUp, Settings, Edit2, Mail } from 'lucide-react';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { useMenuItems, MenuItem } from '@/hooks/useMenuItems';
import EmailTemplateManager from '@/components/EmailTemplates/EmailTemplateManager';
import SMSTemplateManager from '@/components/SMSTemplateManager';

interface ContentPage {
  id: string;
  page_key: string;
  page_name: string;
  description?: string;
}

interface ContentSection {
  id: string;
  page_id: string;
  section_key: string;
  section_name: string;
  description?: string;
}

interface ContentTranslation {
  id: string;
  section_id: string;
  language_code: string;
  content_key: string;
  content_value: string;
  content_type: string;
}

const ContentManagementAdmin: React.FC = () => {
  const [pages, setPages] = useState<ContentPage[]>([]);
  const [sections, setSections] = useState<ContentSection[]>([]);
  const [translations, setTranslations] = useState<ContentTranslation[]>([]);
  const [allMenuItems, setAllMenuItems] = useState<MenuItem[]>([]);
  const [selectedPage, setSelectedPage] = useState<string>('');
  const [selectedSection, setSelectedSection] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const { updateMenuItem } = useMenuItems();

  useEffect(() => {
    fetchPages();
    fetchAllMenuItems();
  }, []);

  useEffect(() => {
    if (selectedPage) {
      fetchSections(selectedPage);
    }
  }, [selectedPage]);

  useEffect(() => {
    if (selectedSection) {
      fetchTranslations(selectedSection);
    }
  }, [selectedSection]);

  const fetchPages = async () => {
    try {
      const { data, error } = await supabase
        .from('content_pages')
        .select('*')
        .order('page_name');

      if (error) throw error;
      setPages(data || []);
      
      if (data && data.length > 0 && !selectedPage) {
        setSelectedPage(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching pages:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch pages',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAllMenuItems = async () => {
    try {
      const { data, error } = await supabase
        .from('menu_items')
        .select('*')
        .order('display_order');

      if (error) throw error;
      setAllMenuItems(data || []);
    } catch (error) {
      console.error('Error fetching all menu items:', error);
    }
  };

  const fetchSections = async (pageId: string) => {
    try {
      const { data, error } = await supabase
        .from('content_sections')
        .select('*')
        .eq('page_id', pageId)
        .order('section_name');

      if (error) throw error;
      setSections(data || []);
      
      if (data && data.length > 0) {
        setSelectedSection(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching sections:', error);
    }
  };

  const fetchTranslations = async (sectionId: string) => {
    try {
      const { data, error } = await supabase
        .from('content_translations')
        .select('*')
        .eq('section_id', sectionId)
        .order('content_key');

      if (error) throw error;
      setTranslations(data || []);
    } catch (error) {
      console.error('Error fetching translations:', error);
    }
  };

  const saveTranslation = async (translationId: string, value: string) => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('content_translations')
        .update({ content_value: value })
        .eq('id', translationId);

      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Translation updated successfully',
      });
    } catch (error) {
      console.error('Error saving translation:', error);
      toast({
        title: 'Error',
        description: 'Failed to update translation',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const addNewTranslation = async (contentKey: string) => {
    if (!selectedSection) return;

    setSaving(true);
    try {
      // Add for both languages
      const newTranslations = [
        {
          section_id: selectedSection,
          language_code: 'da' as const,
          content_key: contentKey,
          content_value: '',
          content_type: 'text'
        },
        {
          section_id: selectedSection,
          language_code: 'en' as const,
          content_key: contentKey,
          content_value: '',
          content_type: 'text'
        }
      ];

      const { error } = await supabase
        .from('content_translations')
        .insert(newTranslations);

      if (error) throw error;
      
      await fetchTranslations(selectedSection);
      toast({
        title: 'Success',
        description: 'New translation key added',
      });
    } catch (error) {
      console.error('Error adding translation:', error);
      toast({
        title: 'Error',
        description: 'Failed to add translation',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const handleMenuItemToggle = async (id: string, isVisible: boolean) => {
    try {
      await updateMenuItem(id, { is_visible: isVisible });
      await fetchAllMenuItems();
      toast({
        title: 'Success',
        description: 'Menu item updated successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update menu item',
        variant: 'destructive',
      });
    }
  };

  const groupedTranslations = translations.reduce((acc, translation) => {
    if (!acc[translation.content_key]) {
      acc[translation.content_key] = {};
    }
    acc[translation.content_key][translation.language_code] = translation;
    return acc;
  }, {} as Record<string, Record<string, ContentTranslation>>);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-lg">Loading content management...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Content Management</h1>
        <p className="text-muted-foreground">Manage translations, content, and menu visibility across all pages and languages</p>
      </div>

      <Tabs defaultValue="content" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="content">Content & Translations</TabsTrigger>
          <TabsTrigger value="email">Email Templates</TabsTrigger>
          <TabsTrigger value="sms">SMS Notifications</TabsTrigger>
          <TabsTrigger value="menu">Menu Settings</TabsTrigger>
          <TabsTrigger value="blog">Blog Management</TabsTrigger>
          <TabsTrigger value="seo">SEO Tools</TabsTrigger>
        </TabsList>
        
        <TabsContent value="content" className="mt-6">

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Pages Sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Pages</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {pages.map((page) => (
                  <Button
                    key={page.id}
                    variant={selectedPage === page.id ? 'default' : 'ghost'}
                    className="w-full justify-start"
                    onClick={() => setSelectedPage(page.id)}
                  >
                    {page.page_name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Sections */}
          {selectedPage && (
            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-lg">Sections</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sections.map((section) => (
                    <Button
                      key={section.id}
                      variant={selectedSection === section.id ? 'default' : 'ghost'}
                      className="w-full justify-start text-sm"
                      onClick={() => setSelectedSection(section.id)}
                    >
                      {section.section_name}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Content Area */}
        <div className="lg:col-span-3">
          {selectedSection ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Translations</span>
                  <Button
                    onClick={() => {
                      const key = prompt('Enter new content key:');
                      if (key) addNewTranslation(key);
                    }}
                    size="sm"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Key
                  </Button>
                </CardTitle>
                <CardDescription>
                  Manage translations for {sections.find(s => s.id === selectedSection)?.section_name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {Object.entries(groupedTranslations).map(([contentKey, languages]) => (
                    <div key={contentKey} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-semibold text-lg">{contentKey}</h3>
                        <Badge variant="outline">{contentKey}</Badge>
                      </div>
                      
                      <Tabs defaultValue="da" className="w-full">
                         <TabsList className="grid w-full grid-cols-2">
                           <TabsTrigger value="da" className="flex items-center gap-2">
                             <CountryFlag code="DK" size="sm" />
                             Danish
                           </TabsTrigger>
                           <TabsTrigger value="en" className="flex items-center gap-2">
                             <CountryFlag code="GB" size="sm" />
                             English
                           </TabsTrigger>
                         </TabsList>
                        
                        {(['da', 'en'] as const).map((lang) => (
                          <TabsContent key={lang} value={lang} className="mt-4">
                            {languages[lang] ? (
                              <TranslationEditor
                                translation={languages[lang]}
                                onSave={(value) => saveTranslation(languages[lang].id, value)}
                                saving={saving}
                              />
                            ) : (
                              <div className="text-muted-foreground">No translation found for {lang}</div>
                            )}
                          </TabsContent>
                        ))}
                      </Tabs>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="py-12">
                <div className="text-center text-muted-foreground">
                  Select a page and section to manage translations
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
        </TabsContent>
        
        <TabsContent value="email" className="mt-6">
          <EmailTemplateManager />
        </TabsContent>
        
        <TabsContent value="sms" className="mt-6">
          <SMSTemplateManager />
        </TabsContent>
        
        <TabsContent value="menu" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Menu Item Visibility
              </CardTitle>
              <CardDescription>
                Control which menu items appear in the header navigation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {allMenuItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <h3 className="font-medium">{item.menu_name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Key: {item.menu_key} • Link: {item.href}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-muted-foreground">
                        {item.is_visible ? 'Visible' : 'Hidden'}
                      </span>
                      <Switch
                        checked={item.is_visible}
                        onCheckedChange={(checked) => handleMenuItemToggle(item.id, checked)}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="blog" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button className="w-full justify-start" variant="outline">
                    <Plus className="w-4 h-4 mr-2" />
                    Create New Post
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Settings className="w-4 h-4 mr-2" />
                    Manage Categories
                  </Button>
                  <Button className="w-full justify-start" variant="outline">
                    <Settings className="w-4 h-4 mr-2" />
                    Media Library
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Blog Posts</CardTitle>
                <CardDescription>
                  Latest blog posts across all markets
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-muted-foreground">
                  No blog posts yet. Create your first post to get started.
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Blog Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Posts</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Published</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Drafts</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Categories</span>
                    <span className="font-medium">0</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Market Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <CountryFlag code="DK" size="sm" />
                      Denmark
                    </span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <CountryFlag code="GB" size="sm" />
                      United Kingdom
                    </span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <CountryFlag code="DE" size="sm" />
                      Germany
                    </span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <CountryFlag code="US" size="sm" />
                      United States
                    </span>
                    <span className="font-medium">0</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Views</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">This Month</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Avg. per Post</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Top Category</span>
                    <span className="font-medium">-</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="seo" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  SEO Management
                </CardTitle>
                <CardDescription>
                  Manage meta tags, redirects, and site optimization
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Meta Tags</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Manage SEO meta tags for all pages across markets
                    </p>
                    <Button variant="outline" size="sm">
                      Manage Meta Tags
                    </Button>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">URL Redirects</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Set up 301/302 redirects for improved SEO
                    </p>
                    <Button variant="outline" size="sm">
                      Manage Redirects
                    </Button>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Sitemaps</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Generate and manage XML sitemaps
                    </p>
                    <Button variant="outline" size="sm">
                      Generate Sitemaps
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>SEO Health Check</CardTitle>
                <CardDescription>
                  Overview of SEO performance across markets
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Meta Titles</span>
                      <span className="text-green-600">✓ Good</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Meta Descriptions</span>
                      <span className="text-yellow-600">⚠ Needs Work</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Image Alt Tags</span>
                      <span className="text-red-600">✗ Issues Found</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Schema Markup</span>
                      <span className="text-green-600">✓ Good</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Mobile Friendly</span>
                      <span className="text-green-600">✓ Good</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Page Speed</span>
                      <span className="text-yellow-600">⚠ Moderate</span>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <h4 className="font-medium mb-2">Quick Actions</h4>
                    <div className="space-y-2">
                      <Button variant="outline" size="sm" className="w-full justify-start">
                        Run SEO Audit
                      </Button>
                      <Button variant="outline" size="sm" className="w-full justify-start">
                        Generate Schema
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Meta Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">156</div>
                <p className="text-xs text-muted-foreground">Pages with meta tags</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Redirects</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">23</div>
                <p className="text-xs text-muted-foreground">Active redirects</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Sitemaps</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4</div>
                <p className="text-xs text-muted-foreground">Generated sitemaps</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Schema Types</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8</div>
                <p className="text-xs text-muted-foreground">Structured data types</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface TranslationEditorProps {
  translation: ContentTranslation;
  onSave: (value: string) => void;
  saving: boolean;
}

const TranslationEditor: React.FC<TranslationEditorProps> = ({ translation, onSave, saving }) => {
  const [value, setValue] = useState(translation.content_value);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = () => {
    onSave(value);
    setIsEditing(false);
  };

  if (!isEditing) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Current value:</span>
          <Button variant="ghost" size="sm" onClick={() => setIsEditing(true)}>
            <Edit2 className="w-4 h-4 mr-2" />
            Edit
          </Button>
        </div>
        <div className="p-3 bg-muted rounded-md min-h-[40px]">
          {translation.content_value || <span className="text-muted-foreground">No content</span>}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Textarea
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Enter translation..."
        rows={3}
      />
      <div className="flex gap-2">
        <Button onClick={handleSave} disabled={saving}>
          <Save className="w-4 h-4 mr-2" />
          {saving ? 'Saving...' : 'Save'}
        </Button>
        <Button variant="ghost" onClick={() => {
          setValue(translation.content_value);
          setIsEditing(false);
        }}>
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default ContentManagementAdmin;