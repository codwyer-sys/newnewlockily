import React, { useState, useEffect } from 'react';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import NumberStepper from "@/components/ui/number-stepper";

interface Question {
  question_key: string;
  question_type: 'radio' | 'number' | 'text' | 'checkbox';
  options?: string[];
  option_icons?: Record<string, string>;
}

interface QuestionInputProps {
  question: Question;
  answer: any;
  onAnswerSelect: (answer: any) => void;
  onCheckboxChange: (option: string, checked: boolean) => void;
}

const QuestionInput: React.FC<QuestionInputProps> = ({
  question,
  answer,
  onAnswerSelect,
  onCheckboxChange
}) => {
  const [otherDetails, setOtherDetails] = useState('');

  // Helper function to check if an option is "Other"
  const isOtherOption = (option: string) => {
    return option.toLowerCase() === 'andet' || option.toLowerCase() === 'other';
  };

  // Helper function to get the current answer for "Other" options
  const getAnswerValue = (option: string) => {
    if (isOtherOption(option) && typeof answer === 'object' && answer?.selection === option) {
      return answer.selection;
    }
    return typeof answer === 'string' ? answer : '';
  };

  // Helper function to handle "Other" selection with details
  const handleOtherAnswer = (option: string, details: string = '') => {
    if (isOtherOption(option)) {
      onAnswerSelect({ selection: option, details });
    } else {
      onAnswerSelect(option);
    }
  };

  // Update other details when answer changes
  useEffect(() => {
    if (typeof answer === 'object' && answer?.details) {
      setOtherDetails(answer.details);
    } else if (typeof answer === 'string' && !isOtherOption(answer)) {
      setOtherDetails('');
    }
  }, [answer]);
  switch (question.question_type) {
    case 'radio':
      return (
        <div className="space-y-3">
          <RadioGroup 
            value={answer || ""} 
            onValueChange={onAnswerSelect}
            className="space-y-2"
          >
            {question.options?.map((option) => {
              const isSelected = getAnswerValue(option) === option || 
                (typeof answer === 'object' && answer?.selection === option);
              const icon = question.option_icons?.[option] || '';
              const isOther = isOtherOption(option);
              
              return (
                <div key={option} className="space-y-3">
                  <div 
                    className={`bg-white border-2 rounded-lg p-4 hover:border-primary/50 transition-all duration-200 cursor-pointer ${
                      isSelected ? 'border-primary bg-primary/5' : 'border-border hover:bg-primary/5'
                    }`}
                    onClick={() => handleOtherAnswer(option, isOther ? otherDetails : '')}
                  >
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem 
                        value={option} 
                        id={`${question.question_key}-${option}`} 
                        className="text-primary border-primary flex-shrink-0" 
                      />
                      {icon && (
                        <span className="text-xl flex-shrink-0">{icon}</span>
                      )}
                      <Label 
                        htmlFor={`${question.question_key}-${option}`} 
                        className={`cursor-pointer flex-1 font-headline font-semibold text-left ${
                          isSelected ? 'text-primary' : 'text-card-foreground'
                        }`}
                      >
                        {option}
                      </Label>
                    </div>
                  </div>
                  
                  {/* Show additional text input for "Other" options when selected */}
                  {isOther && isSelected && (
                    <div className="ml-8 animate-fade-in">
                      <Input
                        type="text"
                        value={otherDetails}
                        onChange={(e) => {
                          setOtherDetails(e.target.value);
                          handleOtherAnswer(option, e.target.value);
                        }}
                        className="bg-white border-2 border-border focus:border-primary"
                        placeholder="Tilføj detaljer..."
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </RadioGroup>
        </div>
      );

    case 'checkbox':
      return (
        <div className="space-y-3">
          {question.options?.map((option) => {
            const isSelected = (answer || []).some((item: any) => 
              typeof item === 'string' ? item === option : item?.selection === option
            );
            const icon = question.option_icons?.[option] || '';
            const isOther = isOtherOption(option);
            const selectedOtherItem = (answer || []).find((item: any) => 
              typeof item === 'object' && item?.selection === option
            );
            const currentOtherDetails = selectedOtherItem?.details || '';
            
            return (
              <div key={option} className="space-y-3">
                <div 
                  className={`bg-white border-2 rounded-lg p-4 hover:border-primary/50 transition-all duration-200 cursor-pointer ${
                    isSelected ? 'border-primary bg-primary/5' : 'border-border hover:bg-primary/5'
                  }`}
                  onClick={() => {
                    if (isOther) {
                      const currentAnswers = answer || [];
                      const otherItemIndex = currentAnswers.findIndex((item: any) => 
                        typeof item === 'object' && item?.selection === option
                      );
                      
                      if (otherItemIndex >= 0) {
                        // Remove other item
                        const newAnswers = currentAnswers.filter((_: any, index: number) => index !== otherItemIndex);
                        onAnswerSelect(newAnswers);
                      } else {
                        // Add other item
                        const newAnswers = [...currentAnswers, { selection: option, details: '' }];
                        onAnswerSelect(newAnswers);
                      }
                    } else {
                      onCheckboxChange(option, !isSelected);
                    }
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      id={`${question.question_key}-${option}`}
                      checked={isSelected}
                      onCheckedChange={(checked) => {
                        if (isOther) {
                          const currentAnswers = answer || [];
                          if (checked) {
                            const newAnswers = [...currentAnswers, { selection: option, details: '' }];
                            onAnswerSelect(newAnswers);
                          } else {
                            const newAnswers = currentAnswers.filter((item: any) => 
                              !(typeof item === 'object' && item?.selection === option)
                            );
                            onAnswerSelect(newAnswers);
                          }
                        } else {
                          onCheckboxChange(option, checked as boolean);
                        }
                      }}
                      className="border-primary data-[state=checked]:bg-primary flex-shrink-0"
                    />
                    {icon && (
                      <span className="text-xl flex-shrink-0">{icon}</span>
                    )}
                    <Label 
                      htmlFor={`${question.question_key}-${option}`} 
                      className={`cursor-pointer flex-1 font-headline font-semibold text-left ${
                        isSelected ? 'text-primary' : 'text-card-foreground'
                      }`}
                    >
                      {option}
                    </Label>
                  </div>
                </div>
                
                {/* Show additional text input for "Other" options when selected */}
                {isOther && isSelected && (
                  <div className="ml-8 animate-fade-in">
                    <Input
                      type="text"
                      value={currentOtherDetails}
                      onChange={(e) => {
                        const currentAnswers = answer || [];
                        const newAnswers = currentAnswers.map((item: any) => 
                          typeof item === 'object' && item?.selection === option
                            ? { ...item, details: e.target.value }
                            : item
                        );
                        onAnswerSelect(newAnswers);
                      }}
                      className="bg-white border-2 border-border focus:border-primary"
                      placeholder="Tilføj detaljer..."
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      );

    case 'number':
      return (
        <div className="flex justify-center">
          <NumberStepper
            value={parseInt(answer) || 1}
            onChange={(value) => onAnswerSelect(value.toString())}
            min={1}
            className="bg-white"
          />
        </div>
      );

    case 'text':
      return (
        <Input
          type="text"
          value={answer || ""}
          onChange={(e) => onAnswerSelect(e.target.value)}
          className="bg-white border-2 border-border focus:border-primary"
          placeholder="Dit svar..."
        />
      );

    default:
      return null;
  }
};

export default QuestionInput;