import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Phone, Menu, X, ChevronDown } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import LanguagePicker from '@/components/LanguagePicker';
import { useMenuItems } from '@/hooks/useMenuItems';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { useHeaderTheme } from '@/contexts/HeaderThemeContext';
import { useIsMobile } from '@/hooks/use-mobile';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '@/components/ui/navigation-menu';
import { CitiesMegaMenu } from '@/components/CitiesMegaMenu';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

const Header = () => {
  const { t } = useLanguage();
  const { menuItems } = useMenuItems();
  const { generateUrl } = useMarketUrl();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [citiesOpen, setCitiesOpen] = useState(false);
  const { theme } = useHeaderTheme();
  const isDarkBackground = theme === 'dark';
  const isMobile = useIsMobile();

  // Convert database href to market-aware URL
  const getMenuUrl = (href) => {
    if (!href || !href.startsWith('/')) return href; // External links stay as-is
    return generateUrl(href); // Convert /blog to /se/blog etc.
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      {/* Single backdrop with smooth gradient fade */}
      <div className="absolute inset-0 h-16 backdrop-blur-sm bg-gradient-to-b from-background/10 to-transparent"></div>
      <div className="relative container-wide pt-4 pb-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <img 
              src={isDarkBackground ? "/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png" : "/lovable-uploads/57166235-1698-4ec1-b97a-4f4ed9310ab8.png"}
              alt="Lockily" 
              className="h-16 w-auto transition-all duration-300"
            />
          </Link>

          {/* Navigation - Desktop */}
          <NavigationMenu className="hidden md:flex">
            <NavigationMenuList className="space-x-2">
              {/* Cities Mega Menu */}
              <NavigationMenuItem>
                <NavigationMenuTrigger 
                  className={`text-foreground font-medium hover:text-primary transition-colors px-3 py-2 rounded-md hover:bg-background/20 backdrop-blur-sm bg-transparent ${isDarkBackground ? 'text-white hover:text-white data-[state=open]:text-white' : ''}`}
                >
                  Cities
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <CitiesMegaMenu />
                </NavigationMenuContent>
              </NavigationMenuItem>

              {/* Regular Menu Items */}
              {menuItems.map((item) => {
                const linkClass = `text-foreground font-medium hover:text-primary transition-colors px-3 py-2 rounded-md hover:bg-background/20 backdrop-blur-sm ${isDarkBackground ? 'text-white hover:text-white' : ''}`;
                const menuUrl = getMenuUrl(item.href);
                
                return (
                  <NavigationMenuItem key={item.menu_key}>
                    {item.href && item.href.startsWith('/') ? (
                      <Link to={menuUrl} className={linkClass}>
                        {item.menu_name}
                      </Link>
                    ) : (
                      <a href={menuUrl} className={linkClass}>
                        {item.menu_name}
                      </a>
                    )}
                  </NavigationMenuItem>
                );
              })}
            </NavigationMenuList>
          </NavigationMenu>

          {/* Desktop: Language + Book Now + Mobile Menu Button */}
          {/* Mobile: Only Menu Button */}
          <div className="flex items-center space-x-4">
            {/* Language Picker - Desktop Only */}
            {!isMobile && (
              <div className={`transition-colors ${isDarkBackground ? 'text-white' : ''}`}>
                <LanguagePicker />
              </div>
            )}
            
            {/* Book Now Button - Desktop Only */}
            {!isMobile && (
              <Button size="sm" className="font-headline bg-primary text-primary-foreground hover:bg-primary/90">
                {t('header.cta.book_now')}
              </Button>
            )}
            
            {/* Mobile Menu Toggle */}
            {isMobile && (
              <Button 
                variant="ghost" 
                size="sm" 
                className={`transition-colors ${isDarkBackground ? 'text-white hover:text-white' : 'text-foreground'}`}
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            )}
          </div>
        </div>

        {/* Mobile Menu - Simplified Structure */}
        {mobileMenuOpen && isMobile && (
          <div className="absolute top-full left-0 right-0 z-40 bg-background/95 backdrop-blur-md border-t border-border shadow-lg">
            <nav className="container-wide py-4 space-y-1">
              {/* Language Picker at top */}
              <div className="pb-3 mb-3 border-b border-border">
                <LanguagePicker />
              </div>
              
              {/* Cities Section with Collapsible */}
              <Collapsible open={citiesOpen} onOpenChange={setCitiesOpen}>
                <CollapsibleTrigger className="flex items-center justify-between w-full px-3 py-3 text-left font-medium hover:bg-accent/50 rounded-md transition-colors">
                  <span>Cities</span>
                  <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${citiesOpen ? 'rotate-180' : ''}`} />
                </CollapsibleTrigger>
                <CollapsibleContent className="overflow-hidden data-[state=open]:animate-accordion-down data-[state=closed]:animate-accordion-up">
                  <div className="px-6 pb-2">
                    <CitiesMegaMenu />
                  </div>
                </CollapsibleContent>
              </Collapsible>
              
              {/* Regular Menu Items */}
              {menuItems.map((item) => {
                const menuUrl = getMenuUrl(item.href);
                
                if (item.href && item.href.startsWith('/')) {
                  return (
                    <Link 
                      key={item.menu_key} 
                      to={menuUrl} 
                      className="block px-3 py-3 font-medium hover:bg-accent/50 rounded-md transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.menu_name}
                    </Link>
                  );
                } else {
                  return (
                    <a 
                      key={item.menu_key} 
                      href={menuUrl} 
                      className="block px-3 py-3 font-medium hover:bg-accent/50 rounded-md transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.menu_name}
                    </a>
                  );
                }
              })}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;