import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle, ExternalLink } from 'lucide-react';
import { getRequirementInfo, getRequirements } from '@/utils/stripeRequirements';

interface Props {
  accountStatus: any;
}

const StripeRequirements: React.FC<Props> = ({ accountStatus }) => {
  const requirements = getRequirements(accountStatus);

  if (requirements.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-muted-foreground">Påkrævede handlinger</label>
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 space-y-3">
        {requirements.map((requirement, index) => {
          const reqInfo = getRequirementInfo(requirement);
          return (
            <div key={index} className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-medium text-sm">{reqInfo.title}</p>
                    <p className="text-sm text-muted-foreground">{reqInfo.description}</p>
                  </div>
                </div>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  console.log('Button clicked, onboarding URL:', accountStatus.onboardingUrl);
                  if (accountStatus.onboardingUrl) {
                    window.open(accountStatus.onboardingUrl, '_blank');
                  } else {
                    console.error('No onboarding URL available');
                  }
                }}
                className="ml-4 flex-shrink-0"
              >
                <ExternalLink className="h-3 w-3 mr-1" />
                {reqInfo.actionText}
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StripeRequirements;