
import React from 'react';

interface QuestionProgressIndicatorProps {
  currentIndex: number;
  totalQuestions: number;
}

const QuestionProgressIndicator: React.FC<QuestionProgressIndicatorProps> = ({
  currentIndex,
  totalQuestions
}) => {
  return (
    <div className="flex items-center gap-apple-2">
      <div className="flex-1 glass rounded-apple-capsule h-2">
        <div 
          className="bg-system-blue h-2 rounded-apple-capsule transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
        />
      </div>
    </div>
  );
};

export default QuestionProgressIndicator;
