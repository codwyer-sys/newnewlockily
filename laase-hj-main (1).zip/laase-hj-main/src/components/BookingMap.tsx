import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { supabase } from '@/integrations/supabase/client';

interface BookingMapProps {
  address: string;
}

const BookingMap: React.FC<BookingMapProps> = ({ address }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    if (!mapContainer.current) return;

    // MapBox public token - this will be loaded from edge function in production
    mapboxgl.accessToken = 'pk.eyJ1IjoibG9ja2lseSIsImEiOiJjbWNxMGpseXowZDNzMmpyMjYzOWE4cjJkIn0.3mcKSl4a-lHwZwhHJGssMQ';
    
    // Initialize map with Copenhagen as default center
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [12.5683, 55.6761], // Copenhagen
      zoom: 14,
    });

    map.current.on('load', () => {
      setIsLoading(false);
      
      // Geocode and add marker for the address
      if (address) {
        geocodeAndAddMarker(address);
      } else {
        // Add default marker for Copenhagen
        new mapboxgl.Marker({ color: '#ef4444' })
          .setLngLat([12.5683, 55.6761])
          .addTo(map.current!);
      }
    });

    return () => {
      map.current?.remove();
    };
  }, []);

  const geocodeAndAddMarker = async (address: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('geocode-with-cache', {
        body: { address }
      });

      if (error) {
        throw error;
      }

      if (data?.latitude && data?.longitude) {
        const lng = data.longitude;
        const lat = data.latitude;
        
        // Update map center and add marker
        map.current?.setCenter([lng, lat]);
        new mapboxgl.Marker({ color: '#ef4444' })
          .setLngLat([lng, lat])
          .setPopup(new mapboxgl.Popup().setHTML(`<div class="font-medium">${address}</div>`))
          .addTo(map.current!);
      }
    } catch (error) {
      console.error('Geocoding failed:', error);
      // Fallback marker at Copenhagen
      new mapboxgl.Marker({ color: '#ef4444' })
        .setLngLat([12.5683, 55.6761])
        .addTo(map.current!);
    }
  };

  return (
    <div className="relative h-64 w-full overflow-hidden rounded-lg">
      <div ref={mapContainer} className="absolute inset-0" />
      {isLoading && (
        <div className="absolute inset-0 bg-muted/50 flex items-center justify-center rounded-lg">
          <div className="text-muted-foreground">Loading map...</div>
        </div>
      )}
      {/* Brand overlay */}
      <div className="absolute inset-0 bg-primary/10 pointer-events-none rounded-lg"></div>
    </div>
  );
};

export default BookingMap;