import React, { forwardRef, useEffect, useLayoutEffect, useRef } from 'react';
import Quill from 'quill';
import 'quill/dist/quill.snow.css';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface QuillEditorProps {
  value: string;
  onChange: (content: string) => void;
  placeholder?: string;
  className?: string;
}

const QuillEditor = forwardRef<HTMLDivElement, QuillEditorProps>(
  ({ value, onChange, placeholder = "Start writing...", className = "" }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const quillRef = useRef<Quill | null>(null);

    useLayoutEffect(() => {
      if (!containerRef.current) return;

      // Create Quill instance
      const quill = new Quill(containerRef.current, {
        theme: 'snow',
        placeholder,
        modules: {
          toolbar: [
            [{ 'header': [1, 2, 3, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'align': [] }],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            ['blockquote', 'code-block'],
            ['link', 'image'],
            ['clean']
          ],
        },
        formats: [
          'header', 'bold', 'italic', 'underline', 'strike',
          'color', 'background', 'align', 'list', 'bullet',
          'blockquote', 'code-block', 'link', 'image'
        ]
      });

      // Custom image handler
      const toolbar = quill.getModule('toolbar') as any;
      toolbar.addHandler('image', () => {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
        input.click();

        input.onchange = async () => {
          const file = input.files?.[0];
          if (file) {
            const range = quill.getSelection();
            if (range) {
              // Show loading state
              quill.insertText(range.index, 'Uploading image...', 'user');
              
              try {
                const fileName = `blog-images/${Date.now()}-${file.name}`;
                const { data, error } = await supabase.storage
                  .from('blog-media')
                  .upload(fileName, file, {
                    cacheControl: '3600',
                    upsert: false
                  });

                if (error) throw error;

                const { data: { publicUrl } } = supabase.storage
                  .from('blog-media')
                  .getPublicUrl(fileName);

                // Remove loading text and insert image
                quill.deleteText(range.index, 'Uploading image...'.length);
                quill.insertEmbed(range.index, 'image', publicUrl, 'user');
                quill.setSelection(range.index + 1);

                toast.success('Image uploaded successfully');
              } catch (error) {
                console.error('Image upload error:', error);
                quill.deleteText(range.index, 'Uploading image...'.length);
                toast.error('Failed to upload image');
              }
            }
          }
        };
      });

      // Handle content changes
      quill.on('text-change', () => {
        const html = quill.root.innerHTML;
        onChange(html === '<p><br></p>' ? '' : html);
      });

      quillRef.current = quill;

      return () => {
        quillRef.current = null;
      };
    }, []);

    // Update content when value changes
    useEffect(() => {
      if (quillRef.current) {
        const currentContent = quillRef.current.root.innerHTML;
        if (currentContent !== value && value !== (currentContent === '<p><br></p>' ? '' : currentContent)) {
          quillRef.current.root.innerHTML = value || '';
        }
      }
    }, [value]);

    return (
      <>
        <style>{`
          .quill-editor .ql-toolbar {
            border: 1px solid hsl(var(--border));
            border-radius: 0.5rem 0.5rem 0 0;
            background: hsl(var(--background));
          }
          .quill-editor .ql-container {
            border: 1px solid hsl(var(--border));
            border-top: none;
            border-radius: 0 0 0.5rem 0.5rem;
            background: hsl(var(--background));
            color: hsl(var(--foreground));
            font-family: inherit;
          }
          .quill-editor .ql-editor {
            min-height: 300px;
            line-height: 1.6;
          }
          .quill-editor .ql-editor.ql-blank::before {
            color: hsl(var(--muted-foreground));
            font-style: normal;
          }
          .quill-editor .ql-snow .ql-picker-options {
            background: hsl(var(--background));
            border: 1px solid hsl(var(--border));
          }
          .quill-editor .ql-snow .ql-picker-item:hover {
            background: hsl(var(--accent));
          }
        `}</style>
        <div className={`quill-editor ${className}`}>
          <div ref={containerRef} />
        </div>
      </>
    );
  }
);

QuillEditor.displayName = 'QuillEditor';

export default QuillEditor;