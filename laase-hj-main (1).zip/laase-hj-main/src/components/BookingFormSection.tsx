
import React from 'react';
import { useToast } from "@/hooks/use-toast";
import BookingFormContent from "@/components/BookingFormContent";
import BookingButtons from "@/components/BookingButtons";
import { GlassCard } from "@/components/ui/glass-card";
import { useBookingForm } from "@/hooks/useBookingForm";
import { useBookingFormValidation } from "@/hooks/useBookingFormValidation";
import { useLanguage } from '@/contexts/LanguageContext';
import { useMarket } from '@/contexts/MarketContext';

interface BookingFormSectionProps {
  onStartBooking: (bookingData: {
    address: string;
    urgency: string;
    selectedDate: string;
    jobType: string;
    followUpAnswers: Record<string, any>;
  }) => void;
}

const BookingFormSection: React.FC<BookingFormSectionProps> = ({ onStartBooking }) => {
  const { toast } = useToast();
  const { language } = useLanguage();
  const { market } = useMarket();
  
  const {
    address,
    setAddress,
    skipAddressSearch,
    setSkipAddressSearch,
    showSuggestions,
    setShowSuggestions,
    hasSelectedSuggestion,
    setHasSelectedSuggestion,
    urgency,
    setUrgency,
    selectedDate,
    setSelectedDate,
    jobType,
    setJobType,
    followUpAnswers,
    setFollowUpAnswers,
    showUrgency,
    showJobType,
    showFollowUp,
    getRequiredQuestionsForJobType
  } = useBookingForm();

  const { isBookingDisabled, allFollowUpAnswered } = useBookingFormValidation({
    address,
    urgency,
    selectedDate,
    jobType,
    followUpAnswers,
    getRequiredQuestionsForJobType
  });

  const handleUrgencySelect = (selectedUrgency: string) => {
    setUrgency(selectedUrgency);
    if (selectedUrgency === "nu") {
      setSelectedDate("");
    }
  };

  const handleJobTypeSelect = (type: string | { selection: string; details: string }) => {
    setJobType(type);
    setFollowUpAnswers({});
  };

  const handleFollowUpAnswer = (questionKey: string, answer: any) => {
    setFollowUpAnswers(prev => ({
      ...prev,
      [questionKey]: answer
    }));
  };

  const handleStartBooking = async () => {
    if (!address || !urgency || !jobType) {
      toast({
        title: "Manglende oplysninger",
        description: "Udfyld venligst alle felter for at fortsætte",
        variant: "destructive"
      });
      return;
    }

    if (urgency === "senere" && !selectedDate) {
      toast({
        title: "Vælg tidspunkt",
        description: "Vælg venligst hvornår du har brug for hjælp",
        variant: "destructive"
      });
      return;
    }

    const jobTypeId = typeof jobType === 'object' ? jobType.selection : jobType;
    const requiredQuestions = await getRequiredQuestionsForJobType(jobTypeId);
    const missingAnswers = requiredQuestions.filter(q => !followUpAnswers[q]);
    
    if (missingAnswers.length > 0) {
      toast({
        title: "Udfyld alle felter",
        description: "Besvar venligst alle påkrævede spørgsmål for at fortsætte",
        variant: "destructive"
      });
      return;
    }

    console.log('Starting booking with:', { address, urgency, selectedDate, jobType, followUpAnswers, languageCode: language, marketCode: market.country_code });
    
    // Extract jobType details for storage
    const jobTypeForStorage = typeof jobType === 'object' && jobType ? jobType.selection : (jobType as string);
    const jobTypeDetails = typeof jobType === 'object' && jobType ? jobType.details : null;
    
    const finalFollowUpAnswers = {
      ...followUpAnswers,
      preferredLanguage: language,
      marketCode: market.country_code
    };
    
    // Add job type details if it's an "Other" selection
    if (jobTypeDetails) {
      finalFollowUpAnswers['jobTypeDetails'] = jobTypeDetails;
    }
    
    onStartBooking({ 
      address, 
      urgency, 
      selectedDate, 
      jobType: jobTypeForStorage, 
      followUpAnswers: finalFollowUpAnswers
    });
  };

  return (
    <div className="px-apple-4">
      <div className="container mx-auto max-w-2xl">
        <GlassCard 
          variant="thick" 
          floating={true}
          className="p-apple-6 md:p-apple-8"
        >
          <BookingFormContent
            address={address}
            setAddress={setAddress}
            skipAddressSearch={skipAddressSearch}
            setSkipAddressSearch={setSkipAddressSearch}
            showSuggestions={showSuggestions}
            setShowSuggestions={setShowSuggestions}
            hasSelectedSuggestion={hasSelectedSuggestion}
            setHasSelectedSuggestion={setHasSelectedSuggestion}
            urgency={urgency}
            selectedDate={selectedDate}
            onUrgencySelect={handleUrgencySelect}
            onDateChange={setSelectedDate}
            showUrgency={showUrgency}
            jobType={jobType}
            onJobTypeSelect={handleJobTypeSelect}
            showJobType={showJobType}
            followUpAnswers={followUpAnswers}
            onFollowUpAnswer={handleFollowUpAnswer}
            showFollowUp={showFollowUp}
          />
        </GlassCard>

        <BookingButtons
          onStartBooking={handleStartBooking}
          isDisabled={isBookingDisabled}
          allFollowUpAnswered={allFollowUpAnswered}
        />
      </div>
    </div>
  );
};

export default BookingFormSection;
