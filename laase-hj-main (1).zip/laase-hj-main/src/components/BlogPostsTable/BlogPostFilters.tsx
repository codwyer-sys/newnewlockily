import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Search, X, Globe, Folder, Filter } from 'lucide-react';
import { getCountryFlag } from '@/utils/countryFlags';

interface BlogPostFiltersProps {
  filters: {
    search: string;
    market: string;
    categories: string[];
    status: string;
    author: string;
  };
  markets: Array<{ country_code: string; country_name: string }>;
  categories: Array<{ id: string; name: string; market_code?: string }>;
  onFiltersChange: (filters: any) => void;
  onClearFilters: () => void;
  totalCount: number;
}

export const BlogPostFilters: React.FC<BlogPostFiltersProps> = ({
  filters,
  markets,
  categories,
  onFiltersChange,
  onClearFilters,
  totalCount
}) => {
  // Filter categories based on selected market
  const filteredCategories = categories.filter(category => 
    !filters.market || 
    filters.market === 'all' || 
    !category.market_code || 
    category.market_code === filters.market
  );

  const handleSearchChange = (value: string) => {
    onFiltersChange({ ...filters, search: value });
  };

  const handleMarketChange = (value: string) => {
    onFiltersChange({ 
      ...filters, 
      market: value,
      categories: [] // Clear categories when market changes
    });
  };

  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    const newCategories = checked
      ? [...filters.categories, categoryId]
      : filters.categories.filter(id => id !== categoryId);
    
    onFiltersChange({ ...filters, categories: newCategories });
  };

  const handleStatusChange = (value: string) => {
    onFiltersChange({ ...filters, status: value });
  };

  const hasActiveFilters = 
    filters.search || 
    filters.market !== 'all' || 
    filters.categories.length > 0 || 
    filters.status !== 'all';

  return (
    <Card className="h-fit">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
          {hasActiveFilters && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClearFilters}
              className="text-xs"
            >
              <X className="h-3 w-3 mr-1" />
              Clear
            </Button>
          )}
        </div>
        <p className="text-sm text-muted-foreground">
          {totalCount} posts found
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Search */}
        <div className="space-y-2">
          <Label htmlFor="search">Search</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="search"
              placeholder="Search posts..."
              value={filters.search}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Separator />

        {/* Market Filter */}
        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Market
          </Label>
          <Select value={filters.market} onValueChange={handleMarketChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select market" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Markets</SelectItem>
              {markets.map((market) => (
                <SelectItem key={market.country_code} value={market.country_code}>
                  <div className="flex items-center gap-2">
                    <span>{getCountryFlag(market.country_code)}</span>
                    <span>{market.country_name}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator />

        {/* Categories Filter */}
        {filteredCategories.length > 0 && (
          <>
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Folder className="h-4 w-4" />
                Categories
                {filters.categories.length > 0 && (
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                    {filters.categories.length}
                  </span>
                )}
              </Label>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {filteredCategories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={category.id}
                      checked={filters.categories.includes(category.id)}
                      onCheckedChange={(checked) => 
                        handleCategoryChange(category.id, checked as boolean)
                      }
                    />
                    <Label 
                      htmlFor={category.id} 
                      className="text-sm font-normal cursor-pointer flex-1"
                    >
                      {category.name}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            <Separator />
          </>
        )}

        {/* Status Filter */}
        <div className="space-y-3">
          <Label>Status</Label>
          <Select value={filters.status} onValueChange={handleStatusChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
};