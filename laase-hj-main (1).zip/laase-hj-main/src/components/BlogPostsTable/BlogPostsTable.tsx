import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from '@/components/ui/pagination';
import { Eye, Edit, Copy, Trash2, Plus, Loader2, FileText, Globe, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { BlogPostFilters } from './BlogPostFilters';
import { useBlogPostsTable } from '@/hooks/useBlogPostsTable';
import { getCountryFlag } from '@/utils/countryFlags';
import { format } from 'date-fns';

const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'published':
        return 'default';
      case 'draft':
        return 'secondary';
      case 'archived':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  return (
    <Badge variant={getStatusVariant(status)} className="capitalize">
      {status}
    </Badge>
  );
};

const BlogPostsTable: React.FC = () => {
  const navigate = useNavigate();
  const {
    posts,
    loading,
    totalCount,
    currentPage,
    totalPages,
    filters,
    markets,
    categories,
    setCurrentPage,
    updateFilters,
    clearFilters,
    deletePost,
    duplicatePost
  } = useBlogPostsTable();

  const handleDelete = async (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await deletePost(id);
        toast.success('Post deleted successfully');
      } catch (error) {
        toast.error('Failed to delete post');
      }
    }
  };

  const handleDuplicate = async (post: any) => {
    try {
      await duplicatePost(post);
      toast.success('Post duplicated successfully');
    } catch (error) {
      toast.error('Failed to duplicate post');
    }
  };

  const handlePreview = (slug: string) => {
    // In a real app, this would open the public blog post URL
    toast.info('Preview functionality coming soon');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex gap-6 h-full">
      {/* Left Sidebar - Filters */}
      <div className="w-80 flex-shrink-0">
        <BlogPostFilters
          filters={filters}
          markets={markets}
          categories={categories}
          onFiltersChange={updateFilters}
          onClearFilters={clearFilters}
          totalCount={totalCount}
        />
      </div>

      {/* Right Main Area - Posts Table */}
      <div className="flex-1 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Blog Posts</h1>
            <p className="text-muted-foreground">Manage your blog content and SEO</p>
          </div>
          <Button onClick={() => navigate('/admin-portal/blog/create')}>
            <Plus className="mr-2 h-4 w-4" />
            Create New Post
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <div className="overflow-hidden">
              {/* Table Header */}
              <div className="grid grid-cols-12 gap-4 p-4 bg-muted/30 border-b text-sm font-medium text-muted-foreground">
                <div className="col-span-4">Title & Status</div>
                <div className="col-span-2">Market</div>
                <div className="col-span-2">Category</div>
                <div className="col-span-1">Views</div>
                <div className="col-span-2">Date</div>
                <div className="col-span-1">Actions</div>
              </div>

              {/* Table Body */}
              <div className="divide-y">
                {posts.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground">
                    <div className="flex flex-col items-center space-y-2">
                      <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                        <FileText className="h-6 w-6" />
                      </div>
                      <p>No blog posts found</p>
                      <p className="text-sm">Try adjusting your filters or create your first post</p>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => navigate('/admin-portal/blog/create')}
                      >
                        Create your first post
                      </Button>
                    </div>
                  </div>
                ) : (
                  posts.map((post) => (
                    <div 
                      key={post.id} 
                      className="grid grid-cols-12 gap-4 p-4 hover:bg-muted/20 transition-colors"
                    >
                      {/* Title & Status */}
                      <div className="col-span-4">
                        <div className="space-y-1">
                          <div className="font-medium line-clamp-1">{post.title}</div>
                          <div className="flex items-center gap-2">
                            <StatusBadge status={post.status} />
                            {post.excerpt && (
                              <span className="text-xs text-muted-foreground line-clamp-1">
                                {post.excerpt}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Market */}
                      <div className="col-span-2 flex items-center">
                        <div className="flex items-center gap-2">
                          {post.is_global ? (
                            <>
                              <Globe className="h-4 w-4 text-blue-500" />
                              <span className="text-sm">Global</span>
                            </>
                          ) : (
                            <>
                              <MapPin className="h-4 w-4 text-green-500" />
                              <span className="text-lg">{getCountryFlag(post.market_code)}</span>
                              <span className="text-sm">{post.market_code || 'All'}</span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Category */}
                      <div className="col-span-2 flex items-center">
                        <span className="text-sm">
                          {categories.find(c => c.id === post.category_id)?.name || 'Uncategorized'}
                        </span>
                      </div>

                      {/* Views */}
                      <div className="col-span-1 flex items-center">
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3 text-muted-foreground" />
                          <span className="text-sm">{post.view_count}</span>
                        </div>
                      </div>

                      {/* Date */}
                      <div className="col-span-2 flex items-center">
                        <div className="text-sm">
                          <div>{format(new Date(post.created_at), 'MMM dd, yyyy')}</div>
                          {post.published_at && (
                            <div className="text-xs text-muted-foreground">
                              Published {format(new Date(post.published_at), 'MMM dd')}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="col-span-1 flex items-center">
                        <div className="flex items-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handlePreview(post.slug)}
                            title="Preview"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`/admin-portal/blog/edit/${post.id}`)}
                            title="Edit"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDuplicate(post)}
                            title="Duplicate"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDelete(post.id, post.title)}
                            title="Delete"
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center">
            <Pagination>
              <PaginationContent>
                {currentPage > 1 && (
                  <PaginationItem>
                    <PaginationPrevious 
                      onClick={() => setCurrentPage(currentPage - 1)}
                      className="cursor-pointer"
                    />
                  </PaginationItem>
                )}
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const page = i + 1;
                  return (
                    <PaginationItem key={page}>
                      <PaginationLink
                        onClick={() => setCurrentPage(page)}
                        isActive={currentPage === page}
                        className="cursor-pointer"
                      >
                        {page}
                      </PaginationLink>
                    </PaginationItem>
                  );
                })}
                
                {currentPage < totalPages && (
                  <PaginationItem>
                    <PaginationNext 
                      onClick={() => setCurrentPage(currentPage + 1)}
                      className="cursor-pointer"
                    />
                  </PaginationItem>
                )}
              </PaginationContent>
            </Pagination>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogPostsTable;