import React, { useEffect } from 'react';
import { Routes, Route, useParams, useNavigate, useLocation } from 'react-router-dom';
import { useMarket } from '@/contexts/MarketContext';
import Blog from '@/pages/Blog';
import BlogPost from '@/pages/BlogPost';
import Index from '@/pages/Index';
import Admin from '@/pages/Admin';
import AdminPortal from '@/pages/AdminPortal';
import LocksmithSignup from '@/pages/LocksmithSignup';
import LocksmithPortal from '@/pages/LocksmithPortal';
import Auth from '@/pages/Auth';
import PostalCodeSafety from '@/pages/PostalCodeSafety';
import ContentAdmin from '@/pages/ContentAdmin';
import WaitingForQuotes from '@/pages/WaitingForQuotes';
import BookingStatus from '@/pages/BookingStatus';
import JobsManagement from '@/pages/JobsManagement';
import BlogPostEdit from '@/pages/BlogPostEdit';
import CityOverview from '@/pages/CityOverview';
import CityPage from '@/pages/CityPage';
import AreaPage from '@/pages/AreaPage';
import PlaceBid from '@/pages/PlaceBid';
import PaymentSuccess from '@/pages/PaymentSuccess';
import PaymentCancel from '@/pages/PaymentCancel';
import NotFound from '@/pages/NotFound';

// Market redirect component for root path
const MarketRedirect: React.FC = () => {
  const { market, isLoading } = useMarket();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && market) {
      navigate(`/${market.country_code.toLowerCase()}/`, { replace: true });
    }
  }, [market, isLoading, navigate]);

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return null;
};

// Market-aware wrapper component
const MarketWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { marketCode } = useParams<{ marketCode: string }>();
  const { setMarketByCode, market } = useMarket();
  const location = useLocation();

  useEffect(() => {
    if (marketCode && marketCode.toUpperCase() !== market.country_code) {
      setMarketByCode(marketCode.toUpperCase());
    }
  }, [marketCode, market.country_code, setMarketByCode]);

  // If market code in URL doesn't match current market, wait for sync
  if (marketCode && marketCode.toUpperCase() !== market.country_code) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return <>{children}</>;
};

export const MarketAwareRouter = () => {
  return (
    <Routes>
      {/* Root path - redirect to market-specific homepage */}
      <Route path="/" element={<MarketRedirect />} />
      
      {/* Market-specific routes */}
      <Route path="/:marketCode/*" element={
        <MarketWrapper>
          <Routes>
            <Route index element={<Index />} />
            <Route path="blog" element={<Blog />} />
            <Route path="blog/:categorySlug/:postSlug" element={<BlogPost />} />
            <Route path="blog/:slug" element={<BlogPost />} /> {/* Backward compatibility */}
            <Route path="blog/edit/:id" element={<BlogPostEdit />} />
            <Route path="cities" element={<CityOverview />} />
            <Route path="cities/:citySlug" element={<CityPage />} />
            <Route path="cities/:citySlug/:areaSlug" element={<AreaPage />} />
            <Route path="postnummer-sikkerhed" element={<PostalCodeSafety />} />
            <Route path="waiting-for-quotes/:bookingId" element={<WaitingForQuotes />} />
            <Route path="booking-status/:bookingId" element={<BookingStatus />} />
          </Routes>
        </MarketWrapper>
      } />
      
      {/* Global routes (no market prefix) */}
      <Route path="/admin" element={<Admin />} />
      <Route path="/admin-portal/*" element={<AdminPortal />} />
      <Route path="/locksmith-signup" element={<LocksmithSignup />} />
      <Route path="/locksmith-portal/*" element={<LocksmithPortal />} />
      <Route path="/place-bid" element={<PlaceBid />} />
      <Route path="/auth" element={<Auth />} />
      <Route path="/content-admin" element={<ContentAdmin />} />
      <Route path="/jobs-management" element={<JobsManagement />} />
      <Route path="/payment-success" element={<PaymentSuccess />} />
      <Route path="/payment-cancel" element={<PaymentCancel />} />
      
      {/* Catch all - 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};