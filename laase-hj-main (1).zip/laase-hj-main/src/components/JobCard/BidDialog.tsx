import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Euro, Clock, MessageSquare } from "lucide-react";
import { PriceBreakdown as PriceBreakdownType } from '@/utils/priceCalculator';
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { useMarket } from "@/contexts/MarketContext";
import { useMarketAddressSearch } from "@/hooks/useMarketAddressSearch";
import { useMapBoxDistance } from "@/hooks/useMapBoxDistance";
import { usePriceSuggestion } from "@/hooks/usePriceSuggestion";
import { AddressSection } from "./AddressSection";
import { PriceBreakdownSection } from "./PriceBreakdownSection";
import { ArrivalTimeSection } from "./ArrivalTimeSection";
import { OrderDetailsSection } from "./OrderDetailsSection";
import { BidDialogProps } from "./types";
import { AddressSearchResult } from '@/services/address/types';

export const BidDialog: React.FC<BidDialogProps> = ({
  job,
  priceBreakdown: initialPriceBreakdown,
  isCalculating: initialIsCalculating,
  hasValidConfiguration: initialHasValidConfiguration,
  distance: initialDistance,
  onSubmitBid,
  isSubmittingBid
}) => {
  const [bidAmount, setBidAmount] = useState('');
  const [bidNotes, setBidNotes] = useState('');
  const [arrivalTime, setArrivalTime] = useState('');
  const [address, setAddress] = useState(''); // Display address (business address)
  const [searchQuery, setSearchQuery] = useState(''); // Search input query
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [localDistance, setLocalDistance] = useState<{ km: number; duration: number } | null>(null);
  const [editingPriceComponent, setEditingPriceComponent] = useState<string | null>(null);
  const [customPrices, setCustomPrices] = useState<{
    basePrice?: number;
    timeSurcharge?: number;
    distanceFee?: number;
    materials?: number;
  }>({});
  const [chargeClientForReferral, setChargeClientForReferral] = useState(false);
  const [materialEnabled, setMaterialEnabled] = useState(false);
  
  const { user } = useAuth();
  const { t } = useLanguage();
  const { market } = useMarket();
  const addressInputRef = useRef<HTMLInputElement>(null);
  const { suggestions: addressSuggestions, error: addressSearchError, isLoading: isSearchingAddress } = useMarketAddressSearch(searchQuery, isEditingAddress && searchQuery.length > 0);
  const { calculateDistance, isLoading: isCalculatingDistance } = useMapBoxDistance();
  
  // Debug logging
  console.log('🔍 BidDialog Address Search Debug:', {
    address,
    searchQuery,
    isEditingAddress,
    showSuggestions,
    addressSuggestionsCount: addressSuggestions.length,
    marketCode: market.country_code,
    addressSearchError
  });
  
  // Use local price calculation when address is being edited, otherwise use props
  const jobForPricing = { ...job, followUpAnswers: undefined };
  const distanceForPricing = localDistance || initialDistance;
  const { 
    priceBreakdown: localPriceBreakdown, 
    isCalculating: localIsCalculating, 
    hasValidConfiguration: localHasValidConfiguration 
  } = usePriceSuggestion(jobForPricing, distanceForPricing ? { km: distanceForPricing.km } : undefined, chargeClientForReferral);
  
  // Use local calculations when editing address, otherwise use props
  const priceBreakdown = isEditingAddress ? localPriceBreakdown : initialPriceBreakdown;
  const isCalculating = isEditingAddress ? localIsCalculating : initialIsCalculating;
  const hasValidConfiguration = isEditingAddress ? localHasValidConfiguration : initialHasValidConfiguration;
  
  // Calculate final prices (custom or original)
  const finalPrices = priceBreakdown ? {
    basePrice: customPrices.basePrice ?? priceBreakdown.basePrice,
    timeSurcharge: customPrices.timeSurcharge ?? priceBreakdown.timeSurcharge.amount,
    distanceFee: customPrices.distanceFee ?? priceBreakdown.distanceFee,
    materials: materialEnabled ? (customPrices.materials ?? 0) : 0,
    get referralFeeAmount() {
      // Calculate referral fee dynamically based on current subtotal including materials
      const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
      return priceBreakdown.referralFee ? (subtotal * priceBreakdown.referralFee.percentage) / 100 : 0;
    },
    get total() {
      const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
      // Add referral fee if charging client, otherwise use subtotal as is
      return chargeClientForReferral && priceBreakdown.referralFee 
        ? subtotal + this.referralFeeAmount 
        : subtotal;
    },
    get locksmithEarnings() {
      const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
      // If charging client, locksmith gets full amount. Otherwise, deduct referral fee
      return chargeClientForReferral 
        ? this.total 
        : (priceBreakdown.referralFee ? subtotal - this.referralFeeAmount : subtotal);
    }
  } : null;

  // Simplified ASAP detection based on actual booking system logic
  const isASAPJob = job.urgency === 'emergency';

  const handlePriceEdit = (component: string, value: string) => {
    const numValue = parseFloat(value) || 0;
    setCustomPrices(prev => ({
      ...prev,
      [component]: numValue
    }));
  };

  // Helper function to format time consistently as HH:MM
  const formatTimeToHHMM = (date: Date): string => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  // Helper function to parse and validate time string
  const parseTimeString = (timeStr: string): { hours: number; minutes: number } | null => {
    if (!timeStr || typeof timeStr !== 'string') return null;
    
    // Normalize time string - handle different separators and formats
    const normalizedTime = timeStr.replace(/[.,\s]/g, ':').trim();
    const parts = normalizedTime.split(':');
    
    if (parts.length !== 2) return null;
    
    const hours = parseInt(parts[0], 10);
    const minutes = parseInt(parts[1], 10);
    
    if (isNaN(hours) || isNaN(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
      return null;
    }
    
    return { hours, minutes };
  };

  const adjustArrivalTime = (minutes: number) => {
    let timeToAdjust = arrivalTime;
    
    // If no valid arrivalTime, create a default time
    if (!timeToAdjust) {
      const now = new Date();
      const defaultTime = new Date(now.getTime() + 30 * 60000); // 30 minutes from now
      timeToAdjust = formatTimeToHHMM(defaultTime);
    }
    
    // Parse the time string
    const parsedTime = parseTimeString(timeToAdjust);
    if (!parsedTime) {
      console.error('Could not parse time:', timeToAdjust);
      // Fallback to current time + 30 minutes
      const now = new Date();
      const fallbackTime = new Date(now.getTime() + 30 * 60000);
      timeToAdjust = formatTimeToHHMM(fallbackTime);
      const fallbackParsed = parseTimeString(timeToAdjust);
      if (!fallbackParsed) return; // Should never happen, but safety check
      
      const totalMinutes = fallbackParsed.hours * 60 + fallbackParsed.minutes + minutes;
      const newHours = Math.floor(totalMinutes / 60) % 24;
      const newMins = totalMinutes % 60;
      const formattedTime = `${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`;
      setArrivalTime(formattedTime);
      return;
    }
    
    // Calculate new time
    const totalMinutes = parsedTime.hours * 60 + parsedTime.minutes + minutes;
    
    // Handle wrap-around for 24-hour format
    let newHours = Math.floor(totalMinutes / 60) % 24;
    let newMins = totalMinutes % 60;
    
    // Handle negative values (going to previous day)
    if (newHours < 0) newHours += 24;
    if (newMins < 0) {
      newMins += 60;
      newHours = (newHours - 1 + 24) % 24;
    }
    
    const formattedTime = `${newHours.toString().padStart(2, '0')}:${newMins.toString().padStart(2, '0')}`;
    setArrivalTime(formattedTime);
  };

  // Calculate distance when address changes and we're editing
  useEffect(() => {
    const calculateNewDistance = async () => {
      if (!address || !isEditingAddress || address.length < 10) {
        setLocalDistance(null);
        return;
      }
      
      try {
        const result = await calculateDistance(address, job.address);
        if (result) {
          setLocalDistance({ km: result.distance, duration: result.duration });
        }
      } catch (error) {
        console.error('Failed to calculate distance for bid:', error);
        setLocalDistance(null);
      }
    };

    const timeoutId = setTimeout(calculateNewDistance, 500); // Debounce
    return () => clearTimeout(timeoutId);
  }, [address, isEditingAddress, job.address, calculateDistance]);

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    console.log('🔍 Search query changed:', {
      newValue,
      length: newValue.length,
      isEditingAddress,
      marketCode: market.country_code
    });
    setSearchQuery(newValue);
    setShowSuggestions(newValue.length >= 3);
  };

  const handleSuggestionClick = (suggestion: AddressSearchResult) => {
    const selectedAddress = suggestion.fullAddress || suggestion.displayText;
    setAddress(selectedAddress);
    setSearchQuery(''); // Clear the search query
    setShowSuggestions(false);
    setIsEditingAddress(false);
    if (addressInputRef.current) {
      addressInputRef.current.blur();
    }
  };

  const handleAddressFocus = () => {
    console.log('🔍 Address input focused, searchQuery:', searchQuery);
    if (searchQuery.length >= 3 && addressSuggestions.length > 0) {
      setShowSuggestions(true);
    }
  };

  const handleAddressBlur = () => {
    setTimeout(() => {
      setShowSuggestions(false);
    }, 150);
  };

  // Fetch locksmith's business address
  const fetchBusinessAddress = async () => {
    if (!user) return '';
    
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('address, postal_code, city')
        .eq('id', user.id)
        .single();

      if (profile?.address) {
        return `${profile.address}, ${profile.postal_code} ${profile.city}`;
      }
    } catch (error) {
      console.error('Failed to fetch business address:', error);
    }
    
    return '';
  };

  // Calculate estimated arrival time
  const calculateArrivalTime = () => {
    const currentDistance = localDistance || initialDistance;
    const now = new Date();
    
    if (!currentDistance) {
      // For ASAP jobs without distance, default to 30 minutes from now
      const defaultArrival = new Date(now.getTime() + 30 * 60000);
      return formatTimeToHHMM(defaultArrival);
    }
    
    const arrivalMinutes = currentDistance.duration + 10; // Travel time + 10 minutes
    const arrivalDate = new Date(now.getTime() + arrivalMinutes * 60000);
    
    return formatTimeToHHMM(arrivalDate);
  };

  // Reset and populate form when dialog opens
  useEffect(() => {
    if (isOpen) {
      const initializeForm = async () => {
        // Calculate and set arrival time
        const estimatedArrival = calculateArrivalTime();
        setArrivalTime(estimatedArrival);
        
        // Fetch and set business address (only if not already set)
        if (!address) {
          const businessAddress = await fetchBusinessAddress();
          setAddress(businessAddress);
        }
        setIsEditingAddress(false);
        setLocalDistance(null);
        setCustomPrices({}); // Reset custom prices
        setMaterialEnabled(false); // Reset materials toggle
      };
      
      initializeForm();
    } else {
      // Reset form when dialog closes
      setBidAmount('');
      setBidNotes('');
      setArrivalTime('');
      setAddress('');
      setIsEditingAddress(false);
      setLocalDistance(null);
      setCustomPrices({});
      setEditingPriceComponent(null);
      setMaterialEnabled(false);
    }
  }, [isOpen]);

  // Update bid amount when price changes (but don't interfere with editing)
  useEffect(() => {
    if (isOpen && finalPrices && finalPrices.total > 0) {
      setBidAmount(finalPrices.total.toString());
    } else if (isOpen && !priceBreakdown) {
      // For manual pricing, start with empty bidAmount
      setBidAmount('');
    }
  }, [finalPrices?.total, isOpen, priceBreakdown]);

  const handleSubmit = async () => {
    console.log('🚀 BidDialog handleSubmit clicked!', {
      user: !!user,
      userId: user?.id,
      finalPrices,
      bidAmount,
      hasValidConfiguration,
      isSubmittingBid
    });

    if (!user) {
      console.error('❌ User not authenticated');
      return;
    }

    console.log('🔄 Starting bid submission from dialog...');
    
    try {
      // Calculate final amount from custom prices if no auto-pricing
      let finalAmount = finalPrices?.total.toString() || bidAmount;
      
      // If we have custom prices but no finalPrices (manual mode), calculate total
      if (!finalPrices && (customPrices.basePrice || customPrices.timeSurcharge || customPrices.distanceFee || (materialEnabled && customPrices.materials))) {
        const basePrice = customPrices.basePrice || 0;
        const timeSurcharge = customPrices.timeSurcharge || 0;
        const distanceFee = customPrices.distanceFee || 0;
        const materials = materialEnabled ? (customPrices.materials || 0) : 0;
        const manualTotal = basePrice + timeSurcharge + distanceFee + materials;
        finalAmount = manualTotal.toString();
      }
      
      console.log('📊 Submitting bid with amount:', finalAmount);
      
      if (!finalAmount || finalAmount === '0') {
        console.error('❌ No bid amount provided');
        return;
      }
      
      const result = await onSubmitBid(finalAmount, bidNotes, arrivalTime, address);
      console.log('📊 Bid submission result:', result);
      
      if (result?.success) {
        // Only close dialog if submission was successful
        console.log('✅ Bid submission successful, closing dialog');
        setIsOpen(false);
      } else {
        console.error('❌ Bid submission failed:', result);
      }
    } catch (error) {
      console.error('❌ Bid submission failed in dialog:', error);
      // Dialog stays open so user can see the error and retry
      // Error toasts are already shown by LocksmithJobCard
    }
  };

  const formatCurrency = (amount: number) => `${amount.toFixed(0)} kr`;

  // Debug logging for button state
  console.log('🔧 BidDialog button state:', {
    isOpen,
    finalPrices,
    bidAmount,
    hasValidConfiguration,
    isCalculating,
    user: !!user,
    priceBreakdown,
    isSubmittingBid,
    buttonDisabled: !finalPrices?.total && !bidAmount || isSubmittingBid
  });

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            className="flex-1" 
            disabled={isSubmittingBid}
          >
            <Euro className="w-4 h-4 mr-2" />
            {t('job_cards.actions.place_bid')}
          </Button>
        </DialogTrigger>
      <DialogContent className="max-w-6xl">
        <DialogHeader>
          <DialogTitle>{t('job_cards.actions.place_bid')} - {job.category}</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Bidding Form */}
          <div className="space-y-4">
            {/* Address Section */}
            <AddressSection
              address={address}
              searchQuery={searchQuery}
              isEditingAddress={isEditingAddress}
              showSuggestions={showSuggestions}
              addressSuggestions={addressSuggestions}
              addressInputRef={addressInputRef}
              onAddressChange={handleAddressChange}
              onEditToggle={() => {
                console.log('Edit button clicked, current isEditingAddress:', isEditingAddress);
                if (!isEditingAddress) {
                  // Entering edit mode - clear search query for fresh start
                  setSearchQuery('');
                  setShowSuggestions(false);
                }
                setIsEditingAddress(!isEditingAddress);
                // Focus the input after state updates
                setTimeout(() => {
                  if (addressInputRef.current) {
                    addressInputRef.current.focus();
                  }
                }, 100);
              }}
              onSuggestionClick={handleSuggestionClick}
              onAddressFocus={handleAddressFocus}
              onAddressBlur={handleAddressBlur}
            />

            {/* Price Breakdown Section - Always Show */}
            <PriceBreakdownSection
              priceBreakdown={priceBreakdown}
              finalPrices={finalPrices}
              editingPriceComponent={editingPriceComponent}
              onPriceEdit={handlePriceEdit}
              onSetEditingComponent={setEditingPriceComponent}
              chargeClientForReferral={chargeClientForReferral}
              onToggleReferralCharge={setChargeClientForReferral}
              materialEnabled={materialEnabled}
              onToggleMaterials={setMaterialEnabled}
            />

            {/* Arrival Time Section */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Ankomst tid
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ArrivalTimeSection
                  isASAPJob={isASAPJob}
                  arrivalTime={arrivalTime}
                  onArrivalTimeChange={setArrivalTime}
                  onAdjustArrivalTime={adjustArrivalTime}
                  distance={localDistance || initialDistance}
                  scheduledDate={job.scheduledDate}
                  locksmithAddress={address}
                />
              </CardContent>
            </Card>

            {/* Notes */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <MessageSquare className="w-4 h-4" />
                  {t('job_cards.interface.notes')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  id="bidNotes"
                  placeholder={t('job_cards.interface.notes_placeholder')}
                  value={bidNotes}
                  onChange={(e) => setBidNotes(e.target.value)}
                  rows={3}
                />
              </CardContent>
            </Card>

            {/* Submit Button */}
            <Button 
              onClick={handleSubmit}
              disabled={isSubmittingBid}
              className="w-full"
            >
              {isSubmittingBid ? t('job_cards.actions.sending_bid') : t('job_cards.actions.send_bid')}
            </Button>
          </div>

          {/* Right Column: Order Details */}
          <div className="border-l border-border pl-6">
            <OrderDetailsSection job={job} />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};