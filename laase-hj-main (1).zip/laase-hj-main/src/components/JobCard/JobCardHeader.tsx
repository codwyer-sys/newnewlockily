import React from 'react';
import { CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, X } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { LocksmithJob } from '@/types/locksmith';

interface JobCardHeaderProps {
  job: LocksmithJob;
  onDismiss: () => void;
  isDismissing: boolean;
}

const urgencyConfig = {
  low: { label: 'Lav', color: 'bg-green-100 text-green-800' },
  medium: { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
  high: { label: 'Høj', color: 'bg-orange-100 text-orange-800' },
  emergency: { label: 'Akut', color: 'bg-red-100 text-red-800' }
};

const getUrgencyConfig = (urgency: string) => {
  return urgencyConfig[urgency as keyof typeof urgencyConfig] || urgencyConfig.medium;
};

const maskCustomerName = (name: string) => {
  const names = name.split(' ').filter(n => n.length > 0);
  return names.map(namePart => {
    if (namePart.length <= 2) {
      // For very short names, show as is
      return namePart;
    } else if (namePart.length <= 6) {
      // For short names, show first 2 chars + stars up to max 4 stars
      const starsCount = Math.min(namePart.length - 2, 4);
      return namePart.substring(0, 2) + '*'.repeat(starsCount);
    } else {
      // For longer names, show first 2 chars + exactly 4 stars
      return namePart.substring(0, 2) + '****';
    }
  }).join(' ');
};

const formatTimeAgo = (isoString: string) => {
  const now = new Date();
  const date = new Date(isoString);
  const diffInMs = now.getTime() - date.getTime();
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  
  if (diffInMinutes < 60) {
    return `${diffInMinutes}m`;
  } else if (diffInMinutes < 1440) { // Less than 24 hours
    const hours = Math.floor(diffInMinutes / 60);
    return `${hours}h`;
  } else {
    const days = Math.floor(diffInMinutes / 1440);
    return `${days}d`;
  }
};

const formatTimingDisplay = (timing?: string, scheduledDate?: string) => {
  const normalizedTiming = timing?.toLowerCase();
  if (normalizedTiming === 'now' || normalizedTiming === 'asap' || normalizedTiming === 'nu') {
    return { isASAP: true, display: 'ASAP' };
  }
  
  if (scheduledDate) {
    const date = new Date(scheduledDate);
    const display = date.toLocaleString('da-DK', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    return { isASAP: false, display };
  }
  
  // For non-ASAP jobs, show the timing or date if available
  if (timing) {
    return { isASAP: false, display: timing };
  }
  
  return null; // Don't show anything if no timing info
};

export const JobCardHeader: React.FC<JobCardHeaderProps> = ({ job, onDismiss, isDismissing }) => {
  const { t } = useLanguage();
  
  return (
    <CardHeader className="pb-3">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <CardTitle className="text-lg">
            {job.customerName ? maskCustomerName(job.customerName) : job.categoryName || job.category}
          </CardTitle>
          <div className="flex items-center gap-2 mt-2">
            {(() => {
              const timingInfo = formatTimingDisplay(job.timing, job.scheduledDate);
              return timingInfo ? (
                timingInfo.isASAP ? (
                  <Badge className="bg-red-100 text-red-800">
                    {timingInfo.display}
                  </Badge>
                ) : (
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    {timingInfo.display}
                  </div>
                )
              ) : null;
            })()}
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              {formatTimingDisplay(job.timing, job.scheduledDate) ? '•' : ''}
              {formatTimeAgo(job.timeRequested)}
            </div>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onDismiss}
          disabled={isDismissing}
          className="text-muted-foreground hover:text-destructive h-8 w-8 p-0"
          title={t('job_cards.actions.dismiss_job')}
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </CardHeader>
  );
};