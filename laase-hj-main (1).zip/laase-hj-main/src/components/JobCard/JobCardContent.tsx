import React from 'react';
import { CardContent } from "@/components/ui/card";
import { MapPin, Navigation } from "lucide-react";
import { LocksmithJob } from '@/types/locksmith';

interface JobCardContentProps {
  job: LocksmithJob;
  distance: { km: number; duration: number } | null;
  isCalculatingDistance: boolean;
}

const formatAddress = (fullAddress: string) => {
  // Extract street name, postal code and city from full address
  // Example: "Silkeborgvej 160, 1. th, 8000 Aarhus C" -> "Silkeborgvej, 8000 Aarhus C"
  const parts = fullAddress.split(',').map(p => p.trim());
  if (parts.length >= 2) {
    const streetName = parts[0].split(' ')[0]; // Get just street name
    const lastPart = parts[parts.length - 1]; // Should be "8000 Aarhus C"
    return `${streetName}, ${lastPart}`;
  }
  return fullAddress;
};

export const JobCardContent: React.FC<JobCardContentProps> = ({ 
  job, 
  distance, 
  isCalculatingDistance 
}) => {
  return (
    <CardContent className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm">
          <MapPin className="w-4 h-4 text-muted-foreground" />
          <span>{formatAddress(job.address)}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Navigation className="w-4 h-4" />
          {isCalculatingDistance ? (
            <span>Beregner afstand...</span>
          ) : distance ? (
            <span>{distance.km} km • {distance.duration} min kørsel</span>
          ) : (
            <span>Afstand ikke tilgængelig</span>
          )}
        </div>
      </div>

      {job.lockBrand && (
        <div className="text-sm">
          <span className="font-medium">Låsmærke:</span> {job.lockBrand}
        </div>
      )}
    </CardContent>
  );
};