import { LocksmithJob } from '@/types/locksmith';

export interface BidDialogProps {
  job: LocksmithJob;
  priceBreakdown: any | null;
  isCalculating: boolean;
  hasValidConfiguration: boolean;
  distance: { km: number; duration: number } | null;
  onSubmitBid: (amount: string, notes: string, arrivalTime: string, address: string) => Promise<{ success: boolean }>;
  isSubmittingBid: boolean;
}