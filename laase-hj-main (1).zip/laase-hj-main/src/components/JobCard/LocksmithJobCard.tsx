import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Phone, ChevronDown, X, Euro } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMapBoxDistance } from "@/hooks/useMapBoxDistance";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/contexts/LanguageContext";
import { LocksmithJob } from '@/types/locksmith';
import { JobCardHeader } from "./JobCardHeader";
import { JobCardContent } from "./JobCardContent";

interface LocksmithJobCardProps {
  job: LocksmithJob;
  onJobDismissed?: (jobId: string) => void;
}

const LocksmithJobCard = ({ job, onJobDismissed }: LocksmithJobCardProps) => {
  const [isRequestingInfo, setIsRequestingInfo] = useState(false);
  const [isDismissing, setIsDismissing] = useState(false);
  const [distance, setDistance] = useState<{ km: number; duration: number } | null>(null);
  const { toast } = useToast();
  const { calculateDistance, isLoading: isCalculatingDistance } = useMapBoxDistance();
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  // Calculate distance when component mounts
  useEffect(() => {
    const calculateJobDistance = async () => {
      if (!user) return;
      
      try {
        // Get locksmith's address from profile
        const { data: profile } = await supabase
          .from('profiles')
          .select('address, postal_code, city')
          .eq('id', user.id)
          .single();

        if (profile?.address) {
          const locksmithAddress = `${profile.address}, ${profile.postal_code} ${profile.city}`;
          const result = await calculateDistance(locksmithAddress, job.address);
          
          if (result) {
            setDistance({ km: result.distance, duration: result.duration });
          }
        }
      } catch (error) {
        console.error('Failed to calculate distance:', error);
      }
    };

    calculateJobDistance();
  }, [user?.id, job.address, calculateDistance]);

  const handlePlaceBid = () => {
    navigate('/place-bid', { state: { job } });
  };

  const handleRequestMoreInfo = async () => {
    setIsRequestingInfo(true);
    try {
      // TODO: Implement request more info logic - creates quote with only phone number visible
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: t('job_cards.actions.request_sent'),
        description: t('job_cards.actions.request_sent_desc')
      });
    } catch (error) {
      toast({
        title: t('job_cards.actions.error'),
        description: t('job_cards.actions.request_error'),
        variant: "destructive"
      });
    } finally {
      setIsRequestingInfo(false);
    }
  };

  const handleDismissJob = async () => {
    if (!user) return;
    
    setIsDismissing(true);
    try {
      // Store the dismissed job in localStorage for now
      // In a production app, you might want to store this in the database
      const dismissedJobs = JSON.parse(localStorage.getItem('dismissedJobs') || '[]');
      const updatedDismissedJobs = [...dismissedJobs, job.id];
      localStorage.setItem('dismissedJobs', JSON.stringify(updatedDismissedJobs));
      
      // Call the callback to remove from parent component
      onJobDismissed?.(job.id);
      
      toast({
        title: t('job_cards.actions.job_dismissed'),
        description: t('job_cards.actions.job_dismissed_desc')
      });
    } catch (error) {
      toast({
        title: t('job_cards.actions.error'),
        description: t('job_cards.actions.dismiss_error'),
        variant: "destructive"
      });
    } finally {
      setIsDismissing(false);
    }
  };

  return (
    <Card className="h-full">
      <JobCardHeader 
        job={job}
        onDismiss={handleDismissJob}
        isDismissing={isDismissing}
      />
      
      <JobCardContent 
        job={job}
        distance={distance}
        isCalculatingDistance={isCalculatingDistance}
      />

      <div className="px-6 pb-6">
        <div className="flex gap-2 pt-4">
          <Button 
            className="flex-1" 
            onClick={handlePlaceBid}
          >
            <Euro className="w-4 h-4 mr-2" />
            {t('job_cards.actions.place_bid')}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex-1" disabled={isRequestingInfo || isDismissing}>
                <Phone className="w-4 h-4 mr-2" />
                {t('job_cards.actions.contact_customer')}
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleRequestMoreInfo} disabled={isRequestingInfo}>
                <Phone className="w-4 h-4 mr-2" />
                {isRequestingInfo ? t('job_cards.actions.sending') : t('job_cards.actions.contact_customer')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDismissJob} disabled={isDismissing} className="text-destructive">
                <X className="w-4 h-4 mr-2" />
                {isDismissing ? t('job_cards.actions.dismissing') : t('job_cards.actions.dismiss_job')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </Card>
  );
};

export default LocksmithJobCard;