import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface ArrivalTimeSectionProps {
  isASAPJob: boolean;
  arrivalTime: string;
  onArrivalTimeChange: (value: string) => void;
  onAdjustArrivalTime: (minutes: number) => void;
  distance: { km: number; duration: number } | null;
  scheduledDate?: string;
  locksmithAddress: string;
}

const formatScheduledDate = (isoString: string) => {
  const date = new Date(isoString);
  return date.toLocaleString('da-DK', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const calculateDepartureTime = (targetTime: string, travelMinutes: number): string => {
  try {
    const today = new Date();
    const [hours, minutes] = targetTime.split(':').map(Number);
    const targetDate = new Date(today.getFullYear(), today.getMonth(), today.getDate(), hours, minutes);
    const departureDate = new Date(targetDate.getTime() - travelMinutes * 60000);
    
    return departureDate.toLocaleTimeString('da-DK', {
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return 'Ukendt';
  }
};

const calculateDepartureFromScheduled = (scheduledDate: string, travelMinutes: number): string => {
  try {
    const scheduledDateTime = new Date(scheduledDate);
    const departureDate = new Date(scheduledDateTime.getTime() - travelMinutes * 60000);
    
    return departureDate.toLocaleTimeString('da-DK', {
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return 'Ukendt';
  }
};

export const ArrivalTimeSection: React.FC<ArrivalTimeSectionProps> = ({
  isASAPJob,
  arrivalTime,
  onArrivalTimeChange,
  onAdjustArrivalTime,
  distance,
  scheduledDate,
  locksmithAddress
}) => {
  const getDepartureText = () => {
    if (!distance) return "Beregner rejsetid...";
    
    if (scheduledDate && !isASAPJob) {
      const departureTime = calculateDepartureFromScheduled(scheduledDate, distance.duration);
      return `Du skal afrejse kl. ${departureTime} for at nå frem til tiden`;
    }
    
    if (arrivalTime) {
      const departureTime = calculateDepartureTime(arrivalTime, distance.duration);
      return `Du skal afrejse kl. ${departureTime} for at nå frem til tiden`;
    }
    
    return "Venter på ankomsttid...";
  };

  // If job has scheduled date, show that instead of editable arrival time
  if (scheduledDate && !isASAPJob) {
    return (
      <div>
        <div className="mt-1 p-3 bg-muted/30 rounded-md">
          <div className="text-lg font-medium">
            {formatScheduledDate(scheduledDate)}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {getDepartureText()}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div>
      {isASAPJob && (
        <div className="flex justify-end mb-2">
          <div className="flex gap-1">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onAdjustArrivalTime(-5)}
              className="h-6 w-8 p-0 text-xs"
            >
              -5
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onAdjustArrivalTime(5)}
              className="h-6 w-8 p-0 text-xs"
            >
              +5
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onAdjustArrivalTime(10)}
              className="h-6 w-10 p-0 text-xs"
            >
              +10
            </Button>
          </div>
        </div>
      )}
      
      {isASAPJob ? (
        <div>
          <div className="text-xl font-semibold">
            {arrivalTime ? `${arrivalTime} (i dag)` : 'Beregner...'}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {getDepartureText()}
          </p>
        </div>
      ) : (
        <>
          <Input
            id="arrivalTime"
            type="time"
            value={arrivalTime}
            onChange={(e) => onArrivalTimeChange(e.target.value)}
          />
          <p className="text-xs text-muted-foreground mt-1">
            {getDepartureText()}
          </p>
          {distance && (
            <p className="text-xs text-muted-foreground">
              Estimeret: {distance.duration + 10} min (kørsel + forberedelse)
            </p>
          )}
        </>
      )}
    </div>
  );
};