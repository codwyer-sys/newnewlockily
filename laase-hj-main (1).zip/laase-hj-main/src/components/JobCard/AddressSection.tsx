import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Edit2 } from "lucide-react";

import { AddressSearchResult } from '@/services/address/types';

interface AddressSectionProps {
  address: string; // Display address (when not editing)
  searchQuery: string; // Input value (when editing)
  isEditingAddress: boolean;
  showSuggestions: boolean;
  addressSuggestions: AddressSearchResult[];
  addressInputRef: React.RefObject<HTMLInputElement>;
  onAddressChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onEditToggle: () => void;
  onSuggestionClick: (suggestion: AddressSearchResult) => void;
  onAddressFocus: () => void;
  onAddressBlur: () => void;
  addressSearchError?: string | null;
  isSearchingAddress?: boolean;
}

export const AddressSection: React.FC<AddressSectionProps> = ({
  address,
  searchQuery,
  isEditingAddress,
  showSuggestions,
  addressSuggestions,
  addressInputRef,
  onAddressChange,
  onEditToggle,
  onSuggestionClick,
  onAddressFocus,
  onAddressBlur,
  addressSearchError,
  isSearchingAddress
}) => {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Hvor kører du fra?
          </CardTitle>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onEditToggle}
            className="h-6 px-2 text-xs"
          >
            <Edit2 className="w-3 h-3 mr-1" />
            Rediger
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isEditingAddress ? (
          <div className="relative">
            <Input
              ref={addressInputRef}
              placeholder="Indtast ny adresse..."
              value={searchQuery}
              onChange={onAddressChange}
              onFocus={onAddressFocus}
              onBlur={onAddressBlur}
            />
            {showSuggestions && addressSuggestions.length > 0 && (
              <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg max-h-60 overflow-y-auto">
                {addressSuggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    type="button"
                    className="w-full text-left px-3 py-2 hover:bg-accent text-sm border-b last:border-b-0 rounded-none first:rounded-t-md last:rounded-b-md flex items-center gap-2"
                    onClick={() => onSuggestionClick(suggestion)}
                  >
                    <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <span className="truncate">
                      {suggestion.fullAddress || suggestion.displayText}
                    </span>
                  </button>
                ))}
              </div>
            )}
            
            {/* Show loading state */}
            {isSearchingAddress && (
              <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg p-3">
                <div className="text-sm text-muted-foreground">Søger adresser...</div>
              </div>
            )}
            
            {/* Show error state */}
            {addressSearchError && !isSearchingAddress && (
              <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-lg p-3">
                <div className="text-sm text-destructive">{addressSearchError}</div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-2 bg-muted rounded-md text-sm">
            {address || 'Ingen adresse angivet'}
          </div>
        )}
      </CardContent>
    </Card>
  );
};