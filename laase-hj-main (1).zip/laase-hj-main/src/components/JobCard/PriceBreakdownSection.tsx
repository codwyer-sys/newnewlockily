import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, Clock, MapPin, Users, Package, Plus } from "lucide-react";

interface PriceBreakdownSectionProps {
  priceBreakdown: any;
  finalPrices: any;
  editingPriceComponent: string | null;
  onPriceEdit: (component: string, value: string) => void;
  onSetEditingComponent: (component: string | null) => void;
  chargeClientForReferral: boolean;
  onToggleReferralCharge: (value: boolean) => void;
  materialEnabled: boolean;
  onToggleMaterials: (enabled: boolean) => void;
}

export const PriceBreakdownSection: React.FC<PriceBreakdownSectionProps> = ({
  priceBreakdown,
  finalPrices,
  editingPriceComponent,
  onPriceEdit,
  onSetEditingComponent,
  chargeClientForReferral,
  onToggleReferralCharge,
  materialEnabled,
  onToggleMaterials
}) => {
  const formatCurrency = (amount: number) => `${amount.toFixed(0)} kr`;
  
  // Provide defaults when priceBreakdown is null (manual pricing mode)
  const defaultBreakdown = {
    basePrice: 0,
    timeSurcharge: { amount: 0, type: 'none' },
    distanceFee: 0,
    total: 0,
    locksmithEarnings: 0,
    referralFee: null
  };
  
  const breakdown = priceBreakdown || defaultBreakdown;
  const isManualMode = !priceBreakdown;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Calculator className="w-4 h-4" />
          Prisberegning
          {isManualMode && (
            <span className="text-xs font-normal text-muted-foreground ml-2">
              (Manuel indtastning)
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {/* Referral Fee Toggle */}
        <div className="flex items-center justify-between text-sm p-3 border border-border/50 rounded bg-background/50 hover:border-border transition-colors">
          <div className="flex items-center gap-2">
            <Label htmlFor="referral-toggle" className="text-xs cursor-pointer">
              Tillæg formidlingsgebyr til kunden
            </Label>
            <div className="group relative">
              <div className="w-3 h-3 rounded-full border border-muted-foreground/30 flex items-center justify-center cursor-help text-xs text-muted-foreground hover:border-muted-foreground transition-colors">
                ?
              </div>
              <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-64 p-2 bg-popover text-popover-foreground text-xs rounded shadow-lg border opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                Kunden vil altid kun se den fulde pris. Funktionen tillægger blot gebyret på din pris til kundens tilbud.
              </div>
            </div>
          </div>
          <Switch
            id="referral-toggle"
            checked={chargeClientForReferral}
            onCheckedChange={onToggleReferralCharge}
          />
        </div>

        <div className="flex justify-between text-sm">
          <span>Grundpris:</span>
          {editingPriceComponent === 'basePrice' ? (
            <Input
              type="number"
              value={finalPrices?.basePrice ?? breakdown.basePrice}
              onChange={(e) => onPriceEdit('basePrice', e.target.value)}
              onBlur={() => onSetEditingComponent(null)}
              onKeyDown={(e) => e.key === 'Enter' && onSetEditingComponent(null)}
              className="h-6 w-20 text-right text-sm"
              autoFocus
              placeholder="0"
            />
          ) : (
            <span 
              className="font-medium cursor-pointer hover:bg-accent px-1 rounded"
              onClick={() => onSetEditingComponent('basePrice')}
            >
              {formatCurrency(finalPrices?.basePrice || breakdown.basePrice)}
            </span>
          )}
        </div>

        {/* Show referral fee when charged to client */}
        {chargeClientForReferral && breakdown.referralFee && (
          <div className="flex justify-between text-sm pl-4">
            <div className="flex items-center gap-1">
              <Users className="w-3 h-3" />
              <span className="text-xs">Formidlingsgebyr ({breakdown.referralFee.percentage}%):</span>
            </div>
            <span className="font-medium text-xs">
              +{formatCurrency(finalPrices?.referralFeeAmount || breakdown.referralFee.amount)}
            </span>
          </div>
        )}
        
        {/* Always show time surcharge section for editing */}
        <div className="flex justify-between text-sm">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>
              {breakdown.timeSurcharge.type === 'both' && 'Nat + Weekend:'}
              {breakdown.timeSurcharge.type === 'nighttime' && 'Nattillæg:'}
              {breakdown.timeSurcharge.type === 'weekend' && 'Weekend:'}
              {(breakdown.timeSurcharge.type === 'none' || isManualMode) && 'Tidstillæg:'}
            </span>
          </div>
          {editingPriceComponent === 'timeSurcharge' ? (
            <Input
              type="number"
              value={finalPrices?.timeSurcharge ?? breakdown.timeSurcharge.amount}
              onChange={(e) => onPriceEdit('timeSurcharge', e.target.value)}
              onBlur={() => onSetEditingComponent(null)}
              onKeyDown={(e) => e.key === 'Enter' && onSetEditingComponent(null)}
              className="h-6 w-20 text-right text-sm"
              autoFocus
              placeholder="0"
            />
          ) : (
            <span 
              className="font-medium cursor-pointer hover:bg-accent px-1 rounded"
              onClick={() => onSetEditingComponent('timeSurcharge')}
            >
              {breakdown.timeSurcharge.amount > 0 ? `+${formatCurrency(finalPrices?.timeSurcharge || breakdown.timeSurcharge.amount)}` : `${formatCurrency(0)}`}
            </span>
          )}
        </div>
        
        <div className="flex justify-between text-sm">
          <div className="flex items-center gap-1">
            <MapPin className="w-3 h-3" />
            <span>Afstandstillæg:</span>
          </div>
          {editingPriceComponent === 'distanceFee' ? (
            <Input
              type="number"
              value={finalPrices?.distanceFee ?? breakdown.distanceFee}
              onChange={(e) => onPriceEdit('distanceFee', e.target.value)}
              onBlur={() => onSetEditingComponent(null)}
              onKeyDown={(e) => e.key === 'Enter' && onSetEditingComponent(null)}
              className="h-6 w-20 text-right text-sm"
              autoFocus
              placeholder="0"
            />
          ) : (
            <span 
              className="font-medium cursor-pointer hover:bg-accent px-1 rounded"
              onClick={() => onSetEditingComponent('distanceFee')}
            >
              {breakdown.distanceFee > 0 ? `+${formatCurrency(finalPrices?.distanceFee ?? breakdown.distanceFee)}` : `${formatCurrency(0)}`}
            </span>
          )}
        </div>
        
        {/* Materials section */}
        {!materialEnabled ? (
          <div className="flex justify-between text-sm text-muted-foreground">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggleMaterials(true)}
              className="h-6 p-0 text-muted-foreground hover:text-foreground flex items-center"
            >
              <Plus className="w-3 h-3 mr-1" />
              Materialer
            </Button>
            <span 
              className="cursor-pointer hover:text-foreground"
              onClick={() => onToggleMaterials(true)}
            >
              0 kr
            </span>
          </div>
        ) : (
          <div className="flex justify-between text-sm">
            <div className="flex items-center gap-1">
              <Package className="w-3 h-3" />
              <span>Materialer:</span>
            </div>
            {editingPriceComponent === 'materials' ? (
              <Input
                type="number"
                value={finalPrices?.materials ?? 0}
                onChange={(e) => onPriceEdit('materials', e.target.value)}
                onBlur={() => onSetEditingComponent(null)}
                onKeyDown={(e) => e.key === 'Enter' && onSetEditingComponent(null)}
                className="h-6 w-20 text-right text-sm"
                autoFocus
                placeholder="0"
              />
            ) : (
              <span 
                className="font-medium cursor-pointer hover:bg-accent px-1 rounded"
                onClick={() => onSetEditingComponent('materials')}
              >
                {formatCurrency(finalPrices?.materials || 0)}
              </span>
            )}
          </div>
        )}
        
        <Separator />
        <div className="flex justify-between font-semibold">
          <span>Kundens pris:</span>
          <span>{formatCurrency(finalPrices?.total || breakdown.total)}</span>
        </div>
        
        {/* Always show locksmith earnings breakdown when referral fee exists */}
        {breakdown.referralFee && (
          <>
            <Separator className="my-2" />
            <div className="bg-muted/50 p-2 rounded">
              <div className="flex justify-between text-sm text-muted-foreground mb-1">
                <span>Formidlingsgebyr ({breakdown.referralFee.percentage}%):</span>
                <span>{chargeClientForReferral ? '+' : '-'}{formatCurrency(finalPrices?.referralFeeAmount || breakdown.referralFee.amount)}</span>
              </div>
              <div className="flex justify-between font-semibold text-green-600">
                <span>Din betaling:</span>
                <span>
                  {formatCurrency(
                    chargeClientForReferral 
                      ? (finalPrices?.total || breakdown.total) - (finalPrices?.referralFeeAmount || breakdown.referralFee.amount)
                      : finalPrices?.locksmithEarnings || breakdown.locksmithEarnings
                  )}
                </span>
              </div>
            </div>
          </>
        )}

        {/* Show helpful tip when in manual mode */}
        {isManualMode && (
          <div className="mt-3 p-2 bg-blue-50 border border-blue-200 rounded text-xs text-blue-700">
            💡 Klik på tallene for at redigere priser. Opsæt <a href="/locksmith-portal/auto-byd" className="underline">AutoByd</a> for automatisk prisberegning.
          </div>
        )}
      </CardContent>
    </Card>
  );
};