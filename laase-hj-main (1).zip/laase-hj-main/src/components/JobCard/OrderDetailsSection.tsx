import React from 'react';
import { Clock, User, MapPin, Key, Shield, Phone } from 'lucide-react';
import { LocksmithJob } from '@/types/locksmith';
import { useLanguage } from "@/contexts/LanguageContext";

interface OrderDetailsSectionProps {
  job: LocksmithJob;
}

const formatTimeAgo = (isoString: string) => {
  const now = new Date();
  const date = new Date(isoString);
  const diffInMs = now.getTime() - date.getTime();
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  
  if (diffInMinutes < 60) {
    return `${diffInMinutes}m siden`;
  } else if (diffInMinutes < 1440) {
    const hours = Math.floor(diffInMinutes / 60);
    return `${hours}h siden`;
  } else {
    const days = Math.floor(diffInMinutes / 1440);
    return `${days}d siden`;
  }
};

const maskCustomerName = (name: string) => {
  const names = name.split(' ').filter(n => n.length > 0);
  return names.map(namePart => {
    if (namePart.length <= 2) {
      return namePart;
    } else if (namePart.length <= 6) {
      const starsCount = Math.min(namePart.length - 2, 4);
      return namePart.substring(0, 2) + '*'.repeat(starsCount);
    } else {
      return namePart.substring(0, 2) + '****';
    }
  }).join(' ');
};

const formatFollowUpAnswers = (answers: Record<string, any>) => {
  const answerLabels: Record<string, string> = {
    // Customer Information
    customerName: 'Kunde navn',
    customerPhone: 'Telefonnummer',
    phone: 'Telefonnummer',
    email: 'Email',
    contact_person: 'Kontaktperson',
    
    // Lock & Door Details
    keyLocation: 'Hvor er nøglen?',
    lockType: 'Låsetype',
    doorType: 'Dørtype',
    lockBrand: 'Låsemærke',
    lock_brand: 'Låsemærke',
    door_material: 'Dørmateriale',
    lock_age: 'Låsens alder',
    has_spare_key: 'Har reservenøgle',
    key_type: 'Nøgletype',
    lock_condition: 'Låsens tilstand',
    
    // Building & Location
    building_type: 'Bygningstype',
    floor_level: 'Etage',
    access_code: 'Adgangskode',
    access_info: 'Adgangsinformation',
    building_access: 'Bygningsadgang',
    
    // Problem & Service
    problem_description: 'Problembeskrivelse',
    service_type: 'Servicetype',
    urgency: 'Hastighed',
    timing: 'Tidspunkt',
    when_needed: 'Hvornår skal det udføres',
    work_type: 'Arbejdstype',
    
    // Additional Information
    special_instructions: 'Særlige instruktioner',
    additional_info: 'Yderligere information',
    notes: 'Noter',
    preferred_time: 'Foretrukket tidspunkt',
    budget_range: 'Budgetramme'
  };

  // Group answers by category for better organization
  const categoryMapping: Record<string, string> = {
    // Customer info
    customerName: 'customer',
    customerPhone: 'customer',
    phone: 'customer',
    email: 'customer',
    contact_person: 'customer',
    
    // Lock details
    keyLocation: 'lock',
    lockType: 'lock',
    doorType: 'lock',
    lockBrand: 'lock',
    lock_brand: 'lock',
    door_material: 'lock',
    lock_age: 'lock',
    has_spare_key: 'lock',
    key_type: 'lock',
    lock_condition: 'lock',
    
    // Building
    building_type: 'building',
    floor_level: 'building',
    access_code: 'building',
    access_info: 'building',
    building_access: 'building',
    
    // Service
    problem_description: 'service',
    service_type: 'service',
    urgency: 'service',
    timing: 'service',
    when_needed: 'service',
    work_type: 'service',
    preferred_time: 'service',
    budget_range: 'service',
    
    // Additional
    special_instructions: 'additional',
    additional_info: 'additional',
    notes: 'additional'
  };

  const formatted: Array<{ 
    label: string; 
    value: string; 
    icon?: React.ReactNode; 
    category: string;
  }> = [];

  Object.entries(answers).forEach(([key, value]) => {
    // Handle various value types and empty states
    if (value === null || value === undefined || value === '') return;
    
    // Handle arrays
    if (Array.isArray(value)) {
      if (value.length === 0) return;
      value = value.join(', ');
    }
    
    // Handle objects
    if (typeof value === 'object' && value !== null) {
      value = JSON.stringify(value);
    }

    const label = answerLabels[key] || key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    let displayValue = String(value);
    
    // Special formatting for specific field types
    if (key === 'customerName' && displayValue) {
      displayValue = maskCustomerName(displayValue);
    }
    
    // Format boolean values
    if (typeof value === 'boolean') {
      displayValue = value ? 'Ja' : 'Nej';
    }
    
    // Format phone numbers
    if ((key === 'customerPhone' || key === 'phone') && displayValue) {
      // Simple phone formatting - add spaces for readability
      displayValue = displayValue.replace(/(\d{2})(\d{2})(\d{2})(\d{2})/, '$1 $2 $3 $4');
    }

    // Assign appropriate icons
    let icon: React.ReactNode = undefined;
    const category = categoryMapping[key] || 'additional';
    
    switch (category) {
      case 'customer':
        if (key === 'customerPhone' || key === 'phone') {
          icon = <Phone className="w-4 h-4" />;
        } else {
          icon = <User className="w-4 h-4" />;
        }
        break;
      case 'lock':
        if (key === 'keyLocation') {
          icon = <Key className="w-4 h-4" />;
        } else {
          icon = <Shield className="w-4 h-4" />;
        }
        break;
      case 'building':
        icon = <MapPin className="w-4 h-4" />;
        break;
      case 'service':
        if (key === 'timing' || key === 'when_needed' || key === 'preferred_time') {
          icon = <Clock className="w-4 h-4" />;
        } else {
          icon = <Shield className="w-4 h-4" />;
        }
        break;
      default:
        icon = <User className="w-4 h-4" />;
    }
    
    formatted.push({ label, value: displayValue, icon, category });
  });

  return formatted;
};

export const OrderDetailsSection: React.FC<OrderDetailsSectionProps> = ({ job }) => {
  const { t } = useLanguage();
  
  const formattedAnswers = job.followUpAnswers ? formatFollowUpAnswers(job.followUpAnswers) : [];

  return (
    <div className="bg-muted/30 p-6 space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <User className="w-5 h-5" />
          Ordredetaljer
        </h3>
        
        {/* Basic Job Info */}
        <div className="space-y-3 mb-6">
          <div className="flex items-start gap-2">
            <MapPin className="w-4 h-4 mt-1 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Adresse</p>
              <p className="text-sm text-muted-foreground">{job.address}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Oprettet</p>
              <p className="text-sm text-muted-foreground">{formatTimeAgo(job.timeRequested)}</p>
            </div>
          </div>

          {job.jobNumber && (
            <div>
              <p className="text-sm font-medium">Jobnummer</p>
              <p className="text-sm text-muted-foreground">#{job.jobNumber}</p>
            </div>
          )}
        </div>

        {/* Customer Answers */}
        {formattedAnswers.length > 0 && (
          <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
            <h4 className="text-md font-medium mb-3 text-primary">Kundens svar</h4>
            <div className="space-y-4">
              {(() => {
                // Group answers by category
                const groupedAnswers = formattedAnswers.reduce((groups, answer) => {
                  const category = (answer as any).category || 'additional';
                  if (!groups[category]) groups[category] = [];
                  groups[category].push(answer);
                  return groups;
                }, {} as Record<string, typeof formattedAnswers>);

                const categoryTitles: Record<string, string> = {
                  customer: 'Kunde information',
                  lock: 'Lås og dør detaljer',
                  building: 'Bygning og adgang',
                  service: 'Service behov',
                  additional: 'Yderligere information'
                };

                const categoryOrder = ['customer', 'service', 'lock', 'building', 'additional'];

                return categoryOrder.map(categoryKey => {
                  const categoryAnswers = groupedAnswers[categoryKey];
                  if (!categoryAnswers || categoryAnswers.length === 0) return null;

                  return (
                    <div key={categoryKey} className="space-y-2">
                      <h5 className="text-xs font-semibold text-primary/70 uppercase tracking-wide">
                        {categoryTitles[categoryKey]}
                      </h5>
                      <div className="space-y-2">
                        {categoryAnswers.map((answer, index) => (
                          <div key={`${categoryKey}-${index}`} className="flex items-start gap-2 bg-background/50 p-3 rounded-md">
                            {answer.icon && (
                              <div className="text-primary mt-0.5 flex-shrink-0">
                                {answer.icon}
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-foreground">{answer.label}</p>
                              <p className="text-sm text-foreground/80 break-words">{answer.value}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                }).filter(Boolean);
              })()}
            </div>
          </div>
        )}

        {formattedAnswers.length === 0 && (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">Ingen kundesvar tilgængelige</p>
            {job.followUpAnswers && (
              <div className="mt-4 text-xs text-muted-foreground">
                <p>Debug: {JSON.stringify(job.followUpAnswers)}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};