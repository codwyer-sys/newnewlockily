import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Phone } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

interface ContactInfoDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (contactInfo: { name: string; phone: string }) => void;
  isSubmitting?: boolean;
}

const ContactInfoDialog: React.FC<ContactInfoDialogProps> = ({
  open,
  onOpenChange,
  onSubmit,
  isSubmitting = false
}) => {
  const { t } = useLanguage();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const isFormValid = name.trim().length >= 2 && phone.trim().length >= 8;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      onSubmit({ name: name.trim(), phone: phone.trim() });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-card-foreground font-headline font-bold text-xl">
            {t('contact_dialog.title')}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-card-foreground font-medium">
              {t('contact_dialog.name_label')}
            </Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="name"
                type="text"
                placeholder={t('contact_dialog.name_placeholder')}
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10 h-12 bg-background border-border focus:border-primary"
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="text-card-foreground font-medium">
              {t('contact_dialog.phone_label')}
            </Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="phone"
                type="tel"
                placeholder={t('contact_dialog.phone_placeholder')}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="pl-10 h-12 bg-background border-border focus:border-primary"
                disabled={isSubmitting}
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={!isFormValid || isSubmitting}
            className="w-full h-12 font-headline font-bold bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {isSubmitting ? t('contact_dialog.submitting_button') : t('contact_dialog.submit_button')}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ContactInfoDialog;