import React from 'react';
import { BlogCategoryWithTranslations } from '@/hooks/useBlogCategories';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';

interface BlogFiltersProps {
  categories: BlogCategoryWithTranslations[];
  selectedCategory: string;
  onCategoryChange: (categoryId: string) => void;
  loading?: boolean;
}

export const BlogFilters: React.FC<BlogFiltersProps> = ({
  categories,
  selectedCategory,
  onCategoryChange,
  loading = false
}) => {
  if (loading) {
    return (
      <div className="bg-muted/30 rounded-lg p-6 space-y-4">
        <Skeleton className="h-5 w-24" />
        <div className="flex flex-wrap gap-2">
          {[...Array(5)].map((_, index) => (
            <Skeleton key={index} className="h-8 w-20" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-muted/30 rounded-lg p-6 space-y-4">
      <h3 className="font-semibold text-sm text-foreground mb-3">Filter by Category</h3>
      
      <div className="flex flex-wrap gap-2">
        {/* All Categories Button */}
        <Button
          variant={selectedCategory === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => onCategoryChange('all')}
          className="text-xs"
        >
          All Posts
          <Badge variant="secondary" className="ml-2 text-xs">
            {categories.length}
          </Badge>
        </Button>

        <Separator orientation="vertical" className="h-8 mx-2" />

        {/* Category Buttons */}
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? 'default' : 'outline'}
            size="sm"
            onClick={() => onCategoryChange(category.id)}
            className="text-xs"
          >
            {category.name}
          </Button>
        ))}
      </div>

      {/* Clear Filters */}
      {selectedCategory !== 'all' && (
        <div className="pt-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onCategoryChange('all')}
            className="text-xs text-muted-foreground hover:text-foreground"
          >
            Clear filters
          </Button>
        </div>
      )}
    </div>
  );
};