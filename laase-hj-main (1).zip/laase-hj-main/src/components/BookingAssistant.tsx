
import React from 'react';
import BookingForm from "@/components/BookingForm";
import { useLanguage } from '@/contexts/LanguageContext';

interface BookingAssistantProps {
  address: string;
  urgency: string;
  selectedDate: string;
}

const BookingAssistant: React.FC<BookingAssistantProps> = ({ address, urgency, selectedDate }) => {
  const { t } = useLanguage();
  
  const getUrgencyText = () => {
    if (urgency === "nu" || urgency === "asap") return t('booking.assistant.help_time');
    if ((urgency === "scheduled" || urgency === "senere") && selectedDate) return `d. ${selectedDate}`;
    return t('booking.assistant.help_time');
  };

  const handleStartBooking = (data: {
    address: string;
    urgency: string;
    selectedDate: string;
    jobType: string;
    followUpAnswers: Record<string, any>;
  }) => {
    console.log('Booking started from assistant:', data);
    // Additional logic can be added here if needed
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto mb-6">
          <div className="bg-cyan-900/20 border border-cyan-500/30 rounded-lg p-4 mb-6 animate-pulse">
            <p className="text-cyan-200 font-medium">
              🔒 {t('booking.assistant.searching')} <strong className="text-white">{address}</strong>, {getUrgencyText()}. Et øjeblik…
            </p>
          </div>
        </div>
        <BookingForm onStartBooking={handleStartBooking} />
      </div>
    </div>
  );
};

export default BookingAssistant;
