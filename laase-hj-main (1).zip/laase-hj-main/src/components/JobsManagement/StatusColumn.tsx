import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AdminJobCard } from './AdminJobCard';
import { LocksmithJob } from '@/types/locksmith';

interface StatusColumnProps {
  status: string;
  title: string;
  color: string;
  jobs: LocksmithJob[];
  onJobClick: (job: LocksmithJob) => void;
  onJobSelect: (jobId: string, selected: boolean) => void;
  selectedJobs: Set<string>;
  onStatusChange?: (jobId: string, newStatus: string) => void;
  isUpdating: boolean;
}

export const StatusColumn: React.FC<StatusColumnProps> = ({
  status,
  title,
  color,
  jobs,
  onJobClick,
  onJobSelect,
  selectedJobs,
  onStatusChange,
  isUpdating
}) => {

  return (
    <Card className="h-fit min-h-[600px]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-sm">
          <span>{title}</span>
          <Badge variant="secondary" className={color}>
            {jobs.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 min-h-[500px] p-3">
        {jobs.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <p>No jobs in this status</p>
          </div>
        ) : (
          jobs.map(job => (
            <AdminJobCard
              key={job.id}
              job={job}
              onClick={() => onJobClick(job)}
              onSelect={(selected) => onJobSelect(job.id, selected)}
              isSelected={selectedJobs.has(job.id)}
              isUpdating={isUpdating}
            />
          ))
        )}
      </CardContent>
    </Card>
  );
};