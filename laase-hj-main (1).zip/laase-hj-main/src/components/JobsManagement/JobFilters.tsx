import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Filter, X } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface JobFiltersProps {
  filters: {
    search: string;
    status: string[];
    dateRange: { start: string; end: string };
    market: string[];
  };
  onFilterChange: (key: string, value: any) => void;
  onClearFilters: () => void;
  jobCount: number;
}

const STATUS_OPTIONS = [
  { value: 'waiting_for_quotes', label: 'Waiting for Quotes' },
  { value: 'quotes_received', label: 'Quotes Received' },
  { value: 'order_placed', label: 'Order Placed' },
  { value: 'order_fulfilled', label: 'Order Fulfilled' },
  { value: 'canceled', label: 'Canceled' }
];


const MARKET_OPTIONS = [
  { value: 'DK', label: 'Denmark', color: 'bg-blue-100 text-blue-800' },
  { value: 'SE', label: 'Sweden', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'NO', label: 'Norway', color: 'bg-red-100 text-red-800' },
  { value: 'FI', label: 'Finland', color: 'bg-cyan-100 text-cyan-800' },
  { value: 'DE', label: 'Germany', color: 'bg-gray-100 text-gray-800' },
  { value: 'UK', label: 'United Kingdom', color: 'bg-purple-100 text-purple-800' },
  { value: 'US', label: 'United States', color: 'bg-green-100 text-green-800' }
];

export const JobFilters: React.FC<JobFiltersProps> = ({
  filters,
  onFilterChange,
  onClearFilters,
  jobCount
}) => {
  const [isOpen, setIsOpen] = React.useState(false);
  
  const activeFilterCount = [
    filters.search ? 1 : 0,
    filters.status.length,
    filters.market.length,
    (filters.dateRange.start || filters.dateRange.end) ? 1 : 0
  ].reduce((sum, count) => sum + count, 0);

  const handleStatusToggle = (status: string) => {
    const newStatus = filters.status.includes(status)
      ? filters.status.filter(s => s !== status)
      : [...filters.status, status];
    onFilterChange('status', newStatus);
  };


  const handleMarketToggle = (market: string) => {
    const newMarket = filters.market.includes(market)
      ? filters.market.filter(m => m !== market)
      : [...filters.market, market];
    onFilterChange('market', newMarket);
  };

  return (
    <Card>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CardHeader className="pb-3">
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between cursor-pointer">
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                Filters
                {activeFilterCount > 0 && (
                  <Badge variant="secondary">{activeFilterCount}</Badge>
                )}
              </CardTitle>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">
                  {jobCount} jobs
                </span>
                {activeFilterCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onClearFilters();
                    }}
                  >
                    <X className="w-4 h-4 mr-1" />
                    Clear
                  </Button>
                )}
              </div>
            </div>
          </CollapsibleTrigger>
        </CardHeader>
        
        <CollapsibleContent>
          <CardContent className="space-y-4">
            {/* Search */}
            <div>
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search by customer name, phone, address, or job ID..."
                  value={filters.search}
                  onChange={(e) => onFilterChange('search', e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Status Filter */}
              <div>
                <Label>Status</Label>
                <div className="space-y-2 mt-2">
                  {STATUS_OPTIONS.map(option => (
                    <div key={option.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`status-${option.value}`}
                        checked={filters.status.includes(option.value)}
                        onCheckedChange={() => handleStatusToggle(option.value)}
                      />
                      <Label 
                        htmlFor={`status-${option.value}`}
                        className="text-sm font-normal"
                      >
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Market Filter */}
              <div>
                <Label>Market</Label>
                <div className="space-y-2 mt-2">
                  {MARKET_OPTIONS.map(option => (
                    <div key={option.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`market-${option.value}`}
                        checked={filters.market.includes(option.value)}
                        onCheckedChange={() => handleMarketToggle(option.value)}
                      />
                      <Label 
                        htmlFor={`market-${option.value}`}
                        className="text-sm font-normal"
                      >
                        <Badge variant="outline" className={option.color}>
                          {option.label}
                        </Badge>
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Date Range Filter */}
              <div>
                <Label>Date Range</Label>
                <div className="space-y-2 mt-2">
                  <div>
                    <Label htmlFor="start-date" className="text-xs text-muted-foreground">Start Date</Label>
                    <Input
                      id="start-date"
                      type="date"
                      value={filters.dateRange.start}
                      onChange={(e) => onFilterChange('dateRange', { ...filters.dateRange, start: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="end-date" className="text-xs text-muted-foreground">End Date</Label>
                    <Input
                      id="end-date"
                      type="date"
                      value={filters.dateRange.end}
                      onChange={(e) => onFilterChange('dateRange', { ...filters.dateRange, end: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};