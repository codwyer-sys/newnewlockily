import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { CreditCard, DollarSign, RefreshCw, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface PaymentSectionProps {
  jobId: string;
}

interface PaymentTransaction {
  id: string;
  amount_total: number;
  status: string;
  stripe_payment_intent_id: string;
  created_at: string;
  platform_fee: number;
  locksmith_amount: number;
}

export const PaymentSection: React.FC<PaymentSectionProps> = ({ jobId }) => {
  const [paymentData, setPaymentData] = useState<PaymentTransaction | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefunding, setIsRefunding] = useState(false);
  const { toast } = useToast();

  const fetchPaymentData = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('payment_transactions')
        .select('*')
        .eq('booking_id', jobId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      setPaymentData(data);
    } catch (error) {
      console.error('Failed to fetch payment data:', error);
      toast({
        title: "Failed to Load Payment Data",
        description: "Could not retrieve payment information for this job.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefund = async () => {
    if (!paymentData?.stripe_payment_intent_id) {
      toast({
        title: "Cannot Process Refund",
        description: "No payment information available for refund.",
        variant: "destructive"
      });
      return;
    }

    setIsRefunding(true);
    try {
      // This would integrate with your existing Stripe refund functionality
      // For now, we'll just update the status in the database
      const { error } = await supabase
        .from('payment_transactions')
        .update({ status: 'refunded' })
        .eq('id', paymentData.id);

      if (error) throw error;

      toast({
        title: "Refund Processed",
        description: `Refund of $${(paymentData.amount_total / 100).toFixed(2)} has been processed.`
      });

      // Refresh payment data
      fetchPaymentData();
    } catch (error) {
      console.error('Refund failed:', error);
      toast({
        title: "Refund Failed",
        description: "Failed to process refund. Please try again or contact support.",
        variant: "destructive"
      });
    } finally {
      setIsRefunding(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const configs = {
      'succeeded': { label: 'Paid', color: 'bg-green-100 text-green-800' },
      'pending': { label: 'Pending', color: 'bg-yellow-100 text-yellow-800' },
      'failed': { label: 'Failed', color: 'bg-red-100 text-red-800' },
      'refunded': { label: 'Refunded', color: 'bg-gray-100 text-gray-800' },
      'canceled': { label: 'Canceled', color: 'bg-red-100 text-red-800' }
    };
    return configs[status as keyof typeof configs] || configs.pending;
  };

  React.useEffect(() => {
    fetchPaymentData();
  }, [jobId]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-4 h-4" />
          Payment Information
          <Button
            variant="ghost"
            size="sm"
            onClick={fetchPaymentData}
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          <div className="text-center text-muted-foreground">Loading payment data...</div>
        ) : paymentData ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Status</span>
              <Badge variant="outline" className={getStatusBadge(paymentData.status).color}>
                {getStatusBadge(paymentData.status).label}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Total Amount</span>
              <span className="font-mono">
                ${(paymentData.amount_total / 100).toFixed(2)}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Platform Fee</span>
              <span className="font-mono text-muted-foreground">
                ${(paymentData.platform_fee / 100).toFixed(2)}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Locksmith Amount</span>
              <span className="font-mono">
                ${(paymentData.locksmith_amount / 100).toFixed(2)}
              </span>
            </div>
            
            {paymentData.stripe_payment_intent_id && (
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Payment ID</span>
                <span className="font-mono text-xs text-muted-foreground">
                  {paymentData.stripe_payment_intent_id.slice(0, 20)}...
                </span>
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Date</span>
              <span className="text-sm">
                {new Date(paymentData.created_at).toLocaleDateString()}
              </span>
            </div>
            
            {paymentData.status === 'succeeded' && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    disabled={isRefunding}
                  >
                    <DollarSign className="w-4 h-4 mr-2" />
                    {isRefunding ? 'Processing Refund...' : 'Issue Refund'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-destructive" />
                      Confirm Refund
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to refund ${(paymentData.amount_total / 100).toFixed(2)} for this job?
                      This action cannot be undone and will be processed immediately.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleRefund}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Process Refund
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>
        ) : (
          <div className="text-center text-muted-foreground">
            <CreditCard className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No payment information available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};