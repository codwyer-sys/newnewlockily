import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { JobFilters } from './JobFilters';
import { BulkActions } from './BulkActions';
import { useJobsKanban } from '@/hooks/useJobsKanban';
import { useJobFilters } from '@/hooks/useJobFilters';
import { LocksmithJob } from '@/types/locksmith';
import { format } from 'date-fns';
import { ExternalLink, ChevronUp, ChevronDown } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { getCountryFlag } from '@/utils/countryFlags';

type SortField = 'jobNumber' | 'customerName' | 'category' | 'address' | 'status' | 'timeRequested';
type SortDirection = 'asc' | 'desc';

const STATUS_COLORS = {
  waiting_for_quotes: 'bg-yellow-50 text-yellow-700 border-yellow-200',
  quotes_received: 'bg-blue-50 text-blue-700 border-blue-200',
  order_placed: 'bg-purple-50 text-purple-700 border-purple-200',
  order_fulfilled: 'bg-green-50 text-green-700 border-green-200',
  canceled: 'bg-red-50 text-red-700 border-red-200'
};

export const JobsDataTable: React.FC = () => {
  const navigate = useNavigate();
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set());
  const [sortField, setSortField] = useState<SortField>('jobNumber');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [pageSize, setPageSize] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);

  const { 
    jobs, 
    isLoading, 
    error, 
    updateJobStatus, 
    isUpdating 
  } = useJobsKanban();
  
  const {
    filteredJobs,
    filters,
    updateFilter,
    clearFilters
  } = useJobFilters(jobs);

  // Sort jobs
  const sortedJobs = React.useMemo(() => {
    const sorted = [...filteredJobs].sort((a, b) => {
      let aValue: any = a[sortField];
      let bValue: any = b[sortField];

      // Handle special cases
      if (sortField === 'timeRequested') {
        aValue = new Date(a.timeRequested);
        bValue = new Date(b.timeRequested);
      }

      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return sorted;
  }, [filteredJobs, sortField, sortDirection]);

  // Paginate jobs
  const paginatedJobs = React.useMemo(() => {
    const startIndex = (currentPage - 1) * pageSize;
    return sortedJobs.slice(startIndex, startIndex + pageSize);
  }, [sortedJobs, currentPage, pageSize]);

  const totalPages = Math.ceil(sortedJobs.length / pageSize);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleJobSelect = (jobId: string, selected: boolean) => {
    const newSelected = new Set(selectedJobs);
    if (selected) {
      newSelected.add(jobId);
    } else {
      newSelected.delete(jobId);
    }
    setSelectedJobs(newSelected);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedJobs(new Set(paginatedJobs.map(job => job.id)));
    } else {
      setSelectedJobs(new Set());
    }
  };

  const handleJobClick = (job: LocksmithJob) => {
    const url = `/admin-portal/jobs/${job.id}`;
    window.open(url, '_blank');
  };

  const handleStatusChange = async (jobId: string, newStatus: string) => {
    try {
      await updateJobStatus(jobId, newStatus);
    } catch (error) {
      console.error('Failed to update job status:', error);
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? 
      <ChevronUp className="h-4 w-4" /> : 
      <ChevronDown className="h-4 w-4" />;
  };

  const formatStatus = (status: string) => {
    return status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading jobs...</div>;
  }

  if (error) {
    return <div className="text-destructive text-center">Error loading jobs: {error.message}</div>;
  }

  return (
    <div className="space-y-6">
      <JobFilters 
        filters={filters}
        onFilterChange={updateFilter}
        onClearFilters={clearFilters}
        jobCount={sortedJobs.length}
      />
      
      {selectedJobs.size > 0 && (
        <BulkActions 
          selectedJobs={Array.from(selectedJobs)}
          onClearSelection={() => setSelectedJobs(new Set())}
          onStatusUpdate={handleStatusChange}
        />
      )}

      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-b bg-muted/20">
              <TableHead className="w-12 h-11">
                <Checkbox
                  checked={selectedJobs.size === paginatedJobs.length && paginatedJobs.length > 0}
                  onCheckedChange={handleSelectAll}
                />
              </TableHead>
              <TableHead className="w-8 h-11"></TableHead>
              <TableHead 
                className="cursor-pointer hover:bg-muted/50 select-none h-11"
                onClick={() => handleSort('jobNumber')}
              >
                <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Job #
                  {getSortIcon('jobNumber')}
                </div>
              </TableHead>
              <TableHead 
                className="cursor-pointer hover:bg-muted/50 select-none h-11"
                onClick={() => handleSort('customerName')}
              >
                <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Customer
                  {getSortIcon('customerName')}
                </div>
              </TableHead>
              <TableHead className="h-11">
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Phone
                </div>
              </TableHead>
              <TableHead 
                className="cursor-pointer hover:bg-muted/50 select-none h-11"
                onClick={() => handleSort('category')}
              >
                <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Category
                  {getSortIcon('category')}
                </div>
              </TableHead>
              <TableHead 
                className="cursor-pointer hover:bg-muted/50 select-none h-11"
                onClick={() => handleSort('address')}
              >
                <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Address
                  {getSortIcon('address')}
                </div>
              </TableHead>
              <TableHead 
                className="cursor-pointer hover:bg-muted/50 select-none h-11"
                onClick={() => handleSort('status')}
              >
                <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Status
                  {getSortIcon('status')}
                </div>
              </TableHead>
              <TableHead 
                className="cursor-pointer hover:bg-muted/50 select-none h-11"
                onClick={() => handleSort('timeRequested')}
              >
                <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Created
                  {getSortIcon('timeRequested')}
                </div>
              </TableHead>
              <TableHead className="w-16 h-11"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedJobs.map((job) => (
              <TableRow 
                key={job.id}
                className="cursor-pointer hover:bg-muted/30 border-b border-border/50 h-14"
                onClick={() => handleJobClick(job)}
              >
                <TableCell onClick={(e) => e.stopPropagation()} className="py-3">
                  <Checkbox
                    checked={selectedJobs.has(job.id)}
                    onCheckedChange={(checked) => handleJobSelect(job.id, checked as boolean)}
                  />
                </TableCell>
                <TableCell className="py-3">
                  <div className="flex items-center justify-center" title={job.market || 'DK'}>
                    <span className="text-base leading-none">
                      {getCountryFlag(job.market || 'DK')}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="py-3">
                  <Button 
                    variant="link" 
                    className="p-0 h-auto font-mono text-sm font-medium text-foreground hover:text-primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleJobClick(job);
                    }}
                  >
                    #{job.jobNumber}
                    <ExternalLink className="h-3 w-3 ml-1 opacity-50" />
                  </Button>
                </TableCell>
                <TableCell className="py-3">
                  <div className="font-medium text-sm">{job.customerName || 'Unknown Customer'}</div>
                </TableCell>
                <TableCell className="py-3">
                  <div className="text-sm text-muted-foreground">{job.customerPhone}</div>
                </TableCell>
                <TableCell className="py-3">
                  <div className="text-sm font-medium">{job.category}</div>
                </TableCell>
                <TableCell className="py-3">
                  <div className="max-w-[250px] truncate text-sm" title={job.address}>
                    {job.address}
                  </div>
                </TableCell>
                <TableCell onClick={(e) => e.stopPropagation()} className="py-3">
                  <Select 
                    value={job.status || 'waiting_for_quotes'} 
                    onValueChange={(value) => handleStatusChange(job.id, value)}
                    disabled={isUpdating}
                  >
                    <SelectTrigger className="w-fit border-0 bg-transparent p-0 h-auto">
                      <Badge 
                        variant="outline" 
                        className={`${STATUS_COLORS[job.status as keyof typeof STATUS_COLORS] || STATUS_COLORS.waiting_for_quotes} border font-normal text-xs px-2 py-1`}
                      >
                        {formatStatus(job.status || 'waiting_for_quotes')}
                      </Badge>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="waiting_for_quotes">Waiting for Quotes</SelectItem>
                      <SelectItem value="quotes_received">Quotes Received</SelectItem>
                      <SelectItem value="order_placed">Order Placed</SelectItem>
                      <SelectItem value="order_fulfilled">Order Fulfilled</SelectItem>
                      <SelectItem value="canceled">Canceled</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell className="py-3">
                  <div className="text-sm text-muted-foreground">
                    <div className="leading-none">{format(new Date(job.timeRequested), 'MMM dd, yyyy')}</div>
                    <div className="text-xs leading-none mt-0.5">
                      {format(new Date(job.timeRequested), 'HH:mm')}
                    </div>
                  </div>
                </TableCell>
                <TableCell onClick={(e) => e.stopPropagation()} className="py-3">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleJobClick(job)}
                    className="h-7 w-7 p-0 hover:bg-muted/50"
                  >
                    <ExternalLink className="h-3 w-3 text-muted-foreground" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            Showing {((currentPage - 1) * pageSize) + 1} to {Math.min(currentPage * pageSize, sortedJobs.length)} of {sortedJobs.length} jobs
          </span>
          <Select value={pageSize.toString()} onValueChange={(value) => {
            setPageSize(Number(value));
            setCurrentPage(1);
          }}>
            <SelectTrigger className="w-20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="10">10</SelectItem>
              <SelectItem value="25">25</SelectItem>
              <SelectItem value="50">50</SelectItem>
              <SelectItem value="100">100</SelectItem>
            </SelectContent>
          </Select>
          <span className="text-sm text-muted-foreground">per page</span>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <span className="text-sm">
            Page {currentPage} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
};