import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { CheckSquare, X, Download, RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface BulkActionsProps {
  selectedJobs: string[];
  onClearSelection: () => void;
  onStatusUpdate: (jobId: string, status: string) => void;
}

const STATUS_OPTIONS = [
  { value: 'waiting_for_quotes', label: 'Waiting for Quotes' },
  { value: 'quotes_received', label: 'Quotes Received' },
  { value: 'order_placed', label: 'Order Placed' },
  { value: 'order_fulfilled', label: 'Order Fulfilled' },
  { value: 'canceled', label: 'Canceled' }
];

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low Priority' },
  { value: 'medium', label: 'Medium Priority' },
  { value: 'high', label: 'High Priority' }
];

export const BulkActions: React.FC<BulkActionsProps> = ({
  selectedJobs,
  onClearSelection,
  onStatusUpdate
}) => {
  const [selectedBulkStatus, setSelectedBulkStatus] = useState<string>('');
  const [selectedBulkPriority, setSelectedBulkPriority] = useState<string>('');
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const handleBulkStatusUpdate = async () => {
    if (!selectedBulkStatus) {
      toast({
        title: "No Status Selected",
        description: "Please select a status to update all selected jobs.",
        variant: "destructive"
      });
      return;
    }

    setIsUpdating(true);
    try {
      const promises = selectedJobs.map(jobId => onStatusUpdate(jobId, selectedBulkStatus));
      await Promise.all(promises);
      
      toast({
        title: "Bulk Update Successful",
        description: `Updated ${selectedJobs.length} jobs to ${STATUS_OPTIONS.find(s => s.value === selectedBulkStatus)?.label}`
      });
      
      onClearSelection();
      setSelectedBulkStatus('');
    } catch (error) {
      console.error('Bulk status update failed:', error);
      toast({
        title: "Bulk Update Failed",
        description: "Some jobs may not have been updated. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleExportSelected = () => {
    // Create CSV data for selected jobs
    const csvData = selectedJobs.map(jobId => ({
      jobId,
      exportedAt: new Date().toISOString()
    }));
    
    const csvContent = [
      ['Job ID', 'Exported At'],
      ...csvData.map(row => [row.jobId, row.exportedAt])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `selected-jobs-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: `Exported ${selectedJobs.length} selected jobs to CSV.`
    });
  };

  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardContent className="py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-primary" />
              <span className="font-medium">
                {selectedJobs.length} job{selectedJobs.length !== 1 ? 's' : ''} selected
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <Select value={selectedBulkStatus} onValueChange={setSelectedBulkStatus}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Change status to..." />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    size="sm" 
                    disabled={!selectedBulkStatus || isUpdating}
                  >
                    {isUpdating ? (
                      <>
                        <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                        Updating...
                      </>
                    ) : (
                      'Update Status'
                    )}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Bulk Status Update</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to update {selectedJobs.length} job{selectedJobs.length !== 1 ? 's' : ''} to{' '}
                      <Badge variant="outline">
                        {STATUS_OPTIONS.find(s => s.value === selectedBulkStatus)?.label}
                      </Badge>?
                      This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleBulkStatusUpdate}>
                      Update {selectedJobs.length} Job{selectedJobs.length !== 1 ? 's' : ''}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleExportSelected}>
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
            
            <Button variant="ghost" size="sm" onClick={onClearSelection}>
              <X className="w-4 h-4 mr-2" />
              Clear Selection
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};