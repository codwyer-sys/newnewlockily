import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Phone, Clock, AlertTriangle, User, Calendar, FileText } from 'lucide-react';
import { LocksmithJob } from '@/types/locksmith';
import { PaymentSection } from './PaymentSection';
import { useJobStatusUpdate } from '@/hooks/useJobStatusUpdate';
import { useToast } from '@/hooks/use-toast';

interface JobDetailsModalProps {
  job: LocksmithJob;
  onClose: () => void;
  onUpdate: () => void;
}

const STATUS_OPTIONS = [
  { value: 'waiting_for_quotes', label: 'Waiting for Quotes' },
  { value: 'quotes_received', label: 'Quotes Received' },
  { value: 'order_placed', label: 'Order Placed' },
  { value: 'order_fulfilled', label: 'Order Fulfilled' },
  { value: 'canceled', label: 'Canceled' }
];

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low', color: 'bg-green-100 text-green-800' },
  { value: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'high', label: 'High', color: 'bg-red-100 text-red-800' }
];

export const JobDetailsModal: React.FC<JobDetailsModalProps> = ({
  job,
  onClose,
  onUpdate
}) => {
  const [editMode, setEditMode] = useState(false);
  const [editedJob, setEditedJob] = useState(job);
  const [adminNotes, setAdminNotes] = useState(job.adminNotes || '');
  const [selectedStatus, setSelectedStatus] = useState(job.status || 'waiting_for_quotes');
  const [selectedPriority, setSelectedPriority] = useState(job.priority || 'medium');
  
  const { updateJobStatus, updateJobDetails, isUpdating } = useJobStatusUpdate();
  const { toast } = useToast();

  const handleSave = async () => {
    try {
      await updateJobDetails(job.id, {
        ...editedJob,
        adminNotes,
        priority: selectedPriority,
        status: selectedStatus
      });
      
      toast({
        title: "Job Updated",
        description: "Job details have been successfully updated."
      });
      
      setEditMode(false);
      onUpdate();
    } catch (error) {
      console.error('Failed to update job:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update job details. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    try {
      await updateJobStatus(job.id, newStatus);
      setSelectedStatus(newStatus);
      toast({
        title: "Status Updated",
        description: `Job status changed to ${STATUS_OPTIONS.find(s => s.value === newStatus)?.label}`
      });
      onUpdate();
    } catch (error) {
      console.error('Failed to update status:', error);
      toast({
        title: "Status Update Failed",
        description: "Failed to update job status. Please try again.",
        variant: "destructive"
      });
    }
  };

  const getUrgencyBadge = (urgency: string) => {
    const configs = {
      emergency: { label: 'Emergency', color: 'bg-red-100 text-red-800' },
      high: { label: 'High', color: 'bg-orange-100 text-orange-800' },
      medium: { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
      low: { label: 'Low', color: 'bg-green-100 text-green-800' }
    };
    return configs[urgency as keyof typeof configs] || configs.medium;
  };

  const urgencyConfig = getUrgencyBadge(job.urgency);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Job Details - #{job.id.slice(0, 8)}</span>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={urgencyConfig.color}>
                <AlertTriangle className="w-3 h-3 mr-1" />
                {urgencyConfig.label}
              </Badge>
              <Badge variant="outline">
                {STATUS_OPTIONS.find(s => s.value === selectedStatus)?.label}
              </Badge>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Job Information */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Customer Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">{job.customerName || 'Unknown Customer'}</span>
                </div>
                {job.customerPhone && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <span>{job.customerPhone}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{job.address}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Job Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <Label>Category</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-lg">{job.category}</span>
                    <span>{job.category}</span>
                  </div>
                </div>
                
                {job.timing && (
                  <div>
                    <Label>Timing</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{job.timing === 'nu' || job.timing === 'now' ? 'ASAP' : job.timing}</span>
                    </div>
                  </div>
                )}
                
                {job.lockBrand && (
                  <div>
                    <Label>Lock Brand</Label>
                    <p className="text-sm mt-1">{job.lockBrand}</p>
                  </div>
                )}
                
                <div>
                  <Label>Created</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{new Date(job.timeRequested).toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Follow-up Answers */}
            {job.followUpAnswers && Object.keys(job.followUpAnswers).length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Follow-up Answers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(job.followUpAnswers).map(([key, value]) => (
                      <div key={key} className="text-sm">
                        <span className="font-medium capitalize">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:</span>
                        <span className="ml-2">{String(value)}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Admin Controls */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Status & Priority</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Status</Label>
                  <Select value={selectedStatus} onValueChange={handleStatusChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Priority</Label>
                  <Select value={selectedPriority} onValueChange={setSelectedPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIORITY_OPTIONS.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          <Badge variant="outline" className={option.color}>
                            {option.label}
                          </Badge>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Admin Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add internal notes about this job..."
                  rows={4}
                />
              </CardContent>
            </Card>

            <PaymentSection jobId={job.id} />
          </div>
        </div>

        <Separator />

        <div className="flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <div className="flex gap-2">
            <Button onClick={handleSave} disabled={isUpdating}>
              {isUpdating ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};