import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { MapPin, Clock, Phone, AlertTriangle } from 'lucide-react';
import { LocksmithJob } from '@/types/locksmith';

interface AdminJobCardProps {
  job: LocksmithJob;
  onClick: () => void;
  onSelect: (selected: boolean) => void;
  isSelected: boolean;
  isUpdating: boolean;
}

export const AdminJobCard: React.FC<AdminJobCardProps> = ({
  job,
  onClick,
  onSelect,
  isSelected,
  isUpdating
}) => {
  const getUrgencyConfig = (urgency: string) => {
    switch (urgency) {
      case 'emergency':
        return { label: 'Emergency', color: 'bg-red-100 text-red-800', icon: AlertTriangle };
      case 'high':
        return { label: 'High', color: 'bg-orange-100 text-orange-800', icon: AlertTriangle };
      case 'medium':
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800', icon: Clock };
      case 'low':
        return { label: 'Low', color: 'bg-green-100 text-green-800', icon: Clock };
      default:
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800', icon: Clock };
    }
  };

  const urgencyConfig = getUrgencyConfig(job.urgency);
  const UrgencyIcon = urgencyConfig.icon;

  const formatAddress = (address: string) => {
    if (address.length > 40) {
      return address.substring(0, 40) + '...';
    }
    return address;
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const date = new Date(timestamp);
    const diffInMs = now.getTime() - date.getTime();
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
      return `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}d ago`;
    }
  };

  const handleCheckboxChange = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <Card 
      className={`cursor-pointer transition-all hover:shadow-md ${isSelected ? 'ring-2 ring-primary' : ''} ${isUpdating ? 'opacity-50' : ''}`}
      onClick={onClick}
    >
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2">
            <div onClick={handleCheckboxChange}>
              <Checkbox 
                checked={isSelected}
                onCheckedChange={onSelect}
                className="mt-1"
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">
                  {job.customerName || 'Unknown Customer'}
                </span>
                <Badge variant="outline" className={urgencyConfig.color}>
                  <UrgencyIcon className="w-3 h-3 mr-1" />
                  {urgencyConfig.label}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                #{job.id.slice(0, 8)} • {formatTimeAgo(job.timeRequested)}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-lg">{job.category}</span>
            <span className="text-muted-foreground">
              {job.category}
            </span>
          </div>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            <span>{formatAddress(job.address)}</span>
          </div>
          
          {job.customerPhone && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Phone className="w-3 h-3" />
              <span>{job.customerPhone}</span>
            </div>
          )}
        </div>

        {job.timing && (
          <div className="flex items-center gap-2 text-xs">
            <Clock className="w-3 h-3 text-muted-foreground" />
            <span className="text-muted-foreground">
              {job.timing === 'nu' || job.timing === 'now' || job.timing === 'asap' ? 'ASAP' : job.timing}
            </span>
          </div>
        )}

        {job.lockBrand && (
          <div className="text-xs">
            <span className="font-medium">Lock:</span> {job.lockBrand}
          </div>
        )}
      </CardContent>
    </Card>
  );
};