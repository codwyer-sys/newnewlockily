import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StatusColumn } from './StatusColumn';
import { JobFilters } from './JobFilters';
import { BulkActions } from './BulkActions';
import { useJobsKanban } from '@/hooks/useJobsKanban';
import { useJobFilters } from '@/hooks/useJobFilters';
import { LocksmithJob } from '@/types/locksmith';

const STATUS_CONFIG = {
  waiting_for_quotes: {
    title: 'Waiting for Quotes',
    color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    description: 'Jobs awaiting locksmith quotes'
  },
  quotes_received: {
    title: 'Quotes Received',
    color: 'bg-blue-100 text-blue-800 border-blue-300',
    description: 'Jobs with available quotes'
  },
  order_placed: {
    title: 'Order Placed',
    color: 'bg-purple-100 text-purple-800 border-purple-300',
    description: 'Jobs with confirmed orders'
  },
  order_fulfilled: {
    title: 'Order Fulfilled',
    color: 'bg-green-100 text-green-800 border-green-300',
    description: 'Completed jobs'
  },
  canceled: {
    title: 'Canceled',
    color: 'bg-red-100 text-red-800 border-red-300',
    description: 'Canceled jobs'
  }
};

export const JobsKanbanBoard: React.FC = () => {
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set());
  const navigate = useNavigate();
  
  const { 
    jobs, 
    isLoading, 
    error, 
    updateJobStatus, 
    isUpdating 
  } = useJobsKanban();
  
  const {
    filteredJobs,
    filters,
    updateFilter,
    clearFilters,
    applyFilters
  } = useJobFilters(jobs);

  const groupedJobs = React.useMemo(() => {
    const grouped: Record<string, LocksmithJob[]> = {
      waiting_for_quotes: [],
      quotes_received: [],
      order_placed: [],
      order_fulfilled: [],
      canceled: []
    };
    
    filteredJobs.forEach(job => {
      const status = job.status || 'waiting_for_quotes';
      if (grouped[status]) {
        grouped[status].push(job);
      }
    });
    
    return grouped;
  }, [filteredJobs]);

  const handleJobSelect = (jobId: string, selected: boolean) => {
    const newSelected = new Set(selectedJobs);
    if (selected) {
      newSelected.add(jobId);
    } else {
      newSelected.delete(jobId);
    }
    setSelectedJobs(newSelected);
  };

  const handleJobClick = (job: LocksmithJob) => {
    navigate(`/admin-portal/jobs/${job.id}`);
  };

  const handleStatusChange = async (jobId: string, newStatus: string) => {
    try {
      await updateJobStatus(jobId, newStatus);
    } catch (error) {
      console.error('Failed to update job status:', error);
    }
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading jobs...</div>;
  }

  if (error) {
    return <div className="text-destructive text-center">Error loading jobs: {error.message}</div>;
  }

  return (
    <div className="space-y-6">
      <JobFilters 
        filters={filters}
        onFilterChange={updateFilter}
        onClearFilters={clearFilters}
        jobCount={filteredJobs.length}
      />
      
      {selectedJobs.size > 0 && (
        <BulkActions 
          selectedJobs={Array.from(selectedJobs)}
          onClearSelection={() => setSelectedJobs(new Set())}
          onStatusUpdate={handleStatusChange}
        />
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {Object.entries(STATUS_CONFIG).map(([status, config]) => (
          <StatusColumn
            key={status}
            status={status}
            title={config.title}
            color={config.color}
            jobs={groupedJobs[status] || []}
            onJobClick={handleJobClick}
            onJobSelect={handleJobSelect}
            selectedJobs={selectedJobs}
            isUpdating={isUpdating}
          />
        ))}
      </div>
    </div>
  );
};