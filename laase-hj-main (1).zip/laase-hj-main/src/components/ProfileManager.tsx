
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Loader2, User, Phone, Mail, Edit, Save, X } from "lucide-react";
import { useUserProfile } from "@/hooks/useUserProfile";

const ProfileManager = () => {
  const { profile, isLoading, updateProfile } = useUserProfile();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    phone: ''
  });

  React.useEffect(() => {
    if (profile && !isEditing) {
      setFormData({
        first_name: profile.first_name || '',
        last_name: profile.last_name || '',
        phone: profile.phone || ''
      });
    }
  }, [profile, isEditing]);

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleSave = async () => {
    await updateProfile(formData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    if (profile) {
      setFormData({
        first_name: profile.first_name || '',
        last_name: profile.last_name || '',
        phone: profile.phone || ''
      });
    }
    setIsEditing(false);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    );
  }

  if (!profile) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500">No profile found</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            User Profile
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="capitalize">
              {profile.role}
            </Badge>
            {!isEditing ? (
              <Button variant="outline" size="sm" onClick={handleEdit}>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleSave}>
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button variant="outline" size="sm" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="first_name">First Name</Label>
            {isEditing ? (
              <Input
                id="first_name"
                value={formData.first_name}
                onChange={(e) => setFormData(prev => ({ ...prev, first_name: e.target.value }))}
              />
            ) : (
              <p className="text-sm text-gray-600 mt-1">{profile.first_name || 'Not set'}</p>
            )}
          </div>
          <div>
            <Label htmlFor="last_name">Last Name</Label>
            {isEditing ? (
              <Input
                id="last_name"
                value={formData.last_name}
                onChange={(e) => setFormData(prev => ({ ...prev, last_name: e.target.value }))}
              />
            ) : (
              <p className="text-sm text-gray-600 mt-1">{profile.last_name || 'Not set'}</p>
            )}
          </div>
        </div>

        <div>
          <Label className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email
          </Label>
          <p className="text-sm text-gray-600 mt-1">{profile.email}</p>
        </div>

        <div>
          <Label className="flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Phone
          </Label>
          {isEditing ? (
            <Input
              value={formData.phone}
              onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
            />
          ) : (
            <p className="text-sm text-gray-600 mt-1">{profile.phone || 'Not set'}</p>
          )}
        </div>

        {profile.role === 'locksmith' && profile.profile_data && (
          <div className="border-t pt-4">
            <h3 className="font-semibold mb-2">Locksmith Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
              <div>
                <span className="font-medium">Company:</span> {profile.profile_data.company_name}
              </div>
              <div>
                <span className="font-medium">CVR:</span> {profile.profile_data.cvr_number}
              </div>
              <div className="md:col-span-2">
                <span className="font-medium">Address:</span> {profile.profile_data.address}, {profile.profile_data.postal_code} {profile.profile_data.city}
              </div>
            </div>
          </div>
        )}

        {profile.role === 'admin' && profile.profile_data && (
          <div className="border-t pt-4">
            <h3 className="font-semibold mb-2">Admin Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
              <div>
                <span className="font-medium">Department:</span> {profile.profile_data.department || 'Not set'}
              </div>
              <div>
                <span className="font-medium">Access Level:</span> 
                <Badge variant="outline" className="ml-2 capitalize">
                  {profile.profile_data.access_level}
                </Badge>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ProfileManager;
