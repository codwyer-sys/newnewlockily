import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard,
  FileText,
  Languages,
  ClipboardList,
  Briefcase,
  Users,
  Settings,
  LogOut,
  ChevronRight,
  BarChart3,
  MapPin,
  Phone
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarHeader,
  SidebarFooter,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

const navigationItems = [
  {
    title: 'Dashboard',
    url: '/admin-portal',
    icon: LayoutDashboard,
  },
  {
    title: 'Analytics',
    url: '/admin-portal/analytics',
    icon: BarChart3,
  },
];

const contentItems = [
  {
    title: 'Content Management',
    url: '/admin-portal/content',
    icon: FileText,
  },
  {
    title: 'Translation Management',
    url: '/admin-portal/translations',
    icon: Languages,
  },
  {
    title: 'Blog Management',
    icon: FileText,
    subItems: [
      { title: 'All Posts', url: '/admin-portal/blog/posts' },
      { title: 'Create Post', url: '/admin-portal/blog/create' },
      { title: 'Categories', url: '/admin-portal/blog/categories' },
      { title: 'Media Library', url: '/admin-portal/blog/media' },
    ]
  },
  {
    title: 'SEO Tools',
    icon: BarChart3,
    subItems: [
      { title: 'Meta Tags', url: '/admin-portal/seo/meta-tags' },
      { title: 'Redirects', url: '/admin-portal/seo/redirects' },
      { title: 'Sitemaps', url: '/admin-portal/seo/sitemaps' },
    ]
  },
];

const managementItems = [
  {
    title: 'Order Form',
    icon: ClipboardList,
    subItems: [
      { title: 'Categories', url: '/admin-portal/order-form/categories' },
      { title: 'Follow-up Questions', url: '/admin-portal/order-form/questions' },
    ]
  },
  {
    title: 'Jobs',
    url: '/admin-portal/jobs',
    icon: Briefcase,
  },
  {
    title: 'Locksmiths',
    icon: Users,
    subItems: [
      { title: 'All Locksmiths', url: '/admin-portal/locksmiths' },
      { title: 'Create New', url: '/admin-portal/locksmiths/create' },
    ]
  },
  {
    title: 'Locations',
    icon: MapPin,
    subItems: [
      { title: 'Cities', url: '/admin-portal/locations/cities' },
      { title: 'Areas', url: '/admin-portal/locations/areas' },
    ]
  },
  {
    title: 'Voice AI',
    icon: Phone,
    subItems: [
      { title: 'Call Management', url: '/admin-portal/voice-ai/calls' },
      { title: 'Agent Configuration', url: '/admin-portal/voice-ai/agent' },
      { title: 'Webhook Management', url: '/admin-portal/voice-ai/webhooks' },
      { title: 'Performance Monitor', url: '/admin-portal/voice-ai/performance' },
      { title: 'Integration Settings', url: '/admin-portal/voice-ai/settings' },
    ]
  },
];

const adminItems = [
  {
    title: 'Settings',
    icon: Settings,
    subItems: [
      { title: 'System Settings', url: '/admin-portal/settings' },
      { title: 'User Management', url: '/admin-portal/settings/users' },
    ]
  },
];

export function AdminSidebar() {
  const { state } = useSidebar();
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <Sidebar className="border border-primary-foreground/30 bg-primary m-3 mb-3 rounded-lg overflow-hidden shadow-lg">
      <SidebarHeader className="p-4 bg-primary">
        <div className="flex flex-col space-y-3">
          <div className="flex items-center justify-start">
            <img 
              src="/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png"
              alt="Lockily Admin" 
              className="h-10 w-auto"
            />
          </div>
          {state === 'expanded' && (
            <div className="text-white/70 text-sm font-medium">
              Admin Portal
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-primary">
        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">Overview</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      end={item.url === '/admin-portal'}
                      className={({ isActive }) =>
                        `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 !text-white ${
                          isActive 
                            ? 'bg-white/15 !text-white' 
                            : '!text-white/90 hover:!text-white hover:bg-white/8'
                        }`
                      }
                    >
                       <item.icon className="h-4 w-4 flex-shrink-0" />
                       {state === 'expanded' && <span className="font-medium">{item.title}</span>}
                     </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">Content</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {contentItems.map((item) => (
                <React.Fragment key={item.title}>
                  {item.subItems ? (
                    <Collapsible className="group/collapsible">
                      <SidebarMenuItem>
                        <CollapsibleTrigger asChild>
                          <SidebarMenuButton className="!text-white/90 hover:!text-white hover:bg-white/8 transition-all duration-200 p-3 rounded-lg font-medium">
                            <item.icon className="h-4 w-4 flex-shrink-0" />
                            {state === 'expanded' && (
                              <>
                                <span className="font-medium">{item.title}</span>
                                <ChevronRight className="ml-auto h-4 w-4 transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                              </>
                            )}
                          </SidebarMenuButton>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <SidebarMenuSub>
                            {item.subItems.map((subItem) => (
                              <SidebarMenuSubItem key={subItem.title}>
                                <SidebarMenuSubButton asChild>
                                  <NavLink 
                                    to={subItem.url}
                                    className={({ isActive }) =>
                                      `!text-white/90 hover:!text-white hover:bg-white/10 transition-all duration-200 pl-8 ${
                                        isActive ? 'bg-white/15 !text-white font-medium' : ''
                                      }`
                                    }
                                  >
                                    {subItem.title}
                                  </NavLink>
                                </SidebarMenuSubButton>
                              </SidebarMenuSubItem>
                            ))}
                          </SidebarMenuSub>
                        </CollapsibleContent>
                      </SidebarMenuItem>
                    </Collapsible>
                  ) : (
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <NavLink 
                          to={item.url} 
                          className={({ isActive }) =>
                            `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 !text-white ${
                              isActive 
                                ? 'bg-white/15 !text-white' 
                                : '!text-white/90 hover:!text-white hover:bg-white/8'
                            }`
                          }
                        >
                           <item.icon className="h-4 w-4 flex-shrink-0" />
                           {state === 'expanded' && <span className="font-medium">{item.title}</span>}
                         </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )}
                </React.Fragment>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">Management</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {managementItems.map((item) => (
                <React.Fragment key={item.title}>
                  {item.subItems ? (
                    <Collapsible className="group/collapsible">
                      <SidebarMenuItem>
                        <CollapsibleTrigger asChild>
                          <SidebarMenuButton className="!text-white/90 hover:!text-white hover:bg-white/8 transition-all duration-200 p-3 rounded-lg font-medium">
                            <item.icon className="h-4 w-4 flex-shrink-0" />
                            {state === 'expanded' && (
                              <>
                                <span className="font-medium">{item.title}</span>
                                <ChevronRight className="ml-auto h-4 w-4 transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                              </>
                            )}
                          </SidebarMenuButton>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <SidebarMenuSub>
                            {item.subItems.map((subItem) => (
                              <SidebarMenuSubItem key={subItem.title}>
                                <SidebarMenuSubButton asChild>
                                  <NavLink 
                                    to={subItem.url}
                                    className={({ isActive }) =>
                                      `!text-white/90 hover:!text-white hover:bg-white/10 transition-all duration-200 pl-8 ${
                                        isActive ? 'bg-white/15 !text-white font-medium' : ''
                                      }`
                                    }
                                  >
                                    {subItem.title}
                                  </NavLink>
                                </SidebarMenuSubButton>
                              </SidebarMenuSubItem>
                            ))}
                          </SidebarMenuSub>
                        </CollapsibleContent>
                      </SidebarMenuItem>
                    </Collapsible>
                  ) : (
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <NavLink 
                          to={item.url} 
                          className={({ isActive }) =>
                            `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 !text-white ${
                              isActive 
                                ? 'bg-white/15 !text-white' 
                                : '!text-white/90 hover:!text-white hover:bg-white/8'
                            }`
                          }
                        >
                           <item.icon className="h-4 w-4 flex-shrink-0" />
                           {state === 'expanded' && <span className="font-medium">{item.title}</span>}
                         </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )}
                </React.Fragment>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">Administration</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminItems.map((item) => (
                <Collapsible key={item.title} className="group/collapsible">
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton className="!text-white/90 hover:!text-white hover:bg-white/8 transition-all duration-200 p-3 rounded-lg font-medium">
                        <item.icon className="h-4 w-4 flex-shrink-0" />
                        {state === 'expanded' && (
                          <>
                            <span className="font-medium">{item.title}</span>
                            <ChevronRight className="ml-auto h-4 w-4 transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                          </>
                        )}
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {item.subItems?.map((subItem) => (
                          <SidebarMenuSubItem key={subItem.title}>
                             <SidebarMenuSubButton asChild>
                               <NavLink 
                                 to={subItem.url}
                                 className={({ isActive }) =>
                                   `!text-white/90 hover:!text-white hover:bg-white/10 transition-all duration-200 pl-8 ${
                                     isActive ? 'bg-white/15 !text-white font-medium' : ''
                                   }`
                                 }
                               >
                                 {subItem.title}
                               </NavLink>
                             </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </SidebarMenuItem>
                </Collapsible>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 bg-primary rounded-b-lg">
        <Button 
          variant="ghost" 
          onClick={handleSignOut}
          className="w-full justify-start !text-white/90 hover:!text-white hover:bg-white/8 transition-all duration-200 p-3 rounded-lg font-medium"
        >
          <LogOut className="h-4 w-4 mr-2 flex-shrink-0" />
          {state === 'expanded' && <span>Sign Out</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}