import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';

interface StripeAccount {
  id: string;
  charges_enabled: boolean;
  payouts_enabled: boolean;
  details_submitted: boolean;
  business_profile?: {
    name?: string;
    support_email?: string;
  };
}

interface AccountStatus {
  connected: boolean;
  account: StripeAccount | null;
  onboardingUrl?: string;
}

interface Props {
  accountStatus: AccountStatus;
  onRefreshStatus: () => void;
}

const StripeAccountStatus: React.FC<Props> = ({ accountStatus, onRefreshStatus }) => {
  const getStatusBadge = () => {
    if (!accountStatus?.connected || !accountStatus.account) {
      return <Badge variant="secondary">Ikke tilsluttet</Badge>;
    }

    const account = accountStatus.account;
    
    if (account.charges_enabled && account.payouts_enabled) {
      return <Badge variant="default" className="bg-green-600">Aktiv</Badge>;
    }
    
    if (account.details_submitted) {
      return <Badge variant="outline">Under behandling</Badge>;
    }
    
    return <Badge variant="destructive">Kræver handling</Badge>;
  };

  return (
    <div className="space-y-4">
      {/* Account Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="text-sm font-medium text-muted-foreground">Konto ID</label>
          <p className="font-mono text-sm">{accountStatus.account?.id}</p>
        </div>
        <div>
          <label className="text-sm font-medium text-muted-foreground">Virksomhedsnavn</label>
          <p>{accountStatus.account?.business_profile?.name || 'Ikke angivet'}</p>
        </div>
      </div>

      {/* Capabilities */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-muted-foreground">Funktioner</label>
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            {accountStatus.account?.charges_enabled ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <span className="text-sm">Modtage betalinger</span>
          </div>
          <div className="flex items-center space-x-2">
            {accountStatus.account?.payouts_enabled ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <span className="text-sm">Udbetalinger</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="pt-4 border-t">
        {accountStatus.onboardingUrl && (
          <Button 
            onClick={() => window.open(accountStatus.onboardingUrl, '_blank')}
            className="mr-2"
          >
            <ExternalLink className="mr-2 h-4 w-4" />
            Fuldfør opsætning
          </Button>
        )}
        <Button variant="outline" onClick={onRefreshStatus}>
          Opdater status
        </Button>
      </div>
    </div>
  );
};

export default StripeAccountStatus;