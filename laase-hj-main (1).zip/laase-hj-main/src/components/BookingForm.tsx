
import React from 'react';
import BookingFormContent from "./BookingFormContent";
import BookingButtons from "./BookingButtons";
import { useBookingFormWithLocksmith } from "@/hooks/useBookingFormWithLocksmith";

interface BookingFormProps {
  onStartBooking: (data: {
    address: string;
    urgency: string;
    selectedDate: string;
    jobType: string;
    followUpAnswers: Record<string, any>;
  }) => void;
}

const BookingForm: React.FC<BookingFormProps> = ({ onStartBooking }) => {
  const {
    // Address props
    address,
    setAddress,
    skipAddressSearch,
    setSkipAddressSearch,
    showSuggestions,
    setShowSuggestions,
    hasSelectedSuggestion,
    setHasSelectedSuggestion,
    
    // Urgency props
    urgency,
    selectedDate,
    onUrgencySelect,
    onDateChange,
    showUrgency,
    
    // Job type props
    jobType,
    onJobTypeSelect,
    showJobType,
    
    // Follow up props
    followUpAnswers,
    onFollowUpAnswer,
    showFollowUp,
    
    // Booking props
    showBookingButtons,
    isBookingDisabled,
    isBookingInProgress,
    handleStartBooking
  } = useBookingFormWithLocksmith();

  const handleBookingSubmit = async () => {
    try {
      const booking = await handleStartBooking();
      
      // Call the parent callback with the booking data
      onStartBooking({
        address,
        urgency,
        selectedDate,
        jobType,
        followUpAnswers
      });
    } catch (error) {
      // Error handling is already done in the hook
      console.error('Booking submission failed:', error);
    }
  };

  return (
    <div className="space-y-apple-8">
      <BookingFormContent
        address={address}
        setAddress={setAddress}
        skipAddressSearch={skipAddressSearch}
        setSkipAddressSearch={setSkipAddressSearch}
        showSuggestions={showSuggestions}
        setShowSuggestions={setShowSuggestions}
        hasSelectedSuggestion={hasSelectedSuggestion}
        setHasSelectedSuggestion={setHasSelectedSuggestion}
        urgency={urgency}
        selectedDate={selectedDate}
        onUrgencySelect={onUrgencySelect}
        onDateChange={onDateChange}
        showUrgency={showUrgency}
        jobType={jobType}
        onJobTypeSelect={onJobTypeSelect}
        showJobType={showJobType}
        followUpAnswers={followUpAnswers}
        onFollowUpAnswer={onFollowUpAnswer}
        showFollowUp={showFollowUp}
      />

      {showBookingButtons && (
        <BookingButtons
          isDisabled={isBookingDisabled}
          isBookingInProgress={isBookingInProgress}
          onStartBooking={handleBookingSubmit}
        />
      )}
    </div>
  );
};

export default BookingForm;
