import React, { useState } from 'react';
import { BlogCategoryWithTranslations } from '@/hooks/useBlogCategories';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Skeleton } from '@/components/ui/skeleton';

interface BlogCategoryMultiSelectProps {
  categories: BlogCategoryWithTranslations[];
  selectedCategories: string[];
  onSelectionChange: (categories: string[]) => void;
  loading?: boolean;
}

export const BlogCategoryMultiSelect: React.FC<BlogCategoryMultiSelectProps> = ({
  categories,
  selectedCategories,
  onSelectionChange,
  loading = false
}) => {
  const [isOpen, setIsOpen] = useState(true);
  const { t } = useLanguage();

  const handleCategoryToggle = (categoryId: string) => {
    const isSelected = selectedCategories.includes(categoryId);
    if (isSelected) {
      onSelectionChange(selectedCategories.filter(id => id !== categoryId));
    } else {
      onSelectionChange([...selectedCategories, categoryId]);
    }
  };

  const selectAll = () => {
    onSelectionChange(categories.map(c => c.id));
  };

  const clearAll = () => {
    onSelectionChange([]);
  };

  if (loading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-8 w-full" />
        {[...Array(4)].map((_, index) => (
          <div key={index} className="flex items-center space-x-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 flex-1" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Header with Select/Clear All */}
      <div className="flex justify-between items-center">
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={selectAll}
            disabled={selectedCategories.length === categories.length}
            className="h-8 px-2 text-xs"
          >
            {t('blog.sidebar.select_all')}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAll}
            disabled={selectedCategories.length === 0}
            className="h-8 px-2 text-xs"
          >
            {t('blog.sidebar.clear_all')}
          </Button>
        </div>
        
        {selectedCategories.length > 0 && (
          <Badge variant="secondary" className="text-xs">
            {t('blog.sidebar.selected_count').replace('{count}', selectedCategories.length.toString())}
          </Badge>
        )}
      </div>

      {/* Categories List */}
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" className="w-full justify-between p-0 h-8">
            <span className="text-sm font-medium">{t('blog.sidebar.categories_title')}</span>
            {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </CollapsibleTrigger>
        
        <CollapsibleContent className="space-y-2 mt-2">
          {categories.map((category) => (
            <div key={category.id} className="flex items-center space-x-2">
              <Checkbox
                id={`category-${category.id}`}
                checked={selectedCategories.includes(category.id)}
                onCheckedChange={() => handleCategoryToggle(category.id)}
              />
              <label
                htmlFor={`category-${category.id}`}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex-1"
              >
                {category.name}
              </label>
            </div>
          ))}
          
          {categories.length === 0 && (
            <div className="text-sm text-muted-foreground text-center py-4">
              {t('blog.interface.no_posts_message_default')}
            </div>
          )}
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
};