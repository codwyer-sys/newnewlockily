import React, { useEffect, useState, useRef } from 'react';
import { MapPin, Loader2 } from 'lucide-react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { supabase } from '@/integrations/supabase/client';

interface PostalCodeLocation {
  code: string;
  lat: number;
  lon: number;
  city: string;
}

interface ServiceAreaMapProps {
  address: string;
  serviceType: 'postal_codes' | 'radius';
  postalCodes?: string[];
  radiusKm?: number;
  onAddressChange?: (address: string) => void;
}

const ServiceAreaMap: React.FC<ServiceAreaMapProps> = ({ 
  address, 
  serviceType, 
  postalCodes = [], 
  radiusKm = 25,
  onAddressChange 
}) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [coordinates, setCoordinates] = useState<{lat: number, lon: number} | null>(null);
  const [postalCodeLocations, setPostalCodeLocations] = useState<PostalCodeLocation[]>([]);
  const [isLoadingPostalCodes, setIsLoadingPostalCodes] = useState(false);
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  
  // Initialize MapBox
  useEffect(() => {
    if (!mapContainer.current) return;

    mapboxgl.accessToken = 'pk.eyJ1IjoibG9ja2lseSIsImEiOiJjbWNxMGpseXowZDNzMmpyMjYzOWE4cjJkIn0.3mcKSl4a-lHwZwhHJGssMQ';
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [12.5683, 55.6761], // Copenhagen default
      zoom: 10,
    });

    map.current.on('load', () => {
      setIsMapLoaded(true);
      geocodeMainAddress();
    });

    return () => {
      map.current?.remove();
    };
  }, []);

  // Geocode the main address using cached edge function
  const geocodeMainAddress = async () => {
    if (!address) {
      setCoordinates({ lat: 55.6761, lon: 12.5683 });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('geocode-with-cache', {
        body: { address }
      });

      if (error) {
        throw error;
      }

      if (data?.latitude && data?.longitude) {
        const lat = data.latitude;
        const lng = data.longitude;
        setCoordinates({ lat, lon: lng });
        
        if (map.current) {
          map.current.setCenter([lng, lat]);
        }
      } else {
        setCoordinates({ lat: 55.6761, lon: 12.5683 });
      }
    } catch (error) {
      console.error('Geocoding failed:', error);
      setCoordinates({ lat: 55.6761, lon: 12.5683 });
    }
  };

  // Geocode postal codes when they change
  useEffect(() => {
    const geocodePostalCodes = async () => {
      if (!postalCodes || postalCodes.length === 0 || serviceType !== 'postal_codes') {
        setPostalCodeLocations([]);
        return;
      }

      setIsLoadingPostalCodes(true);
      const locations: PostalCodeLocation[] = [];

      try {
        for (const code of postalCodes) {
          try {
            // Simple mock locations for Danish postal codes to avoid CORS issues
            // This is a simplified approach - in production you'd use a backend proxy
            const mockLocation = getMockLocationForPostalCode(code);
            if (mockLocation) {
              locations.push(mockLocation);
            }
          } catch (error) {
            console.error(`Error geocoding postal code ${code}:`, error);
          }
        }
        
        setPostalCodeLocations(locations);
      } finally {
        setIsLoadingPostalCodes(false);
      }
    };

    geocodePostalCodes();
  }, [postalCodes, serviceType]);

  // Helper function to provide mock locations for common Danish postal codes
  const getMockLocationForPostalCode = (code: string): PostalCodeLocation | null => {
    // Common Danish postal codes with approximate coordinates
    const mockLocations: { [key: string]: { lat: number, lon: number, city: string } } = {
      '1000': { lat: 55.6838, lon: 12.5700, city: 'København K' },
      '1001': { lat: 55.6838, lon: 12.5700, city: 'København K' },
      '1050': { lat: 55.6838, lon: 12.5700, city: 'København K' },
      '1100': { lat: 55.6870, lon: 12.5700, city: 'København Ø' },
      '1200': { lat: 55.6783, lon: 12.5700, city: 'København V' },
      '1300': { lat: 55.6870, lon: 12.5700, city: 'København K' },
      '1400': { lat: 55.6870, lon: 12.5700, city: 'København K' },
      '1440': { lat: 55.6870, lon: 12.5700, city: 'København K' },
      '1500': { lat: 55.6783, lon: 12.5700, city: 'København V' },
      '1600': { lat: 55.6783, lon: 12.5700, city: 'København V' },
      '1700': { lat: 55.6783, lon: 12.5700, city: 'København V' },
      '1800': { lat: 55.6870, lon: 12.5700, city: 'Frederiksberg C' },
      '1900': { lat: 55.6870, lon: 12.5700, city: 'Frederiksberg C' },
      '2000': { lat: 55.6761, lon: 12.5683, city: 'Frederiksberg' },
      '2100': { lat: 55.6915, lon: 12.5700, city: 'København Ø' },
      '2200': { lat: 55.6915, lon: 12.5700, city: 'København N' },
      '2300': { lat: 55.6915, lon: 12.5700, city: 'København S' },
      '2400': { lat: 55.6915, lon: 12.5700, city: 'København NV' },
      '2500': { lat: 55.6459, lon: 12.4931, city: 'Valby' },
      '2600': { lat: 55.6506, lon: 12.5342, city: 'Glostrup' },
      '2700': { lat: 55.6506, lon: 12.5342, city: 'Brønshøj' },
      '2800': { lat: 55.6761, lon: 12.5683, city: 'Kongens Lyngby' },
      '2900': { lat: 55.7221, lon: 12.5254, city: 'Hellerup' },
      '3000': { lat: 55.7221, lon: 12.5254, city: 'Helsingør' },
    };

    const location = mockLocations[code];
    if (location) {
      return {
        code,
        lat: location.lat,
        lon: location.lon,
        city: location.city
      };
    }

    // For unknown postal codes, generate a location near Copenhagen
    const baseLatitude = 55.6761;
    const baseLongitude = 12.5683;
    const offset = 0.01; // Small random offset
    
    return {
      code,
      lat: baseLatitude + (Math.random() - 0.5) * offset,
      lon: baseLongitude + (Math.random() - 0.5) * offset,
      city: 'Danmark'
    };
  };

  // Update map markers and overlays when data changes
  useEffect(() => {
    if (!map.current || !isMapLoaded || !coordinates) return;

    // Clear existing markers and layers
    const existingMarkers = document.querySelectorAll('.mapboxgl-marker');
    existingMarkers.forEach(marker => marker.remove());
    
    // Add main business location marker
    new mapboxgl.Marker({ color: '#ef4444' })
      .setLngLat([coordinates.lon, coordinates.lat])
      .setPopup(new mapboxgl.Popup().setHTML('<div class="font-medium">Din virksomhed</div>'))
      .addTo(map.current);

    // Add radius circle for radius service type
    if (serviceType === 'radius' && radiusKm) {
      const radiusInMeters = radiusKm * 1000;
      
      if (map.current.getSource('radius-source')) {
        map.current.removeLayer('radius-layer');
        map.current.removeSource('radius-source');
      }

      map.current.addSource('radius-source', {
        type: 'geojson',
        data: {
          type: 'Feature',
          geometry: {
            type: 'Point',
            coordinates: [coordinates.lon, coordinates.lat]
          },
          properties: {}
        }
      });

      map.current.addLayer({
        id: 'radius-layer',
        type: 'circle',
        source: 'radius-source',
        paint: {
          'circle-radius': {
            stops: [[0, 0], [20, radiusInMeters / 100]],
            base: 2
          },
          'circle-color': 'rgba(59, 130, 246, 0.1)',
          'circle-stroke-color': 'rgba(59, 130, 246, 0.4)',
          'circle-stroke-width': 2
        }
      });
    }

    // Add postal code markers
    if (serviceType === 'postal_codes' && postalCodeLocations.length > 0) {
      postalCodeLocations.forEach((location, index) => {
        new mapboxgl.Marker({ color: '#3b82f6' })
          .setLngLat([location.lon, location.lat])
          .setPopup(new mapboxgl.Popup().setHTML(`<div class="font-medium">${location.code} - ${location.city}</div>`))
          .addTo(map.current!);
      });

      // Fit map to show all postal codes
      const bounds = new mapboxgl.LngLatBounds();
      bounds.extend([coordinates.lon, coordinates.lat]);
      postalCodeLocations.forEach(location => {
        bounds.extend([location.lon, location.lat]);
      });
      map.current.fitBounds(bounds, { padding: 50 });
    } else if (serviceType === 'radius') {
      // Set appropriate zoom for radius
      const zoom = radiusKm > 50 ? 8 : radiusKm > 25 ? 10 : 12;
      map.current.setZoom(zoom);
    }
  }, [coordinates, serviceType, postalCodeLocations, radiusKm, isMapLoaded]);

  if (!isMapLoaded && !coordinates) {
    return (
      <div className="relative h-64 w-full overflow-hidden rounded-lg bg-muted flex items-center justify-center border border-border">
        <div className="flex items-center space-x-2 text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          <span>Loading map...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-64 w-full overflow-hidden rounded-lg border border-border">
      <div ref={mapContainer} className="absolute inset-0" />
      
      {/* Service area overlay indicator */}
      <div className="absolute inset-0 pointer-events-none">
        {serviceType === 'radius' && radiusKm && (
          <div className="absolute top-2 left-2 bg-background/90 text-foreground px-2 py-1 rounded text-sm font-medium">
            Service Radius: {radiusKm} km
          </div>
        )}
        
        {serviceType === 'postal_codes' && (
          <div className="absolute top-2 left-2 bg-background/90 text-foreground px-2 py-1 rounded text-sm font-medium">
            {isLoadingPostalCodes ? (
              <div className="flex items-center space-x-1">
                <Loader2 className="h-3 w-3 animate-spin" />
                <span>Loading areas...</span>
              </div>
            ) : (
              <span>{postalCodeLocations.length} of {postalCodes?.length || 0} areas shown</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceAreaMap;