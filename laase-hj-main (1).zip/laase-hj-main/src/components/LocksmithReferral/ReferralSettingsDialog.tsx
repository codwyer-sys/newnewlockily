import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, X, Plus } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useReferralSettings, LocksmithPromotion } from '@/hooks/useReferralSettings';
import { useAuth } from '@/hooks/useAuth';

interface ReferralSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  locksmithId: string;
  locksmithName: string;
}

export const ReferralSettingsDialog: React.FC<ReferralSettingsDialogProps> = ({
  open,
  onOpenChange,
  locksmithId,
  locksmithName,
}) => {
  const { user } = useAuth();
  const {
    settings,
    promotions,
    isLoading,
    updateDefaultFee,
    createPromotion,
    deactivatePromotion
  } = useReferralSettings(locksmithId);

  const [defaultFee, setDefaultFee] = useState<string>('');
  const [showPromotionForm, setShowPromotionForm] = useState(false);
  const [promotionType, setPromotionType] = useState<'percentage_on_next_jobs' | 'percentage_until_date'>('percentage_on_next_jobs');
  const [promotionPercentage, setPromotionPercentage] = useState<string>('');
  const [jobsCount, setJobsCount] = useState<string>('');
  const [validUntil, setValidUntil] = useState<Date>();

  React.useEffect(() => {
    if (settings) {
      setDefaultFee(settings.default_referral_fee_percentage.toString());
    }
  }, [settings]);

  const handleUpdateDefaultFee = async () => {
    if (!defaultFee || isNaN(Number(defaultFee))) return;
    
    const percentage = Number(defaultFee);
    if (percentage < 0 || percentage > 100) return;
    
    await updateDefaultFee(percentage);
  };

  const handleCreatePromotion = async () => {
    if (!promotionPercentage || isNaN(Number(promotionPercentage)) || !user) return;
    
    const percentage = Number(promotionPercentage);
    if (percentage < 0 || percentage > 100) return;
    
    const promotion: Omit<LocksmithPromotion, 'id' | 'created_at' | 'updated_at' | 'jobs_used'> = {
      locksmith_id: locksmithId,
      promotion_type: promotionType,
      discount_percentage: percentage,
      is_active: true,
      created_by: user.id,
      jobs_count: promotionType === 'percentage_on_next_jobs' ? Number(jobsCount) : undefined,
      valid_until: promotionType === 'percentage_until_date' ? validUntil?.toISOString() : undefined,
    };

    try {
      await createPromotion(promotion);
      setShowPromotionForm(false);
      setPromotionPercentage('');
      setJobsCount('');
      setValidUntil(undefined);
    } catch (error) {
      console.error('Failed to create promotion:', error);
    }
  };

  const formatPromotionDescription = (promotion: LocksmithPromotion) => {
    if (promotion.promotion_type === 'percentage_on_next_jobs') {
      const remaining = (promotion.jobs_count || 0) - promotion.jobs_used;
      return `${promotion.discount_percentage}% fee on next ${promotion.jobs_count} jobs (${remaining} remaining)`;
    } else {
      return `${promotion.discount_percentage}% fee until ${format(new Date(promotion.valid_until!), 'MMM dd, yyyy')}`;
    }
  };

  if (isLoading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <div className="flex items-center justify-center p-6">
            Loading referral settings...
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Referral Settings</DialogTitle>
          <DialogDescription>
            Manage referral fee settings and promotions for {locksmithName}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Default Fee Setting */}
          <div className="space-y-2">
            <Label htmlFor="defaultFee">Default Referral Fee (%)</Label>
            <div className="flex items-center gap-2">
              <Input
                id="defaultFee"
                type="number"
                min="0"
                max="100"
                step="0.1"
                value={defaultFee}
                onChange={(e) => setDefaultFee(e.target.value)}
                className="w-32"
              />
              <Button 
                onClick={handleUpdateDefaultFee}
                disabled={!defaultFee || defaultFee === settings?.default_referral_fee_percentage.toString()}
              >
                Update
              </Button>
            </div>
          </div>

          {/* Active Promotions */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Active Promotions</Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowPromotionForm(!showPromotionForm)}
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Promotion
              </Button>
            </div>

            {promotions.length === 0 ? (
              <p className="text-sm text-muted-foreground">No active promotions</p>
            ) : (
              <div className="space-y-2">
                {promotions.map((promotion) => (
                  <div
                    key={promotion.id}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div>
                      <p className="text-sm font-medium">
                        {formatPromotionDescription(promotion)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Created {format(new Date(promotion.created_at), 'MMM dd, yyyy')}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deactivatePromotion(promotion.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Promotion Form */}
          {showPromotionForm && (
            <div className="space-y-4 p-4 border rounded-lg bg-muted/20">
              <Label>Create New Promotion</Label>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Promotion Type</Label>
                  <Select
                    value={promotionType}
                    onValueChange={(value: 'percentage_on_next_jobs' | 'percentage_until_date') => 
                      setPromotionType(value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage_on_next_jobs">% on next X jobs</SelectItem>
                      <SelectItem value="percentage_until_date">% until date</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Fee Percentage (%)</Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={promotionPercentage}
                    onChange={(e) => setPromotionPercentage(e.target.value)}
                    placeholder="15"
                  />
                </div>
              </div>

              {promotionType === 'percentage_on_next_jobs' && (
                <div className="space-y-2">
                  <Label>Number of Jobs</Label>
                  <Input
                    type="number"
                    min="1"
                    value={jobsCount}
                    onChange={(e) => setJobsCount(e.target.value)}
                    placeholder="10"
                  />
                </div>
              )}

              {promotionType === 'percentage_until_date' && (
                <div className="space-y-2">
                  <Label>Valid Until</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !validUntil && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {validUntil ? format(validUntil, "PPP") : "Pick a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={validUntil}
                        onSelect={setValidUntil}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              )}

              <div className="flex gap-2">
                <Button onClick={handleCreatePromotion}>Create Promotion</Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowPromotionForm(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};