import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import QuillEditor from './QuillEditor';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useBlogPosts } from '@/hooks/useBlogPosts';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { validateUserForSubmission } from '@/utils/uuid';
import { Loader2, Save, Eye, Globe, Hash, Image, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ImageUpload } from '@/components/ImageUpload';
import { PostTypeSelector } from '@/components/PostTypeSelector';

const blogPostSchema = z.object({
  title: z.string().min(1, 'Title is required').max(60, 'Title should be under 60 characters for SEO'),
  slug: z.string().min(1, 'URL slug is required').regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
  excerpt: z.string().max(160, 'Excerpt should be under 160 characters').optional(),
  content: z.string().min(1, 'Content is required'),
  is_global: z.boolean().default(false),
  market_code: z.string().optional(),
  category_id: z.string().optional(),
  status: z.enum(['draft', 'published', 'archived']).default('draft'),
  featured_image_url: z.string().url('Please enter a valid image URL').optional().or(z.literal('')),
  featured_image_alt: z.string().optional(),
  
  // SEO fields
  seo_title: z.string().max(60, 'SEO title should be under 60 characters').optional(),
  seo_description: z.string().max(160, 'SEO description should be under 160 characters').optional(),
  seo_keywords: z.string().optional(),
  
  // Open Graph fields
  og_title: z.string().max(60, 'OG title should be under 60 characters').optional(),
  og_description: z.string().max(160, 'OG description should be under 160 characters').optional(),
  og_image_url: z.string().url('Please enter a valid image URL').optional().or(z.literal('')),
  
  // Twitter fields
  twitter_title: z.string().max(60, 'Twitter title should be under 60 characters').optional(),
  twitter_description: z.string().max(160, 'Twitter description should be under 160 characters').optional(),
  twitter_image_url: z.string().url('Please enter a valid image URL').optional().or(z.literal('')),
}).refine((data) => {
  // Market code is required for market-specific posts
  if (!data.is_global && !data.market_code) {
    return false;
  }
  return true;
}, {
  message: "Market is required for market-specific posts",
  path: ["market_code"],
});

type BlogPostForm = z.infer<typeof blogPostSchema>;

const generateSlug = (title: string): string => {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9 -]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
};

const BlogPostEditor: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [postType, setPostType] = useState<'global' | 'market'>('market');
  const [markets, setMarkets] = useState<Array<{country_code: string, country_name: string}>>([]);
  const navigate = useNavigate();
  
  const { createPost, categories, loading: blogLoading } = useBlogPosts();
  const { user } = useAuth();

  const form = useForm<BlogPostForm>({
    resolver: zodResolver(blogPostSchema),
    defaultValues: {
      status: 'draft',
      is_global: false,
      market_code: 'DK',
      content: '',
    },
  });

  const { watch, setValue, getValues } = form;
  const watchedTitle = watch('title');
  const watchedMarket = watch('market_code');
  const watchedContent = watch('content');

  // Update form when post type changes
  useEffect(() => {
    setValue('is_global', postType === 'global');
    if (postType === 'global') {
      setValue('market_code', undefined);
    } else if (!watchedMarket) {
      setValue('market_code', 'DK');
    }
  }, [postType, setValue, watchedMarket]);

  // Fetch markets on component mount
  useEffect(() => {
    const fetchMarkets = async () => {
      const { data, error } = await supabase
        .from('markets')
        .select('country_code, country_name')
        .order('country_code');
      
      if (data && !error) {
        setMarkets(data);
      }
    };

    fetchMarkets();
  }, []);

  // Auto-generate slug from title
  useEffect(() => {
    if (watchedTitle && !getValues('slug')) {
      const slug = generateSlug(watchedTitle);
      setValue('slug', slug);
    }
  }, [watchedTitle, setValue, getValues]);

  // Update word count
  useEffect(() => {
    if (watchedContent) {
      const text = watchedContent.replace(/<[^>]*>/g, ''); // Strip HTML
      const words = text.trim().split(/\s+/).filter(word => word.length > 0);
      setWordCount(words.length);
    } else {
      setWordCount(0);
    }
  }, [watchedContent]);

  // Categories are now global - no need to filter by market
  const marketCategories = categories;

  const onSubmit = async (data: BlogPostForm) => {
    setIsLoading(true);
    try {
      // Validate user authentication before proceeding
      const validatedUserId = validateUserForSubmission(user?.id);
      
      // Convert keywords string to array
      const keywordsArray = data.seo_keywords 
        ? data.seo_keywords.split(',').map(k => k.trim()).filter(k => k.length > 0)
        : [];

      const postData = {
        title: data.title,
        slug: data.slug,
        content: data.content,
        excerpt: data.excerpt,
        featured_image_url: data.featured_image_url,
        featured_image_alt: data.featured_image_alt,
        author_id: validatedUserId,
        category_id: data.category_id,
        market_code: data.market_code,
        is_global: data.is_global,
        status: data.status,
        seo_title: data.seo_title,
        seo_description: data.seo_description,
        seo_keywords: keywordsArray,
      };

      await createPost(postData);
      toast.success('Blog post created successfully!');
      navigate('/admin-portal/blog/posts');
    } catch (error) {
      console.error('Error creating blog post:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to create blog post';
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditorChange = (content: string) => {
    setValue('content', content);
  };

  if (blogLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-heading-lg text-foreground">Create Blog Post</h1>
          <p className="text-muted-foreground">Create and publish content for your blog</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <Hash className="h-3 w-3" />
            {wordCount} words
          </Badge>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Post Type Selection */}
          <PostTypeSelector
            postType={postType}
            selectedMarket={watchedMarket}
            markets={markets}
            onPostTypeChange={setPostType}
            onMarketChange={(market) => setValue('market_code', market)}
          />

          {/* Category Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Category
              </CardTitle>
              <CardDescription>
                Select a category for this blog post (optional)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="category_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category (optional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {marketCategories.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Basic Content */}
          <Card>
            <CardHeader>
              <CardTitle>Content</CardTitle>
              <CardDescription>
                Main content and basic information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter blog post title..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="slug"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>URL Slug</FormLabel>
                    <FormControl>
                      <Input placeholder="url-slug" {...field} />
                    </FormControl>
                    <p className="text-sm text-muted-foreground">
                      Preview: /blog/{field.value || 'url-slug'}
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="excerpt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Excerpt</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Brief description of the blog post..."
                        rows={3}
                        {...field}
                      />
                    </FormControl>
                    <p className="text-sm text-muted-foreground">
                      {field.value?.length || 0}/160 characters
                    </p>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <QuillEditor
                        value={field.value}
                        onChange={handleEditorChange}
                        placeholder="Start writing your blog post content..."
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Featured Image */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Image className="h-5 w-5" />
                Featured Image
              </CardTitle>
              <CardDescription>
                Add a featured image for your blog post
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ImageUpload
                label="Featured Image"
                value={form.watch('featured_image_url')}
                onChange={(url) => form.setValue('featured_image_url', url)}
                onAltTextChange={(altText) => form.setValue('featured_image_alt', altText)}
                altText={form.watch('featured_image_alt')}
                showAltText={true}
              />
            </CardContent>
          </Card>

          {/* SEO Settings */}
          <Card>
            <CardHeader>
              <CardTitle>SEO & Social Media</CardTitle>
              <CardDescription>
                Optimize your content for search engines and social sharing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Basic SEO */}
              <div className="space-y-4">
                <h4 className="font-medium">Search Engine Optimization</h4>
                
                <FormField
                  control={form.control}
                  name="seo_title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SEO Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Optimized title for search engines..." {...field} />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        {field.value?.length || 0}/60 characters
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="seo_description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SEO Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Meta description for search results..."
                          rows={2}
                          {...field}
                        />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        {field.value?.length || 0}/160 characters
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="seo_keywords"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Keywords</FormLabel>
                      <FormControl>
                        <Input placeholder="keyword1, keyword2, keyword3..." {...field} />
                      </FormControl>
                      <p className="text-sm text-muted-foreground">
                        Separate keywords with commas
                      </p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Separator />

              {/* Open Graph */}
              <div className="space-y-4">
                <h4 className="font-medium">Facebook & Open Graph</h4>
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="og_title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>OG Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Facebook share title..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <ImageUpload
                    label="Open Graph Image"
                    value={form.watch('og_image_url')}
                    onChange={(url) => form.setValue('og_image_url', url)}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="og_description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>OG Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Description for Facebook shares..."
                          rows={2}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Separator />

              {/* Twitter */}
              <div className="space-y-4">
                <h4 className="font-medium">Twitter</h4>
                
                <div className="space-y-4">
                  <FormField
                    control={form.control}
                    name="twitter_title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Twitter Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Twitter share title..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <ImageUpload
                    label="Twitter Image"
                    value={form.watch('twitter_image_url')}
                    onChange={(url) => form.setValue('twitter_image_url', url)}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="twitter_description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Twitter Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Description for Twitter shares..."
                          rows={2}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          {/* Publishing Options */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Publishing
              </CardTitle>
              <CardDescription>
                Control when and how your post is published
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="w-full md:w-48">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex items-center justify-between pt-6 border-t border-border">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate('/admin-portal/blog/posts')}
            >
              Cancel
            </Button>
            
            <div className="flex items-center gap-2">
              <Button
                type="submit"
                disabled={isLoading}
                className="flex items-center gap-2"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
                Create Post
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
};

export default BlogPostEditor;