import React from 'react';
import { useMarket } from '@/contexts/MarketContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { BookOpen, Lightbulb, Shield } from 'lucide-react';
import { useHeaderThemeSection } from '@/hooks/useHeaderThemeSection';

export const BlogHero: React.FC = () => {
  const { market } = useMarket();
  const { t } = useLanguage();
  const sectionRef = useHeaderThemeSection('dark', 'blog-hero');

  return (
    <section ref={sectionRef} className="relative bg-slate-900 text-white py-20 pt-28">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.05%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          {/* Hero Content */}
          <div className="mb-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              {t('blog.hero.title')}
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 leading-relaxed">
              {t('blog.hero.subtitle').replace('{country}', market.country_name)}
            </p>
          </div>

          {/* Feature Icons */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="flex flex-col items-center text-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-full p-4 mb-4">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{t('blog.hero.security_tips_title')}</h3>
              <p className="text-white/80 text-sm">
                {t('blog.hero.security_tips_desc')}
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-full p-4 mb-4">
                <Lightbulb className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{t('blog.hero.expert_insights_title')}</h3>
              <p className="text-white/80 text-sm">
                {t('blog.hero.expert_insights_desc')}
              </p>
            </div>

            <div className="flex flex-col items-center text-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-full p-4 mb-4">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{t('blog.hero.how_to_guides_title')}</h3>
              <p className="text-white/80 text-sm">
                {t('blog.hero.how_to_guides_desc')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Smooth gradient transition */}
      <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-b from-transparent to-background/20 pointer-events-none"></div>
    </section>
  );
};