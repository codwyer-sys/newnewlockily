import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Activity, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  Code, 
  RefreshCw,
  ChevronDown,
  ChevronRight,
  Phone,
  Globe,
  Database,
  AlertTriangle
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface LogEntry {
  id: string;
  timestamp: string;
  function_id: string;
  status_code: number;
  execution_time_ms: number;
  event_message: string;
  request_method: string;
  success: boolean;
  request_headers?: any;
  request_body?: any;
  response_headers?: any;
  response_body?: any;
  error_stack?: string;
  client_ip?: string;
  user_agent?: string;
  call_metadata?: any;
}

interface WebhookLogsProps {
  selectedWebhook: string;
  timeRange: string;
}

export const WebhookLogs: React.FC<WebhookLogsProps> = ({ 
  selectedWebhook, 
  timeRange 
}) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const [isAutoRefresh, setIsAutoRefresh] = useState(true);

  const fetchLogs = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('get-function-logs', {
        body: { 
          functions: selectedWebhook === 'all' ? [
            'validate-address', 
            'get-job-categories', 
            'get-follow-up-questions', 
            'get-available-times', 
            'create-booking-from-call'
          ] : [selectedWebhook],
          timeRange,
          limit: 50
        }
      });

      if (error) {
        console.error('Error fetching logs:', error);
        setLogs([]);
      } else {
        setLogs(data?.logs || []);
      }
    } catch (error) {
      console.error('Error fetching logs:', error);
      setLogs([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Real-time subscription for new logs
  useEffect(() => {
    const channel = supabase
      .channel('webhook-logs-updates')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'webhook_logs'
        },
        (payload) => {
          console.log('New webhook log:', payload.new);
          const newLog = {
            id: payload.new.id,
            timestamp: payload.new.created_at,
            function_id: payload.new.function_name,
            status_code: payload.new.response_status_code || 200,
            execution_time_ms: payload.new.execution_time_ms || 0,
            event_message: payload.new.error_message || 'Function executed',
            request_method: payload.new.request_method,
            success: (payload.new.response_status_code || 200) < 400,
            request_headers: payload.new.request_headers,
            request_body: payload.new.request_body,
            response_headers: payload.new.response_headers,
            response_body: payload.new.response_body,
            error_stack: payload.new.error_stack,
            client_ip: payload.new.client_ip,
            user_agent: payload.new.user_agent,
            call_metadata: payload.new.call_metadata
          };
          
          // Only add if it matches the current filter
          if (selectedWebhook === 'all' || newLog.function_id === selectedWebhook) {
            setLogs(prev => [newLog, ...prev].slice(0, 50));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedWebhook]);

  useEffect(() => {
    fetchLogs();
    
    // Set up auto-refresh if enabled
    let interval: NodeJS.Timeout | null = null;
    if (isAutoRefresh) {
      interval = setInterval(fetchLogs, 10000); // Refresh every 10 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [selectedWebhook, timeRange, isAutoRefresh]);

  const getFunctionIcon = (functionName: string) => {
    switch (functionName) {
      case 'validate-address':
        return <Globe className="h-4 w-4" />;
      case 'get-job-categories':
      case 'get-follow-up-questions':
        return <Database className="h-4 w-4" />;
      case 'get-available-times':
        return <Clock className="h-4 w-4" />;
      case 'create-booking-from-call':
        return <Phone className="h-4 w-4" />;
      default:
        return <Code className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (log: LogEntry) => {
    if (log.success && log.status_code === 200) {
      return (
        <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
          <CheckCircle className="h-3 w-3 mr-1" />
          {log.status_code}
        </Badge>
      );
    } else {
      return (
        <Badge variant="destructive">
          <AlertCircle className="h-3 w-3 mr-1" />
          {log.status_code}
        </Badge>
      );
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const getExecutionTimeColor = (time: number) => {
    if (time < 100) return 'text-green-600';
    if (time < 300) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            <CardTitle>Live Webhook Logs</CardTitle>
            {isLoading && <RefreshCw className="h-4 w-4 animate-spin" />}
            <Badge variant="outline" className="text-xs">
              {logs.length} logs
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              onClick={() => setIsAutoRefresh(!isAutoRefresh)} 
              variant={isAutoRefresh ? "default" : "outline"} 
              size="sm"
            >
              {isAutoRefresh ? "Auto-refresh On" : "Auto-refresh Off"}
            </Button>
            <Button onClick={fetchLogs} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          Real-time monitoring of webhook requests and responses with detailed request/response data
        </p>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[600px] w-full">
          <div className="space-y-2">
            {logs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No logs found for the selected criteria</p>
              </div>
            ) : (
              logs.map((log) => (
                <div 
                  key={log.id} 
                  className="border rounded-lg p-3 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                        className="h-6 w-6 p-0"
                      >
                        {expandedLog === log.id ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </Button>
                      
                      <div className="flex items-center gap-2">
                        {getStatusBadge(log)}
                        <div className="flex items-center gap-1">
                          {getFunctionIcon(log.function_id)}
                          <Badge variant="outline" className="font-mono text-xs">
                            {log.function_id}
                          </Badge>
                        </div>
                        {log.call_metadata?.caller_phone_number && (
                          <Badge variant="secondary" className="text-xs">
                            <Phone className="h-3 w-3 mr-1" />
                            {log.call_metadata.caller_phone_number}
                          </Badge>
                        )}
                      </div>
                      
                      <span className="text-sm text-muted-foreground">
                        {log.event_message}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span className={getExecutionTimeColor(log.execution_time_ms)}>
                          {log.execution_time_ms}ms
                        </span>
                      </div>
                      <span>{formatTimestamp(log.timestamp)}</span>
                    </div>
                  </div>
                  
                  {expandedLog === log.id && (
                    <div className="mt-3 pt-3 border-t space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <h4 className="font-medium mb-2 flex items-center gap-2">
                            <Code className="h-4 w-4" />
                            Request Details
                          </h4>
                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Method:</span>
                              <span className="font-mono">{log.request_method}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Function:</span>
                              <span className="font-mono">{log.function_id}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Timestamp:</span>
                              <span>{formatTimestamp(log.timestamp)}</span>
                            </div>
                            {log.client_ip && (
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Client IP:</span>
                                <span className="font-mono">{log.client_ip}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium mb-2">Response Details</h4>
                          <div className="space-y-1 text-xs">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Status:</span>
                              <span className="font-mono">{log.status_code}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Execution Time:</span>
                              <span className={getExecutionTimeColor(log.execution_time_ms)}>
                                {log.execution_time_ms}ms
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Success:</span>
                              <span>{log.success ? 'Yes' : 'No'}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {log.request_body && (
                        <div>
                          <h4 className="font-medium mb-2 flex items-center gap-2">
                            <Database className="h-4 w-4" />
                            Request Body
                          </h4>
                          <div className="p-2 bg-muted rounded text-xs font-mono max-h-40 overflow-y-auto">
                            <pre>{JSON.stringify(log.request_body, null, 2)}</pre>
                          </div>
                        </div>
                      )}

                      {log.response_body && (
                        <div>
                          <h4 className="font-medium mb-2 flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            Response Body
                          </h4>
                          <div className="p-2 bg-muted rounded text-xs font-mono max-h-40 overflow-y-auto">
                            <pre>{JSON.stringify(log.response_body, null, 2)}</pre>
                          </div>
                        </div>
                      )}

                      {log.error_stack && (
                        <div>
                          <h4 className="font-medium mb-2 flex items-center gap-2">
                            <AlertTriangle className="h-4 w-4 text-red-500" />
                            Error Stack Trace
                          </h4>
                          <div className="p-2 bg-red-50 border border-red-200 rounded text-xs font-mono max-h-40 overflow-y-auto">
                            <pre className="text-red-700">{log.error_stack}</pre>
                          </div>
                        </div>
                      )}

                      {log.call_metadata && Object.keys(log.call_metadata).length > 0 && (
                        <div>
                          <h4 className="font-medium mb-2 flex items-center gap-2">
                            <Phone className="h-4 w-4" />
                            Call Metadata
                          </h4>
                          <div className="p-2 bg-muted rounded text-xs font-mono max-h-40 overflow-y-auto">
                            <pre>{JSON.stringify(log.call_metadata, null, 2)}</pre>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};