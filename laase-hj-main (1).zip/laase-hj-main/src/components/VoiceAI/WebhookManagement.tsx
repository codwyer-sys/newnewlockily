import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Activity, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  Code, 
  Globe, 
  PlayCircle, 
  RefreshCw,
  Search,
  Settings,
  TrendingUp,
  Webhook,
  Zap
} from 'lucide-react';
import { useWebhookAnalytics } from '@/hooks/useWebhookAnalytics';
import { useWebhookTesting } from '@/hooks/useWebhookTesting';
import { WebhookDirectory } from './WebhookDirectory';
import { WebhookLogs } from './WebhookLogs';
import { WebhookAnalytics } from './WebhookAnalytics';
import { WebhookTester } from './WebhookTester';

export const WebhookManagement = () => {
  const { analytics, isLoading, refresh } = useWebhookAnalytics();
  const [selectedWebhook, setSelectedWebhook] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<string>('24h');

  const webhooks = [
    { 
      id: 'validate-address', 
      name: 'Address Validation', 
      url: 'https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/validate-address',
      description: 'Validates customer addresses using unified lookup service',
      status: 'active'
    },
    { 
      id: 'get-job-categories', 
      name: 'Job Categories', 
      url: 'https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/get-job-categories',
      description: 'Fetches available locksmith service categories with translations',
      status: 'active'
    },
    { 
      id: 'get-follow-up-questions', 
      name: 'Follow-up Questions', 
      url: 'https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/get-follow-up-questions',
      description: 'Retrieves dynamic questions based on selected job category',
      status: 'active'
    },
    { 
      id: 'get-available-times', 
      name: 'Available Times', 
      url: 'https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/get-available-times',
      description: 'Provides scheduling options based on urgency level',
      status: 'active'
    },
    { 
      id: 'create-booking-from-call', 
      name: 'Create Booking', 
      url: 'https://pysmpkinlgpqowmlwttr.supabase.co/functions/v1/create-booking-from-call',
      description: 'Creates final booking with all collected information',
      status: 'active'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Webhook Management</h1>
          <p className="text-muted-foreground">Monitor and manage ElevenLabs webhook integrations</p>
        </div>
        <Button onClick={refresh} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Webhooks</CardTitle>
            <Webhook className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">5</div>
            <p className="text-xs text-muted-foreground">All systems operational</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.avgResponseTime || '145'}ms</div>
            <p className="text-xs text-muted-foreground">+12ms from yesterday</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{analytics?.successRate || '98.5'}%</div>
            <p className="text-xs text-muted-foreground">+0.5% from last week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Calls</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.totalCalls || '1,247'}</div>
            <p className="text-xs text-muted-foreground">Last 24 hours</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters & Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <Label htmlFor="webhook-select">Webhook</Label>
              <Select value={selectedWebhook} onValueChange={setSelectedWebhook}>
                <SelectTrigger id="webhook-select">
                  <SelectValue placeholder="Select webhook" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Webhooks</SelectItem>
                  {webhooks.map((webhook) => (
                    <SelectItem key={webhook.id} value={webhook.id}>
                      {webhook.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[200px]">
              <Label htmlFor="time-range">Time Range</Label>
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger id="time-range">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last Hour</SelectItem>
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[200px]">
              <Label htmlFor="search">Search Logs</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="Search requests, responses..."
                  className="pl-8"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Tabs */}
      <Tabs defaultValue="directory" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="directory" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Directory
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Live Logs
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="testing" className="flex items-center gap-2">
            <PlayCircle className="h-4 w-4" />
            Testing
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="directory">
          <WebhookDirectory webhooks={webhooks} />
        </TabsContent>

        <TabsContent value="logs">
          <WebhookLogs 
            selectedWebhook={selectedWebhook} 
            timeRange={timeRange} 
          />
        </TabsContent>

        <TabsContent value="analytics">
          <WebhookAnalytics 
            selectedWebhook={selectedWebhook} 
            timeRange={timeRange}
            analytics={analytics}
          />
        </TabsContent>

        <TabsContent value="testing">
          <WebhookTester webhooks={webhooks} />
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Integration Settings</CardTitle>
              <p className="text-sm text-muted-foreground">
                Configure webhook security, rate limiting, and monitoring settings
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>CORS Origins</Label>
                  <Input value="*" readOnly />
                  <p className="text-xs text-muted-foreground">
                    Currently allows all origins for ElevenLabs integration
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Rate Limiting</Label>
                  <Input value="1000 requests/hour" readOnly />
                  <p className="text-xs text-muted-foreground">
                    Per IP address rate limiting
                  </p>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-medium">Webhook Health Monitoring</h4>
                  <p className="text-sm text-muted-foreground">
                    Automatically monitor webhook health and send alerts
                  </p>
                </div>
                <Badge variant="secondary">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Enabled
                </Badge>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-medium">Error Notifications</h4>
                  <p className="text-sm text-muted-foreground">
                    Email alerts for webhook failures and performance issues
                  </p>
                </div>
                <Badge variant="secondary">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Enabled
                </Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};