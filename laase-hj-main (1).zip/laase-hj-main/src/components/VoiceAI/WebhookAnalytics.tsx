import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  Activity, 
  TrendingUp, 
  Clock, 
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface WebhookAnalytics {
  totalCalls: number;
  successRate: number;
  avgResponseTime: number;
  errorRate: number;
  callsPerHour: Array<{ hour: string; calls: number }>;
  popularWebhooks: Array<{ webhook: string; calls: number }>;
  errorsByWebhook: Array<{ webhook: string; errors: number }>;
  responseTimeByWebhook: Array<{ webhook: string; avgTime: number }>;
}

interface WebhookAnalyticsProps {
  selectedWebhook: string;
  timeRange: string;
  analytics: WebhookAnalytics | null;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#ff0000'];

export const WebhookAnalytics: React.FC<WebhookAnalyticsProps> = ({ 
  selectedWebhook, 
  timeRange, 
  analytics 
}) => {
  if (!analytics) {
    return (
      <div className="flex items-center justify-center h-[400px]">
        <div className="text-center">
          <Activity className="h-8 w-8 mx-auto mb-2 animate-pulse" />
          <p className="text-muted-foreground">Loading analytics...</p>
        </div>
      </div>
    );
  }

  const formatWebhookName = (webhook: string) => {
    return webhook.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.totalCalls.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              In the last {timeRange === '1h' ? 'hour' : timeRange === '24h' ? '24 hours' : timeRange}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{analytics.successRate}%</div>
            <Progress value={analytics.successRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.avgResponseTime}ms</div>
            <div className="mt-2">
              <Badge variant={analytics.avgResponseTime < 200 ? 'default' : analytics.avgResponseTime < 500 ? 'secondary' : 'destructive'}>
                {analytics.avgResponseTime < 200 ? 'Excellent' : analytics.avgResponseTime < 500 ? 'Good' : 'Needs Attention'}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Error Rate</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{analytics.errorRate}%</div>
            <Progress value={analytics.errorRate} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Request Volume Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Request Volume Over Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analytics.callsPerHour}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="calls" 
                  stroke="#8884d8" 
                  strokeWidth={2}
                  dot={{ fill: '#8884d8' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Popular Webhooks */}
        <Card>
          <CardHeader>
            <CardTitle>Most Used Webhooks</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analytics.popularWebhooks}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ webhook, percent }) => `${formatWebhookName(webhook)} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="calls"
                >
                  {analytics.popularWebhooks.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Response Time by Webhook */}
        <Card>
          <CardHeader>
            <CardTitle>Response Time by Webhook</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analytics.responseTimeByWebhook}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="webhook" 
                  angle={-45} 
                  textAnchor="end" 
                  height={80}
                  fontSize={12}
                />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [`${value}ms`, 'Avg Response Time']}
                  labelFormatter={(label) => formatWebhookName(label)}
                />
                <Bar dataKey="avgTime" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Error Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Errors by Webhook</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analytics.errorsByWebhook}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="webhook" 
                  angle={-45} 
                  textAnchor="end" 
                  height={80}
                  fontSize={12}
                />
                <YAxis />
                <Tooltip 
                  formatter={(value, name) => [`${value}`, 'Errors']}
                  labelFormatter={(label) => formatWebhookName(label)}
                />
                <Bar dataKey="errors" fill="#ff7300" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Metrics Table */}
      <Card>
        <CardHeader>
          <CardTitle>Detailed Webhook Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Webhook</th>
                  <th className="text-left p-2">Total Calls</th>
                  <th className="text-left p-2">Success Rate</th>
                  <th className="text-left p-2">Avg Response Time</th>
                  <th className="text-left p-2">Errors</th>
                  <th className="text-left p-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {analytics.popularWebhooks.map((webhook, index) => {
                  const errors = analytics.errorsByWebhook.find(e => e.webhook === webhook.webhook)?.errors || 0;
                  const responseTime = analytics.responseTimeByWebhook.find(r => r.webhook === webhook.webhook)?.avgTime || 0;
                  const successRate = ((webhook.calls - errors) / webhook.calls * 100).toFixed(1);
                  
                  return (
                    <tr key={webhook.webhook} className="border-b hover:bg-muted/50">
                      <td className="p-2 font-medium">{formatWebhookName(webhook.webhook)}</td>
                      <td className="p-2">{webhook.calls.toLocaleString()}</td>
                      <td className="p-2">
                        <span className={`${parseFloat(successRate) > 95 ? 'text-green-600' : parseFloat(successRate) > 90 ? 'text-yellow-600' : 'text-red-600'}`}>
                          {successRate}%
                        </span>
                      </td>
                      <td className="p-2">
                        <span className={`${responseTime < 200 ? 'text-green-600' : responseTime < 500 ? 'text-yellow-600' : 'text-red-600'}`}>
                          {responseTime}ms
                        </span>
                      </td>
                      <td className="p-2">{errors}</td>
                      <td className="p-2">
                        <Badge variant={errors === 0 ? 'default' : errors < 5 ? 'secondary' : 'destructive'}>
                          {errors === 0 ? 'Healthy' : errors < 5 ? 'Warning' : 'Critical'}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};