import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  PlayCircle, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Code,
  Settings,
  Zap
} from 'lucide-react';
import { useWebhookTesting } from '@/hooks/useWebhookTesting';
import { useToast } from '@/hooks/use-toast';

interface Webhook {
  id: string;
  name: string;
  url: string;
  description: string;
  status: string;
}

interface WebhookTesterProps {
  webhooks: Webhook[];
}

export const WebhookTester: React.FC<WebhookTesterProps> = ({ webhooks }) => {
  const { testWebhook, testAllWebhooks, clearResults, results, isLoading } = useWebhookTesting();
  const { toast } = useToast();
  
  const [selectedWebhook, setSelectedWebhook] = useState<string>('');
  const [testPayload, setTestPayload] = useState<string>('{}');
  const [activeTab, setActiveTab] = useState('single');

  const getDefaultPayload = (webhookId: string) => {
    const payloads = {
      'validate-address': {
        address: "Hovedgaden 1, 1000 København",
        market_code: "DK"
      },
      'get-job-categories': {
        language_code: "da",
        market_code: "DK"
      },
      'get-follow-up-questions': {
        job_category_id: "550e8400-e29b-41d4-a716-446655440000",
        language_code: "da",
        market_code: "DK"
      },
      'get-available-times': {
        urgency: "scheduled",
        preferred_date: "2024-01-15"
      },
      'create-booking-from-call': {
        address: "Hovedgaden 1, København",
        urgency: "scheduled",
        job_category_id: "550e8400-e29b-41d4-a716-446655440000",
        follow_up_answers: { lockType: "Cylinder" },
        caller_phone_number: "+4512345678",
        caller_name: "Test User"
      }
    };
    
    return JSON.stringify(payloads[webhookId as keyof typeof payloads] || {}, null, 2);
  };

  const handleWebhookChange = (webhookId: string) => {
    setSelectedWebhook(webhookId);
    setTestPayload(getDefaultPayload(webhookId));
  };

  const handleSingleTest = async () => {
    if (!selectedWebhook) {
      toast({
        title: "Error",
        description: "Please select a webhook to test",
        variant: "destructive"
      });
      return;
    }

    try {
      const payload = JSON.parse(testPayload);
      const result = await testWebhook(selectedWebhook, payload);
      
      toast({
        title: result.success ? "Test Successful" : "Test Failed",
        description: result.success ? 
          `Webhook responded in ${result.responseTime}ms` : 
          `Error: ${result.error}`,
        variant: result.success ? "default" : "destructive"
      });
    } catch (error) {
      toast({
        title: "Invalid JSON",
        description: "Please check your payload format",
        variant: "destructive"
      });
    }
  };

  const handleBulkTest = async () => {
    const requests = webhooks.map(webhook => ({
      webhook: webhook.id,
      payload: JSON.parse(getDefaultPayload(webhook.id))
    }));

    await testAllWebhooks(requests);
    
    const successCount = Object.values(results).filter(r => r.success).length;
    const totalCount = webhooks.length;
    
    toast({
      title: "Bulk Test Complete",
      description: `${successCount}/${totalCount} webhooks passed`,
      variant: successCount === totalCount ? "default" : "destructive"
    });
  };

  const getResultBadge = (webhookId: string) => {
    const result = results[webhookId];
    if (!result) return null;

    return (
      <Badge variant={result.success ? 'default' : 'destructive'} className="ml-2">
        {result.success ? (
          <CheckCircle className="h-3 w-3 mr-1" />
        ) : (
          <AlertCircle className="h-3 w-3 mr-1" />
        )}
        {result.success ? `${result.responseTime}ms` : 'Failed'}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="single">Single Test</TabsTrigger>
          <TabsTrigger value="bulk">Bulk Test</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        <TabsContent value="single" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PlayCircle className="h-5 w-5" />
                Single Webhook Test
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Test individual webhooks with custom payloads
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="webhook-select">Select Webhook</Label>
                  <Select value={selectedWebhook} onValueChange={handleWebhookChange}>
                    <SelectTrigger id="webhook-select">
                      <SelectValue placeholder="Choose a webhook to test" />
                    </SelectTrigger>
                    <SelectContent>
                      {webhooks.map((webhook) => (
                        <SelectItem key={webhook.id} value={webhook.id}>
                          {webhook.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedWebhook && (
                  <div className="space-y-2">
                    <Label>Webhook URL</Label>
                    <Input 
                      value={webhooks.find(w => w.id === selectedWebhook)?.url || ''} 
                      readOnly 
                      className="font-mono text-xs"
                    />
                  </div>
                )}
              </div>

              {selectedWebhook && (
                <div className="space-y-2">
                  <Label htmlFor="payload">Test Payload (JSON)</Label>
                  <Textarea
                    id="payload"
                    value={testPayload}
                    onChange={(e) => setTestPayload(e.target.value)}
                    className="font-mono text-sm min-h-[200px]"
                    placeholder="Enter JSON payload..."
                  />
                </div>
              )}

              <div className="flex gap-2">
                <Button 
                  onClick={handleSingleTest} 
                  disabled={!selectedWebhook || isLoading}
                  className="flex-1"
                >
                  {isLoading ? (
                    <>
                      <Clock className="h-4 w-4 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    <>
                      <PlayCircle className="h-4 w-4 mr-2" />
                      Test Webhook
                    </>
                  )}
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={() => setTestPayload(getDefaultPayload(selectedWebhook))}
                  disabled={!selectedWebhook}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Reset to Default
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Bulk Webhook Test
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Test all webhooks simultaneously with default payloads
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {webhooks.map((webhook) => (
                  <div key={webhook.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{webhook.name}</h4>
                      {getResultBadge(webhook.id)}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {webhook.description}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {webhook.id}
                    </Badge>
                  </div>
                ))}
              </div>

              <Button 
                onClick={handleBulkTest} 
                disabled={isLoading}
                className="w-full"
                size="lg"
              >
                {isLoading ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Testing All Webhooks...
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4 mr-2" />
                    Test All Webhooks
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Test Results
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Detailed results from webhook tests
              </p>
            </CardHeader>
            <CardContent>
              {Object.keys(results).length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Code className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No test results yet. Run some tests to see results here.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {Object.entries(results).map(([webhookId, result]) => {
                    const webhook = webhooks.find(w => w.id === webhookId);
                    return (
                      <div key={webhookId} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{webhook?.name || webhookId}</h4>
                            <Badge variant={result.success ? 'default' : 'destructive'}>
                              {result.success ? (
                                <CheckCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <AlertCircle className="h-3 w-3 mr-1" />
                              )}
                              {result.success ? 'Success' : 'Failed'}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {result.timestamp.toLocaleString()}
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3 text-sm">
                          <div>
                            <span className="text-muted-foreground">Status Code:</span>
                            <span className="ml-2 font-mono">{result.statusCode}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Response Time:</span>
                            <span className="ml-2 font-mono">{result.responseTime}ms</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Success:</span>
                            <span className="ml-2">{result.success ? 'Yes' : 'No'}</span>
                          </div>
                        </div>

                        {result.error && (
                          <div className="mb-3">
                            <h5 className="text-sm font-medium text-red-600 mb-1">Error:</h5>
                            <div className="p-2 bg-red-50 border border-red-200 rounded text-sm text-red-700">
                              {result.error}
                            </div>
                          </div>
                        )}

                        <div>
                          <h5 className="text-sm font-medium mb-2">Response:</h5>
                          <div className="p-3 bg-muted rounded font-mono text-xs overflow-auto max-h-60">
                            <pre className="whitespace-pre-wrap">
                              {result.response ? JSON.stringify(result.response, null, 2) : 'No response data'}
                            </pre>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};