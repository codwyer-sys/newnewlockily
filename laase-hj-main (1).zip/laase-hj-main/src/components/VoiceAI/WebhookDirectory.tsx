import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle, 
  Copy, 
  ExternalLink, 
  FileText, 
  Globe,
  AlertCircle,
  Settings
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Webhook {
  id: string;
  name: string;
  url: string;
  description: string;
  status: string;
}

interface WebhookDirectoryProps {
  webhooks: Webhook[];
}

export const WebhookDirectory: React.FC<WebhookDirectoryProps> = ({ webhooks }) => {
  const { toast } = useToast();

  const copyToClipboard = async (text: string, type: 'url' | 'elevenlabs' = 'url') => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: type === 'url' ? "URL copied to clipboard" : "ElevenLabs tool configuration copied to clipboard",
      });
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getRequestBodyDescription = (webhookId: string): string => {
    const descriptions = {
      'validate-address': 'Request body containing address information to validate and standardize',
      'address_validation': 'Request body containing address information to validate and confirm',
      'get-job-categories': 'Request body containing language and market preferences for job categories',
      'get-follow-up-questions': 'Request body containing job category selection to retrieve relevant questions',
      'get-available-times': 'Request body containing urgency and timing preferences for scheduling',
      'create-booking-from-call': 'Request body containing complete booking information collected during the call'
    };
    return descriptions[webhookId as keyof typeof descriptions] || 'Request body for webhook operation';
  };

  const generateElevenLabsTool = (webhook: Webhook) => {
    const docs = getWebhookDocs(webhook.id);
    if (!docs) return null;

    // Convert our parameter format to ElevenLabs properties format (array of objects)
    const properties = docs.parameters.map(param => ({
      id: param.name,
      type: param.type === 'number' ? 'number' : 'string',
      description: param.description,
      required: param.required,
      value_type: "llm_prompt",
      dynamic_variable: "",
      constant_value: ""
    }));

    // Check if any parameters are required
    const hasRequiredParams = docs.parameters.some(param => param.required);

    const elevenLabsTool = {
      type: "webhook",
      name: webhook.id,
      description: webhook.description,
      api_schema: {
        url: webhook.url,
        method: "POST",
        path_params_schema: [],
        query_params_schema: [],
        request_body_schema: {
          id: `${webhook.id}_body`,
          type: "object",
          description: getRequestBodyDescription(webhook.id),
          properties: properties,
          required: hasRequiredParams,
          value_type: "llm_prompt",
          dynamic_variable: "",
          constant_value: ""
        },
        request_headers: [
          {
            name: "Content-Type",
            value: "application/json",
            type: "value",
            required: true
          },
          {
            name: "Authorization",
            value: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5c21wa2lubGdwcW93bWx3dHRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEyMTk2NjMsImV4cCI6MjA2Njc5NTY2M30.qkUY2UXZp5mJp-fRwHWP_-b8kz3hvE2EUkU4kKL6sbk",
            type: "value",
            required: true
          }
        ],
        auth_connection: null
      },
      dynamic_variables: {
        dynamic_variable_placeholders: {}
      },
      response_timeout_secs: 10
    };

    return JSON.stringify(elevenLabsTool, null, 2);
  };

  const getWebhookDocs = (webhookId: string) => {
    const docs = {
      'validate-address': {
        parameters: [
          { name: 'address', type: 'string', required: true, description: 'Customer address to validate - MUST include full address with postal code and city for Danish addresses' },
          { name: 'market_code', type: 'string', required: false, description: 'Market code (default: DK)' }
        ],
        example: {
          address: "Hovedgaden 1, 1000 København",
          market_code: "DK"
        },
        response: {
          success: true,
          matched: true,
          confidence_score: 0.95,
          clarification_needed: false,
          message: "Adresse valideret succesfuldt",
          address: {
            formatted_address: "Hovedgaden 1, 1000 København K",
            display_text: "Hovedgaden 1, København K",
            postal_code: "1000",
            city: "København K",
            coordinates: { latitude: 55.6761, longitude: 12.5683 }
          },
          follow_up_message: null,
          suggestions: []
        }
      },
      'address_validation': {
        parameters: [
          { name: 'address', type: 'string', required: true, description: 'Customer address to validate and confirm' },
          { name: 'market_code', type: 'string', required: false, description: 'Market code (default: DK)' }
        ],
        example: {
          address: "Hovedgaden 1, 1000 København",
          market_code: "DK"
        },
        response: {
          success: true,
          matched: true,
          confidence_score: 0.95,
          clarification_needed: false,
          message: "Adresse valideret succesfuldt",
          address: {
            formatted_address: "Hovedgaden 1, 1000 København K",
            display_text: "Hovedgaden 1, København K",
            postal_code: "1000",
            city: "København K",
            coordinates: { latitude: 55.6761, longitude: 12.5683 }
          },
          follow_up_message: null,
          suggestions: []
        }
      },
      'get-job-categories': {
        parameters: [
          { name: 'language_code', type: 'string', required: false, description: 'Language code (default: da)' },
          { name: 'market_code', type: 'string', required: false, description: 'Market code (default: DK)' }
        ],
        example: {
          language_code: "da",
          market_code: "DK"
        },
        response: {
          success: true,
          categories: [
            { id: "1", name: "Udlåst", description: "Hjælp med udlåsning", emoji: "🔓" }
          ],
          category_list: "Jeg kan hjælpe dig med følgende...",
          message: "Job kategorier hentet succesfuldt"
        }
      },
      'get-follow-up-questions': {
        parameters: [
          { name: 'job_category_id', type: 'string', required: true, description: 'Selected job category ID' },
          { name: 'language_code', type: 'string', required: false, description: 'Language code (default: da)' },
          { name: 'market_code', type: 'string', required: false, description: 'Market code (default: DK)' }
        ],
        example: {
          job_category_id: "uuid-here",
          language_code: "da",
          market_code: "DK"
        },
        response: {
          success: true,
          questions: [
            {
              id: "1",
              question: "Hvilken type lås er det?",
              question_type: "select",
              options: ["Cylinder", "Dørlås", "Hængelås"],
              is_required: true
            }
          ],
          current_question: {},
          conversation_text: "Formatted question for voice",
          message: "Opfølgende spørgsmål hentet succesfuldt"
        }
      },
      'get-available-times': {
        parameters: [
          { name: 'urgency', type: 'string', required: true, description: 'Urgency level (nu/asap for immediate, scheduled for planned visits)' },
          { name: 'preferred_date', type: 'string', required: false, description: 'Preferred date if specified for scheduled visits' }
        ],
        example: {
          urgency: "nu",
          preferred_date: null
        },
        response: {
          success: true,
          urgency: "nu",
          message: "Vi kommer til dig inden for 30-60 minutter. Vores akutteam er på vej.",
          estimated_arrival: "Inden for 30-60 minutter",
          next_steps: "Ring til 112 hvis det er et sikkerhedsmæssigt nødstilfælde. Ellers er hjælp på vej."
        }
      },
      'create-booking-from-call': {
        parameters: [
          { name: 'address', type: 'string', required: true, description: 'Customer address' },
          { name: 'urgency', type: 'string', required: true, description: 'Urgency level' },
          { name: 'job_category_id', type: 'string', required: true, description: 'Job category ID' },
          { name: 'follow_up_answers', type: 'object', required: true, description: 'Answers to follow-up questions' },
          { name: 'caller_phone_number', type: 'string', required: true, description: 'Phone number' },
          { name: 'caller_name', type: 'string', required: false, description: 'Caller name' },
          { name: 'call_id', type: 'string', required: false, description: 'ElevenLabs call ID' },
          { name: 'call_duration_seconds', type: 'number', required: false, description: 'Call duration' },
          { name: 'call_transcription', type: 'string', required: false, description: 'Call transcription' }
        ],
        example: {
          address: "Hovedgaden 1, København",
          urgency: "scheduled",
          job_category_id: "uuid-here",
          follow_up_answers: { lockType: "Cylinder" },
          caller_phone_number: "+4512345678",
          caller_name: "John Doe"
        },
        response: {
          success: true,
          booking: {
            id: "booking-uuid",
            reference_number: "12345678",
            address: "Hovedgaden 1, København",
            urgency: "scheduled",
            status: "pending"
          },
          message: "Booking oprettet succesfuldt",
          next_steps: "Vi kontakter dig snarest"
        }
      }
    };

    return docs[webhookId as keyof typeof docs] || null;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {webhooks.map((webhook) => {
        const docs = getWebhookDocs(webhook.id);
        
        return (
          <Card key={webhook.id} className="h-fit">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Globe className="h-5 w-5 text-primary" />
                  <div>
                    <CardTitle className="text-lg">{webhook.name}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      {webhook.description}
                    </p>
                  </div>
                </div>
                <Badge variant={webhook.status === 'active' ? 'default' : 'secondary'}>
                  {webhook.status === 'active' ? (
                    <CheckCircle className="h-3 w-3 mr-1" />
                  ) : (
                    <AlertCircle className="h-3 w-3 mr-1" />
                  )}
                  {webhook.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* URL */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium">Webhook URL</h4>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(webhook.url)}
                      className="h-6 px-2"
                      title="Copy URL"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        const elevenLabsTool = generateElevenLabsTool(webhook);
                        if (elevenLabsTool) {
                          copyToClipboard(elevenLabsTool, 'elevenlabs');
                        }
                      }}
                      className="h-6 px-2"
                      title="Copy ElevenLabs Tool Configuration"
                    >
                      <Settings className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="p-2 bg-muted rounded text-xs font-mono break-all">
                  {webhook.url}
                </div>
              </div>

              {/* Parameters */}
              {docs && (
                <div>
                  <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Parameters
                  </h4>
                  <div className="space-y-2">
                    {docs.parameters.map((param, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded text-xs">
                        <div className="flex items-center gap-2">
                          <code className="font-mono">{param.name}</code>
                          <Badge variant={param.required ? 'destructive' : 'secondary'} className="text-xs">
                            {param.required ? 'Required' : 'Optional'}
                          </Badge>
                        </div>
                        <span className="text-muted-foreground">{param.type}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Example Request */}
              {docs && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Example Request</h4>
                  <div className="p-2 bg-muted rounded text-xs font-mono">
                    <pre>{JSON.stringify(docs.example, null, 2)}</pre>
                  </div>
                </div>
              )}

              {/* Example Response */}
              {docs && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Example Response</h4>
                  <div className="p-2 bg-muted rounded text-xs font-mono">
                    <pre>{JSON.stringify(docs.response, null, 2)}</pre>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};