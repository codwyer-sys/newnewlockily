import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import { useCitiesMegaMenu } from '@/hooks/useCitiesMegaMenu';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { CityNameDisplay } from '@/components/CityNameDisplay';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

export const CitiesMegaMenu: React.FC = () => {
  const { featuredCities, standardCities, loading } = useCitiesMegaMenu();
  const { generateCityUrl } = useMarketUrl();

  if (loading) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 p-4 lg:p-6 w-full max-w-sm lg:max-w-[800px]">
        <div className="space-y-3">
          <h3 className="text-base font-semibold text-foreground">Featured Cities</h3>
          <div className="grid gap-2">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="border">
                <CardContent className="p-3">
                  <Skeleton className="h-5 w-32" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <div className="space-y-3">
          <h3 className="text-base font-semibold text-foreground">More Cities</h3>
          <div className="grid grid-cols-1 gap-1">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6 p-4 lg:p-6 w-full max-w-sm lg:max-w-[800px]">
      {/* Featured Cities Grid */}
      <div className="space-y-3">
        <h3 className="text-base font-semibold text-foreground">Featured Cities</h3>
        <div className="grid gap-2">
          {featuredCities.map((city) => (
            <Link
              key={city.id}
              to={generateCityUrl(city.slug)}
              className="block"
            >
              <Card className="transition-all duration-200 hover:shadow-md hover:bg-accent/50 border">
                <CardContent className="p-2 lg:p-3">
                  <CityNameDisplay
                    englishName={city.name}
                    localName={city.local_name}
                    marketCode={city.market_code}
                    showSourceBadge={false}
                    showFlag={false}
                  />
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Standard Cities List */}
      <div className="space-y-3">
        <h3 className="text-base font-semibold text-foreground">More Cities</h3>
        <div className="grid grid-cols-1 gap-1">
          {standardCities.map((city) => (
            <Link
              key={city.id}
              to={generateCityUrl(city.slug)}
              className="block py-2 px-3 rounded-md text-foreground hover:bg-accent/50 transition-colors border border-transparent hover:border-border"
            >
              <CityNameDisplay
                englishName={city.name}
                localName={city.local_name}
                marketCode={city.market_code}
                showSourceBadge={false}
                showFlag={false}
              />
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};