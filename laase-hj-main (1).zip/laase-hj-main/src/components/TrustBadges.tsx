
import React from 'react';
import { Shield, Clock, CheckCircle, Phone } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

const TrustBadges = () => {
  const { t } = useLanguage();
  
  const trustBadges = [
    { icon: Clock, text: t('home.trust.response_time') },
    { icon: Shield, text: t('home.trust.fixed_price') },
    { icon: CheckCircle, text: t('home.trust.quick_arrival') },
    { icon: Phone, text: t('home.trust.emergency') }
  ];

  return (
    <div className="container mx-auto px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-8">
          {t('home.trust.title')}
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {trustBadges.map((badge, index) => (
            <div key={index} className="flex flex-col items-center gap-2 p-6 bg-slate-800 rounded-lg border border-slate-700 hover:border-cyan-500/50 transition-colors">
              <badge.icon className="w-8 h-8 text-cyan-400" />
              <span className="text-sm font-medium text-slate-200 text-center">
                ✅ {badge.text}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrustBadges;
