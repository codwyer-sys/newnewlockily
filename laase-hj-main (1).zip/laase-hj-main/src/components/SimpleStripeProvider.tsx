import React, { useEffect, useState } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';

// Load Stripe publishable key - using the correct test key that matches backend
const STRIPE_PUBLISHABLE_KEY = 'pk_test_51RlPnfPk98j6fgNJxaJvyEIIXi0coRQaGl0YQL7cWKjjBqrLNw6SlWmjCp6YcZ9eWSa7ewo3k0wPnx09bl2Xk5RW00g3ShUgeC';
const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);

interface SimpleStripeProviderProps {
  children: React.ReactNode;
  clientSecret: string;
}

// Simplified appearance for sandbox mode - using basic safe colors
const getSimplifiedAppearance = () => {
  return {
    theme: 'stripe' as const,
    variables: {
      colorPrimary: '#0570de',
      colorBackground: '#ffffff',
      colorText: '#30313d',
      colorDanger: '#df1b41',
      fontFamily: 'system-ui, sans-serif',
      spacingUnit: '4px',
      borderRadius: '4px',
    },
  };
};

export const SimpleStripeProvider: React.FC<SimpleStripeProviderProps> = ({ children, clientSecret }) => {
  const [stripeError, setStripeError] = useState<string>('');

  useEffect(() => {
    // Verify Stripe key format and validate key alignment
    if (!STRIPE_PUBLISHABLE_KEY.startsWith('pk_test_')) {
      setStripeError('Invalid Stripe key: sandbox mode requires test keys');
      console.error('❌ Invalid Stripe publishable key for sandbox mode');
      return;
    }
    
    // Extract account ID from publishable key to validate alignment
    const pubKeyAccountId = STRIPE_PUBLISHABLE_KEY.split('_')[2];
    console.log('✅ Using Stripe test key for sandbox mode');
    console.log(`🔑 Publishable key account ID: ${pubKeyAccountId}`);
    
    // Test Stripe connectivity
    stripePromise.then(stripe => {
      if (stripe) {
        console.log('✅ Stripe loaded successfully');
      } else {
        console.error('❌ Failed to load Stripe');
        setStripeError('Failed to initialize Stripe');
      }
    }).catch(error => {
      console.error('❌ Stripe initialization error:', error);
      setStripeError(`Stripe initialization failed: ${error.message}`);
    });
  }, []);

  // Always use payment mode with clientSecret - no setup mode
  const options = {
    clientSecret,
    appearance: getSimplifiedAppearance(),
  };

  console.log('💳 SimpleStripeProvider rendering with clientSecret:', !!clientSecret);

  if (stripeError) {
    return (
      <div className="p-4 border border-destructive rounded-lg bg-destructive/10">
        <p className="text-destructive text-sm">Stripe Error: {stripeError}</p>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="p-4 border border-muted rounded-lg bg-muted/10">
        <p className="text-muted-foreground text-sm">Preparing payment...</p>
      </div>
    );
  }

  // Only render Elements when we have a clientSecret
  return (
    <Elements stripe={stripePromise} options={options}>
      {children}
    </Elements>
  );
};