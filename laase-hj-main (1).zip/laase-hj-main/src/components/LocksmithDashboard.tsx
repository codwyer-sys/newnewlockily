
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CheckCircle, Clock, MapPin, Phone, Euro, AlertTriangle, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

interface Job {
  id: string;
  customerName: string;
  address: string;
  issueType: string;
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  description: string;
  estimatedPrice: number;
  status: 'pending' | 'accepted' | 'en-route' | 'completed';
  timeRequested: string;
  customerPhone: string;
}

const LocksmithDashboard = () => {
  const { t } = useLanguage();
  const [activeJobs, setActiveJobs] = useState<Job[]>([
    {
      id: '1',
      customerName: 'Maria Hansen',
      address: 'Vesterbrogade 123, 1620 København V',
      issueType: 'locked-out',
      urgency: 'emergency',
      description: 'Låst ude af lejlighed, har baby indeni',
      estimatedPrice: 1200,
      status: 'pending',
      timeRequested: '14:35',
      customerPhone: '+45 23 45 67 89'
    },
    {
      id: '2',
      customerName: 'Lars Petersen',
      address: 'Nørrebrogade 45, 2200 København N',
      issueType: 'broken-lock',
      urgency: 'medium',
      description: 'Cylinderlås virker ikke, nøgle drejer ikke',
      estimatedPrice: 800,
      status: 'accepted',
      timeRequested: '13:20',
      customerPhone: '+45 87 65 43 21'
    }
  ]);

  const [locksmithStats] = useState({
    completedToday: 3,
    revenue: 4500,
    rating: 4.8,
    responseTime: '12 min'
  });

  const { toast } = useToast();

  const handleAcceptJob = (jobId: string) => {
    setActiveJobs(jobs => 
      jobs.map(job => 
        job.id === jobId ? { ...job, status: 'accepted' } : job
      )
    );
    toast({
      title: t('locksmith_portal.dashboard.job_accepted'),
      description: t('locksmith_portal.dashboard.job_accepted_desc')
    });
  };

  const handleRejectJob = (jobId: string) => {
    setActiveJobs(jobs => jobs.filter(job => job.id !== jobId));
    toast({
      title: t('locksmith_portal.dashboard.job_rejected'),
      description: t('locksmith_portal.dashboard.job_rejected_desc')
    });
  };

  const urgencyConfig = {
    low: { label: 'Lav', color: 'bg-green-100 text-green-800' },
    medium: { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
    high: { label: 'Høj', color: 'bg-orange-100 text-orange-800' },
    emergency: { label: 'Akut', color: 'bg-red-100 text-red-800' }
  };

  const issueTypeLabels = {
    'locked-out': 'Låst ude',
    'locked-out-car': 'Låst ude af bil',
    'broken-lock': 'Ødelagt lås',
    'key-broken': 'Knækket nøgle',
    'lock-installation': 'Låsinstallation',
    'security-upgrade': 'Sikkerhedsopgradering',
    'other': 'Andet'
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{locksmithStats.completedToday}</div>
            <div className="text-sm text-gray-600">{t('locksmith_portal.dashboard.jobs_today')}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{locksmithStats.revenue} kr</div>
            <div className="text-sm text-gray-600">{t('locksmith_portal.dashboard.earnings')}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{locksmithStats.rating}</div>
            <div className="text-sm text-gray-600">{t('locksmith_portal.dashboard.rating')}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{locksmithStats.responseTime}</div>
            <div className="text-sm text-gray-600">{t('locksmith_portal.dashboard.response_time')}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">{t('locksmith_portal.dashboard.active_jobs')} ({activeJobs.length})</TabsTrigger>
          <TabsTrigger value="completed">{t('locksmith_portal.dashboard.completed')}</TabsTrigger>
          <TabsTrigger value="settings">{t('locksmith_portal.dashboard.settings')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="space-y-4">
          {activeJobs.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-600 mb-2">{t('locksmith_portal.dashboard.no_active_jobs')}</h3>
                <p className="text-gray-500">{t('locksmith_portal.dashboard.no_active_jobs_desc')}</p>
              </CardContent>
            </Card>
          ) : (
            activeJobs.map(job => (
              <Card key={job.id} className={`${job.urgency === 'emergency' ? 'border-red-200 bg-red-50' : ''}`}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {job.customerName}
                        <Badge className={urgencyConfig[job.urgency].color}>
                          {urgencyConfig[job.urgency].label}
                        </Badge>
                      </CardTitle>
                      <CardDescription className="flex items-center gap-1 mt-1">
                        <Clock className="w-4 h-4" />
                        Anmodet kl. {job.timeRequested}
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-600">{job.estimatedPrice} kr</div>
                      <div className="text-sm text-gray-500">Estimeret pris</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span className="font-medium">{job.address}</span>
                    </div>
                    <div className="text-sm text-gray-600 mb-2">
                      <strong>Problem:</strong> {issueTypeLabels[job.issueType as keyof typeof issueTypeLabels]}
                    </div>
                    <div className="text-sm text-gray-600">
                      {job.description}
                    </div>
                  </div>

                  {job.status === 'pending' && (
                    <div className="flex gap-2 pt-2">
                      <Button 
                        onClick={() => handleAcceptJob(job.id)}
                        className="flex-1"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Accepter Job
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => handleRejectJob(job.id)}
                        className="flex-1"
                      >
                        Afvis
                      </Button>
                      <Button variant="outline" size="icon">
                        <Phone className="w-4 h-4" />
                      </Button>
                    </div>
                  )}

                  {job.status === 'accepted' && (
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <div className="flex items-center gap-2 text-blue-700">
                        <CheckCircle className="w-4 h-4" />
                        <span className="font-medium">Job accepteret</span>
                      </div>
                      <div className="text-sm text-blue-600 mt-1">
                        Kunde kontaktinfo: {job.customerPhone}
                      </div>
                      <div className="flex gap-2 mt-3">
                        <Button size="sm" variant="default">
                          Jeg er på vej
                        </Button>
                        <Button size="sm" variant="outline">
                          Ring til kunde
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="completed">
          <Card>
            <CardContent className="p-8 text-center">
              <h3 className="text-lg font-medium text-gray-600 mb-2">Afsluttede jobs</h3>
              <p className="text-gray-500">Dine færdige jobs fra i dag vil vise sig her</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Låsesmed Indstillinger</CardTitle>
              <CardDescription>
                Administrer din tilgængelighed og priser
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <Card className="p-4">
                  <h3 className="font-medium mb-2">Tilgængelighed</h3>
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    Aktiv - Modtager jobs
                  </Badge>
                </Card>
                <Card className="p-4">
                  <h3 className="font-medium mb-2">Arbejdsområde</h3>
                  <p className="text-sm text-gray-600">København og omegn (15 km)</p>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LocksmithDashboard;
