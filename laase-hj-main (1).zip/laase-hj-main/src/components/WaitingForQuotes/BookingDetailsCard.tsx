import React from 'react';
import { MapPin, Clock, User, Phone, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface BookingDetailsCardProps {
  address: string;
  urgency: string;
  customerName: string;
  customerPhone: string;
}

const BookingDetailsCard: React.FC<BookingDetailsCardProps> = ({
  address,
  urgency,
  customerName,
  customerPhone
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-500" />
          Booking detaljer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
          <div>
            <p className="font-medium text-card-foreground">Adresse</p>
            <p className="text-muted-foreground">{address}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Clock className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
          <div>
            <p className="font-medium text-card-foreground">Hastighed</p>
            <Badge variant={urgency === 'nu' ? 'destructive' : 'secondary'}>
              {urgency === 'nu' ? 'Akut - Nu' : 'Kan vente'}
            </Badge>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <User className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
          <div>
            <p className="font-medium text-card-foreground">Kontakt</p>
            <p className="text-muted-foreground">{customerName}</p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Phone className="w-5 h-5 text-muted-foreground mt-1 flex-shrink-0" />
          <div>
            <p className="font-medium text-card-foreground">Telefon</p>
            <p className="text-muted-foreground">{customerPhone}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BookingDetailsCard;