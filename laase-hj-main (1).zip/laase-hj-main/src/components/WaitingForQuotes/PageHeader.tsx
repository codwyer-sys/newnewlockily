import React from 'react';
import { Clock } from 'lucide-react';

const PageHeader = () => {
  return (
    <div className="text-center mb-8">
      <div className="inline-flex items-center px-4 py-2 rounded-full bg-card border border-border text-card-foreground text-sm font-medium mb-4">
        <Clock className="w-4 h-4 mr-2" />
        Booking oprettet
      </div>
      <h1 className="text-heading-xl font-headline font-bold text-foreground mb-4">
        Venter på tilbud fra låsesmede
      </h1>
      <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
        Din booking er sendt til låsesmede i området. Du vil snart modtage tilbud med priser og ankomsttider.
      </p>
    </div>
  );
};

export default PageHeader;