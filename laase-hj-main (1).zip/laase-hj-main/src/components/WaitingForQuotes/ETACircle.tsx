import React from 'react';

interface ETACircleProps {
  minutes?: number;
}

const ETACircle: React.FC<ETACircleProps> = ({ minutes = 30 }) => {
  return (
    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
      <div className="bg-white rounded-full shadow-xl p-6 min-w-[120px] text-center">
        <div className="text-2xl font-bold text-foreground">~{minutes}</div>
        <div className="text-sm text-muted-foreground">minutter</div>
      </div>
    </div>
  );
};

export default ETACircle;