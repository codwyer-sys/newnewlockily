import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const ActionButtons = () => {
  const navigate = useNavigate();

  return (
    <div className="text-center mt-8">
      <Button 
        variant="outline" 
        onClick={() => navigate('/')}
        className="mr-4"
      >
        Tilbage til forsiden
      </Button>
      <Button 
        onClick={() => window.location.href = 'tel:70203040'}
      >
        Ring til os: 70 20 30 40
      </Button>
    </div>
  );
};

export default ActionButtons;