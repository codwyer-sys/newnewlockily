import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const BookingNotFound = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-foreground mb-4">Booking ikke fundet</h1>
        <Button onClick={() => navigate('/')}>Tilbage til forsiden</Button>
      </div>
    </div>
  );
};

export default BookingNotFound;