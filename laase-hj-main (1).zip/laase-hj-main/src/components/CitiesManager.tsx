import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, MapPin, Users, Building2, Globe, Languages, UserCheck, Clock } from 'lucide-react';
import { useCities, City } from '@/hooks/useCities';
import { useMarketKPIs } from '@/hooks/useMarketKPIs';
import { useMarket } from '@/contexts/MarketContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { WikidataCitySearch } from '@/components/WikidataCitySearch';
import { CityNameDisplay } from '@/components/CityNameDisplay';
import { useCityTranslations } from '@/hooks/useCityTranslations';
import { getCountryFlag } from '@/utils/countryFlags';

interface CityFormData {
  name: string;
  slug: string;
  market_code: string;
  latitude?: number;
  longitude?: number;
  population?: number;
  is_metropolitan: boolean;
  seo_title?: string;
  seo_description?: string;
  seo_keywords: string[];
  featured_image_url?: string;
  featured_image_alt?: string;
  is_active: boolean;
  status: 'draft' | 'published';
}

export const CitiesManager: React.FC = () => {
  const { market } = useMarket();
  const [selectedMarket, setSelectedMarket] = useState<string>(market.country_code);
  const [availableMarkets, setAvailableMarkets] = useState<Array<{country_code: string, country_name: string}>>([]);
  const { cities, loading, fetchCities } = useCities(selectedMarket);
  const kpis = useMarketKPIs(selectedMarket === 'ALL' ? null : selectedMarket);
  const { toast } = useToast();
  const { saveCityTranslations } = useCityTranslations();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [mapboxDialogOpen, setMapboxDialogOpen] = useState(false);
  const [editingCity, setEditingCity] = useState<City | null>(null);
  const [editingTranslation, setEditingTranslation] = useState<{ cityId: string; cityName: string; currentLocal: string } | null>(null);
  const [formData, setFormData] = useState<CityFormData>({
    name: '',
    slug: '',
    market_code: market.country_code,
    is_metropolitan: false,
    seo_keywords: [],
    is_active: true,
    status: 'draft',
  });

  const resetForm = () => {
    setFormData({
      name: '',
      slug: '',
      market_code: market.country_code,
      is_metropolitan: false,
      seo_keywords: [],
      is_active: true,
      status: 'draft',
    });
    setEditingCity(null);
    setEditingTranslation(null);
  };

  const openEditDialog = (city: City) => {
    setEditingCity(city);
    setFormData({
      name: city.name,
      slug: city.slug,
      market_code: city.market_code,
      latitude: city.latitude,
      longitude: city.longitude,
      population: city.population,
      is_metropolitan: city.is_metropolitan,
      seo_title: city.seo_title,
      seo_description: city.seo_description,
      seo_keywords: city.seo_keywords || [],
      featured_image_url: city.featured_image_url,
      featured_image_alt: city.featured_image_alt,
      is_active: city.is_active,
      status: city.status,
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const cityData = {
        ...formData,
        seo_keywords: formData.seo_keywords.filter(k => k.trim()),
      };

      if (editingCity) {
        const { error } = await supabase
          .from('cities')
          .update(cityData)
          .eq('id', editingCity.id);
        
        if (error) throw error;
        
        toast({
          title: 'Success',
          description: 'City updated successfully',
        });
      } else {
        const { data: insertedCity, error } = await supabase
          .from('cities')
          .insert([cityData])
          .select()
          .single();
        
        if (error) throw error;
        
        // Trigger background AI translation for manual city creation
        if (insertedCity) {
          try {
            await supabase.functions.invoke('ai-translate-city-names', {
              body: {
                cityId: insertedCity.id,
                cityName: formData.name,
                marketCode: formData.market_code
              }
            });
          } catch (error) {
            console.warn('Background AI translation failed:', error);
          }
        }
        
        toast({
          title: 'Success',
          description: 'City created successfully',
        });
      }
      
      setDialogOpen(false);
      resetForm();
      fetchCities();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save city',
        variant: 'destructive',
      });
    }
  };

  const handleDelete = async (cityId: string) => {
    try {
      const { error } = await supabase
        .from('cities')
        .delete()
        .eq('id', cityId);
      
      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'City deleted successfully',
      });
      
      fetchCities();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete city',
        variant: 'destructive',
      });
    }
  };

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleNameChange = (name: string) => {
    setFormData(prev => ({
      ...prev,
      name,
      slug: prev.slug || generateSlug(name),
    }));
  };

  // Fetch available markets
  useEffect(() => {
    const fetchMarkets = async () => {
      try {
        const { data, error } = await supabase
          .from('markets')
          .select('country_code, country_name')
          .order('country_name');

        if (error) throw error;
        
        const marketsWithAll = [
          { country_code: 'ALL', country_name: 'All Markets' },
          ...(data || [])
        ];
        
        setAvailableMarkets(marketsWithAll);
      } catch (error) {
        console.error('Error fetching markets:', error);
      }
    };

    fetchMarkets();
  }, []);

  const handleTranslationEdit = async (cityId: string, newLocalName: string) => {
    try {
      const languageCode = market.country_code === 'DK' ? 'da' : 
                          market.country_code === 'DE' ? 'de' : 
                          market.country_code === 'SE' ? 'sv' : 
                          market.country_code === 'NO' ? 'no' : 'en';
      
      await saveCityTranslations(
        cityId,
        { [languageCode]: newLocalName },
        'manual',
        market.country_code
      );
      
      toast({
        title: 'Success',
        description: 'Local name updated successfully',
      });
      
      setEditingTranslation(null);
      fetchCities();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update local name',
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Cities Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Locksmiths</p>
                <p className="text-2xl font-bold">{kpis.loading ? '-' : kpis.totalLocksmiths}</p>
              </div>
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Locksmiths</p>
                <p className="text-2xl font-bold text-green-600">{kpis.loading ? '-' : kpis.activeLocksmiths}</p>
              </div>
              <UserCheck className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Onboarding</p>
                <p className="text-2xl font-bold text-orange-600">{kpis.loading ? '-' : kpis.onboardingLocksmiths}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Cities</p>
                <p className="text-2xl font-bold">{kpis.loading ? '-' : `${kpis.activeCities}/${kpis.totalCities}`}</p>
              </div>
              <MapPin className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Cities Management</CardTitle>
        <div className="flex items-center gap-2">
          <Select value={selectedMarket} onValueChange={setSelectedMarket}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select market..." />
            </SelectTrigger>
            <SelectContent>
              {availableMarkets.map((marketOption) => (
                <SelectItem key={marketOption.country_code} value={marketOption.country_code}>
                  <div className="flex items-center gap-2">
                    {marketOption.country_code === 'ALL' ? (
                      <Globe className="h-4 w-4" />
                    ) : (
                      <span>{getCountryFlag(marketOption.country_code)}</span>
                    )}
                    {marketOption.country_name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button 
            variant="outline" 
            onClick={() => setMapboxDialogOpen(true)}
          >
            <Globe className="h-4 w-4 mr-2" />
            Add from Mapbox
          </Button>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add City
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingCity ? 'Edit City' : 'Add New City'}</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">City Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="slug">URL Slug</Label>
                  <Input
                    id="slug"
                    value={formData.slug}
                    onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="latitude">Latitude</Label>
                  <Input
                    id="latitude"
                    type="number"
                    step="any"
                    value={formData.latitude || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, latitude: e.target.value ? parseFloat(e.target.value) : undefined }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="longitude">Longitude</Label>
                  <Input
                    id="longitude"
                    type="number"
                    step="any"
                    value={formData.longitude || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, longitude: e.target.value ? parseFloat(e.target.value) : undefined }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="population">Population</Label>
                  <Input
                    id="population"
                    type="number"
                    value={formData.population || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, population: e.target.value ? parseInt(e.target.value) : undefined }))}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="is_metropolitan"
                  checked={formData.is_metropolitan}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_metropolitan: checked }))}
                />
                <Label htmlFor="is_metropolitan">Metropolitan City (supports areas)</Label>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
                  />
                  <Label htmlFor="is_active">Active</Label>
                </div>
                
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, status: value as 'draft' | 'published' }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="published">Published</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="seo_title">SEO Title</Label>
                <Input
                  id="seo_title"
                  value={formData.seo_title || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, seo_title: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="seo_description">SEO Description</Label>
                <Textarea
                  id="seo_description"
                  value={formData.seo_description || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, seo_description: e.target.value }))}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="featured_image_url">Featured Image URL</Label>
                  <Input
                    id="featured_image_url"
                    value={formData.featured_image_url || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, featured_image_url: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="featured_image_alt">Featured Image Alt Text</Label>
                  <Input
                    id="featured_image_alt"
                    value={formData.featured_image_alt || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, featured_image_alt: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingCity ? 'Update' : 'Create'} City
                </Button>
              </div>
            </form>
          </DialogContent>
          </Dialog>
          </div>
        </CardHeader>
        
        <CardContent>
        <div className="space-y-4">
          {cities.map((city) => (
            <div key={city.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                 <div className="flex items-center gap-2 mb-1">
                   {selectedMarket === 'ALL' && (
                     <Badge variant="outline" className="text-xs">
                       {getCountryFlag(city.market_code)} {city.market_code}
                     </Badge>
                   )}
                   <CityNameDisplay 
                     englishName={city.name}
                     localName={city.local_name}
                     marketCode={city.market_code}
                     translationSource={city.translation_source}
                     showSourceBadge={true}
                   />
                  {city.wikidata_id && (
                    <Badge variant="outline">
                      <Globe className="h-3 w-3 mr-1" />
                      Wikidata
                    </Badge>
                  )}
                  {city.is_metropolitan && (
                    <Badge variant="secondary">
                      <Building2 className="h-3 w-3 mr-1" />
                      Metro
                    </Badge>
                  )}
                   {!city.is_active && (
                     <Badge variant="destructive">Inactive</Badge>
                   )}
                   {city.status === 'draft' && (
                     <Badge variant="secondary">Draft</Badge>
                   )}
                   {city.status === 'published' && (
                     <Badge variant="default">Published</Badge>
                   )}
                </div>
                
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>/{city.slug}</span>
                  
                  {city.latitude && city.longitude && (
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{city.latitude.toFixed(2)}, {city.longitude.toFixed(2)}</span>
                    </div>
                  )}
                  
                  {city.population && (
                    <div className="flex items-center">
                      <Users className="h-3 w-3 mr-1" />
                      <span>{city.population.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingTranslation({
                    cityId: city.id,
                    cityName: city.name,
                    currentLocal: city.local_name || city.name
                  })}
                  title="Edit local name"
                >
                  <Languages className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => openEditDialog(city)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete City</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{city.name}"? This will also delete all associated areas and cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDelete(city.id)}>
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
          
          {cities.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              No cities found. Add your first city to get started.
            </div>
          )}
        </div>
        
        <WikidataCitySearch
          open={mapboxDialogOpen}
          onOpenChange={setMapboxDialogOpen}
          onCityImported={fetchCities}
          selectedMarket={selectedMarket}
        />

        {/* Translation Edit Dialog */}
        <Dialog open={!!editingTranslation} onOpenChange={() => setEditingTranslation(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Local Name</DialogTitle>
            </DialogHeader>
            
            {editingTranslation && (
              <div className="space-y-4">
                <div>
                  <Label>English Name</Label>
                  <div className="text-sm text-muted-foreground">{editingTranslation.cityName}</div>
                </div>
                
                <div>
                  <Label htmlFor="local-name">Local Name</Label>
                  <Input
                    id="local-name"
                    defaultValue={editingTranslation.currentLocal}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        const target = e.target as HTMLInputElement;
                        handleTranslationEdit(editingTranslation.cityId, target.value);
                      }
                    }}
                  />
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setEditingTranslation(null)}>
                    Cancel
                  </Button>
                  <Button 
                    onClick={() => {
                      const input = document.getElementById('local-name') as HTMLInputElement;
                      handleTranslationEdit(editingTranslation.cityId, input.value);
                    }}
                  >
                    Save
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
    </div>
  );
};