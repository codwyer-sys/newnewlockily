import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Plus, Search, MoreHorizontal, Edit, Trash2, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { BlogCategoryEditor } from './BlogCategoryEditor';
import { ErrorBoundary } from './ui/error-boundary';
import { toast } from 'sonner';

const BlogCategoryManager = () => {
  const { categories, loading, deleteCategory } = useBlogCategories();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState(null);

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.category_key.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = async (category: any) => {
    setCategoryToDelete(category);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (categoryToDelete) {
      try {
        await deleteCategory(categoryToDelete.id);
        toast.success('Category deleted successfully');
        setDeleteDialogOpen(false);
        setCategoryToDelete(null);
      } catch (error) {
        toast.error('Failed to delete category');
      }
    }
  };

  const handleEdit = (category: any) => {
    setSelectedCategory(category);
    setEditDialogOpen(true);
  };

  const handleCreateNew = () => {
    setSelectedCategory(null);
    setEditDialogOpen(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Blog Categories</h1>
          <p className="text-muted-foreground">Manage your blog categories and their translations</p>
        </div>
        <Button onClick={handleCreateNew}>
          <Plus className="mr-2 h-4 w-4" />
          Add Category
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search categories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="text-sm text-muted-foreground">
              {filteredCategories.length} of {categories.length} categories
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-hidden">
            {/* Table Header */}
            <div className="grid grid-cols-12 gap-4 p-4 bg-muted/30 border-b text-sm font-medium text-muted-foreground">
              <div className="col-span-4">Name & Key</div>
              <div className="col-span-2">Status</div>
              <div className="col-span-2">Order</div>
              <div className="col-span-2">Parent</div>
              <div className="col-span-2">Actions</div>
            </div>

            {/* Table Body */}
            <div className="divide-y">
              {filteredCategories.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                      <Plus className="h-6 w-6" />
                    </div>
                    <p>No categories found</p>
                    <p className="text-sm">Create your first blog category to get started</p>
                    <Button variant="outline" size="sm" onClick={handleCreateNew}>
                      Create Category
                    </Button>
                  </div>
                </div>
              ) : (
                filteredCategories.map((category) => (
                  <div 
                    key={category.id} 
                    className="grid grid-cols-12 gap-4 p-4 hover:bg-muted/20 transition-colors"
                  >
                    {/* Name & Key */}
                    <div className="col-span-4">
                      <div className="space-y-1">
                        <div className="font-medium">{category.name}</div>
                        <div className="text-sm text-muted-foreground font-mono">
                          {category.category_key}
                        </div>
                      </div>
                    </div>

                    {/* Status */}
                    <div className="col-span-2 flex items-center">
                      <Badge variant={category.is_active ? 'default' : 'secondary'}>
                        {category.is_active ? (
                          <>
                            <Eye className="mr-1 h-3 w-3" />
                            Active
                          </>
                        ) : (
                          <>
                            <EyeOff className="mr-1 h-3 w-3" />
                            Inactive
                          </>
                        )}
                      </Badge>
                    </div>

                    {/* Order */}
                    <div className="col-span-2 flex items-center">
                      <span className="text-sm">{category.display_order}</span>
                    </div>

                    {/* Parent */}
                    <div className="col-span-2 flex items-center">
                      <span className="text-sm">
                        {category.parent_id ? 
                          categories.find(c => c.id === category.parent_id)?.name || 'Unknown' : 
                          'None'
                        }
                      </span>
                    </div>

                    {/* Actions */}
                    <div className="col-span-2 flex items-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(category)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDelete(category)}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Edit/Create Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedCategory ? 'Edit Category' : 'Create New Category'}
            </DialogTitle>
          </DialogHeader>
          <ErrorBoundary>
            <BlogCategoryEditor 
              category={selectedCategory}
              onSave={() => {
                setEditDialogOpen(false);
                setSelectedCategory(null);
              }}
              onCancel={() => {
                setEditDialogOpen(false);
                setSelectedCategory(null);
              }}
            />
          </ErrorBoundary>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Category</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{categoryToDelete?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteDialogOpen(false)}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default BlogCategoryManager;