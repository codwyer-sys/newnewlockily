import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLanguage } from '@/contexts/LanguageContext';
import { useTranslatedJobCategories } from '@/hooks/useTranslatedJobCategories';

interface JobTypeSelectorProps {
  jobType: string | { selection: string; details: string };
  onJobTypeSelect: (type: string | { selection: string; details: string }) => void;
}

const JobTypeSelector: React.FC<JobTypeSelectorProps> = ({ jobType, onJobTypeSelect }) => {
  const { t } = useLanguage();
  const { categories, loading } = useTranslatedJobCategories();
  const [otherDetails, setOtherDetails] = useState('');

  // Helper function to check if a category is "Other"
  const isOtherCategory = (category: any) => {
    return category.name.toLowerCase() === 'andet' || category.name.toLowerCase() === 'other';
  };

  // Helper function to get current selection ID
  const getCurrentSelection = () => {
    if (typeof jobType === 'string') return jobType;
    if (typeof jobType === 'object') return jobType.selection;
    return '';
  };

  // Helper function to handle "Other" category selection
  const handleCategorySelect = (categoryId: string, categoryData: any) => {
    if (isOtherCategory(categoryData)) {
      onJobTypeSelect({ selection: categoryId, details: otherDetails });
    } else {
      onJobTypeSelect(categoryId);
    }
  };

  // Update other details when jobType changes
  useEffect(() => {
    if (typeof jobType === 'object' && jobType?.details) {
      setOtherDetails(jobType.details);
    } else if (typeof jobType === 'string') {
      setOtherDetails('');
    }
  }, [jobType]);

  if (loading) {
    return (
      <div className="space-y-4 animate-fade-in">
        <label className="block text-sm font-medium text-card-foreground mb-2">
          {t('home.booking.job_type_title')}
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 bg-card border-2 border-border rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <label className="block text-sm font-medium text-card-foreground mb-2">
        {t('home.booking.job_type_title')}
      </label>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories.map((type) => {
          const currentSelection = getCurrentSelection();
          const isSelected = currentSelection === type.id;
          const isOther = isOtherCategory(type);
          
          return (
            <div key={type.id} className="space-y-3">
              <Button
                type="button"
                variant={isSelected ? "default" : "outline"}
                onClick={() => handleCategorySelect(type.id, type)}
                className={`h-16 md:h-20 flex items-center justify-start gap-3 md:gap-4 p-3 md:p-4 transition-all duration-200 w-full ${
                  isSelected 
                    ? "bg-primary text-primary-foreground border border-primary" 
                    : "bg-card border border-border hover:border-primary hover:bg-primary/5"
                }`}
              >
                <span className="text-xl md:text-2xl flex-shrink-0">{type.emoji}</span>
                <div className="text-left flex-1 min-w-0">
                  <div className={`font-headline font-semibold text-sm md:text-base ${
                    isSelected ? "text-primary-foreground" : "text-card-foreground"
                  }`}>
                    {type.name}
                  </div>
                  <div className={`text-xs md:text-sm ${
                    isSelected ? "text-primary-foreground/80" : "text-muted-foreground"
                  }`}>
                    {type.description}
                  </div>
                </div>
              </Button>
              
              {/* Show additional text input for "Other" category when selected */}
              {isOther && isSelected && (
                <div className="animate-fade-in">
                  <Input
                    type="text"
                    value={otherDetails}
                    onChange={(e) => {
                      setOtherDetails(e.target.value);
                      onJobTypeSelect({ selection: type.id, details: e.target.value });
                    }}
                    className="bg-white border-2 border-border focus:border-primary"
                    placeholder="Tilføj detaljer..."
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default JobTypeSelector;