import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  Calendar, 
  Users, 
  Settings, 
  BarChart3, 
  MapPin, 
  Clock,
  LogOut,
  Home,
  ChevronRight,
  CreditCard,
  ChevronDown,
  AlertTriangle,
  Zap
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarHeader,
  SidebarFooter,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { useServiceAreas } from '@/hooks/useServiceAreas';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { useLanguage } from '@/contexts/LanguageContext';

export function LocksmithSidebar() {
  const { state } = useSidebar();
  const { signOut } = useAuth();
  const { isConfigured: serviceAreasConfigured } = useServiceAreas();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [currentStatus, setCurrentStatus] = useState<'ready' | 'busy' | 'offline'>('ready');
  const [showBusyDialog, setShowBusyDialog] = useState(false);
  const [busyMinutes, setBusyMinutes] = useState([30]);
  const [remainingMinutes, setRemainingMinutes] = useState<number | null>(null);

  const navigationItems = [
    {
      title: t('locksmith_portal.sidebar.dashboard'),
      url: '/locksmith-portal',
      icon: Home,
    },
    {
      title: t('locksmith_portal.sidebar.my_jobs'),
      url: '/locksmith-portal/bookings',
      icon: Calendar,
    },
    {
      title: t('locksmith_portal.sidebar.customers'),
      url: '/locksmith-portal/customers',
      icon: Users,
    },
    {
      title: t('locksmith_portal.sidebar.statistics'),
      url: '/locksmith-portal/analytics',
      icon: BarChart3,
    },
    {
      title: t('locksmith_portal.sidebar.work_time'),
      url: '/locksmith-portal/schedule',
      icon: Clock,
    },
  ];

  const serviceItems = [
    {
      title: t('locksmith_portal.sidebar.service_areas'),
      url: '/locksmith-portal/service-areas',
      icon: MapPin,
    },
    {
      title: t('locksmith_portal.sidebar.auto_bid'),
      url: '/locksmith-portal/auto-byd',
      icon: Zap,
    },
  ];

  const adminItems = [
    {
      title: t('locksmith_portal.sidebar.payments'),
      url: '/locksmith-portal/payments',
      icon: CreditCard,
      subItems: [
        { title: 'Betalingsindstillinger', url: '/locksmith-portal/payments/settings' },
      ]
    },
    {
      title: t('locksmith_portal.sidebar.settings'),
      icon: Settings,
      subItems: [
        { title: 'Virksomhed', url: '/locksmith-portal/settings' },
        { title: 'Notifikationer', url: '/locksmith-portal/settings/notifications' },
      ]
    },
  ];

  const statusOptions = [
    { value: 'ready', label: t('locksmith_portal.status.ready'), color: 'bg-green-500', dotColor: 'bg-green-500' },
    { value: 'busy', label: t('locksmith_portal.status.busy'), color: 'bg-yellow-500', dotColor: 'bg-yellow-500' },
    { value: 'offline', label: t('locksmith_portal.status.offline'), color: 'bg-red-500', dotColor: 'bg-red-500' }
  ];

  const currentStatusInfo = statusOptions.find(option => option.value === currentStatus)!

  // Timer countdown effect
  useEffect(() => {
    if (remainingMinutes !== null && remainingMinutes > 0) {
      const interval = setInterval(() => {
        setRemainingMinutes(prev => {
          if (prev === null || prev <= 1) {
            setCurrentStatus('ready');
            return null;
          }
          return prev - 1;
        });
      }, 60000); // Update every minute

      return () => clearInterval(interval);
    }
  }, [remainingMinutes]);

  const handleStatusChange = (newStatus: 'ready' | 'busy' | 'offline') => {
    if (newStatus === 'busy') {
      setShowBusyDialog(true);
    } else {
      setCurrentStatus(newStatus);
      setRemainingMinutes(null); // Clear timer when manually changing status
    }
  };

  const confirmBusyStatus = () => {
    setCurrentStatus('busy');
    setShowBusyDialog(false);
    setRemainingMinutes(busyMinutes[0]);
  };

  // Get display label with countdown
  const getStatusDisplayLabel = () => {
    if (currentStatus === 'busy' && remainingMinutes !== null) {
      return `${t('locksmith_portal.status.busy')} (${remainingMinutes}m)`;
    }
    return currentStatusInfo.label;
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <Sidebar className="border border-primary-foreground/30 bg-primary m-3 mb-3 rounded-lg overflow-hidden shadow-lg">
      <SidebarHeader className="p-4 bg-primary">
        <div className="flex flex-col space-y-3">
          <div className="flex items-center justify-start">
            <img 
              src="/lovable-uploads/355ab5e2-65aa-41be-b596-a5abcb103b9c.png"
              alt="Lockily" 
              className="h-10 w-auto"
            />
          </div>
          {state === 'expanded' && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="w-full justify-between !text-white/90 hover:!text-white bg-white/5 hover:bg-white/10 transition-all duration-200 p-2 rounded-lg text-sm border border-white/10"
                >
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 ${currentStatusInfo.dotColor} rounded-full animate-pulse`}></div>
                    <span>{getStatusDisplayLabel()}</span>
                  </div>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="start" 
                className="w-56 bg-background border border-border shadow-lg z-50"
              >
                {statusOptions.map((option) => (
                  <DropdownMenuItem 
                    key={option.value}
                    onClick={() => handleStatusChange(option.value as any)}
                    className="flex items-center space-x-2 p-3 hover:bg-muted cursor-pointer"
                  >
                    <div className={`w-2 h-2 ${option.dotColor} rounded-full`}></div>
                    <span>{option.label}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </SidebarHeader>

      {/* Busy Status Dialog */}
      <Dialog open={showBusyDialog} onOpenChange={setShowBusyDialog}>
        <DialogContent className="bg-background border border-border">
          <DialogHeader>
            <DialogTitle>{t('locksmith_portal.status.busy_dialog_title')}</DialogTitle>
            <DialogDescription>
              {t('locksmith_portal.status.busy_dialog_description')}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label>{t('locksmith_portal.status.minutes_label')}: {busyMinutes[0]}</Label>
              <Slider
                value={busyMinutes}
                onValueChange={setBusyMinutes}
                max={180}
                min={5}
                step={5}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>5 min</span>
                <span>180 min</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBusyDialog(false)}>
              {t('locksmith_portal.status.cancel')}
            </Button>
            <Button onClick={confirmBusyStatus}>
              {t('locksmith_portal.status.confirm')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SidebarContent className="bg-primary">
        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">{t('locksmith_portal.sidebar.main_menu')}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      end={item.url === '/locksmith-portal'}
                      className={({ isActive }) =>
                        `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 !text-white ${
                          isActive 
                            ? 'bg-white/15 !text-white' 
                            : '!text-white/90 hover:!text-white hover:bg-white/8'
                        }`
                      }
                    >
                       <item.icon className="h-4 w-4 flex-shrink-0" />
                       {state === 'expanded' && <span className="font-medium">{item.title}</span>}
                     </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">{t('locksmith_portal.sidebar.service_menu')}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {serviceItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      className={({ isActive }) =>
                        `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 !text-white ${
                          isActive 
                            ? 'bg-white/15 !text-white' 
                            : '!text-white/90 hover:!text-white hover:bg-white/8'
                        }`
                      }
                    >
                       <item.icon className="h-4 w-4 flex-shrink-0" />
                       {state === 'expanded' && (
                         <div className="flex items-center w-full">
                           <span className="font-medium">{item.title}</span>
                           {item.title === 'Serviceområder' && !serviceAreasConfigured && (
                             <AlertTriangle className="h-3 w-3 text-yellow-500 ml-auto" />
                           )}
                         </div>
                       )}
                     </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 font-medium">{t('locksmith_portal.sidebar.admin_menu')}</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {adminItems.map((item) => (
                item.url ? (
                  // Main link with optional submenu
                  <Collapsible key={item.title} className="group/collapsible">
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild>
                        <NavLink 
                          to={item.url}
                          className={({ isActive }) =>
                            `flex items-center space-x-3 p-3 rounded-lg transition-all duration-200 !text-white ${
                              isActive 
                                ? 'bg-white/15 !text-white' 
                                : '!text-white/90 hover:!text-white hover:bg-white/8'
                            }`
                          }
                        >
                          <item.icon className="h-4 w-4 flex-shrink-0" />
                          {state === 'expanded' && <span className="font-medium">{item.title}</span>}
                        </NavLink>
                      </SidebarMenuButton>
                      {item.subItems && (
                        <CollapsibleContent>
                          <SidebarMenuSub>
                            {item.subItems.map((subItem) => (
                              <SidebarMenuSubItem key={subItem.title}>
                                 <SidebarMenuSubButton asChild>
                                   <NavLink 
                                     to={subItem.url}
                                     className={({ isActive }) =>
                                       `!text-white/90 hover:!text-white hover:bg-white/10 transition-all duration-200 pl-8 ${
                                         isActive ? 'bg-white/15 !text-white font-medium' : ''
                                       }`
                                     }
                                   >
                                     {subItem.title}
                                   </NavLink>
                                 </SidebarMenuSubButton>
                              </SidebarMenuSubItem>
                            ))}
                          </SidebarMenuSub>
                        </CollapsibleContent>
                      )}
                    </SidebarMenuItem>
                  </Collapsible>
                ) : (
                  // Collapsible group without main link
                  <Collapsible key={item.title} className="group/collapsible">
                    <SidebarMenuItem>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton className="!text-white/90 hover:!text-white hover:bg-white/8 transition-all duration-200 p-3 rounded-lg font-medium">
                          <item.icon className="h-4 w-4 flex-shrink-0" />
                          {state === 'expanded' && (
                            <>
                              <span className="font-medium">{item.title}</span>
                              <ChevronRight className="ml-auto h-4 w-4 transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                            </>
                          )}
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.subItems?.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                               <SidebarMenuSubButton asChild>
                                 <NavLink 
                                   to={subItem.url}
                                   className={({ isActive }) =>
                                     `!text-white/90 hover:!text-white hover:bg-white/10 transition-all duration-200 pl-8 ${
                                       isActive ? 'bg-white/15 !text-white font-medium' : ''
                                     }`
                                   }
                                 >
                                   {subItem.title}
                                 </NavLink>
                               </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </SidebarMenuItem>
                  </Collapsible>
                )
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 bg-primary rounded-b-lg">
        <Button 
          variant="ghost" 
          onClick={handleSignOut}
          className="w-full justify-start !text-white/90 hover:!text-white hover:bg-white/8 transition-all duration-200 p-3 rounded-lg font-medium"
        >
          <LogOut className="h-4 w-4 mr-2 flex-shrink-0" />
          {state === 'expanded' && <span>{t('locksmith_portal.sidebar.logout')}</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}