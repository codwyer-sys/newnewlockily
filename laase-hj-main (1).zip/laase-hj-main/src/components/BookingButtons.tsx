import React from 'react';
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";
import { useLanguage } from '@/contexts/LanguageContext';

interface BookingButtonsProps {
  onStartBooking: () => void;
  isDisabled: boolean;
  isBookingInProgress?: boolean;
  allFollowUpAnswered?: boolean;
}

const BookingButtons: React.FC<BookingButtonsProps> = ({ 
  onStartBooking, 
  isDisabled, 
  isBookingInProgress = false,
  allFollowUpAnswered = false 
}) => {
  const { t } = useLanguage();
  
  const buttonText = allFollowUpAnswered 
    ? t('home.booking.find_locksmith_fast')
    : t('home.booking.find_locksmith');

  // Don't render buttons at all if disabled
  if (isDisabled) {
    return null;
  }

  return (
    <div className="pt-6">
      <Button 
        onClick={onStartBooking}
        disabled={isBookingInProgress}
        className="w-full h-12 md:h-16 text-sm md:text-lg font-headline font-bold border border-primary-foreground shadow-md hover:shadow-lg transition-all hover:scale-[1.01] active:scale-[0.99] bg-cta-primary hover:bg-cta-primary/90 text-white"
      >
        <Lock className="w-5 h-5 md:w-6 md:h-6 mr-2 md:mr-3" />
        {isBookingInProgress ? t('home.booking.finding') : buttonText}
      </Button>
    </div>
  );
};

export default BookingButtons;