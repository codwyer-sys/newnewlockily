import React from 'react';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Globe, MapPin } from 'lucide-react';
import { getCountryFlag } from '@/utils/countryFlags';

interface Market {
  country_code: string;
  country_name: string;
}

interface PostTypeSelectorProps {
  postType: 'global' | 'market';
  selectedMarket?: string;
  markets: Market[];
  onPostTypeChange: (type: 'global' | 'market') => void;
  onMarketChange: (market: string) => void;
}

export const PostTypeSelector: React.FC<PostTypeSelectorProps> = ({
  postType,
  selectedMarket,
  markets,
  onPostTypeChange,
  onMarketChange,
}) => {
  return (
    <div className="space-y-4 p-4 border rounded-lg bg-muted/30">
      <Label className="text-base font-medium">Post Type</Label>
      
      <RadioGroup value={postType} onValueChange={onPostTypeChange}>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="global" id="global" />
          <Label htmlFor="global" className="flex items-center gap-2 cursor-pointer">
            <Globe className="h-4 w-4 text-blue-500" />
            Global Post
            <span className="text-sm text-muted-foreground">
              (Available in all markets with market-specific SEO)
            </span>
          </Label>
        </div>
        
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="market" id="market" />
          <Label htmlFor="market" className="flex items-center gap-2 cursor-pointer">
            <MapPin className="h-4 w-4 text-green-500" />
            Market-Specific Post
            <span className="text-sm text-muted-foreground">
              (Only available in selected market)
            </span>
          </Label>
        </div>
      </RadioGroup>

      {postType === 'market' && (
        <div className="space-y-2 ml-6">
          <Label htmlFor="market-select">Select Market</Label>
          <Select value={selectedMarket} onValueChange={onMarketChange}>
            <SelectTrigger id="market-select" className="w-full">
              <SelectValue placeholder="Choose a market..." />
            </SelectTrigger>
            <SelectContent>
              {markets.map((market) => (
                <SelectItem key={market.country_code} value={market.country_code}>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{getCountryFlag(market.country_code)}</span>
                    <span>{market.country_name} ({market.country_code})</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
};