
import React from 'react';
import { GlassInput } from "@/components/ui/glass-input";
import { GlassButton } from "@/components/ui/glass-button";
import { GlassCard } from "@/components/ui/glass-card";
import { MapPin } from "lucide-react";

interface AddressInputProps {
  address: string;
  onAddressChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onLocationClick: () => void;
  isLoadingLocation: boolean;
  addressSuggestions: string[];
  showSuggestions: boolean;
  onSuggestionClick: (suggestion: string) => void;
  onFocus: () => void;
  onBlur: () => void;
  inputRef: React.RefObject<HTMLInputElement>;
}

const AddressInput: React.FC<AddressInputProps> = ({
  address,
  onAddressChange,
  onLocationClick,
  isLoadingLocation,
  addressSuggestions,
  showSuggestions,
  onSuggestionClick,
  onFocus,
  onBlur,
  inputRef
}) => {
  return (
    <div className="space-y-apple-4 relative">
      <div className="flex gap-apple-3">
        <div className="relative flex-1">
          <div className="relative">
            <GlassInput
              ref={inputRef}
              id="address"
              placeholder="Hvor skal du bruge en låsesmed?"
              value={address}
              onChange={onAddressChange}
              onFocus={onFocus}
              onBlur={onBlur}
              variant="capsule"
              className="pl-12 h-14 text-apple-body placeholder:text-system-gray2"
              autoFocus
            />
            <MapPin className="absolute left-apple-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-system-gray2" />
          </div>
          
          {showSuggestions && addressSuggestions.length > 0 && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-2 max-h-60 overflow-y-auto"
            >
              {addressSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full text-left px-apple-4 py-apple-3 hover:bg-system-blue/10 active:bg-system-blue/20 transition-colors text-apple-body font-apple border-b border-system-gray6 last:border-b-0 rounded-none first:rounded-t-apple-large last:rounded-b-apple-large"
                  onClick={() => onSuggestionClick(suggestion)}
                >
                  {suggestion}
                </button>
              ))}
            </GlassCard>
          )}
        </div>
        
        <GlassButton
          type="button"
          variant="primary"
          size="capsule"
          onClick={onLocationClick}
          disabled={isLoadingLocation}
          className="h-14 px-apple-6 min-w-[140px] text-apple-callout font-semibold text-white"
        >
          <MapPin className={`w-5 h-5 ${isLoadingLocation ? 'animate-spin' : ''}`} />
          Min lokation
        </GlassButton>
      </div>
    </div>
  );
};

export default AddressInput;
