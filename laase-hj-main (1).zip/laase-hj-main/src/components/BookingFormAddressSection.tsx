
import React from 'react';
import UnifiedAddressInput from "@/components/UnifiedAddressInput";

interface BookingFormAddressSectionProps {
  address: string;
  setAddress: (address: string) => void;
  setHasSelectedSuggestion: (selected: boolean) => void;
}

const BookingFormAddressSection: React.FC<BookingFormAddressSectionProps> = ({
  address,
  setAddress,
  setHasSelectedSuggestion
}) => {
  const handleAddressChange = (newAddress: string) => {
    setAddress(newAddress);
    setHasSelectedSuggestion(true);
  };

  return (
    <UnifiedAddressInput
      address={address}
      onAddressChange={handleAddressChange}
    />
  );
};

export default BookingFormAddressSection;
