
import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { supabase } from '@/integrations/supabase/client';

interface BookingBackgroundMapProps {
  address: string;
}

const BookingBackgroundMap: React.FC<BookingBackgroundMapProps> = ({ address }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    if (!mapContainer.current) return;

    console.log('🗺️ Initializing background map for address:', address);

    // MapBox public token - using environment variable or fallback
    mapboxgl.accessToken = 'pk.eyJ1IjoibG9ja2lseSIsImEiOiJjbWNxMGpseXowZDNzMmpyMjYzOWE4cjJkIn0.3mcKSl4a-lHwZwhHJGssMQ';
    
    // Initialize map with Copenhagen as default center
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/light-v11',
      center: [12.5683, 55.6761], // Copenhagen
      zoom: 13,
      scrollZoom: false,
      dragPan: false,
      doubleClickZoom: false,
      touchZoomRotate: false,
      dragRotate: false,
      keyboard: false,
      interactive: false
    });

    map.current.on('load', () => {
      console.log('🗺️ Background map loaded successfully');
      setIsLoading(false);
      
      // Geocode and add marker for the address
      if (address) {
        geocodeAndAddMarker(address);
      } else {
        // Add default marker for Copenhagen
        console.log('🗺️ Adding default Copenhagen marker');
        new mapboxgl.Marker({ color: '#ef4444' })
          .setLngLat([12.5683, 55.6761])
          .addTo(map.current!);
      }
    });

    return () => {
      console.log('🗺️ Cleaning up background map');
      map.current?.remove();
    };
  }, []);

  const geocodeAndAddMarker = async (address: string) => {
    console.log('🎯 Geocoding address for background map:', address);
    
    try {
      const { data, error } = await supabase.functions.invoke('geocode-with-cache', {
        body: { address }
      });

      if (error) {
        console.error('🚨 Geocoding error:', error);
        throw error;
      }

      console.log('📍 Geocoding result:', data);

      if (data?.latitude && data?.longitude) {
        const lng = data.longitude;
        const lat = data.latitude;
        
        console.log('✅ Setting map center and adding marker at:', { lat, lng });
        
        // Update map center and add marker
        map.current?.setCenter([lng, lat]);
        new mapboxgl.Marker({ color: '#ef4444', scale: 0.8 })
          .setLngLat([lng, lat])
          .addTo(map.current!);
      } else {
        console.warn('⚠️ No coordinates returned, using fallback');
        // Fallback marker at Copenhagen
        new mapboxgl.Marker({ color: '#ef4444' })
          .setLngLat([12.5683, 55.6761])
          .addTo(map.current!);
      }
    } catch (error) {
      console.error('💥 Geocoding failed, using fallback:', error);
      // Fallback marker at Copenhagen
      new mapboxgl.Marker({ color: '#ef4444' })
        .setLngLat([12.5683, 55.6761])
        .addTo(map.current!);
    }
  };

  return (
    <div className="absolute inset-0 w-full h-full">
      <div ref={mapContainer} className="absolute inset-0 w-full h-full" />
      {isLoading && (
        <div className="absolute inset-0 bg-muted/20 flex items-center justify-center">
          <div className="text-muted-foreground text-sm opacity-50">Loading map...</div>
        </div>
      )}
    </div>
  );
};

export default BookingBackgroundMap;
