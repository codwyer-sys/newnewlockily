import React, { useState, useEffect } from 'react';
import { PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, CreditCard, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useJobStatusUpdate } from '@/hooks/useJobStatusUpdate';

// Using the correct Stripe test key that matches the backend secret key
const stripePromise = loadStripe('pk_test_51RlPnfPk98j6fgNJxaJvyEIIXi0coRQaGl0YQL7cWKjjBqrLNw6SlWmjCp6YcZ9eWSa7ewo3k0wPnx09bl2Xk5RW00g3ShUgeC');

type PaymentState = 'loading' | 'ready' | 'processing' | 'success' | 'error';

interface UltraSimplePaymentProps {
  quoteId: string;
  bookingId: string;
  onSuccess: () => void;
  onClose: () => void;
}

const PaymentForm: React.FC<UltraSimplePaymentProps & { clientSecret: string; amount: number; locksmithId: string }> = ({
  quoteId,
  bookingId,
  clientSecret,
  amount,
  locksmithId,
  onSuccess,
  onClose
}) => {
  const [state, setState] = useState<PaymentState>('ready');
  const [error, setError] = useState('');
  const stripe = useStripe();
  const elements = useElements();
  const { updateJobStage } = useJobStatusUpdate();

  const handlePayment = async () => {
    if (!stripe || !elements) {
      console.error('🚨 Stripe or Elements not ready');
      setError('Payment system not ready. Please refresh and try again.');
      return;
    }

    console.log('💳 Starting payment confirmation process...');
    setState('processing');
    setError('');

    try {
      // Validate payment element before confirmation
      const { error: submitError } = await elements.submit();
      if (submitError) {
        console.error('🚨 Payment element submission error:', submitError);
        setError(submitError.message || 'Please check your payment details');
        setState('ready');
        return;
      }

      console.log('✅ Payment element validated, confirming payment...');

      // Confirm payment with minimal parameters - removed problematic return_url and receipt_email
      const { error: paymentError, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: 'if_required', // This prevents redirects and handles payment in-place
      });

      console.log('🔍 Payment confirmation result:', { paymentError, paymentIntent });

      if (paymentError) {
        console.error('🚨 Stripe payment error:', paymentError);
        
        // Handle specific Stripe error types
        let errorMessage = 'Payment failed. Please try again.';
        
        if (paymentError.type === 'card_error') {
          errorMessage = paymentError.message || 'Your card was declined. Please try a different card.';
        } else if (paymentError.type === 'validation_error') {
          errorMessage = 'Please check your payment information and try again.';
        } else if (paymentError.type === 'api_connection_error') {
          errorMessage = 'Connection error. Please check your internet and try again.';
        } else if (paymentError.message) {
          errorMessage = paymentError.message;
        }
        
        setError(errorMessage);
        setState('ready');
        return;
      }

      if (paymentIntent?.status === 'succeeded') {
        console.log('🎉 Payment succeeded! Updating job stage...');
        
        try {
          await updateJobStage(bookingId, 'awaiting_locksmith_acceptance', locksmithId);
          console.log('✅ Job stage updated successfully');
        } catch (stageError) {
          console.error('⚠️ Failed to update job stage (payment still succeeded):', stageError);
          // Don't fail the payment for this - just log it
        }
        
        setState('success');
        onSuccess();
      } else if (paymentIntent?.status === 'processing') {
        console.log('⏳ Payment is processing...');
        setError('Payment is processing. This may take a moment.');
        setState('ready');
      } else if (paymentIntent?.status === 'requires_action') {
        console.log('🔐 Payment requires additional authentication');
        setError('Payment requires additional authentication. Please complete the verification.');
        setState('ready');
      } else {
        console.error('🚨 Unexpected payment status:', paymentIntent?.status);
        setError('Payment status unclear. Please contact support if charged.');
        setState('ready');
      }
    } catch (error) {
      console.error('🚨 Unexpected error during payment:', error);
      setError('An unexpected error occurred. Please try again.');
      setState('ready');
    }
  };

  if (state === 'processing') {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Processing payment...</p>
        </div>
      </div>
    );
  }

  if (state === 'success') {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CreditCard className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Payment Successful!</h3>
          <p className="text-muted-foreground">Your payment has been processed successfully.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="border-t border-border bg-muted/20 p-5 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Complete Payment</h3>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={onClose}
          className="h-8 w-8 p-0"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="space-y-6">
        <div className="bg-muted/30 rounded-lg p-4">
          <PaymentElement />
        </div>

        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
          <Shield className="w-4 h-4" />
          <span>Secured by Stripe</span>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Button 
          onClick={handlePayment}
          disabled={!stripe || !elements}
          className="w-full"
          size="lg"
        >
          Pay {amount} kr
        </Button>
      </div>
    </div>
  );
};

export const UltraSimplePayment: React.FC<UltraSimplePaymentProps> = (props) => {
  const [state, setState] = useState<PaymentState>('loading');
  const [clientSecret, setClientSecret] = useState('');
  const [amount, setAmount] = useState(0);
  const [locksmithId, setLocksmithId] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    createPaymentIntent();
  }, [props.quoteId]);

  const createPaymentIntent = async () => {
    console.log('🚀 Initializing payment intent for quote:', props.quoteId);
    setState('loading');
    setError('');
    
    try {
      const { data, error: invokeError } = await supabase.functions.invoke('create-customer-payment', {
        body: { 
          quoteId: props.quoteId, 
          email: 'guest@payment.com'
        }
      });

      console.log('📥 Payment intent response:', { data, invokeError });

      if (invokeError) {
        console.error('🚨 Supabase function invoke error:', invokeError);
        setError(`Payment initialization failed: ${invokeError.message || 'Unknown error'}`);
        setState('error');
        return;
      }

      if (!data?.client_secret) {
        console.error('🚨 No client secret in response:', data);
        setError('Payment initialization failed. No client secret received.');
        setState('error');
        return;
      }

      console.log('✅ Payment intent created successfully:', {
        clientSecret: data.client_secret.substring(0, 20) + '...',
        amount: data.amount,
        locksmithId: data.locksmith_id
      });

      setClientSecret(data.client_secret);
      setAmount(data.amount || 0);
      setLocksmithId(data.locksmith_id || '');
      setState('ready');
    } catch (error) {
      console.error('🚨 Unexpected error creating payment intent:', error);
      setError('Payment initialization failed. Please try again.');
      setState('error');
    }
  };

  if (state === 'loading') {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-muted-foreground">Preparing payment...</p>
        </div>
      </div>
    );
  }

  if (state === 'error') {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="space-y-4">
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
          <Button 
            onClick={createPaymentIntent}
            className="w-full"
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="border-t border-border bg-muted/20 p-5">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Initializing payment...</p>
        </div>
      </div>
    );
  }

  return (
    <Elements 
      stripe={stripePromise} 
      options={{ 
        clientSecret
      }}
    >
      <PaymentForm 
        {...props} 
        clientSecret={clientSecret}
        amount={amount}
        locksmithId={locksmithId}
      />
    </Elements>
  );
};