import React, { useState, useEffect } from 'react';
import { MapPin, Users, Building2, Shield, Clock, CheckCircle, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useMarketAddressSearch } from '@/hooks/useMarketAddressSearch';
import { useLocksmithData } from '@/hooks/useLocksmithData';
import { useLanguage } from '@/contexts/LanguageContext';
import { useMarket } from '@/contexts/MarketContext';
import { useNavigate } from 'react-router-dom';
import UrgencySelector from '@/components/UrgencySelector';
import JobTypeSelector from '@/components/JobTypeSelector';
import FollowUpQuestions from '@/components/FollowUpQuestions';
import BookingButtons from '@/components/BookingButtons';
import ContactInfoDialog from '@/components/ContactInfoDialog';
import { CityMapCircle } from '@/components/CityMapCircle';

interface City {
  id: string;
  name: string;
  slug: string;
  market_code: string;
  latitude?: number;
  longitude?: number;
  population?: number;
  is_metropolitan: boolean;
  seo_title?: string;
  seo_description?: string;
  featured_image_url?: string;
  featured_image_alt?: string;
}

interface CityHeroSectionProps {
  city: City;
}

export const CityHeroSection: React.FC<CityHeroSectionProps> = ({ city }) => {
  const { t } = useLanguage();
  const { market } = useMarket();
  const navigate = useNavigate();
  const { getCurrentLocation, isLoadingLocation } = useGeolocation();
  const { createBooking } = useLocksmithData();

  // Simple state management - copied from HeroSection
  const [address, setAddress] = useState(city.name); // Pre-fill with city name
  const [skipAddressSearch, setSkipAddressSearch] = useState(true); // Skip search since we pre-filled
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [hasSelectedSuggestion, setHasSelectedSuggestion] = useState(true); // Set to true since we pre-filled
  const [showBookingForm, setShowBookingForm] = useState(true); // Show form immediately
  const [showContactDialog, setShowContactDialog] = useState(false);

  // Booking form state
  const [urgency, setUrgency] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [jobType, setJobType] = useState('');
  const [followUpAnswers, setFollowUpAnswers] = useState<Record<string, any>>({});
  const [isBookingInProgress, setIsBookingInProgress] = useState(false);

  // Form visibility state
  const [showJobType, setShowJobType] = useState(true);
  const [showFollowUp, setShowFollowUp] = useState(false);
  const [showUrgency, setShowUrgency] = useState(false);
  const [showBookingButtons, setShowBookingButtons] = useState(false);


  // Address search
  const { 
    suggestions: addressSuggestions, 
    isLoading: isAddressLoading,
    error: addressError 
  } = useMarketAddressSearch(address, !skipAddressSearch);

  // Form progression logic - copied from HeroSection
  useEffect(() => {
    if (jobType) {
      setShowFollowUp(true);
    }
  }, [jobType]);

  useEffect(() => {
    // Simple check - show urgency when job type is selected
    if (jobType) {
      setShowUrgency(true);
    }
  }, [jobType]);

  useEffect(() => {
    if (urgency && jobType) {
      setShowBookingButtons(true);
    }
  }, [urgency, jobType]);

  const handleAddressChange = (value: string) => {
    setAddress(value);
    setSkipAddressSearch(false);
    setHasSelectedSuggestion(false);
    
    if (value.length >= 3) {
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const handleAddressSelect = (selectedAddress: string) => {
    setAddress(selectedAddress);
    setHasSelectedSuggestion(true);
    setShowSuggestions(false);
    setSkipAddressSearch(true);
    setShowBookingForm(true);
  };

  const handleGetLocation = async () => {
    const location = await getCurrentLocation();
    if (location) {
      setAddress(location);
      setHasSelectedSuggestion(true);
      setShowSuggestions(false);
      setSkipAddressSearch(true);
      setShowBookingForm(true);
    }
  };

  const handleJobTypeSelect = (type: string) => {
    setJobType(type);
    setFollowUpAnswers({});
  };

  const handleFollowUpAnswer = (questionKey: string, answer: any) => {
    setFollowUpAnswers(prev => ({
      ...prev,
      [questionKey]: answer
    }));
  };

  const handleUrgencySelect = (selectedUrgency: string) => {
    setUrgency(selectedUrgency);
  };

  const handleDateChange = (date: string) => {
    setSelectedDate(date);
  };


  const handleBookingButtonClick = () => {
    setShowContactDialog(true);
  };

  const handleContactInfoSubmit = async (contactInfo: { name: string; phone: string }) => {
    setIsBookingInProgress(true);
    try {
      const updatedFollowUpAnswers = {
        ...followUpAnswers,
        customerName: contactInfo.name,
        customerPhone: contactInfo.phone
      };
      
      const bookingData = {
        address,
        urgency,
        selectedDate,
        jobType,
        followUpAnswers: updatedFollowUpAnswers
      };
      
      const booking = await createBooking(bookingData);
      setShowContactDialog(false);
      navigate(`/${market.country_code.toLowerCase()}/booking-status/${booking.id}`);
    } catch (error) {
      console.error('Booking submission failed:', error);
    } finally {
      setIsBookingInProgress(false);
    }
  };

  // Simple validation
  const isBookingDisabled = !address || !urgency || !jobType;

  return (
    <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white overflow-hidden min-h-screen">
      {/* Background Image with Green Overlay */}
      {city.featured_image_url && (
        <div className="absolute inset-0">
          <img
            src={city.featured_image_url}
            alt={city.featured_image_alt || city.name}
            className="w-full h-full object-cover"
          />
          {/* Prominent Green Overlay for visibility */}
          <div className="absolute inset-0 bg-gradient-to-br from-green-900/90 via-green-800/85 to-green-900/90"></div>
        </div>
      )}

      <div className="relative container mx-auto px-4 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left: City Information & Map */}
          <div className="space-y-8">
            {/* Hero Headline */}
            <div className="text-center lg:text-left">
              <div className="flex items-center justify-center lg:justify-start gap-3 mb-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                  Låsesmed i {city.name}
                </h1>
                {city.is_metropolitan && (
                  <Badge variant="outline" className="border-white/30 text-white bg-white/10 backdrop-blur-sm">
                    <Building2 className="h-3 w-3 mr-1" />
                    Storby
                  </Badge>
                )}
              </div>
              
              <p className="text-xl lg:text-2xl text-green-100 font-medium mb-2">
                24/7 Akut Service • Professionelle Låsesmede
              </p>
              
              <p className="text-lg text-white/90 leading-relaxed mb-6">
                Hurtig og pålidelig låsesmedservice i {city.name}. Vi kommer til dig inden for 30 minutter.
              </p>

              {/* Trust Indicators */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 mb-8">
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span className="text-sm font-medium">Certificerede</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                  <Clock className="h-5 w-5 text-green-400" />
                  <span className="text-sm font-medium">30 min respons</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                  <Star className="h-5 w-5 text-yellow-400" />
                  <span className="text-sm font-medium">4.9/5 anmeldelser</span>
                </div>
              </div>
            </div>

            {/* City Coverage Map */}
            {city.latitude && city.longitude && (
              <div className="lg:block hidden">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-400" />
                  Vores serviceområde
                </h3>
                <CityMapCircle
                  cityName={city.name}
                  latitude={city.latitude}
                  longitude={city.longitude}
                  radiusKm={15}
                  className="h-64 w-full"
                />
              </div>
            )}

            {/* City Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="text-center lg:text-left bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <div className="text-2xl font-bold text-white">15 min</div>
                <div className="text-sm text-white/80">Gennemsnitlig ankomsttid</div>
              </div>
              <div className="text-center lg:text-left bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <div className="text-2xl font-bold text-white">500+</div>
                <div className="text-sm text-white/80">Job i {city.name} i år</div>
              </div>
              {city.population && (
                <div className="text-center lg:text-left bg-white/10 backdrop-blur-sm rounded-xl p-4 col-span-2 lg:col-span-1">
                  <div className="text-2xl font-bold text-white">{(city.population / 1000).toFixed(0)}k</div>
                  <div className="text-sm text-white/80">Indbyggere betjent</div>
                </div>
              )}
            </div>
          </div>

          {/* Right: High-Converting Booking Form */}
          <div className="w-full">
            <Card className="bg-white/95 backdrop-blur-sm border-2 border-green-400/30 shadow-2xl lg:sticky lg:top-8">
              <CardContent className="p-6 lg:p-8">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center gap-2 bg-green-100 text-green-800 rounded-full px-4 py-2 text-sm font-medium mb-4">
                    <CheckCircle className="h-4 w-4" />
                    Gratis prisoverslag på 2 minutter
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Få hjælp nu i {city.name}
                  </h2>
                  <p className="text-gray-600">
                    Beskriv dit problem og få tilbud fra certificerede låsesmede
                  </p>
                </div>

                <div className="space-y-6">
                  {/* Address Section */}
                  <div>
                    <div className="relative">
                      <Input 
                        type="text" 
                        placeholder={`Adresse i ${city.name}`}
                        value={address}
                        onChange={e => handleAddressChange(e.target.value)} 
                        className="text-lg p-6 h-16 bg-white text-gray-900 border-2 border-green-300 focus:border-green-500 focus:ring-4 focus:ring-green-200 rounded-xl font-medium placeholder:text-gray-500 shadow-lg hover:shadow-xl transition-all duration-300" 
                      />
                      
                      {/* Address Suggestions Dropdown */}
                      {showSuggestions && addressSuggestions.length > 0 && address.length > 2 && (
                        <div className="absolute top-full left-0 right-0 bg-white border border-border rounded-lg mt-1 shadow-lg z-20 max-h-48 overflow-y-auto">
                          {addressSuggestions.map((suggestion, index) => (
                            <button 
                              key={index} 
                              className="w-full text-left px-3 py-3 hover:bg-secondary/50 active:bg-secondary transition-colors border-b border-border/50 last:border-b-0 first:rounded-t-lg last:rounded-b-lg group" 
                              onClick={() => handleAddressSelect(suggestion.fullAddress)}
                            >
                              <div className="font-medium text-card-foreground text-sm group-hover:text-card-foreground/90">
                                {suggestion.displayText}
                              </div>
                              <div className="text-xs text-muted-foreground mt-0.5 group-hover:text-muted-foreground/80">
                                Klik for at vælge
                              </div>
                            </button>
                          ))}
                        </div>
                      )}
                      
                      {/* Loading State */}
                      {isAddressLoading && address.length > 2 && (
                        <div className="absolute top-full left-0 right-0 bg-white border-2 border-border rounded-lg mt-1 shadow-xl z-20 px-4 py-4">
                          <div className="text-sm text-muted-foreground flex items-center">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                            Søger efter adresser...
                          </div>
                        </div>
                      )}
                      
                      {/* Error State */}
                      {addressError && address.length > 2 && (
                        <div className="absolute top-full left-0 right-0 bg-white border-2 border-border rounded-lg mt-1 shadow-xl z-20 px-4 py-4">
                          <div className="text-sm text-red-600">
                            {addressError}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3 mt-4">
                      <div className="flex-1 h-px bg-border"></div>
                      <span className="text-muted-foreground text-xs font-medium px-2">eller</span>
                      <div className="flex-1 h-px bg-border"></div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      onClick={handleGetLocation} 
                      disabled={isLoadingLocation}
                      className="w-full h-12 text-base font-medium mt-4 rounded-xl border-2 border-green-300 text-green-700 hover:bg-green-50 transition-all duration-300"
                    >
                      <MapPin className={`w-5 h-5 mr-2 ${isLoadingLocation ? 'animate-spin' : ''}`} />
                      {isLoadingLocation ? 'Finder position...' : 'Brug min position'}
                    </Button>
                  </div>

                  {/* Progressive Form Sections */}
                  {showBookingForm && (
                    <div className="space-y-6 animate-fade-in">
                      {showJobType && (
                        <div className="animate-fade-in">
                          <JobTypeSelector
                            jobType={jobType}
                            onJobTypeSelect={handleJobTypeSelect}
                          />
                        </div>
                      )}

                      {showFollowUp && jobType && (
                        <div className="animate-fade-in">
                          <FollowUpQuestions
                            jobType={jobType}
                            answers={followUpAnswers}
                            onAnswerChange={handleFollowUpAnswer}
                          />
                        </div>
                      )}

                      <UrgencySelector
                        urgency={urgency}
                        selectedDate={selectedDate}
                        onUrgencySelect={handleUrgencySelect}
                        onDateChange={handleDateChange}
                        showUrgency={showUrgency}
                      />

                      {showBookingButtons && (
                        <div className="animate-fade-in pt-6">
                          <Button 
                            onClick={handleBookingButtonClick}
                            disabled={isBookingDisabled || isBookingInProgress}
                            className="w-full h-14 text-lg font-bold bg-green-600 hover:bg-green-700 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
                          >
                            <CheckCircle className="w-6 h-6 mr-3" />
                            {isBookingInProgress ? 'Sender anmodning...' : 'Få gratis tilbud nu'}
                          </Button>
                          <p className="text-center text-sm text-gray-500 mt-3">
                            ✓ Ingen binding • ✓ Sammenlign priser • ✓ Vælg den bedste låsesmed
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Mobile Map Section */}
      {city.latitude && city.longitude && (
        <div className="lg:hidden relative container mx-auto px-4 pb-16">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Shield className="h-5 w-5 text-green-400" />
              Vi dækker hele {city.name}
            </h3>
            <CityMapCircle
              cityName={city.name}
              latitude={city.latitude}
              longitude={city.longitude}
              radiusKm={15}
              className="h-48 w-full"
            />
          </div>
        </div>
      )}

      {/* Contact Info Dialog */}
      <ContactInfoDialog
        open={showContactDialog}
        onOpenChange={setShowContactDialog}
        onSubmit={handleContactInfoSubmit}
        isSubmitting={isBookingInProgress}
      />
    </section>
  );
};