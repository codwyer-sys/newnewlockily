import React from 'react';
import { BlogCategoryWithTranslations } from '@/hooks/useBlogCategories';
import { BlogCategoryMultiSelect } from './BlogCategoryMultiSelect';
import { useLanguage } from '@/contexts/LanguageContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface BlogSidebarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  categories: BlogCategoryWithTranslations[];
  selectedCategories: string[];
  onCategoryChange: (categories: string[]) => void;
  totalPosts: number;
  filteredPosts: number;
  loading?: boolean;
}

export const BlogSidebar: React.FC<BlogSidebarProps> = ({
  searchQuery,
  onSearchChange,
  categories,
  selectedCategories,
  onCategoryChange,
  totalPosts,
  filteredPosts,
  loading = false
}) => {
  const { t } = useLanguage();
  const clearAllFilters = () => {
    onSearchChange('');
    onCategoryChange([]);
  };

  const hasActiveFilters = searchQuery.trim() !== '' || selectedCategories.length > 0;

  return (
    <div className="space-y-6">
      {/* Search Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t('blog.sidebar.search_title')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder={t('blog.sidebar.search_placeholder')}
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onSearchChange('')}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          
          {/* Results Count */}
          <div className="text-sm text-muted-foreground">
            {t('blog.sidebar.showing_results')
              .replace('{filtered}', filteredPosts.toString())
              .replace('{total}', totalPosts.toString())}
          </div>
        </CardContent>
      </Card>

      {/* Categories Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t('blog.sidebar.categories_title')}</CardTitle>
        </CardHeader>
        <CardContent>
          <BlogCategoryMultiSelect
            categories={categories}
            selectedCategories={selectedCategories}
            onSelectionChange={onCategoryChange}
            loading={loading}
          />
        </CardContent>
      </Card>

      {/* Active Filters */}
        {hasActiveFilters && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{t('blog.sidebar.active_filters_title')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex flex-wrap gap-2">
              {searchQuery && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  {t('blog.interface.search_label')} "{searchQuery}"
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onSearchChange('')}
                    className="h-4 w-4 p-0 ml-1"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              )}
              
              {selectedCategories.map(categoryId => {
                const category = categories.find(c => c.id === categoryId);
                return category ? (
                  <Badge key={categoryId} variant="secondary" className="flex items-center gap-1">
                    {category.name}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onCategoryChange(selectedCategories.filter(id => id !== categoryId))}
                      className="h-4 w-4 p-0 ml-1"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ) : null;
              })}
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={clearAllFilters}
              className="w-full"
            >
              {t('blog.sidebar.clear_all_filters')}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};