import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { useIsMobile } from '@/hooks/use-mobile';

const LanguagePicker = () => {
  const { language, availableLanguages, setLanguage, canSetLanguage } = useLanguage();
  const isMobile = useIsMobile();

  if (availableLanguages.length <= 1) {
    return null; // Don't show picker if only one language available
  }

  const getLanguageCountryCode = (langCode: string): string => {
    const countryMap: Record<string, string> = {
      'da': 'DK',
      'en': 'GB', 
      'de': 'DE',
      'fr': 'FR',
      'es': 'ES',
      'sv': 'SE',
      'no': 'NO',
      'ga': 'IE'
    };
    return countryMap[langCode] || 'XX';
  };

  const currentLang = availableLanguages.find(lang => lang.code === language);
  const otherLanguages = availableLanguages.filter(lang => lang.code !== language);

  const handleLanguageSwitch = () => {
    const nextLanguage = otherLanguages[0];
    if (nextLanguage && canSetLanguage(nextLanguage.code as any)) {
      setLanguage(nextLanguage.code as any);
    }
  };

  if (isMobile) {
    return (
      <button 
        onClick={handleLanguageSwitch}
        className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium text-foreground bg-card border border-border rounded-md hover:bg-accent/50 transition-colors"
        title={`Switch to ${otherLanguages[0]?.name || 'other language'}`}
      >
        <div className="flex items-center">
          <CountryFlag code={getLanguageCountryCode(otherLanguages[0]?.code || language)} size="sm" className="mr-3" />
          <span>Switch to {otherLanguages[0]?.name || 'other language'}</span>
        </div>
      </button>
    );
  }

  return (
    <button 
      onClick={handleLanguageSwitch}
      className="text-sm font-medium text-inherit transition-colors px-3 py-2 rounded-md hover:bg-background/20 backdrop-blur-sm"
      title={`Switch to ${otherLanguages[0]?.name || 'other language'}`}
    >
      <CountryFlag code={getLanguageCountryCode(currentLang?.code || language)} size="sm" className="mr-1" />
      {currentLang?.code.toUpperCase() || language.toUpperCase()}
    </button>
  );
};

export default LanguagePicker;