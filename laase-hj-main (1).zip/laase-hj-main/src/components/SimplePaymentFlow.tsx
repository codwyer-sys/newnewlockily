import React, { useState, useEffect } from 'react';
import { PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Shield, CreditCard, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useJobStatusUpdate } from '@/hooks/useJobStatusUpdate';

// Simple linear state - no complex state machine  
type PaymentStep = 'collecting_email' | 'payment_ready' | 'processing' | 'success' | 'error';

interface SimplePaymentFlowProps {
  quoteId: string;
  bookingId: string;
  clientSecret: string;
  amount: number;
  locksmithId: string;
  onSuccess: () => void;
  onClose: () => void;
}

export const SimplePaymentFlow: React.FC<SimplePaymentFlowProps> = ({ 
  quoteId, 
  bookingId, 
  clientSecret,
  amount,
  locksmithId,
  onSuccess, 
  onClose 
}) => {
  const [step, setStep] = useState<PaymentStep>('collecting_email');
  const [email, setEmail] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [error, setError] = useState('');
  const [elementReady, setElementReady] = useState(false);
  
  const stripe = useStripe();
  const elements = useElements();
  const { updateJobStage } = useJobStatusUpdate();


  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleEmailSubmit = async () => {
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }

    if (!acceptTerms) {
      setError('Please accept the terms to continue');
      return;
    }

    setError('');

    // Update payment intent with email
    try {
      await supabase.functions.invoke('update-payment-email', {
        body: { 
          paymentIntentId: clientSecret.split('_secret_')[0],
          email: email
        }
      });
      console.log('✅ Email updated successfully');
    } catch (error) {
      console.log('⚠️ Email update failed, but continuing with payment');
    }

    setStep('payment_ready');
  };

  const handlePayment = async () => {
    if (!stripe || !elements) {
      console.error('💥 Payment prerequisites not met');
      return;
    }

    if (!elementReady) {
      setError('Payment form is not ready. Please wait a moment and try again.');
      return;
    }

    setStep('processing');
    setError('');

    try {
      console.log('💳 Confirming payment...');
      
      const { error: paymentError, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.href,
          receipt_email: email,
        },
        redirect: 'if_required',
      });

      if (paymentError) {
        console.error('💥 Payment error:', paymentError);
        setError(paymentError.message || 'Payment failed');
        setStep('payment_ready');
        return;
      }

      if (paymentIntent?.status === 'succeeded') {
        console.log('✅ Payment succeeded!');
        
        // Update job stage
        try {
          await updateJobStage(bookingId, 'awaiting_locksmith_acceptance', locksmithId);
          console.log('✅ Job stage updated');
        } catch (stageError) {
          console.error('💥 Failed to update job stage:', stageError);
        }
        
        setStep('success');
        onSuccess();
      } else {
        console.log('❓ Unexpected payment status:', paymentIntent?.status);
        setError('Payment confirmation failed. Please try again.');
        setStep('payment_ready');
      }
    } catch (error) {
      console.error('💥 Unexpected error during payment:', error);
      setError('An unexpected error occurred. Please try again.');
      setStep('payment_ready');
    }
  };

  const renderContent = () => {
    switch (step) {
      case 'collecting_email':
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="mt-1"
                />
              </div>

              <div className="flex items-start space-x-2">
                <Checkbox
                  id="terms"
                  checked={acceptTerms}
                  onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
                />
                <Label htmlFor="terms" className="text-sm leading-relaxed">
                  I accept the terms and conditions and agree to pay {amount} kr for this service.
                </Label>
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </div>

            <Button 
              onClick={handleEmailSubmit}
              disabled={!email || !acceptTerms}
              className="w-full"
              size="lg"
            >
              Continue to Payment
            </Button>
          </div>
        );

      case 'payment_ready':
        return (
          <div className="space-y-6">
            <div className="bg-muted/30 rounded-lg p-4">
              {!elementReady && (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mr-3"></div>
                  <span className="text-muted-foreground">Preparing secure payment form...</span>
                </div>
              )}
              <PaymentElement 
                options={{
                  layout: "tabs",
                  paymentMethodOrder: ['card'],
                }}
                onReady={() => {
                  console.log('✅ PaymentElement mounted and ready');
                  setElementReady(true);
                }}
                onLoadError={(error) => {
                  console.error('💥 PaymentElement load error:', error);
                  setError('Failed to load payment form. Please refresh and try again.');
                }}
              />
            </div>

            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Shield className="w-4 h-4" />
              <span>Secured by Stripe</span>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button 
              onClick={handlePayment}
              disabled={!elementReady}
              className="w-full"
              size="lg"
            >
              {!elementReady ? 'Loading payment form...' : `Pay ${amount} kr`}
            </Button>
          </div>
        );

      case 'processing':
        return (
          <div className="text-center py-8">
            <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-muted-foreground">Processing payment...</p>
          </div>
        );

      case 'success':
        return (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CreditCard className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Payment Successful!</h3>
            <p className="text-muted-foreground">Your payment has been processed successfully.</p>
          </div>
        );

      case 'error':
        return (
          <div className="space-y-6">
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
            <Button 
              onClick={onClose}
              className="w-full"
              variant="outline"
            >
              Close
            </Button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="border-t border-border bg-muted/20 p-5 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">
            {step === 'collecting_email' ? 'Confirm Payment' : 
             step === 'payment_ready' ? 'Complete Payment' : 
             step === 'success' ? 'Payment Complete' : 
             'Payment'}
          </h3>
        </div>
        <Button 
          variant="ghost" 
          size="sm"
          onClick={onClose}
          disabled={step === 'processing'}
          className="h-8 w-8 p-0"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Content */}
      {renderContent()}
    </div>
  );
};