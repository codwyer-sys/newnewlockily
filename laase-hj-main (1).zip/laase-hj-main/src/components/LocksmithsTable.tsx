import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Pagination, 
  PaginationContent, 
  PaginationItem, 
  PaginationLink, 
  PaginationNext, 
  PaginationPrevious 
} from '@/components/ui/pagination';
import { Eye, Phone, MapPin, Loader2, Plus, Percent } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { useLocksmithsTable } from '@/hooks/useLocksmithsTable';
import { InlineFilters } from './LocksmithsTable/InlineFilters';
import { exportToCSV } from '@/utils/csvExport';
import { getCountryFlag } from '@/utils/countryFlags';
import { ReferralSettingsDialog } from '@/components/LocksmithReferral/ReferralSettingsDialog';

const StatusIndicator: React.FC<{ status: string | null }> = ({ status }) => {
  const getStatusColor = (status: string | null) => {
    switch (status) {
      case 'active':
        return 'bg-green-500';
      case 'pending':
        return 'bg-yellow-500';
      case 'inactive':
      case 'suspended':
        return 'bg-red-500';
      default:
        return 'bg-muted';
    }
  };

  return (
    <div className={`w-3 h-3 rounded-full ${getStatusColor(status)}`} />
  );
};

const LocksmithsTable: React.FC = () => {
  const navigate = useNavigate();
  const [referralDialogOpen, setReferralDialogOpen] = React.useState(false);
  const [selectedLocksmith, setSelectedLocksmith] = React.useState<any>(null);
  const {
    locksmiths,
    loading,
    totalCount,
    currentPage,
    totalPages,
    filters,
    setCurrentPage,
    updateFilters,
    clearFilters
  } = useLocksmithsTable();

  const handleExport = () => {
    if (locksmiths.length === 0) {
      toast.error('No data to export');
      return;
    }
    
    exportToCSV(locksmiths, 'locksmiths_export');
    toast.success('CSV exported successfully');
  };

  const getInitials = (firstName: string | null, lastName: string | null, companyName: string | null) => {
    if (firstName && lastName) {
      return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
    }
    if (companyName) {
      return companyName.split(' ').map(word => word.charAt(0)).join('').substring(0, 2).toUpperCase();
    }
    return 'LK';
  };

  const getDisplayName = (locksmith: any) => {
    if (locksmith.company_name) {
      return locksmith.company_name;
    }
    if (locksmith.first_name && locksmith.last_name) {
      return `${locksmith.first_name} ${locksmith.last_name}`;
    }
    return 'Unnamed Business';
  };

  const getStatusLabel = (status: string | null) => {
    switch (status) {
      case 'pending':
        return 'Onboarding';
      case 'active':
        return 'Active';
      case 'inactive':
        return 'Inactive';
      case 'suspended':
        return 'Suspended';
      default:
        return 'Unknown';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Locksmiths</h1>
          <p className="text-muted-foreground">Manage locksmith profiles and accounts</p>
        </div>
        <Button onClick={() => navigate('/admin-portal/locksmiths/create')}>
          <Plus className="mr-2 h-4 w-4" />
          Add New Locksmith
        </Button>
      </div>

      {/* Filters */}
      <InlineFilters
        filters={filters}
        onFiltersChange={updateFilters}
        onClearFilters={clearFilters}
        onExport={handleExport}
        totalCount={totalCount}
      />

      <Card>
        <CardContent className="p-0">
          <div className="overflow-hidden">
            {/* Table Header */}
            <div className="grid grid-cols-12 gap-4 p-4 bg-muted/30 border-b text-sm font-medium text-muted-foreground">
              <div className="col-span-1">Status</div>
              <div className="col-span-1">Logo</div>
              <div className="col-span-3">Business Name</div>
              <div className="col-span-2">City</div>
              <div className="col-span-2">Phone</div>
              <div className="col-span-2">Jobs</div>
              <div className="col-span-1">Actions</div>
            </div>

            {/* Table Body */}
            <div className="divide-y">
              {locksmiths.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  <div className="flex flex-col items-center space-y-2">
                    <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                      <Eye className="h-6 w-6" />
                    </div>
                    <p>No locksmiths found</p>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigate('/admin-portal/locksmiths/create')}
                    >
                      Create your first locksmith
                    </Button>
                  </div>
                </div>
              ) : (
                locksmiths.map((locksmith) => (
                  <div 
                    key={locksmith.id} 
                    className="grid grid-cols-12 gap-4 p-4 hover:bg-muted/20 transition-colors"
                  >
                    {/* Status */}
                    <div className="col-span-1 flex items-center">
                      <div className="flex items-center gap-2">
                        <StatusIndicator status={locksmith.status} />
                        <span className="text-xs text-muted-foreground hidden sm:inline">
                          {getStatusLabel(locksmith.status)}
                        </span>
                      </div>
                    </div>

                    {/* Logo */}
                    <div className="col-span-1 flex items-center">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=64&h=64&fit=crop&crop=center`} />
                        <AvatarFallback className="text-xs">
                          {getInitials(locksmith.first_name, locksmith.last_name, locksmith.company_name)}
                        </AvatarFallback>
                      </Avatar>
                    </div>

                    {/* Business Name + Flag */}
                    <div className="col-span-3 flex items-center">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getCountryFlag(locksmith.market)}</span>
                        <div>
                          <div className="font-medium">{getDisplayName(locksmith)}</div>
                          {locksmith.first_name && locksmith.last_name && locksmith.company_name && (
                            <div className="text-sm text-muted-foreground">
                              {locksmith.first_name} {locksmith.last_name}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* City */}
                    <div className="col-span-2 flex items-center">
                      <div className="flex items-center space-x-1">
                        <MapPin className="h-3 w-3 text-muted-foreground" />
                        <span className="text-sm">{locksmith.city || 'N/A'}</span>
                      </div>
                    </div>

                    {/* Phone */}
                    <div className="col-span-2 flex items-center">
                      <div className="flex items-center space-x-1">
                        <Phone className="h-3 w-3 text-muted-foreground" />
                        <span className="text-sm">{locksmith.phone || 'N/A'}</span>
                      </div>
                    </div>

                    {/* Jobs Count */}
                    <div className="col-span-2 flex items-center">
                      <div className="text-sm">
                        <span className="font-medium">{locksmith.completed_jobs}</span>
                        <span className="text-muted-foreground ml-1">completed</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="col-span-1 flex items-center gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => {
                          setSelectedLocksmith(locksmith);
                          setReferralDialogOpen(true);
                        }}
                        title="Manage referral settings"
                      >
                        <Percent className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => {
                          toast.info('Full profile view coming soon!');
                        }}
                        title="View profile"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center">
          <Pagination>
            <PaginationContent>
              {currentPage > 1 && (
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => setCurrentPage(currentPage - 1)}
                    className="cursor-pointer"
                  />
                </PaginationItem>
              )}
              
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const page = i + 1;
                return (
                  <PaginationItem key={page}>
                    <PaginationLink
                      onClick={() => setCurrentPage(page)}
                      isActive={currentPage === page}
                      className="cursor-pointer"
                    >
                      {page}
                    </PaginationLink>
                  </PaginationItem>
                );
              })}
              
              {currentPage < totalPages && (
                <PaginationItem>
                  <PaginationNext 
                    onClick={() => setCurrentPage(currentPage + 1)}
                    className="cursor-pointer"
                  />
                </PaginationItem>
              )}
            </PaginationContent>
          </Pagination>
        </div>
      )}

      {/* Referral Settings Dialog */}
      {selectedLocksmith && (
        <ReferralSettingsDialog
          open={referralDialogOpen}
          onOpenChange={setReferralDialogOpen}
          locksmithId={selectedLocksmith.id}
          locksmithName={getDisplayName(selectedLocksmith)}
        />
      )}
    </div>
  );
};

export default LocksmithsTable;