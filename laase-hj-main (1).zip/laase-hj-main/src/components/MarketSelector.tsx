import React, { useState, useEffect } from 'react';
import { Globe, ChevronDown } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useMarket } from '@/contexts/MarketContext';
import { supabase } from '@/integrations/supabase/client';
import { getCountryFlag } from '@/utils/countryFlags';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

interface MarketOption {
  country_code: string;
  country_name: string;
  currency_code: string;
}

export const MarketSelector = () => {
  const { market, setMarketByCode } = useMarket();
  const navigate = useNavigate();
  const location = useLocation();
  const [availableMarkets, setAvailableMarkets] = useState<MarketOption[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMarkets = async () => {
      try {
        const { data, error } = await supabase
          .from('markets')
          .select('country_code, country_name, currency_code')
          .order('country_name');

        if (error) throw error;
        setAvailableMarkets(data || []);
      } catch (error) {
        console.error('Error fetching markets:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMarkets();
  }, []);

  const handleMarketChange = (marketCode: string) => {
    console.log('🌍 MarketSelector: Changing market to:', marketCode);
    setMarketByCode(marketCode);
    
    // Get current path without market prefix
    const currentPath = location.pathname.replace(/^\/[a-z]{2}/, '') || '/';
    
    // Generate new URL with selected market
    const newUrl = `/${marketCode.toLowerCase()}${currentPath}`;
    
    // Navigate to new market URL
    navigate(newUrl, { replace: true });
  };

  const currentMarket = availableMarkets.find(m => m.country_code === market.country_code);

  if (loading) {
    return (
      <Button variant="outline" size="sm" disabled className="bg-white">
        <Globe className="w-4 h-4 mr-2" />
        Loading...
      </Button>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="bg-white border-gray-300 hover:bg-gray-50 text-gray-700 font-medium"
        >
          <Globe className="w-4 h-4 mr-2" />
          <span className="mr-1">{getCountryFlag(currentMarket?.country_code || null)}</span>
          {currentMarket?.country_name || 'Select Market'}
          <ChevronDown className="w-4 h-4 ml-2" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        align="start" 
        className="w-56 bg-white border border-gray-200 shadow-lg rounded-lg z-50"
      >
        {availableMarkets.map((option) => (
          <DropdownMenuItem
            key={option.country_code}
            onClick={() => handleMarketChange(option.country_code)}
            className={`flex items-center px-3 py-2 text-sm cursor-pointer hover:bg-gray-100 ${
              option.country_code === market.country_code ? 'bg-blue-50 text-blue-600' : 'text-gray-700'
            }`}
          >
            <span className="text-lg mr-3">{getCountryFlag(option.country_code)}</span>
            <div className="flex-1">
              <div className="font-medium">{option.country_name}</div>
              <div className="text-xs text-gray-500">{option.currency_code}</div>
            </div>
            {option.country_code === market.country_code && (
              <div className="w-2 h-2 bg-blue-600 rounded-full ml-2"></div>
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};