import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, User, Eye } from 'lucide-react';
import { MarketAwareBlogPost } from '@/hooks/useMarketAwareBlogPosts';
import { BlogCategoryWithTranslations } from '@/hooks/useBlogCategories';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { useLanguage } from '@/contexts/LanguageContext';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { useMarket } from '@/contexts/MarketContext';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';

interface BlogPostCardProps {
  post: MarketAwareBlogPost;
  category?: BlogCategoryWithTranslations;
}

export const BlogPostCard: React.FC<BlogPostCardProps> = ({ post, category }) => {
  const { generateBlogPostUrl, generateBlogPostUrlWithCategory } = useMarketUrl();
  const { t } = useLanguage();
  const { market } = useMarket();
  const { categories } = useBlogCategories(market.country_code, 'en');
  
  // Use market-aware content if available
  const title = post.market_title || post.title;
  const excerpt = post.market_excerpt || post.excerpt;
  const slug = post.market_slug || post.slug;
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const calculateReadTime = (content: string) => {
    const wordsPerMinute = 200;
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / wordsPerMinute);
  };

  // Find the category for this post to generate proper URL
  const postCategory = category || (post.category_id ? categories.find(c => c.id === post.category_id) : null);
  
  // Generate URL with category if available, otherwise use legacy format
  const postUrl = postCategory 
    ? generateBlogPostUrlWithCategory(postCategory.slug, slug)
    : generateBlogPostUrl(slug);

  return (
    <Card className="h-full flex flex-col hover:shadow-lg transition-all duration-300 group border-border hover:border-primary/20">
      <CardHeader className="p-0">
        {/* Featured Image */}
        <div className="relative aspect-[16/9] overflow-hidden rounded-t-lg bg-muted">
          {post.featured_image_url ? (
            <img
              src={post.featured_image_url}
              alt={post.featured_image_alt || title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
              <div className="text-4xl">📝</div>
            </div>
          )}
          
          {/* Category Badge */}
          {category && (
            <div className="absolute top-3 left-3">
              <Badge 
                variant="secondary" 
                className="bg-background/80 text-foreground backdrop-blur-sm border-border"
              >
                {category.name}
              </Badge>
            </div>
          )}
        </div>
      </CardHeader>

      <CardContent className="flex-1 p-6">
        {/* Title */}
        <h3 className="text-xl font-semibold mb-3 line-clamp-2 group-hover:text-primary transition-colors">
          <Link to={postUrl} className="hover:underline">
            {title}
          </Link>
        </h3>

        {/* Excerpt */}
        {excerpt && (
          <p className="text-muted-foreground text-sm line-clamp-3 mb-4">
            {excerpt}
          </p>
        )}

        {/* Metadata */}
        <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
          {/* Publish Date */}
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            <span>{formatDate(post.published_at || post.created_at)}</span>
          </div>

          {/* Read Time */}
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{t('blog.interface.min_read').replace('{minutes}', calculateReadTime(post.market_content || post.content).toString())}</span>
          </div>

          {/* View Count */}
          {post.view_count > 0 && (
            <div className="flex items-center gap-1">
              <Eye className="h-3 w-3" />
              <span>{t('blog.interface.views').replace('{count}', post.view_count.toString())}</span>
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="p-6 pt-0">
        <Link
          to={postUrl}
          className="inline-flex items-center text-sm font-medium text-primary hover:text-primary/80 transition-colors"
        >
          {t('blog.interface.read_more')}
          <svg 
            className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </Link>
      </CardFooter>
    </Card>
  );
};