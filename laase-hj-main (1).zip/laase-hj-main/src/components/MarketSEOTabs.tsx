import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { getCountryFlag } from '@/utils/countryFlags';
import { useBlogPostMarketSEO } from '@/hooks/useBlogPostMarketSEO';
import QuillEditor from '@/components/QuillEditor';
import { toast } from 'sonner';

interface Market {
  country_code: string;
  country_name: string;
}

interface MarketSEOTabsProps {
  postId?: string;
  markets: Market[];
}

export const MarketSEOTabs: React.FC<MarketSEOTabsProps> = ({ postId, markets }) => {
  const { marketSEO, createOrUpdateMarketSEO, getMarketSEO } = useBlogPostMarketSEO(postId);
  const [activeTab, setActiveTab] = useState(markets[0]?.country_code || '');
  const [formData, setFormData] = useState<Record<string, any>>({});

  useEffect(() => {
    // Initialize form data with existing content and SEO data
    const initialData: Record<string, any> = {};
    markets.forEach(market => {
      const existingSEO = getMarketSEO(market.country_code);
      initialData[market.country_code] = {
        title: existingSEO?.title || '',
        slug: existingSEO?.slug || '',
        excerpt: existingSEO?.excerpt || '',
        content: existingSEO?.content || '',
        seo_title: existingSEO?.seo_title || '',
        seo_description: existingSEO?.seo_description || '',
        seo_keywords: existingSEO?.seo_keywords?.join(', ') || '',
        og_title: existingSEO?.og_title || '',
        og_description: existingSEO?.og_description || '',
        og_image_url: existingSEO?.og_image_url || '',
        twitter_title: existingSEO?.twitter_title || '',
        twitter_description: existingSEO?.twitter_description || '',
        twitter_image_url: existingSEO?.twitter_image_url || '',
        canonical_url: existingSEO?.canonical_url || '',
      };
    });
    setFormData(initialData);
  }, [marketSEO, markets]);

  const handleFieldChange = (marketCode: string, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [marketCode]: {
        ...prev[marketCode],
        [field]: value,
      },
    }));
  };

  const handleSaveMarket = async (marketCode: string) => {
    if (!postId) {
      toast.error('Post must be saved before adding market SEO data');
      return;
    }

    const data = formData[marketCode];
    if (!data) return;

    try {
      await createOrUpdateMarketSEO({
        post_id: postId,
        market_code: marketCode,
        title: data.title || undefined,
        slug: data.slug || undefined,
        excerpt: data.excerpt || undefined,
        content: data.content || undefined,
        seo_title: data.seo_title || undefined,
        seo_description: data.seo_description || undefined,
        seo_keywords: data.seo_keywords ? data.seo_keywords.split(',').map((k: string) => k.trim()).filter(Boolean) : undefined,
        og_title: data.og_title || undefined,
        og_description: data.og_description || undefined,
        og_image_url: data.og_image_url || undefined,
        twitter_title: data.twitter_title || undefined,
        twitter_description: data.twitter_description || undefined,
        twitter_image_url: data.twitter_image_url || undefined,
        canonical_url: data.canonical_url || undefined,
      });
    } catch (error) {
      // Error is handled in the hook
    }
  };

  if (!postId) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          <p>Save the post first to manage market-specific content and SEO settings</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Market-Specific Content & SEO</CardTitle>
        <p className="text-sm text-muted-foreground">
          Configure unique content and SEO metadata for each market
        </p>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            {markets.slice(0, 4).map((market) => (
              <TabsTrigger key={market.country_code} value={market.country_code}>
                <span className="mr-2">{getCountryFlag(market.country_code)}</span>
                {market.country_code}
              </TabsTrigger>
            ))}
          </TabsList>

          {markets.map((market) => (
            <TabsContent key={market.country_code} value={market.country_code}>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium flex items-center gap-2">
                    <span className="text-2xl">{getCountryFlag(market.country_code)}</span>
                    {market.country_name}
                  </h3>
                  <Button 
                    onClick={() => handleSaveMarket(market.country_code)}
                    size="sm"
                  >
                    Save {market.country_code} Content
                  </Button>
                </div>

                <div className="grid grid-cols-1 gap-6">
                  {/* Market-Specific Content */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                      Market Content
                    </h4>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`title_${market.country_code}`}>Title</Label>
                        <Input
                          id={`title_${market.country_code}`}
                          value={formData[market.country_code]?.title || ''}
                          onChange={(e) => handleFieldChange(market.country_code, 'title', e.target.value)}
                          placeholder="Market-specific title"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`slug_${market.country_code}`}>URL Slug</Label>
                        <Input
                          id={`slug_${market.country_code}`}
                          value={formData[market.country_code]?.slug || ''}
                          onChange={(e) => handleFieldChange(market.country_code, 'slug', e.target.value)}
                          placeholder="market-url-slug"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`excerpt_${market.country_code}`}>Excerpt</Label>
                      <Textarea
                        id={`excerpt_${market.country_code}`}
                        value={formData[market.country_code]?.excerpt || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'excerpt', e.target.value)}
                        placeholder="Market-specific excerpt"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`content_${market.country_code}`}>Content</Label>
                      <QuillEditor
                        value={formData[market.country_code]?.content || ''}
                        onChange={(content) => handleFieldChange(market.country_code, 'content', content)}
                        placeholder="Write market-specific content..."
                      />
                    </div>
                  </div>
                  {/* Basic SEO */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                      Basic SEO
                    </h4>
                    
                    <div className="space-y-2">
                      <Label htmlFor={`seo_title_${market.country_code}`}>SEO Title</Label>
                      <Input
                        id={`seo_title_${market.country_code}`}
                        value={formData[market.country_code]?.seo_title || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'seo_title', e.target.value)}
                        placeholder="SEO-optimized title for this market"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`seo_description_${market.country_code}`}>SEO Description</Label>
                      <Textarea
                        id={`seo_description_${market.country_code}`}
                        value={formData[market.country_code]?.seo_description || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'seo_description', e.target.value)}
                        placeholder="Meta description for search results"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`seo_keywords_${market.country_code}`}>Keywords</Label>
                      <Input
                        id={`seo_keywords_${market.country_code}`}
                        value={formData[market.country_code]?.seo_keywords || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'seo_keywords', e.target.value)}
                        placeholder="keyword1, keyword2, keyword3"
                      />
                    </div>
                  </div>

                  {/* Open Graph */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                      Open Graph (Facebook)
                    </h4>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`og_title_${market.country_code}`}>OG Title</Label>
                        <Input
                          id={`og_title_${market.country_code}`}
                          value={formData[market.country_code]?.og_title || ''}
                          onChange={(e) => handleFieldChange(market.country_code, 'og_title', e.target.value)}
                          placeholder="Facebook share title"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`og_image_url_${market.country_code}`}>OG Image URL</Label>
                        <Input
                          id={`og_image_url_${market.country_code}`}
                          value={formData[market.country_code]?.og_image_url || ''}
                          onChange={(e) => handleFieldChange(market.country_code, 'og_image_url', e.target.value)}
                          placeholder="https://..."
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`og_description_${market.country_code}`}>OG Description</Label>
                      <Textarea
                        id={`og_description_${market.country_code}`}
                        value={formData[market.country_code]?.og_description || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'og_description', e.target.value)}
                        placeholder="Facebook share description"
                        rows={2}
                      />
                    </div>
                  </div>

                  {/* Twitter */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                      Twitter
                    </h4>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`twitter_title_${market.country_code}`}>Twitter Title</Label>
                        <Input
                          id={`twitter_title_${market.country_code}`}
                          value={formData[market.country_code]?.twitter_title || ''}
                          onChange={(e) => handleFieldChange(market.country_code, 'twitter_title', e.target.value)}
                          placeholder="Twitter share title"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor={`twitter_image_url_${market.country_code}`}>Twitter Image URL</Label>
                        <Input
                          id={`twitter_image_url_${market.country_code}`}
                          value={formData[market.country_code]?.twitter_image_url || ''}
                          onChange={(e) => handleFieldChange(market.country_code, 'twitter_image_url', e.target.value)}
                          placeholder="https://..."
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`twitter_description_${market.country_code}`}>Twitter Description</Label>
                      <Textarea
                        id={`twitter_description_${market.country_code}`}
                        value={formData[market.country_code]?.twitter_description || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'twitter_description', e.target.value)}
                        placeholder="Twitter share description"
                        rows={2}
                      />
                    </div>
                  </div>

                  {/* Additional */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                      Additional
                    </h4>
                    
                    <div className="space-y-2">
                      <Label htmlFor={`canonical_url_${market.country_code}`}>Canonical URL</Label>
                      <Input
                        id={`canonical_url_${market.country_code}`}
                        value={formData[market.country_code]?.canonical_url || ''}
                        onChange={(e) => handleFieldChange(market.country_code, 'canonical_url', e.target.value)}
                        placeholder="https://..."
                      />
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};