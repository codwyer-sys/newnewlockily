
import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Clock, Calendar } from "lucide-react";

interface TimingSelectorProps {
  timing: string;
  selectedDate: string;
  onTimingSelect: (timing: string) => void;
  onDateChange: (date: string) => void;
  showTiming: boolean;
}

const TimingSelector: React.FC<TimingSelectorProps> = ({
  timing,
  selectedDate,
  onTimingSelect,
  onDateChange,
  showTiming
}) => {
  if (!showTiming) return null;

  const handleTimingClick = (selectedTiming: string) => {
    onTimingSelect(selectedTiming);
    if (selectedTiming === "asap") {
      onDateChange("");
    }
  };

  return (
    <div className="space-y-4 animate-in slide-in-from-bottom-4 duration-300">
      <div className="flex items-center gap-2">
        <span className="bg-cyan-500 text-black rounded-full w-8 h-8 flex items-center justify-center font-bold text-lg">3</span>
        <Label className="text-xl font-semibold text-white">
          Hvornår har du brug for hjælp?
        </Label>
      </div>
      <div className="grid grid-cols-1 gap-4">
        <Button
          type="button"
          variant={timing === "asap" ? "default" : "outline"}
          onClick={() => handleTimingClick("asap")}
          className={`h-20 flex items-center justify-start gap-4 text-lg border-2 p-6 ${
            timing === "asap" 
              ? "bg-cyan-500 text-black border-cyan-500 hover:bg-cyan-600" 
              : "border-slate-600 bg-slate-800 text-white hover:border-cyan-500 hover:bg-slate-700"
          }`}
        >
          <Clock className="w-8 h-8 text-red-500" />
          <div className="text-left">
            <div className="font-bold text-xl">Så hurtigt som muligt</div>
            <div className="text-sm opacity-75">Inden for 1-2 timer</div>
          </div>
        </Button>
        
        <Button
          type="button"
          variant={timing === "scheduled" ? "default" : "outline"}
          onClick={() => handleTimingClick("scheduled")}
          className={`h-20 flex items-center justify-start gap-4 text-lg border-2 p-6 ${
            timing === "scheduled" 
              ? "bg-cyan-500 text-black border-cyan-500 hover:bg-cyan-600" 
              : "border-slate-600 bg-slate-800 text-white hover:border-cyan-500 hover:bg-slate-700"
          }`}
        >
          <Calendar className="w-8 h-8" />
          <div className="text-left">
            <div className="font-bold text-xl">Vælg tidspunkt</div>
            <div className="text-sm opacity-75">Book til senere</div>
          </div>
        </Button>
      </div>

      {/* Date/Time Picker - Shows when "scheduled" is selected */}
      {timing === "scheduled" && (
        <div className="space-y-2 animate-in slide-in-from-bottom-4 duration-300">
          <Label htmlFor="datetime" className="text-base font-medium text-slate-300">
            Hvornår passer det dig?
          </Label>
          <Input
            id="datetime"
            type="datetime-local"
            value={selectedDate}
            onChange={(e) => onDateChange(e.target.value)}
            min={new Date().toISOString().slice(0, 16)}
            className="h-14 text-base border-2 border-slate-600 bg-slate-800 text-white focus:border-cyan-500"
          />
        </div>
      )}
    </div>
  );
};

export default TimingSelector;
