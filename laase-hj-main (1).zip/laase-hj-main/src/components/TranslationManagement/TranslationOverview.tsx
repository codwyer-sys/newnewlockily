import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Languages, FileText, AlertTriangle, TrendingUp, Clock } from 'lucide-react';
import { useTranslationManagement } from '@/hooks/useTranslationManagement';
import { getCountryFlag } from '@/utils/countryFlags';
import { formatDistance, parseISO } from 'date-fns';

export const TranslationOverview: React.FC = () => {
  const { stats, loading, markets } = useTranslationManagement();

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-muted rounded w-1/2 mb-2"></div>
                <div className="h-8 bg-muted rounded w-3/4"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Translations</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalTranslations.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Across all markets and languages
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Missing Translations</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{stats.missingCount}</div>
            <p className="text-xs text-muted-foreground">
              Need immediate attention
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Languages</CardTitle>
            <Languages className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Object.keys(stats.completionByLanguage).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Active languages
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Markets</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Object.keys(stats.completionByMarket).length}
            </div>
            <p className="text-xs text-muted-foreground">
              Active markets
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Completion by Market */}
        <Card>
          <CardHeader>
            <CardTitle>Translation Completion by Market</CardTitle>
            <CardDescription>
              Percentage of translations completed for each market
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(stats.completionByMarket).map(([marketCode, completion]) => {
                const market = markets.find(m => m.country_code === marketCode);
                return (
                  <div key={marketCode} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span>{getCountryFlag(marketCode)}</span>
                        <span className="font-medium">
                          {market?.country_name || marketCode.toUpperCase()}
                        </span>
                      </div>
                      <Badge variant={completion >= 90 ? 'default' : completion >= 70 ? 'secondary' : 'destructive'}>
                        {completion}%
                      </Badge>
                    </div>
                    <Progress value={completion} className="h-2" />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Completion by Language */}
        <Card>
          <CardHeader>
            <CardTitle>Translation Completion by Language</CardTitle>
            <CardDescription>
              Percentage of translations completed for each language
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(stats.completionByLanguage).map(([langCode, completion]) => (
                <div key={langCode} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{langCode === 'da' ? '🇩🇰' : '🇬🇧'}</span>
                      <span className="font-medium">
                        {langCode === 'da' ? 'Danish' : 'English'}
                      </span>
                    </div>
                    <Badge variant={completion >= 90 ? 'default' : completion >= 70 ? 'secondary' : 'destructive'}>
                      {completion}%
                    </Badge>
                  </div>
                  <Progress value={completion} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recently Updated Translations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Recently Updated Translations
          </CardTitle>
          <CardDescription>
            Latest translation updates across all markets
          </CardDescription>
        </CardHeader>
        <CardContent>
          {stats.recentlyUpdated.length > 0 ? (
            <div className="space-y-4">
              {stats.recentlyUpdated.map((translation) => (
                <div key={translation.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{translation.content_key}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {translation.section.page.page_name} → {translation.section.section_name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <span>{translation.language_code === 'da' ? '🇩🇰' : '🇬🇧'}</span>
                      <span>{getCountryFlag(translation.market_code || 'DK')}</span>
                      <span className="text-muted-foreground">
                        {translation.market_code || 'Global'}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground">
                      {formatDistance(parseISO(translation.updated_at), new Date(), { addSuffix: true })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No recent translation updates</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};