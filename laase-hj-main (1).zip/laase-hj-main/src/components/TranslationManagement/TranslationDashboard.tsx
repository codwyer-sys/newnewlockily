import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Languages, FileText, AlertCircle, Download, Upload, Eye, Settings, Edit2 } from 'lucide-react';
import { TranslationOverview } from './TranslationOverview';
import { BulkTranslationEditor } from './BulkTranslationEditor';
import { EnglishEditor } from './EnglishEditor';
import { MissingTranslationsDetector } from './MissingTranslationsDetector';
import { TranslationImportExport } from './TranslationImportExport';
import { AISettings } from './AISettings';

const TranslationDashboard: React.FC = () => {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Translation Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage translations across all markets and languages
          </p>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Languages className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="editor" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Market Editor
          </TabsTrigger>
          <TabsTrigger value="english-editor" className="flex items-center gap-2">
            <Edit2 className="h-4 w-4" />
            English Editor
          </TabsTrigger>
          <TabsTrigger value="ai-settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            AI Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <TranslationOverview />
        </TabsContent>

        <TabsContent value="editor" className="mt-6">
          <BulkTranslationEditor />
        </TabsContent>

        <TabsContent value="english-editor" className="mt-6">
          <EnglishEditor />
        </TabsContent>

        <TabsContent value="ai-settings" className="mt-6">
          <AISettings />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TranslationDashboard;