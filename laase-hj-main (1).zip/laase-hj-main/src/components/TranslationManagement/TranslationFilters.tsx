import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Filter } from 'lucide-react';
import { TranslationFilters as TFilters } from '@/hooks/useTranslationSelection';

interface TranslationFiltersProps {
  filters: TFilters;
  setFilters: (filters: TFilters) => void;
  pages: string[];
  sections: string[];
  totalCount: number;
  filteredCount: number;
  selectedCount: number;
}

export const TranslationFilters: React.FC<TranslationFiltersProps> = ({
  filters,
  setFilters,
  pages,
  sections,
  totalCount,
  filteredCount,
  selectedCount
}) => {
  const clearFilters = () => {
    setFilters({
      page: '',
      section: '',
      status: 'all',
      search: ''
    });
  };

  const hasActiveFilters = filters.page || filters.section || filters.status !== 'all' || filters.search;

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          {/* Search */}
          <div>
            <Label htmlFor="search" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              Search Content
            </Label>
            <Input
              id="search"
              placeholder="Search by content key, text, page, or section..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
            />
          </div>

          {/* Filters Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Page Filter */}
            <div>
              <Label className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Page
              </Label>
              <Select
                value={filters.page || "all"}
                onValueChange={(value) => setFilters({ ...filters, page: value === "all" ? "" : value, section: '' })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All pages" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All pages</SelectItem>
                  {pages.map((page) => (
                    <SelectItem key={page} value={page}>
                      {page}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Section Filter */}
            <div>
              <Label>Section</Label>
              <Select
                value={filters.section || "all"}
                onValueChange={(value) => setFilters({ ...filters, section: value === "all" ? "" : value })}
                disabled={!filters.page}
              >
                <SelectTrigger>
                  <SelectValue placeholder={filters.page ? "All sections" : "Select page first"} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All sections</SelectItem>
                  {sections.map((section) => (
                    <SelectItem key={section} value={section}>
                      {section}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Status Filter */}
            <div>
              <Label>Translation Status</Label>
              <Select
                value={filters.status}
                onValueChange={(value: any) => setFilters({ ...filters, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All items</SelectItem>
                  <SelectItem value="missing">Missing translations</SelectItem>
                  <SelectItem value="complete">Fully translated</SelectItem>
                  <SelectItem value="changed">Recently changed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Clear Filters */}
            <div className="flex items-end">
              <Button
                variant="outline"
                onClick={clearFilters}
                disabled={!hasActiveFilters}
                className="w-full"
              >
                Clear Filters
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="flex gap-4 text-sm text-muted-foreground">
            <Badge variant="secondary">
              Total: {totalCount}
            </Badge>
            <Badge variant="secondary">
              Filtered: {filteredCount}
            </Badge>
            {selectedCount > 0 && (
              <Badge variant="default">
                Selected: {selectedCount}
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};