import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Sparkles, Loader2, Copy, Check } from 'lucide-react';
import { useAITranslation } from '@/hooks/useAITranslation';
import { getCountryFlag } from '@/utils/countryFlags';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { toast } from 'sonner';

interface Translation {
  id: string;
  content_key: string;
  content_value: string;
  language_code: string;
  market_code: string | null;
  ai_instruction: string | null;
  section: {
    section_name: string;
    page: {
      page_name: string;
    };
  };
}

interface IndividualAITranslateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  translation: Translation;
  sourceTranslation: Translation;
  onTranslationGenerated: (translatedText: string, instruction: string) => void;
}

export const IndividualAITranslateDialog: React.FC<IndividualAITranslateDialogProps> = ({
  open,
  onOpenChange,
  translation,
  sourceTranslation,
  onTranslationGenerated
}) => {
  const { translateText, isTranslating } = useAITranslation();
  const [customInstruction, setCustomInstruction] = useState(translation.ai_instruction || '');
  const [translatedText, setTranslatedText] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleTranslate = async () => {
    if (!sourceTranslation.content_value.trim()) {
      toast.error('No source text available for translation');
      return;
    }

    try {
      const result = await translateText({
        originalText: sourceTranslation.content_value,
        targetLanguage: translation.language_code,
        market: translation.market_code,
        pageName: translation.section.page.page_name,
        sectionName: translation.section.section_name,
        contentKey: translation.content_key,
        customInstruction: customInstruction || undefined
      });

      if (result) {
        setTranslatedText(result);
        setShowPreview(true);
      }
    } catch (error) {
      // Error handling in useAITranslation hook
    }
  };

  const handleApply = () => {
    onTranslationGenerated(translatedText, customInstruction);
    onOpenChange(false);
    setShowPreview(false);
    setTranslatedText('');
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(translatedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast.success('Translation copied to clipboard');
    } catch (error) {
      toast.error('Failed to copy translation');
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setShowPreview(false);
    setTranslatedText('');
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-500" />
            AI Translate
          </DialogTitle>
          <DialogDescription>
            Generate an AI translation for this specific content
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Translation Context */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Badge variant="outline">{translation.content_key}</Badge>
              <span className="text-sm text-muted-foreground">
                {translation.section.page.page_name} → {translation.section.section_name}
              </span>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <CountryFlag code="GB" size="sm" />
                <span className="text-sm font-medium">EN - Source</span>
              </div>
              <span className="text-sm text-muted-foreground">→</span>
              <div className="flex items-center gap-1">
                <CountryFlag code={translation.language_code === 'da' ? 'DK' : 'GB'} size="sm" />
                <span>{getCountryFlag(translation.market_code || 'DK')}</span>
                <span className="text-sm font-medium">
                  {translation.language_code.toUpperCase()} - {translation.market_code || 'Global'}
                </span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Source Text */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Source Text (English)</label>
            <div className="p-3 bg-muted/30 rounded-md border">
              <p className="text-sm">{sourceTranslation.content_value}</p>
            </div>
          </div>

          {/* AI Instructions */}
          <div className="space-y-2">
            <label className="text-sm font-medium">AI Translation Instructions</label>
            <Input
              value={customInstruction}
              onChange={(e) => setCustomInstruction(e.target.value)}
              placeholder="e.g., 'Keep urgent tone', 'Use formal language', 'Emphasize security'..."
            />
            <p className="text-xs text-muted-foreground">
              Optional: Provide specific instructions for tone, style, or emphasis
            </p>
          </div>

          {/* Current Translation */}
          {translation.content_value && (
            <div className="space-y-2">
              <label className="text-sm font-medium">Current Translation</label>
              <div className="p-3 bg-muted/20 rounded-md border">
                <p className="text-sm">{translation.content_value}</p>
              </div>
            </div>
          )}

          {/* Preview Section */}
          {showPreview && (
            <>
              <Separator />
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-green-700">AI Generated Translation</label>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCopy}
                    className="text-xs"
                  >
                    {copied ? (
                      <Check className="h-3 w-3 mr-1" />
                    ) : (
                      <Copy className="h-3 w-3 mr-1" />
                    )}
                    {copied ? 'Copied!' : 'Copy'}
                  </Button>
                </div>
                <Textarea
                  value={translatedText}
                  onChange={(e) => setTranslatedText(e.target.value)}
                  rows={4}
                  className="resize-none border-green-200 bg-green-50/30"
                />
                <p className="text-xs text-muted-foreground">
                  You can edit the translation above before applying it
                </p>
              </div>
            </>
          )}

          {/* Actions */}
          <div className="flex items-center justify-between pt-4">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            
            <div className="flex items-center gap-2">
              {!showPreview ? (
                <Button 
                  onClick={handleTranslate} 
                  disabled={isTranslating || !sourceTranslation.content_value.trim()}
                  className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                >
                  {isTranslating ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4 mr-2" />
                  )}
                  {isTranslating ? 'Translating...' : 'Generate Translation'}
                </Button>
              ) : (
                <>
                  <Button variant="outline" onClick={() => setShowPreview(false)}>
                    Back to Edit
                  </Button>
                  <Button onClick={handleApply}>
                    Apply Translation
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};