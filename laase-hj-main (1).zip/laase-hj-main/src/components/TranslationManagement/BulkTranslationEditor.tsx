import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Search, Save, Filter, Edit3, Globe, FileText, Sparkles, Loader2 } from 'lucide-react';
import { useTranslationManagement } from '@/hooks/useTranslationManagement';
import { useAITranslation } from '@/hooks/useAITranslation';
import { IndividualAITranslateDialog } from './IndividualAITranslateDialog';
import { getCountryFlag } from '@/utils/countryFlags';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface EditingTranslations {
  [key: string]: {
    value: string;
    notes?: string;
    ai_instruction?: string;
    isDirty: boolean;
  };
}

export const BulkTranslationEditor: React.FC = () => {
  const { translations, markets, loading, updateTranslation, bulkUpdateTranslations, refetch } = useTranslationManagement();
  const { translateText, isTranslating } = useAITranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMarket, setSelectedMarket] = useState<string>('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [selectedPage, setSelectedPage] = useState<string>('all');
  const [editingTranslations, setEditingTranslations] = useState<EditingTranslations>({});
  const [saving, setSaving] = useState(false);
  const [individualAIDialogOpen, setIndividualAIDialogOpen] = useState(false);
  const [selectedTranslation, setSelectedTranslation] = useState<any>(null);
  const [selectedSourceTranslation, setSelectedSourceTranslation] = useState<any>(null);
  const [showAIInstructions, setShowAIInstructions] = useState<Set<string>>(new Set());
  const [marketLanguages, setMarketLanguages] = useState<Array<{market_code: string, language_code: string, is_primary: boolean, is_enabled: boolean}>>([]);

  // Fetch market language access mappings
  useEffect(() => {
    const fetchMarketLanguages = async () => {
      try {
        const { data, error } = await supabase
          .from('market_language_access')
          .select('*')
          .eq('is_enabled', true)
          .order('market_code')
          .order('is_primary', { ascending: false });
        
        if (error) throw error;
        setMarketLanguages(data || []);
      } catch (error) {
        console.error('Error fetching market languages:', error);
      }
    };

    fetchMarketLanguages();
  }, []);

  // Set default market to first available market
  useEffect(() => {
    if (!selectedMarket && markets.length > 0) {
      setSelectedMarket(markets[0].country_code);
    }
  }, [markets, selectedMarket]);

  // Get available languages for the selected market only
  const getAvailableLanguages = useMemo(() => {
    if (!selectedMarket) return [];
    
    // Return languages for specific market
    return marketLanguages
      .filter(ml => ml.market_code === selectedMarket && ml.is_enabled)
      .map(ml => ml.language_code);
  }, [selectedMarket, marketLanguages]);

  // Get language name mapping
  const getLanguageName = (code: string) => {
    const names: Record<string, string> = {
      'en': 'English',
      'da': 'Danish', 
      'de': 'German',
      'fr': 'French',
      'es': 'Spanish',
      'sv': 'Swedish',
      'no': 'Norwegian',
      'ga': 'Irish'
    };
    return names[code] || code.toUpperCase();
  };

  // Get appropriate flag for language
  const getLanguageFlag = (languageCode: string, marketCode: string | null) => {
    const flagMap: Record<string, string> = {
      'en': marketCode === 'US' ? 'US' : 'GB',
      'da': 'DK',
      'de': 'DE',
      'fr': 'FR',
      'es': 'ES',
      'sv': 'SE',
      'no': 'NO',
      'ga': 'IE'
    };
    return flagMap[languageCode] || 'GB';
  };

  // Get unique pages for filter
  const pages = useMemo(() => {
    const uniquePages = new Set(translations.map(t => t.section.page.page_name));
    return Array.from(uniquePages).sort();
  }, [translations]);

  // Simplified filtering logic for single market operation
  const filteredTranslations = useMemo(() => {
    if (!selectedMarket) return [];

    // Get all unique translation keys from source (English) content
    const englishTranslations = translations.filter(t => t.language_code === 'en' && t.market_code === null);
    const uniqueKeys = Array.from(new Set(
      englishTranslations.map(t => `${t.section.page.page_name}:${t.section.section_name}:${t.content_key}`)
    ));

    const virtualTranslations: typeof translations = [];

    uniqueKeys.forEach(key => {
      const [pageName, sectionName, contentKey] = key.split(':');
      
      // Skip if page filter doesn't match
      if (selectedPage !== 'all' && pageName !== selectedPage) return;
      
      // Find the English source translation
      const englishSource = englishTranslations.find(t => 
        `${t.section.page.page_name}:${t.section.section_name}:${t.content_key}` === key
      );
      
      if (!englishSource) return;

      // Always include the English source
      virtualTranslations.push(englishSource);

      // Get target languages for the selected market
      const targetLanguages = getAvailableLanguages.filter(lang => 
        selectedLanguage === 'all' || lang === selectedLanguage
      );

      // Create target translations for each language in the selected market
      targetLanguages.forEach(language => {
        if (language === 'en') return; // Skip English as it's already added as source

        // Check if translation already exists
        const existing = translations.find(t => 
          t.market_code === selectedMarket &&
          t.language_code === language &&
          t.content_key === contentKey &&
          t.section_id === englishSource.section_id
        );

        if (existing) {
          virtualTranslations.push(existing);
        } else {
          // Create virtual target translation
          virtualTranslations.push({
            id: `virtual-${selectedMarket}-${language}-${contentKey}-${Date.now()}`,
            section_id: englishSource.section_id,
            language_code: language,
            content_key: contentKey,
            content_value: '',
            content_type: 'text',
            market_code: selectedMarket,
            updated_at: new Date().toISOString(),
            updated_by: null,
            notes: null,
            ai_instruction: null,
            section: englishSource.section,
            isVirtual: true
          } as any);
        }
      });
    });

    // Apply search filter
    return virtualTranslations.filter(translation => {
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        return (
          translation.content_key.toLowerCase().includes(searchLower) ||
          translation.content_value.toLowerCase().includes(searchLower) ||
          translation.section.section_name.toLowerCase().includes(searchLower) ||
          translation.section.page.page_name.toLowerCase().includes(searchLower)
        );
      }
      return true;
    });
  }, [translations, searchTerm, selectedMarket, selectedLanguage, selectedPage, getAvailableLanguages]);

  // Group translations by content key for matrix view
  const groupedTranslations = useMemo(() => {
    const groups: Record<string, typeof translations> = {};
    
    filteredTranslations.forEach(translation => {
      const key = `${translation.section.page.page_name}:${translation.section.section_name}:${translation.content_key}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(translation);
    });

    return groups;
  }, [filteredTranslations]);

  const handleTranslationChange = (translationId: string, field: 'value' | 'notes' | 'ai_instruction', newValue: string) => {
    setEditingTranslations(prev => ({
      ...prev,
      [translationId]: {
        ...prev[translationId],
        [field]: newValue,
        isDirty: true
      }
    }));
  };

  const getTranslationValue = (translationId: string, field: 'value' | 'notes' | 'ai_instruction', originalValue: string) => {
    const editing = editingTranslations[translationId];
    if (editing && editing.isDirty) {
      return editing[field] || originalValue;
    }
    return originalValue;
  };

  const saveTranslation = async (translationId: string) => {
    const editing = editingTranslations[translationId];
    if (!editing || !editing.isDirty) return;

    setSaving(true);
    try {
      // Check if this is a virtual translation that needs to be created
      if (translationId.startsWith('virtual-')) {
        const translation = filteredTranslations.find(t => t.id === translationId);
        if (!translation) {
          console.error('Translation not found for ID:', translationId);
          toast.error('Translation not found');
          return;
        }

        // Validate required fields
        if (!translation.section_id || !translation.language_code || !translation.content_key) {
          console.error('Missing required fields for translation:', {
            section_id: translation.section_id,
            language_code: translation.language_code,
            content_key: translation.content_key,
            market_code: translation.market_code
          });
          toast.error('Missing required translation data');
          return;
        }

        // Validate language code is in allowed list
        const validLanguages = getAvailableLanguages;
        if (!validLanguages.includes(translation.language_code)) {
          console.error('Invalid language code:', translation.language_code, 'Valid languages:', validLanguages);
          toast.error(`Invalid language code: ${translation.language_code}`);
          return;
        }

        console.log('Creating new translation:', {
          section_id: translation.section_id,
          language_code: translation.language_code,
          content_key: translation.content_key,
          content_value: editing.value || '',
          content_type: translation.content_type,
          market_code: translation.market_code,
          notes: editing.notes || null,
          ai_instruction: editing.ai_instruction || null
        });

        // Create new translation
        const { error } = await supabase
          .from('content_translations')
          .insert({
            section_id: translation.section_id,
            language_code: translation.language_code,
            content_key: translation.content_key,
            content_value: editing.value || '',
            content_type: translation.content_type,
            market_code: translation.market_code,
            notes: editing.notes || null,
            ai_instruction: editing.ai_instruction || null
          });

        if (error) {
          console.error('Database error during insert:', error);
          throw error;
        }
        
        // Remove from editing state
        setEditingTranslations(prev => {
          const { [translationId]: _, ...rest } = prev;
          return rest;
        });
        
        // Refresh data
        await refetch();
        toast.success('Translation created successfully');
      } else {
        // Update existing translation
        console.log('Updating existing translation:', translationId, editing);
        await updateTranslation(translationId, editing.value || '', editing.notes, editing.ai_instruction);
        
        // Remove from editing state
        setEditingTranslations(prev => {
          const { [translationId]: _, ...rest } = prev;
          return rest;
        });
      }
    } catch (error) {
      console.error('Error saving translation:', error);
      
      // Provide specific error messages based on error type
      if (error && typeof error === 'object' && 'code' in error) {
        const dbError = error as any;
        if (dbError.code === '23514') {
          toast.error('Invalid language code - please check allowed languages for this market');
        } else if (dbError.code === '23505') {
          toast.error('Translation already exists for this content key');
        } else {
          toast.error(`Database error: ${dbError.message || 'Unknown error'}`);
        }
      } else {
        toast.error('Failed to save translation');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleIndividualAITranslate = (translation: any, sourceTranslation: any) => {
    if (!sourceTranslation?.content_value.trim()) {
      toast.error('No source text found to translate from');
      return;
    }
    
    setSelectedTranslation(translation);
    setSelectedSourceTranslation(sourceTranslation);
    setIndividualAIDialogOpen(true);
  };

  const handleIndividualTranslationGenerated = (translatedText: string, instruction: string) => {
    if (!selectedTranslation) return;
    
    setEditingTranslations(prev => ({
      ...prev,
      [selectedTranslation.id]: {
        ...prev[selectedTranslation.id],
        value: translatedText,
        notes: 'AI generated translation',
        ai_instruction: instruction,
        isDirty: true
      }
    }));
    
    toast.success('AI translation applied');
  };

  const handleBulkTranslationsGenerated = (updates: Array<{id: string, content_value: string, notes: string}>) => {
    updates.forEach(update => {
      setEditingTranslations(prev => ({
        ...prev,
        [update.id]: {
          ...prev[update.id],
          value: update.content_value,
          notes: update.notes,
          isDirty: true
        }
      }));
    });
    
    toast.success(`Applied ${updates.length} AI translations`);
  };

  const saveAllChanges = async () => {
    const edits = Object.entries(editingTranslations).filter(([_, edit]) => edit.isDirty);
    if (edits.length === 0) return;

    setSaving(true);
    try {
      // Separate virtual (new) translations from existing ones
      const newTranslations = [];
      const updateTranslations = [];

      for (const [translationId, editing] of edits) {
        if (translationId.startsWith('virtual-')) {
          const translation = filteredTranslations.find(t => t.id === translationId);
          if (translation) {
            newTranslations.push({
              section_id: translation.section_id,
              language_code: translation.language_code,
              content_key: translation.content_key,
              content_value: editing.value || '',
              content_type: translation.content_type,
              market_code: translation.market_code,
              notes: editing.notes || null,
              ai_instruction: editing.ai_instruction || null
            });
          }
        } else {
          updateTranslations.push({
            id: translationId,
            content_value: editing.value || '',
            notes: editing.notes,
            ai_instruction: editing.ai_instruction
          });
        }
      }

      // Create new translations
      if (newTranslations.length > 0) {
        console.log('Creating bulk translations:', newTranslations);
        
        // Validate all translations before insert
        for (const trans of newTranslations) {
          if (!trans.section_id || !trans.language_code || !trans.content_key) {
            throw new Error(`Invalid translation data: ${JSON.stringify(trans)}`);
          }
        }
        
        const { error: insertError } = await supabase
          .from('content_translations')
          .insert(newTranslations);
        
        if (insertError) {
          console.error('Bulk insert error:', insertError);
          throw insertError;
        }
      }

      // Update existing translations
      if (updateTranslations.length > 0) {
        await bulkUpdateTranslations(updateTranslations);
      }

      // Clear editing state and refresh
      setEditingTranslations({});
      await refetch();
      
      toast.success(`Saved ${edits.length} translations successfully`);
    } catch (error) {
      console.error('Error saving translations:', error);
      toast.error('Failed to save translations');
    } finally {
      setSaving(false);
    }
  };

  const dirtyCount = Object.values(editingTranslations).filter(e => e.isDirty).length;

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/4"></div>
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-16 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters and Actions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
               <CardTitle className="flex items-center gap-2">
                 <Edit3 className="h-5 w-5" />
                 Market Translation Editor
               </CardTitle>
               <CardDescription>
                 Edit translations for specific markets and languages
               </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {dirtyCount > 0 && (
                <Button onClick={saveAllChanges} disabled={saving}>
                  <Save className="h-4 w-4 mr-2" />
                  Save All Changes ({dirtyCount})
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search translations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Market Filter - Remove All Markets option */}
            <Select value={selectedMarket} onValueChange={setSelectedMarket}>
              <SelectTrigger>
                <SelectValue placeholder="Select Market" />
              </SelectTrigger>
              <SelectContent>
                {markets.map(market => (
                  <SelectItem key={market.country_code} value={market.country_code}>
                    <div className="flex items-center gap-2">
                      <CountryFlag code={market.country_code} size="sm" />
                      <span>{market.country_name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Language Filter */}
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger>
                <SelectValue placeholder="All Languages" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Languages</SelectItem>
                                {getAvailableLanguages.map(langCode => (
                  <SelectItem key={langCode} value={langCode}>
                    <div className="flex items-center gap-2">
                      <CountryFlag code={getLanguageFlag(langCode, selectedMarket)} size="sm" />
                      {getLanguageName(langCode)}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Page Filter */}
            <Select value={selectedPage} onValueChange={setSelectedPage}>
              <SelectTrigger>
                <SelectValue placeholder="All Pages" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Pages</SelectItem>
                {pages.map(page => (
                  <SelectItem key={page} value={page}>
                    {page}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Results Count */}
            <div className="flex items-center text-sm text-muted-foreground">
              <FileText className="h-4 w-4 mr-2" />
              {Object.keys(groupedTranslations).length} translation keys
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Translation Matrix */}
      <div className="space-y-4">
        {Object.entries(groupedTranslations).map(([groupKey, groupTranslations]) => {
          const [pageName, sectionName, contentKey] = groupKey.split(':');
          
          return (
            <Card key={groupKey}>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{contentKey}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {pageName} → {sectionName}
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Find and display source (English) translation first */}
                  {(() => {
                    const englishTranslation = groupTranslations.find(t => t.language_code === 'en');
                    const targetTranslations = groupTranslations.filter(t => t.language_code !== 'en');
                    
                    return (
                      <>
                        {/* Source Translation (English) */}
                        {englishTranslation && (
                          <div className="bg-muted/30 border-2 border-muted/50 rounded-lg p-4">
                            <div className="flex items-center gap-2 mb-3">
                              <CountryFlag code="GB" size="sm" />
                              <span className="text-sm font-medium text-muted-foreground">Source (English)</span>
                              <Badge variant="secondary" className="text-xs">Original</Badge>
                            </div>
                            <Textarea
                              value={englishTranslation.content_value}
                              readOnly
                              rows={3}
                              className="resize-none bg-background/50 text-muted-foreground cursor-default focus-visible:ring-0 focus-visible:ring-offset-0"
                            />
                          </div>
                        )}
                        
                        {/* Target Translations */}
                        {targetTranslations.map(translation => {
                          const currentValue = getTranslationValue(translation.id, 'value', translation.content_value);
                          const canAITranslate = englishTranslation?.content_value.trim();
                          const hasExistingTranslation = currentValue.trim().length > 0;
                          const showInstructions = showAIInstructions.has(translation.id) || translation.ai_instruction;
                          const isDirty = editingTranslations[translation.id]?.isDirty;
                          
                          return (
                            <div key={translation.id} className="border-2 border-border rounded-lg p-4 space-y-4 transition-all duration-200 hover:border-primary/20">
                              {/* Header */}
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <CountryFlag code={getLanguageFlag(translation.language_code, selectedMarket)} size="sm" />
                                  <span className="text-sm font-medium">
                                    {getLanguageName(translation.language_code)} ({selectedMarket})
                                  </span>
                                  {(translation as any).isVirtual && (
                                    <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                                      New
                                    </Badge>
                                  )}
                                  {isDirty && (
                                    <Badge variant="outline" className="text-xs bg-orange-50 text-orange-700 border-orange-200">
                                      Unsaved
                                    </Badge>
                                  )}
                                </div>
                                
                                {/* Action Buttons */}
                                <div className="flex items-center gap-2">
                                  {canAITranslate && (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        setShowAIInstructions(prev => new Set(prev).add(translation.id));
                                        handleIndividualAITranslate(translation, englishTranslation);
                                      }}
                                      disabled={isTranslating}
                                      className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 hover:from-purple-100 hover:to-blue-100 transition-all duration-200 hover:scale-105"
                                    >
                                      <Sparkles className="h-3 w-3 mr-1" />
                                      {hasExistingTranslation ? 'AI Re-translate' : 'AI Translate'}
                                    </Button>
                                  )}
                                  {isDirty && (
                                    <Button
                                      size="sm"
                                      onClick={() => saveTranslation(translation.id)}
                                      disabled={saving}
                                      className="transition-all duration-200 hover:scale-105"
                                    >
                                      <Save className="h-3 w-3 mr-1" />
                                      Save
                                    </Button>
                                  )}
                                </div>
                              </div>
                              
                              {/* AI Translation Instructions (conditionally shown) */}
                              {showInstructions && (
                                <div className="space-y-2 bg-purple-50/50 border border-purple-200 rounded-lg p-3 transition-all duration-300">
                                  <label className="text-xs font-medium text-purple-700 flex items-center gap-1">
                                    <Sparkles className="h-3 w-3" />
                                    AI Translation Instructions
                                  </label>
                                  <Input
                                    value={getTranslationValue(translation.id, 'ai_instruction', translation.ai_instruction || '')}
                                    onChange={(e) => handleTranslationChange(translation.id, 'ai_instruction', e.target.value)}
                                    placeholder="e.g., 'Keep urgent tone', 'Use formal language', 'Emphasize security'..."
                                    className="text-sm border-purple-200 focus:border-purple-400 focus:ring-purple-400/20 transition-all duration-200"
                                  />
                                </div>
                              )}
                              
                              {/* Translation Input */}
                              <div className="space-y-2">
                                <label className="text-sm font-medium text-foreground">Translation</label>
                                <Textarea
                                  value={currentValue}
                                  onChange={(e) => handleTranslationChange(translation.id, 'value', e.target.value)}
                                  placeholder="Enter translation..."
                                  rows={3}
                                  className="resize-none transition-all duration-200 focus:border-primary focus:ring-primary/20 hover:border-primary/50"
                                />
                              </div>
                              
                              {/* Notes Input */}
                              <div className="space-y-2">
                                <label className="text-sm font-medium text-muted-foreground">Notes</label>
                                <Input
                                  value={getTranslationValue(translation.id, 'notes', translation.notes || '')}
                                  onChange={(e) => handleTranslationChange(translation.id, 'notes', e.target.value)}
                                  placeholder="Notes (optional)..."
                                  className="text-sm transition-all duration-200 focus:border-primary focus:ring-primary/20 hover:border-primary/50"
                                />
                              </div>
                            </div>
                          );
                        })}
                      </>
                    );
                  })()}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {Object.keys(groupedTranslations).length === 0 && (
        <Card>
          <CardContent className="py-12">
            <div className="text-center text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No translations found</p>
              <p className="text-sm">
                Try adjusting your filters or search terms
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Individual AI Translate Dialog */}
      {selectedTranslation && selectedSourceTranslation && (
        <IndividualAITranslateDialog
          open={individualAIDialogOpen}
          onOpenChange={setIndividualAIDialogOpen}
          translation={selectedTranslation}
          sourceTranslation={selectedSourceTranslation}
          onTranslationGenerated={handleIndividualTranslationGenerated}
        />
      )}
    </div>
  );
};