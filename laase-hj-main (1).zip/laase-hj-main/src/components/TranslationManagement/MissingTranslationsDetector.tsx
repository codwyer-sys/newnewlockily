import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { AlertTriangle, Plus, RefreshCw, Filter, CheckCircle2 } from 'lucide-react';
import { useTranslationGaps } from '@/hooks/useTranslationGaps';
import { getCountryFlag } from '@/utils/countryFlags';
import { toast } from 'sonner';

export const MissingTranslationsDetector: React.FC = () => {
  const { analysis, loading, createMissingTranslations, refetch } = useTranslationGaps();
  const [selectedGaps, setSelectedGaps] = useState<Set<number>>(new Set());
  const [creating, setCreating] = useState(false);
  const [filter, setFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');

  const handleSelectGap = (index: number, checked: boolean) => {
    const newSelected = new Set(selectedGaps);
    if (checked) {
      newSelected.add(index);
    } else {
      newSelected.delete(index);
    }
    setSelectedGaps(newSelected);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedGaps(new Set(filteredGaps.map((_, index) => index)));
    } else {
      setSelectedGaps(new Set());
    }
  };

  const handleCreateSelected = async () => {
    const gapsToCreate = Array.from(selectedGaps).map(index => filteredGaps[index]);
    
    if (gapsToCreate.length === 0) {
      toast.info('No gaps selected');
      return;
    }

    setCreating(true);
    try {
      const count = await createMissingTranslations(gapsToCreate);
      toast.success(`Created ${count} missing translations`);
      setSelectedGaps(new Set());
    } catch (error) {
      toast.error('Failed to create missing translations');
    } finally {
      setCreating(false);
    }
  };

  const filteredGaps = filter === 'all' 
    ? analysis.allGaps 
    : analysis.allGaps.filter(gap => gap.priority === filter);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return '🔴';
      case 'medium': return '🟡';  
      case 'low': return '🟢';
      default: return '⚪';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/4"></div>
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-16 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Gaps</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{analysis.totalGaps}</div>
            <p className="text-xs text-muted-foreground">
              Missing translations detected
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Gaps</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{analysis.criticalGaps.length}</div>
            <p className="text-xs text-muted-foreground">
              High priority missing translations
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Markets Affected</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.keys(analysis.gapsByMarket).length}</div>
            <p className="text-xs text-muted-foreground">
              Markets with missing translations
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Languages Affected</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.keys(analysis.gapsByLanguage).length}</div>
            <p className="text-xs text-muted-foreground">
              Languages with missing translations
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Gaps by Market */}
      {Object.keys(analysis.gapsByMarket).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Missing Translations by Market</CardTitle>
            <CardDescription>
              Number of missing translations per market
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(analysis.gapsByMarket).map(([market, count]) => (
                <div key={market} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span>{getCountryFlag(market)}</span>
                    <span className="font-medium">{market.toUpperCase()}</span>
                  </div>
                  <Badge variant="destructive">{count} missing</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Missing Translations List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Missing Translations Details
              </CardTitle>
              <CardDescription>
                Detailed view of all missing translations
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={refetch}
                disabled={loading}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              {selectedGaps.size > 0 && (
                <Button
                  onClick={handleCreateSelected}
                  disabled={creating}
                  size="sm"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Selected ({selectedGaps.size})
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filter Buttons */}
          <div className="flex items-center gap-2 mb-6">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All ({analysis.allGaps.length})
            </Button>
            <Button
              variant={filter === 'high' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('high')}
            >
              🔴 High ({analysis.allGaps.filter(g => g.priority === 'high').length})
            </Button>
            <Button
              variant={filter === 'medium' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('medium')}
            >
              🟡 Medium ({analysis.allGaps.filter(g => g.priority === 'medium').length})
            </Button>
            <Button
              variant={filter === 'low' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('low')}
            >
              🟢 Low ({analysis.allGaps.filter(g => g.priority === 'low').length})
            </Button>
          </div>

          {filteredGaps.length > 0 ? (
            <>
              {/* Select All */}
              <div className="flex items-center space-x-2 mb-4 p-3 bg-muted rounded-lg">
                <Checkbox
                  id="select-all"
                  checked={selectedGaps.size === filteredGaps.length}
                  onCheckedChange={handleSelectAll}
                />
                <label htmlFor="select-all" className="text-sm font-medium cursor-pointer">
                  Select all visible gaps ({filteredGaps.length})
                </label>
              </div>

              {/* Gaps List */}
              <div className="space-y-4">
                {filteredGaps.map((gap, index) => (
                  <div key={`${gap.sectionId}-${gap.contentKey}`} className="flex items-start space-x-3 p-4 border rounded-lg">
                    <Checkbox
                      checked={selectedGaps.has(index)}
                      onCheckedChange={(checked) => handleSelectGap(index, checked as boolean)}
                    />
                    
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span>{getPriorityIcon(gap.priority)}</span>
                          <Badge variant={getPriorityColor(gap.priority) as any}>
                            {gap.priority.toUpperCase()}
                          </Badge>
                          <Badge variant="outline">{gap.contentKey}</Badge>
                        </div>
                      </div>
                      
                      <div className="text-sm text-muted-foreground">
                        <span className="font-medium">{gap.pageName}</span> → <span>{gap.sectionName}</span>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm">
                        {gap.missingLanguages.length > 0 && (
                          <div className="flex items-center gap-1">
                            <span className="text-muted-foreground">Missing languages:</span>
                            {gap.missingLanguages.map(lang => (
                              <Badge key={lang} variant="outline" className="text-xs">
                                {lang === 'da' ? '🇩🇰 DA' : '🇬🇧 EN'}
                              </Badge>
                            ))}
                          </div>
                        )}
                        
                        {gap.missingMarkets.length > 0 && (
                          <div className="flex items-center gap-1">
                            <span className="text-muted-foreground">Missing markets:</span>
                            {gap.missingMarkets.map(market => (
                              <Badge key={market} variant="outline" className="text-xs">
                                {getCountryFlag(market)} {market}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          ) : analysis.totalGaps === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-4 text-green-500" />
              <p className="text-lg font-medium">No Missing Translations Found!</p>
              <p className="text-sm">
                All translations are complete across all markets and languages.
              </p>
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No gaps match the current filter</p>
              <p className="text-sm">
                Try selecting a different priority level
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};