import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Sparkles, Globe, CheckCircle } from 'lucide-react';
import { useAITranslation } from '@/hooks/useAITranslation';
import { getCountryFlag } from '@/utils/countryFlags';
import { CountryFlag } from '@/components/ui/CountryFlag';
import { toast } from 'sonner';

interface Translation {
  id: string;
  language_code: string;
  market_code: string | null;
  content_value: string;
  section: {
    page: { page_name: string };
    section_name: string;
  };
  content_key: string;
}

interface BulkAITranslateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  translations: Translation[];
  markets: Array<{country_code: string, country_name: string}>;
  onTranslationsGenerated: (updates: Array<{id: string, content_value: string, notes: string}>) => void;
}

export const BulkAITranslateDialog: React.FC<BulkAITranslateDialogProps> = ({
  open,
  onOpenChange,
  translations,
  markets,
  onTranslationsGenerated
}) => {
  const { translateText, isTranslating } = useAITranslation();
  const [selectedMarkets, setSelectedMarkets] = useState<string[]>([]);
  const [customPrompt, setCustomPrompt] = useState('');
  const [globalInstruction, setGlobalInstruction] = useState('');
  const [sourceTranslation, setSourceTranslation] = useState<Translation | null>(null);
  const [targetTranslations, setTargetTranslations] = useState<Translation[]>([]);
  const [generatedTranslations, setGeneratedTranslations] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);

  // Find the first English translation as source
  useEffect(() => {
    if (translations.length > 0) {
      const englishTranslation = translations.find(t => t.language_code === 'en');
      setSourceTranslation(englishTranslation || translations[0]);
    }
  }, [translations]);

  // Update target translations when markets change
  useEffect(() => {
    if (sourceTranslation) {
      const targets = selectedMarkets.map(marketCode => {
        // Try to find existing translation for this market
        const existingTranslation = translations.find(t => 
          t.language_code !== 'en' && 
          (t.market_code || 'global') === marketCode &&
          t.content_key === sourceTranslation.content_key &&
          t.section.section_name === sourceTranslation.section.section_name &&
          t.section.page.page_name === sourceTranslation.section.page.page_name
        );
        
        if (existingTranslation) {
          return existingTranslation;
        }
        
        // Create placeholder for markets without existing translations
        return {
          id: `placeholder-${marketCode}-${sourceTranslation.content_key}`,
          language_code: marketCode === 'DK' ? 'da' : 'en',
          market_code: marketCode === 'global' ? null : marketCode,
          content_value: '',
          section: sourceTranslation.section,
          content_key: sourceTranslation.content_key
        } as Translation;
      });
      setTargetTranslations(targets);
    }
  }, [selectedMarkets, translations, sourceTranslation]);

  // Set default prompt based on source translation
  useEffect(() => {
    if (sourceTranslation && !customPrompt) {
      const defaultPrompt = `Translate the following text for Lockily, a professional locksmith booking platform:

"${sourceTranslation.content_value}"

Context: ${sourceTranslation.section.page.page_name} → ${sourceTranslation.section.section_name} → ${sourceTranslation.content_key}

Keep the translation professional, clear, and appropriate for the locksmith service industry.`;
      
      setCustomPrompt(defaultPrompt);
    }
  }, [sourceTranslation, customPrompt]);

  const handleMarketToggle = (marketCode: string) => {
    setSelectedMarkets(prev => 
      prev.includes(marketCode) 
        ? prev.filter(m => m !== marketCode)
        : [...prev, marketCode]
    );
  };

  const generateTranslations = async () => {
    if (!sourceTranslation || targetTranslations.length === 0) {
      toast.error('Please select at least one market to translate to');
      return;
    }

    setIsGenerating(true);
    const newGeneratedTranslations: Record<string, string> = {};

    try {
      for (const target of targetTranslations) {
        const translatedText = await translateText({
          originalText: sourceTranslation.content_value,
          targetLanguage: target.language_code,
          market: target.market_code,
          pageName: target.section.page.page_name,
          sectionName: target.section.section_name,
          contentKey: target.content_key,
          context: customPrompt,
          customInstruction: globalInstruction || undefined
        });

        if (translatedText) {
          newGeneratedTranslations[target.id] = translatedText;
        }
      }

      setGeneratedTranslations(newGeneratedTranslations);
      toast.success(`Generated ${Object.keys(newGeneratedTranslations).length} translations`);
    } catch (error) {
      toast.error('Failed to generate some translations');
    } finally {
      setIsGenerating(false);
    }
  };

  const applyTranslations = () => {
    // Filter out placeholder IDs and only apply to existing translation records
    const updates = Object.entries(generatedTranslations)
      .filter(([id]) => !id.startsWith('placeholder-'))
      .map(([id, content_value]) => ({
        id,
        content_value,
        notes: 'Bulk AI generated translation'
      }));

    onTranslationsGenerated(updates);
    onOpenChange(false);
    
    // Reset state
    setGeneratedTranslations({});
    setSelectedMarkets([]);
    setCustomPrompt('');
    setGlobalInstruction('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Bulk AI Translation
          </DialogTitle>
          <DialogDescription>
            Generate translations for multiple markets using AI. Customize the prompt and select target markets.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Source Translation */}
          {sourceTranslation && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Source Translation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <CountryFlag code={sourceTranslation.language_code === 'da' ? 'DK' : 'GB'} size="sm" />
                    <Badge variant="outline">
                      {sourceTranslation.language_code.toUpperCase()} - {sourceTranslation.market_code || 'Global'}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {sourceTranslation.section.page.page_name} → {sourceTranslation.section.section_name} → {sourceTranslation.content_key}
                  </div>
                  <div className="p-3 bg-muted rounded border">
                    {sourceTranslation.content_value}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Custom Instructions */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Custom Translation Instructions</label>
            <Input
              value={globalInstruction}
              onChange={(e) => setGlobalInstruction(e.target.value)}
              placeholder="e.g., 'Keep urgent tone', 'Use formal language', 'Emphasize security'..."
              className="text-sm"
            />
            <p className="text-xs text-muted-foreground">
              These instructions will be applied to all selected translations
            </p>
          </div>

          {/* Custom Prompt */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Advanced AI Context (Optional)</label>
            <Textarea
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Enter additional context for AI translation..."
              rows={4}
              className="resize-none text-sm"
            />
          </div>

          {/* Market Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Select Target Markets</label>
            <div className="grid grid-cols-2 gap-3">
              {markets.map(market => {
                const isSelected = selectedMarkets.includes(market.country_code);
                const targetTranslation = translations.find(t => 
                  t.market_code === market.country_code && 
                  t.language_code !== 'en' &&
                  sourceTranslation &&
                  t.content_key === sourceTranslation.content_key &&
                  t.section.section_name === sourceTranslation.section.section_name &&
                  t.section.page.page_name === sourceTranslation.section.page.page_name
                );
                
                return (
                  <div key={market.country_code} className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={market.country_code}
                        checked={isSelected}
                        onCheckedChange={() => handleMarketToggle(market.country_code)}
                      />
                      <label htmlFor={market.country_code} className="flex items-center gap-2 cursor-pointer">
                        <span>{getCountryFlag(market.country_code)}</span>
                        <span className="text-sm">{market.country_name}</span>
                      </label>
                    </div>
                    
                    {/* Always show current translation status */}
                    <div className="ml-6 p-2 bg-muted/50 rounded text-xs">
                      <div className="text-muted-foreground mb-1">Current:</div>
                      <div>{targetTranslation?.content_value || 'N/A'}</div>
                    </div>

                    {/* Show generated translation if exists */}
                    {generatedTranslations[targetTranslation?.id || `placeholder-${market.country_code}-${sourceTranslation?.content_key}`] && (
                      <div className="ml-6 p-2 bg-green-50 border border-green-200 rounded text-xs">
                        <div className="text-green-700 mb-1 flex items-center gap-1">
                          <CheckCircle className="h-3 w-3" />
                          Generated:
                        </div>
                        <div>{generatedTranslations[targetTranslation?.id || `placeholder-${market.country_code}-${sourceTranslation?.content_key}`]}</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          
          {Object.keys(generatedTranslations).length === 0 ? (
            <Button 
              onClick={generateTranslations} 
              disabled={isGenerating || selectedMarkets.length === 0}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Translations
                </>
              )}
            </Button>
          ) : (
            <Button onClick={applyTranslations}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Apply {Object.keys(generatedTranslations).length} Translations
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};