import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Save, TestTube, Settings, Info, Sparkles } from 'lucide-react';
import { useAISettings } from '@/hooks/useAISettings';
import { toast } from 'sonner';

export const AISettings: React.FC = () => {
  const { settings, languageMappings, loading, saving, updateSettings, testTranslation } = useAISettings();
  
  const [testText, setTestText] = useState('Welcome to our service');
  const [testLanguage, setTestLanguage] = useState('da');
  const [testMarket, setTestMarket] = useState('DK');
  const [testResult, setTestResult] = useState('');
  const [testing, setTesting] = useState(false);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-1/4"></div>
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-16 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!settings) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-yellow-500" />
          <p className="text-lg font-medium">AI Settings Not Found</p>
          <p className="text-sm text-muted-foreground">
            Please contact your system administrator to initialize AI settings.
          </p>
        </CardContent>
      </Card>
    );
  }

  const handleSettingUpdate = (field: string, value: any) => {
    updateSettings({ [field]: value });
  };

  const handleTestTranslation = async () => {
    setTesting(true);
    try {
      const result = await testTranslation(testText, testLanguage, testMarket);
      if (result) {
        setTestResult(result);
      }
    } finally {
      setTesting(false);
    }
  };

  const availableVariables = [
    '{{TARGET_LANGUAGE}}', '{{TARGET_LANGUAGE_CODE}}', '{{MARKET_NAME}}', 
    '{{MARKET_CODE}}', '{{CURRENCY}}', '{{ORIGINAL_TEXT}}', 
    '{{CUSTOM_INSTRUCTION}}', '{{ELEMENT_TYPE}}', '{{LOCATION}}', 
    '{{BUSINESS_CONTEXT}}'
  ];

  return (
    <div className="space-y-6">
      {/* AI Model Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            AI Model Configuration
          </CardTitle>
          <CardDescription>
            Configure the OpenAI model and parameters for AI translations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="model">AI Model</Label>
              <Select 
                value={settings.model} 
                onValueChange={(value) => handleSettingUpdate('model', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gpt-4.1-2025-04-14">GPT-4.1-2025-04-14 (Best Quality)</SelectItem>
                  <SelectItem value="gpt-4o">GPT-4O</SelectItem>
                  <SelectItem value="gpt-4o-mini">GPT-4O Mini (Faster)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="temperature">Temperature (Creativity)</Label>
              <Input
                id="temperature"
                type="number"
                min="0"
                max="1"
                step="0.1"
                value={settings.temperature}
                onChange={(e) => handleSettingUpdate('temperature', parseFloat(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">0 = Very focused, 1 = Very creative</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_tokens">Max Tokens</Label>
              <Input
                id="max_tokens"
                type="number"
                min="50"
                max="1000"
                value={settings.max_tokens}
                onChange={(e) => handleSettingUpdate('max_tokens', parseInt(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">Maximum response length</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Business Context */}
      <Card>
        <CardHeader>
          <CardTitle>Business Context</CardTitle>
          <CardDescription>
            Describe your business/platform to provide context for AI translations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={settings.business_context}
            onChange={(e) => handleSettingUpdate('business_context', e.target.value)}
            rows={3}
            placeholder="Describe your business, its purpose, and target audience..."
          />
        </CardContent>
      </Card>

      {/* System Message */}
      <Card>
        <CardHeader>
          <CardTitle>System Message</CardTitle>
          <CardDescription>
            The initial instruction that defines the AI's role and behavior
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            value={settings.system_message}
            onChange={(e) => handleSettingUpdate('system_message', e.target.value)}
            rows={3}
            placeholder="You are a professional translator..."
          />
        </CardContent>
      </Card>

      {/* Prompt Template */}
      <Card>
        <CardHeader>
          <CardTitle>Prompt Template</CardTitle>
          <CardDescription>
            The main prompt template with variables that will be replaced with actual values
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Available Variables */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Available Variables</Label>
            <div className="flex flex-wrap gap-2 mb-4">
              {availableVariables.map((variable) => (
                <Badge key={variable} variant="outline" className="text-xs">
                  {variable}
                </Badge>
              ))}
            </div>
          </div>

          <Textarea
            value={settings.prompt_template}
            onChange={(e) => handleSettingUpdate('prompt_template', e.target.value)}
            rows={15}
            className="font-mono text-sm"
            placeholder="Enter your prompt template with variables..."
          />

          <div className="flex items-start gap-2 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">Template Variables:</p>
              <p>Variables in double curly braces format will be automatically replaced with actual values during translation.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Language Mappings */}
      <Card>
        <CardHeader>
          <CardTitle>Language Mappings</CardTitle>
          <CardDescription>
            Current language code to language name mappings per market
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {languageMappings.map((mapping) => (
              <div key={mapping.id} className="p-3 border rounded-md">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{mapping.language_code}</Badge>
                  <Badge variant="secondary">{mapping.market_code || 'Global'}</Badge>
                </div>
                <p className="text-sm font-medium">{mapping.language_name}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Translation Tester */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TestTube className="h-5 w-5" />
            Translation Tester
          </CardTitle>
          <CardDescription>
            Test your AI settings with sample text before applying changes
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="test-text">Test Text</Label>
              <Input
                id="test-text"
                value={testText}
                onChange={(e) => setTestText(e.target.value)}
                placeholder="Enter text to translate..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="test-language">Target Language</Label>
              <Select value={testLanguage} onValueChange={setTestLanguage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="da">Danish</SelectItem>
                  <SelectItem value="de">German</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="test-market">Market</Label>
              <Select value={testMarket} onValueChange={setTestMarket}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DK">Denmark</SelectItem>
                  <SelectItem value="DE">Germany</SelectItem>
                  <SelectItem value="UK">United Kingdom</SelectItem>
                  <SelectItem value="US">United States</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleTestTranslation} 
            disabled={testing || !testText.trim()}
            className="w-full"
          >
            {testing ? (
              <>
                <Sparkles className="h-4 w-4 mr-2 animate-spin" />
                Testing Translation...
              </>
            ) : (
              <>
                <TestTube className="h-4 w-4 mr-2" />
                Test Translation
              </>
            )}
          </Button>

          {testResult && (
            <div className="space-y-2">
              <Label>Translation Result</Label>
              <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                <p className="text-sm">{testResult}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};