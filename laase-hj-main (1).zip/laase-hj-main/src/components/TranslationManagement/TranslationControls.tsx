import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Check, Square, Play, RefreshCw } from 'lucide-react';

interface TranslationControlsProps {
  selectedCount: number;
  filteredCount: number;
  isAllSelected: boolean;
  isPartiallySelected: boolean;
  autoTranslating: boolean;
  autoTranslationProgress: number;
  currentAutoTranslatingItem: any;
  onSelectAll: () => void;
  onClearSelection: () => void;
  onInvertSelection: () => void;
  onStartAutoTranslation: (mode: 'selected' | 'visible' | 'missing') => void;
  onStopAutoTranslation: () => void;
  stopping: boolean;
}

export const TranslationControls: React.FC<TranslationControlsProps> = ({
  selectedCount,
  filteredCount,
  isAllSelected,
  isPartiallySelected,
  autoTranslating,
  autoTranslationProgress,
  currentAutoTranslatingItem,
  onSelectAll,
  onClearSelection,
  onInvertSelection,
  onStartAutoTranslation,
  onStopAutoTranslation,
  stopping
}) => {
  const [translationMode, setTranslationMode] = React.useState<'selected' | 'visible' | 'missing'>('visible');

  const handleStartTranslation = () => {
    onStartAutoTranslation(translationMode);
  };

  const canStartTranslation = () => {
    if (translationMode === 'selected') return selectedCount > 0;
    if (translationMode === 'visible') return filteredCount > 0;
    return true; // missing mode can always run
  };

  const getButtonText = () => {
    switch (translationMode) {
      case 'selected':
        return `Translate Selected (${selectedCount})`;
      case 'visible':
        return `Translate All Visible (${filteredCount})`;
      case 'missing':
        return 'Translate Missing Only';
      default:
        return 'Start Translation';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <RefreshCw className="h-5 w-5" />
          Translation Controls
        </CardTitle>
        <CardDescription>
          Select items and choose translation mode
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Selection Controls */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Selection Controls</Label>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={isAllSelected}
                  ref={React.useRef<HTMLButtonElement>(null)}
                  onClick={(e) => {
                    const checkbox = e.currentTarget;
                    if (checkbox.dataset.state === 'indeterminate' || isPartiallySelected) {
                      onSelectAll();
                    } else if (isAllSelected) {
                      onClearSelection();
                    } else {
                      onSelectAll();
                    }
                  }}
                  className={isPartiallySelected ? 'data-[state=checked]:bg-primary data-[state=indeterminate]:bg-primary' : ''}
                />
                <Label className="text-sm">
                  {isAllSelected ? 'Deselect All' : isPartiallySelected ? 'Select All' : 'Select All'}
                </Label>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={onClearSelection}
                disabled={selectedCount === 0}
              >
                Clear Selection
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={onInvertSelection}
                disabled={filteredCount === 0}
              >
                Invert Selection
              </Button>
            </div>
          </div>

          {/* Translation Mode */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Translation Mode</Label>
            <RadioGroup
              value={translationMode}
              onValueChange={(value: any) => setTranslationMode(value)}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="selected" id="selected" />
                <Label htmlFor="selected" className="text-sm">
                  Translate Selected Items Only
                  {selectedCount > 0 && <Badge variant="secondary" className="ml-2">{selectedCount}</Badge>}
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="visible" id="visible" />
                <Label htmlFor="visible" className="text-sm">
                  Translate All Visible Items
                  <Badge variant="secondary" className="ml-2">{filteredCount}</Badge>
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="missing" id="missing" />
                <Label htmlFor="missing" className="text-sm">
                  Translate Missing Translations Only (Legacy Mode)
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Translation Actions */}
          <div className="space-y-3">
            <div className="flex gap-2">
              {!autoTranslating ? (
                <Button
                  onClick={handleStartTranslation}
                  disabled={!canStartTranslation()}
                  className="flex-1"
                >
                  <Play className="h-4 w-4 mr-2" />
                  {getButtonText()}
                </Button>
              ) : (
                <Button
                  variant="destructive"
                  onClick={onStopAutoTranslation}
                  disabled={stopping}
                  className="flex-1"
                >
                  <Square className="h-4 w-4 mr-2" />
                  {stopping ? 'Stopping...' : 'Stop Translation'}
                </Button>
              )}
            </div>

            {/* Progress */}
            {autoTranslating && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Translation Progress</span>
                  <span>{Math.round(autoTranslationProgress)}%</span>
                </div>
                <Progress value={autoTranslationProgress} />
                {currentAutoTranslatingItem && (
                  <p className="text-xs text-muted-foreground">
                    Currently processing: {currentAutoTranslatingItem.content_key}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};