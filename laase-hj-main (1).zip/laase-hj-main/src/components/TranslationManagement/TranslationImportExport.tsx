import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Download, Upload, FileText, AlertCircle, CheckCircle2, X } from 'lucide-react';
import { useTranslationImportExport } from '@/hooks/useTranslationImportExport';
import { useTranslationManagement } from '@/hooks/useTranslationManagement';
import { getCountryFlag } from '@/utils/countryFlags';
import { toast } from 'sonner';

export const TranslationImportExport: React.FC = () => {
  const { 
    loading, 
    importPreview, 
    exportTranslations, 
    validateImportData, 
    importTranslations, 
    clearPreview 
  } = useTranslationImportExport();
  
  const { markets, refetch } = useTranslationManagement();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [exportFilters, setExportFilters] = useState({
    format: 'csv' as 'csv' | 'json',
    market: 'all',
    language: 'all'
  });

  const handleExport = async () => {
    try {
      await exportTranslations(exportFilters.format, {
        market: exportFilters.market !== 'all' ? exportFilters.market : undefined,
        language: exportFilters.language !== 'all' ? exportFilters.language : undefined
      });
      toast.success(`Translations exported as ${exportFilters.format.toUpperCase()}`);
    } catch (error) {
      // Error handled in hook
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await validateImportData(file);
    } catch (error) {
      // Error handled in hook
    }
  };

  const handleImport = async () => {
    if (!importPreview) return;

    try {
      await importTranslations(importPreview);
      await refetch(); // Refresh the translations data
      toast.success('Translations imported successfully');
    } catch (error) {
      // Error handled in hook
    }
  };

  const handleClearPreview = () => {
    clearPreview();
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Translations
          </CardTitle>
          <CardDescription>
            Export translations to CSV or JSON format for external editing
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Format Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Format</label>
                <Select 
                  value={exportFilters.format} 
                  onValueChange={(value: 'csv' | 'json') => 
                    setExportFilters(prev => ({ ...prev, format: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="csv">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        CSV (Spreadsheet)
                      </div>
                    </SelectItem>
                    <SelectItem value="json">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        JSON (Developer)
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Market Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Market</label>
                <Select 
                  value={exportFilters.market} 
                  onValueChange={(value) => 
                    setExportFilters(prev => ({ ...prev, market: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Markets</SelectItem>
                    <SelectItem value="global">Global</SelectItem>
                    {markets.map(market => (
                      <SelectItem key={market.country_code} value={market.country_code}>
                        <div className="flex items-center gap-2">
                          <span>{getCountryFlag(market.country_code)}</span>
                          <span>{market.country_name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Language Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Language</label>
                <Select 
                  value={exportFilters.language} 
                  onValueChange={(value) => 
                    setExportFilters(prev => ({ ...prev, language: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Languages</SelectItem>
                    <SelectItem value="da">🇩🇰 Danish</SelectItem>
                    <SelectItem value="en">🇬🇧 English</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button onClick={handleExport} disabled={loading} className="w-full md:w-auto">
              <Download className="h-4 w-4 mr-2" />
              Export {exportFilters.format.toUpperCase()}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Import Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Import Translations
          </CardTitle>
          <CardDescription>
            Import translations from CSV or JSON files. Existing translations will be updated.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* File Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Select File</label>
              <Input
                ref={fileInputRef}
                type="file"
                accept=".csv,.json"
                onChange={handleFileSelect}
                disabled={loading}
              />
              <p className="text-xs text-muted-foreground">
                Supported formats: CSV, JSON. Maximum file size: 10MB
              </p>
            </div>

            {/* Import Preview */}
            {importPreview && (
              <div className="space-y-4">
                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-2xl font-bold">{importPreview.stats.totalRows}</div>
                    <div className="text-sm text-muted-foreground">Total Rows</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{importPreview.stats.validRows}</div>
                    <div className="text-sm text-muted-foreground">Valid Rows</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{importPreview.stats.newTranslations}</div>
                    <div className="text-sm text-muted-foreground">New</div>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{importPreview.stats.updates}</div>
                    <div className="text-sm text-muted-foreground">Updates</div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Validation Progress</span>
                    <span>{Math.round((importPreview.stats.validRows / importPreview.stats.totalRows) * 100)}%</span>
                  </div>
                  <Progress 
                    value={(importPreview.stats.validRows / importPreview.stats.totalRows) * 100} 
                    className="h-2"
                  />
                </div>

                {/* Errors */}
                {importPreview.errors.length > 0 && (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <div className="space-y-2">
                        <p className="font-medium">
                          {importPreview.errors.length} validation errors found:
                        </p>
                        <div className="max-h-32 overflow-y-auto space-y-1">
                          {importPreview.errors.slice(0, 10).map((error, index) => (
                            <div key={index} className="text-sm">
                              <Badge variant="destructive" className="text-xs mr-2">
                                Row {error.row}
                              </Badge>
                              <span className="font-medium">{error.field}:</span> {error.message}
                            </div>
                          ))}
                          {importPreview.errors.length > 10 && (
                            <p className="text-sm text-muted-foreground">
                              ...and {importPreview.errors.length - 10} more errors
                            </p>
                          )}
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Success Message */}
                {importPreview.errors.length === 0 && (
                  <Alert>
                    <CheckCircle2 className="h-4 w-4" />
                    <AlertDescription>
                      File validation successful! Ready to import {importPreview.stats.validRows} translations.
                    </AlertDescription>
                  </Alert>
                )}

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <Button 
                    onClick={handleImport} 
                    disabled={loading || importPreview.errors.length > 0}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Import Translations
                  </Button>
                  <Button variant="outline" onClick={handleClearPreview}>
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Format Guide */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Import Format Guide
          </CardTitle>
          <CardDescription>
            Required columns and format for import files
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Required CSV Columns:</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                <Badge variant="outline">page</Badge>
                <Badge variant="outline">section</Badge>
                <Badge variant="outline">content_key</Badge>
                <Badge variant="outline">language</Badge>
                <Badge variant="outline">market</Badge>
                <Badge variant="outline">value</Badge>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-2">Optional Columns:</h4>
              <Badge variant="outline">notes</Badge>
            </div>

            <div>
              <h4 className="font-medium mb-2">Valid Values:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li><strong>language:</strong> da (Danish) or en (English)</li>
                <li><strong>market:</strong> DK, UK, DE, US, or global</li>
                <li><strong>page:</strong> Must match existing page names</li>
                <li><strong>section:</strong> Must match existing section names</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};