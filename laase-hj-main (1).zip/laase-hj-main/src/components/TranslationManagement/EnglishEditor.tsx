import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, Save, Zap, Languages, AlertCircle, Edit2, RefreshCw } from 'lucide-react';
import { useTranslationManagement } from '@/hooks/useTranslationManagement';
import { useAITranslation } from '@/hooks/useAITranslation';
import { useTranslationSelection } from '@/hooks/useTranslationSelection';
import { TranslationFilters } from './TranslationFilters';
import { TranslationControls } from './TranslationControls';
import { ErrorBoundary } from '@/components/ui/error-boundary';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { detectMissingTranslationsBulk, detectMissingTranslations } from '@/utils/translationSync';

interface EnglishTranslation {
  id: string;
  content_key: string;
  content_value: string;
  ai_instruction: string | null;
  section_name: string;
  page_name: string;
  missing_count: number;
  missing_markets: string[];
}

export const EnglishEditor: React.FC = () => {
  console.log('EnglishEditor: Component rendering started');
  
  const [englishTranslations, setEnglishTranslations] = useState<EnglishTranslation[]>([]);
  const [originalTranslations, setOriginalTranslations] = useState<Record<string, { content_value: string; ai_instruction: string | null }>>({});
  const [loading, setLoading] = useState(true);
  const [bulkTranslating, setBulkTranslating] = useState<string | null>(null);
  const [bulkTranslationProgress, setBulkTranslationProgress] = useState(0);
  const [savingContent, setSavingContent] = useState<string | null>(null);
  const [reTranslating, setReTranslating] = useState<string | null>(null);
  
  // Auto-translation state
  const [autoTranslating, setAutoTranslating] = useState(false);
  const [autoTranslationProgress, setAutoTranslationProgress] = useState(0);
  const [currentAutoTranslatingItem, setCurrentAutoTranslatingItem] = useState<EnglishTranslation | null>(null);
  const [autoTranslationOverallProgress, setAutoTranslationOverallProgress] = useState(0);
  const [stopRequested, setStopRequested] = useState(false);
  const [abortController, setAbortController] = useState<AbortController | null>(null);
  const [stopping, setStopping] = useState(false);
  
  const { translateText } = useAITranslation();
  
  // Enhanced selection and filtering
  console.log('EnglishEditor: About to use useTranslationSelection hook');
  console.log('EnglishEditor: englishTranslations length:', englishTranslations.length);
  console.log('EnglishEditor: originalTranslations keys:', Object.keys(originalTranslations).length);

  const {
    selectedIds,
    selectedTranslations,
    filteredTranslations,
    filters,
    setFilters,
    pages,
    sections,
    toggleSelection,
    selectAll,
    clearSelection,
    invertSelection,
    isAllSelected,
    isPartiallySelected,
    hasContentChanged
  } = useTranslationSelection(englishTranslations, originalTranslations);

  console.log('EnglishEditor: useTranslationSelection hook completed');
  console.log('EnglishEditor: filteredTranslations length:', filteredTranslations.length);

  useEffect(() => {
    console.log('EnglishEditor: useEffect triggered, calling fetchEnglishTranslations');
    fetchEnglishTranslations();
  }, []);

  const fetchEnglishTranslations = async () => {
    try {
      setLoading(true);
      console.log('EnglishEditor: Fetching English translations...');
      
      // Fetch English translations with section and page info
      const { data: englishData, error: englishError } = await supabase
        .from('content_translations')
        .select(`
          id,
          content_key,
          content_value,
          ai_instruction,
          section_id,
          section:content_sections!inner(
            id,
            section_name,
            page:content_pages!inner(page_name)
          )
        `)
        .eq('language_code', 'en');

      if (englishError) throw englishError;

      // 🚀 SCALABLE BULK PROCESSING: Replace 486 database queries with just 3!
      console.log(`🚀 [FetchTranslations] Using optimized bulk processing for ${englishData?.length || 0} English translations`);
      
      // Prepare items for bulk processing
      const itemsForBulkProcessing = (englishData || []).map(item => ({
        id: item.id,
        content_key: item.content_key,
        section_id: item.section_id
      }));

      // Use ultra-efficient bulk detection (3 queries instead of 486!)
      const bulkDetectionResults = await detectMissingTranslationsBulk(itemsForBulkProcessing);
      
      // Process results with shared data
      const processedData: EnglishTranslation[] = (englishData || []).map(item => {
        const detectionResult = bulkDetectionResults.get(item.id);
        
        if (detectionResult) {
          console.log(`🔍 [FetchTranslations] ${item.content_key}: missing ${detectionResult.missingCount} languages:`, detectionResult.missingLanguages);
          
          // Get markets for missing languages (not all markets)
          const marketsForMissingLanguages = [...new Set(
            detectionResult.missingLanguages.map(missingLang => {
              // Find all markets that use this language
              return detectionResult.marketLanguageAccess
                ?.filter(access => access.language_code === missingLang)
                ?.map(access => access.market_code)
                ?.filter((market): market is string => market !== null) || [];
            }).flat()
          )];

          console.log(`🗺️ [FetchTranslations] ${item.content_key}: markets affected by missing languages:`, marketsForMissingLanguages);

          return {
            id: item.id,
            content_key: item.content_key,
            content_value: item.content_value,
            ai_instruction: item.ai_instruction,
            section_name: item.section.section_name,
            page_name: item.section.page.page_name,
            missing_count: detectionResult.missingCount,
            missing_markets: marketsForMissingLanguages
          };
        } else {
          // Fallback for items that failed processing
          console.warn(`⚠️ [FetchTranslations] No detection result for ${item.content_key}, using fallback`);
          return {
            id: item.id,
            content_key: item.content_key,
            content_value: item.content_value,
            ai_instruction: item.ai_instruction,
            section_name: item.section.section_name,
            page_name: item.section.page.page_name,
            missing_count: 0,
            missing_markets: []
          };
        }
      });

      setEnglishTranslations(processedData);
      
      // Store original values for change detection
      const originalValues: Record<string, { content_value: string; ai_instruction: string | null }> = {};
      processedData.forEach(item => {
        originalValues[item.id] = {
          content_value: item.content_value,
          ai_instruction: item.ai_instruction
        };
      });
      setOriginalTranslations(originalValues);
      console.log('EnglishEditor: State updated successfully');
    } catch (error) {
      console.error('EnglishEditor: Error fetching English translations:', error);
      toast.error('Failed to fetch English translations');
    } finally {
      setLoading(false);
    }
  };

  const saveAIInstruction = async (translationId: string, instruction: string) => {
    try {
      const { error } = await supabase
        .from('content_translations')
        .update({ ai_instruction: instruction || null })
        .eq('id', translationId);

      if (error) throw error;
      
      // Update local state
      setEnglishTranslations(prev => 
        prev.map(item => 
          item.id === translationId 
            ? { ...item, ai_instruction: instruction || null }
            : item
        )
      );
      
      toast.success('AI instruction saved');
    } catch (error) {
      console.error('Error saving AI instruction:', error);
      toast.error('Failed to save AI instruction');
    }
  };

  const bulkTranslateToAllMarkets = async (englishTranslation: EnglishTranslation, forceRetranslate = false) => {
    setBulkTranslating(englishTranslation.id);
    setBulkTranslationProgress(0);

    try {
      console.log(`🔄 [BulkTranslate] Starting bulk translation for content key: ${englishTranslation.content_key}`);
      console.log(`📊 [BulkTranslate] UI shows ${englishTranslation.missing_count} missing translations, force: ${forceRetranslate}`);
      
      // Get the section ID for this translation
      const { data: sectionData, error: sectionError } = await supabase
        .from('content_translations')
        .select('section_id')
        .eq('id', englishTranslation.id)
        .single();

      if (sectionError) {
        console.error('❌ [BulkTranslate] Failed to get section data:', sectionError);
        throw sectionError;
      }
      console.log(`📁 [BulkTranslate] Section ID: ${sectionData.section_id}`);

      // Use standardized detection logic
      const detectionResult = await detectMissingTranslations(
        englishTranslation.content_key, 
        sectionData.section_id
      );

      console.log(`🔍 [BulkTranslate] Standardized detection results:`, detectionResult.debugInfo);
      console.log(`📋 [BulkTranslate] Missing languages:`, detectionResult.missingLanguages);
      console.log(`📊 [BulkTranslate] Actual missing count: ${detectionResult.missingCount} vs UI count: ${englishTranslation.missing_count}`);

      // Check if UI and database are in sync
      if (detectionResult.missingCount !== englishTranslation.missing_count) {
        console.warn(`⚠️ [BulkTranslate] UI/DB MISMATCH: UI shows ${englishTranslation.missing_count} missing, but database shows ${detectionResult.missingCount} missing`);
        console.warn(`🔍 [BulkTranslate] This suggests the UI needs refreshing - continuing with database state`);
      }

      // Determine what to translate
      let languagesToTranslate: string[];
      if (forceRetranslate) {
        languagesToTranslate = detectionResult.enabledLanguages;
        console.log(`🔄 [BulkTranslate] Force re-translating all ${languagesToTranslate.length} languages`);
      } else {
        if (detectionResult.missingCount === 0) {
          console.warn(`⚠️ [BulkTranslate] No missing languages found for ${englishTranslation.content_key}`);
          toast.info('All translations already exist for this content');
          return;
        }
        languagesToTranslate = detectionResult.missingLanguages;
        console.log(`🎯 [BulkTranslate] Translating ${languagesToTranslate.length} missing languages`);
      }
      console.log(`🎯 [BulkTranslate] Languages to ${forceRetranslate ? 're-translate' : 'translate'}:`, languagesToTranslate);

      const totalTranslations = languagesToTranslate.length;
      let completedTranslations = 0;
      let failedTranslations = 0;
      const failureReasons: Record<string, string> = {};

      // Process translations in batches to avoid overwhelming the API
      const batchSize = 3;
      for (let i = 0; i < languagesToTranslate.length; i += batchSize) {
        const batch = languagesToTranslate.slice(i, i + batchSize);
        console.log(`📦 [BulkTranslate] Processing batch ${Math.floor(i/batchSize) + 1}/${Math.ceil(languagesToTranslate.length/batchSize)}:`, batch);
        
        const batchPromises = batch.map(async (language) => {
          try {
            console.log(`🔄 [BulkTranslate] Starting translation to ${language}`);
            
            // Get a market for this language for AI context
            const marketForLanguage = detectionResult.marketLanguageAccess.find(access => 
              access.language_code === language
            )?.market_code;

            if (!marketForLanguage) {
              console.warn(`⚠️ [BulkTranslate] No market found for language ${language}`);
            }

            // Validate source content
            if (!englishTranslation.content_value?.trim()) {
              const error = `Empty source content for ${englishTranslation.content_key}`;
              console.error(`❌ [BulkTranslate] ${error}`);
              failureReasons[language] = error;
              failedTranslations++;
              return false;
            }

            console.log(`🎯 [BulkTranslate] Sending AI request for ${language}:`, {
              contentKey: englishTranslation.content_key,
              sourceLength: englishTranslation.content_value.length,
              market: marketForLanguage,
              hasCustomInstruction: !!englishTranslation.ai_instruction
            });

            const translatedText = await translateText({
              originalText: englishTranslation.content_value,
              targetLanguage: language,
              market: marketForLanguage,
              pageName: englishTranslation.page_name,
              sectionName: englishTranslation.section_name,
              contentKey: englishTranslation.content_key,
              customInstruction: englishTranslation.ai_instruction || undefined
            });

            if (!translatedText) {
              const error = `AI translation failed - no response`;
              console.error(`❌ [BulkTranslate] ${error} for ${language}`);
              failureReasons[language] = error;
              failedTranslations++;
              return false;
            }

            if (translatedText.trim().length === 0) {
              const error = `AI translation failed - empty response`;
              console.error(`❌ [BulkTranslate] ${error} for ${language}`);
              failureReasons[language] = error;
              failedTranslations++;
              return false;
            }

            console.log(`✅ [BulkTranslate] AI translation successful for ${language}: "${translatedText.substring(0, 50)}..."`);

            // Prepare database record
            const dbRecord = {
              section_id: sectionData.section_id,
              language_code: language,
              market_code: null, // Set to null for global translations
              content_key: englishTranslation.content_key,
              content_value: translatedText.trim(),
              content_type: 'text',
              ai_instruction: englishTranslation.ai_instruction
            };

            console.log(`💾 [BulkTranslate] Saving to database for ${language}:`, {
              section_id: sectionData.section_id,
              language_code: language,
              content_key: englishTranslation.content_key,
              content_length: translatedText.length
            });

            // Use UPSERT to handle potential duplicates with correct constraint
            const { error: upsertError } = await supabase
              .from('content_translations')
              .upsert(dbRecord, {
                onConflict: 'section_id,language_code,content_key'
              });

            if (upsertError) {
              const error = `Database error: ${upsertError.message} (${upsertError.code || 'unknown'})`;
              console.error(`❌ [BulkTranslate] ${error}`, {
                language,
                contentKey: englishTranslation.content_key,
                sectionId: sectionData.section_id,
                fullError: upsertError
              });
              failureReasons[language] = error;
              failedTranslations++;
              return false;
            }

            console.log(`✅ [BulkTranslate] Database save successful for ${language}`);
            return true;

          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : 'Unknown error';
            console.error(`❌ [BulkTranslate] Unexpected error for ${language}:`, error);
            failureReasons[language] = `Unexpected error: ${errorMsg}`;
            failedTranslations++;
            return false;
          }
        });

        const batchResults = await Promise.all(batchPromises);
        const successfulInBatch = batchResults.filter(Boolean).length;
        completedTranslations += successfulInBatch;
        
        console.log(`📊 [BulkTranslate] Batch ${Math.floor(i/batchSize) + 1} complete: ${successfulInBatch}/${batch.length} successful`);
        setBulkTranslationProgress((completedTranslations / totalTranslations) * 100);
      }

      // Comprehensive result reporting
      console.log(`🏁 [BulkTranslate] Final results:`, {
        total: totalTranslations,
        completed: completedTranslations,
        failed: failedTranslations,
        failureReasons
      });

      if (completedTranslations > 0 && failedTranslations === 0) {
        toast.success(`✅ Successfully translated to all ${completedTranslations} languages`);
        await fetchEnglishTranslations(); // Refresh data
      } else if (completedTranslations > 0 && failedTranslations > 0) {
        const failedLangs = Object.keys(failureReasons);
        toast.success(`⚠️ Partial success: ${completedTranslations}/${totalTranslations} completed. Failed: ${failedLangs.join(', ')}`);
        console.warn(`⚠️ [BulkTranslate] Failed languages:`, failureReasons);
        await fetchEnglishTranslations(); // Refresh data
      } else {
        const failedLangs = Object.keys(failureReasons);
        toast.error(`❌ No translations completed. Failed languages: ${failedLangs.join(', ')}`);
        console.error(`❌ [BulkTranslate] All translations failed:`, failureReasons);
      }
    } catch (error) {
      console.error('Bulk translation error:', error);
      toast.error('Bulk translation failed');
    } finally {
      setBulkTranslating(null);
      setBulkTranslationProgress(0);
    }
  };

  const startAutoTranslation = async (mode: 'selected' | 'visible' | 'missing' = 'visible') => {
    let itemsToTranslate: EnglishTranslation[] = [];
    
    switch (mode) {
      case 'selected':
        itemsToTranslate = selectedTranslations;
        if (itemsToTranslate.length === 0) {
          toast.error('No items selected for translation');
          return;
        }
        break;
      case 'visible':
        itemsToTranslate = filteredTranslations;
        if (itemsToTranslate.length === 0) {
          toast.error('No items visible for translation');
          return;
        }
        break;
      case 'missing':
        itemsToTranslate = englishTranslations.filter(item => item.missing_count > 0);
        if (itemsToTranslate.length === 0) {
          toast.info('All translations are complete!');
          return;
        }
        break;
    }

    console.log(`🚀 Starting auto-translation (${mode} mode) for ${itemsToTranslate.length} items`);
    
    // Create new AbortController for this session
    const controller = new AbortController();
    setAbortController(controller);
    
    setAutoTranslating(true);
    setStopRequested(false);
    setStopping(false);
    setAutoTranslationOverallProgress(0);
    
    // Pre-fetch all required data once
    const { data: marketLanguageAccess, error: accessError } = await supabase
      .from('market_language_access')
      .select('market_code, language_code, is_enabled')
      .eq('is_enabled', true);

    if (accessError) {
      console.error('Failed to fetch market language access:', accessError);
      toast.error('Failed to load language configuration');
      setAutoTranslating(false);
      setAbortController(null);
      return;
    }

    const enabledLanguages = [...new Set(
      marketLanguageAccess?.map(access => access.language_code) || []
    )].filter(lang => lang !== 'en'); // Exclude English from auto-translation

    console.log(`📋 Enabled languages:`, enabledLanguages);
    
    if (enabledLanguages.length === 0) {
      console.error('❌ No enabled target languages found');
      toast.error('No target languages configured for translation');
      setAutoTranslating(false);
      setAbortController(null);
      return;
    }
    
    let processedItems = 0;
    let totalTranslations = 0;
    let successfulTranslations = 0;
    
    for (const item of itemsToTranslate) {
      // Check for stop/abort at the beginning of each item
      if (stopRequested || controller.signal.aborted) {
        console.log('🛑 Auto-translation stopped by user');
        toast.info('Auto-translation stopped by user');
        break;
      }

      setCurrentAutoTranslatingItem(item);
      setAutoTranslationProgress(0);
      
      console.log(`🔄 Processing item: ${item.content_key} (${item.missing_count} missing translations)`);
      
      try {
        const result = await translateSingleItemOptimized(item, enabledLanguages, marketLanguageAccess, controller.signal);
        totalTranslations += result.totalAttempted;
        successfulTranslations += result.successful;
        processedItems++;
        setAutoTranslationOverallProgress((processedItems / itemsToTranslate.length) * 100);
      } catch (error) {
        if (controller.signal.aborted) {
          console.log('🛑 Translation aborted');
          break;
        }
        console.error(`❌ Failed to translate item ${item.content_key}:`, error);
        toast.error(`Failed to translate: ${item.content_key}`);
      }
    }
    
    if (!stopRequested && !controller.signal.aborted) {
      const message = `Auto-translation completed! Processed ${processedItems} items (${successfulTranslations}/${totalTranslations} translations successful).`;
      console.log(`✅ ${message}`);
      toast.success(message);
      await fetchEnglishTranslations(); // Refresh all data
    }
    
    // Clean up
    setAutoTranslating(false);
    setCurrentAutoTranslatingItem(null);
    setAutoTranslationProgress(0);
    setAutoTranslationOverallProgress(0);
    setAbortController(null);
    setStopping(false);
  };

  const translateSingleItemOptimized = async (
    englishTranslation: EnglishTranslation, 
    enabledLanguages: string[], 
    marketLanguageAccess: any[],
    abortSignal: AbortSignal
  ) => {
    // Check if aborted at the start
    if (abortSignal.aborted) {
      console.log('🛑 translateSingleItemOptimized aborted at start');
      return { totalAttempted: 0, successful: 0 };
    }

    // Get the section ID for this translation (only database call needed)
    const { data: sectionData, error: sectionError } = await supabase
      .from('content_translations')
      .select('section_id')
      .eq('id', englishTranslation.id)
      .single();

    if (sectionError) throw sectionError;
    if (abortSignal.aborted) return { totalAttempted: 0, successful: 0 };

    // Get existing translations for this content key and section
    const { data: existingTranslations, error: existingError } = await supabase
      .from('content_translations')
      .select('language_code, market_code')
      .eq('content_key', englishTranslation.content_key)
      .eq('section_id', sectionData.section_id);

    if (existingError) {
      console.error(`❌ [AutoTranslate] Failed to get existing translations for ${englishTranslation.content_key}:`, existingError);
      throw existingError;
    }
    if (abortSignal.aborted) return { totalAttempted: 0, successful: 0 };

    console.log(`📋 [AutoTranslate] ${englishTranslation.content_key} existing translations:`, 
      existingTranslations?.map(t => `${t.language_code}(${t.market_code || 'global'})`).join(', ') || 'none');

    // Find missing languages using pre-fetched data (English already excluded from enabledLanguages)
    // Check for global translations (market_code = null) for each language
    const missingLanguages = enabledLanguages.filter(language => 
      !existingTranslations?.some(existing => 
        existing.language_code === language && existing.market_code === null
      )
    );

    console.log(`🎯 [AutoTranslate] ${englishTranslation.content_key}: ${missingLanguages.length} missing languages:`, missingLanguages);

    const totalTranslations = missingLanguages.length;
    let completedTranslations = 0;

    // Process translations with better error tracking
    for (const language of missingLanguages) {
      // Check for abort/stop before each translation
      if (stopRequested || abortSignal.aborted) {
        console.log('🛑 Stopping translation loop');
        break;
      }
      
      try {
        console.log(`🔄 Translating ${englishTranslation.content_key} to ${language}`);
        
        // Get a market for this language for AI context
        const marketForLanguage = marketLanguageAccess?.find(access => 
          access.language_code === language
        )?.market_code;

        // Add fallback AI instruction if missing
        const instruction = englishTranslation.ai_instruction || 
          `Translate this text for the Lockily locksmith platform. Keep the professional tone and ensure accuracy for ${language} speakers.`;

        // Validate content before translation
        if (!englishTranslation.content_value || englishTranslation.content_value.trim().length === 0) {
          console.warn(`⚠️ Skipping ${englishTranslation.content_key} - empty source content`);
          continue;
        }

        const translatedText = await translateText({
          originalText: englishTranslation.content_value,
          targetLanguage: language,
          market: marketForLanguage,
          pageName: englishTranslation.page_name,
          sectionName: englishTranslation.section_name,
          contentKey: englishTranslation.content_key,
          customInstruction: instruction,
          abortSignal
        });

        // Check again after translation
        if (stopRequested || abortSignal.aborted) {
          console.log('🛑 Stopping after translation');
          break;
        }

        if (translatedText && translatedText.trim().length > 0) {
           // Use UPSERT to handle potential duplicates with correct constraint
           // The actual unique constraint includes market_code: (section_id, language_code, content_key, COALESCE(market_code, ''))
           const { error: upsertError } = await supabase
             .from('content_translations')
             .upsert({
               section_id: sectionData.section_id,
               language_code: language,
               market_code: null, // Set to null for global translations
               content_key: englishTranslation.content_key,
               content_value: translatedText.trim(),
               content_type: 'text',
               ai_instruction: englishTranslation.ai_instruction || instruction
             }, {
               onConflict: 'section_id,language_code,content_key'
             });

          if (!upsertError) {
            completedTranslations++;
            console.log(`✅ Successfully translated ${englishTranslation.content_key} to ${language}: "${translatedText.substring(0, 50)}..."`);
          } else {
            console.error(`❌ Database error for ${englishTranslation.content_key} (${language}):`, upsertError);
            // Try to provide more specific error info
            if (upsertError.code === '23505') {
              console.error('🔍 Constraint violation - record may already exist');
            }
          }
        } else {
          console.warn(`⚠️ No valid translation returned for ${englishTranslation.content_key} to ${language} (received: "${translatedText}")`);
        }
      } catch (error) {
        if (abortSignal.aborted) {
          console.log('🛑 Translation aborted');
          break;
        }
        console.error(`❌ Translation error for ${englishTranslation.content_key} (${language}):`, error);
      }
      
      setAutoTranslationProgress((completedTranslations / totalTranslations) * 100);
    }

    return {
      totalAttempted: totalTranslations,
      successful: completedTranslations
    };
  };

  const translateSingleItem = async (englishTranslation: EnglishTranslation) => {
    // Get the section ID for this translation
    const { data: sectionData, error: sectionError } = await supabase
      .from('content_translations')
      .select('section_id')
      .eq('id', englishTranslation.id)
      .single();

    if (sectionError) throw sectionError;

    // Get enabled languages that are missing translations
    const { data: marketLanguageAccess, error: accessError } = await supabase
      .from('market_language_access')
      .select('market_code, language_code, is_enabled')
      .eq('is_enabled', true);

    if (accessError) throw accessError;

    // Get existing translations for this content key  
    const { data: existingTranslations, error: existingError } = await supabase
      .from('content_translations')
      .select('language_code')
      .eq('content_key', englishTranslation.content_key);

    if (existingError) throw existingError;

    // Find missing languages (remove duplicates)
    const enabledLanguages = [...new Set(
      marketLanguageAccess?.map(access => access.language_code) || []
    )];
    
    const missingLanguages = enabledLanguages.filter(language => 
      !existingTranslations?.some(existing => existing.language_code === language)
    );

    const totalTranslations = missingLanguages.length;
    let completedTranslations = 0;

    // Process translations sequentially to avoid overwhelming the API
    for (const language of missingLanguages) {
      if (stopRequested) break;
      
      try {
        // Get a market for this language for AI context
        const marketForLanguage = marketLanguageAccess?.find(access => 
          access.language_code === language
        )?.market_code;

        const translatedText = await translateText({
          originalText: englishTranslation.content_value,
          targetLanguage: language,
          market: marketForLanguage,
          pageName: englishTranslation.page_name,
          sectionName: englishTranslation.section_name,
          contentKey: englishTranslation.content_key,
          customInstruction: englishTranslation.ai_instruction || undefined
        });

        if (translatedText) {
              // Use UPSERT to handle potential duplicates with correct constraint
              const { error: upsertError } = await supabase
                .from('content_translations')
                .upsert({
                  section_id: sectionData.section_id,
                  language_code: language,
                  market_code: null, // Set to null for global translations
                  content_key: englishTranslation.content_key,
                  content_value: translatedText,
                  content_type: 'text',
                  ai_instruction: englishTranslation.ai_instruction
                }, {
                  onConflict: 'section_id,language_code,content_key'
                });

          if (!upsertError) {
            completedTranslations++;
          }
        }
      } catch (error) {
        console.error('Translation error:', error);
      }
      
      setAutoTranslationProgress((completedTranslations / totalTranslations) * 100);
    }
  };

  const stopAutoTranslation = () => {
    setStopRequested(true);
    setStopping(true);
    
    // Abort the current AbortController if it exists
    if (abortController) {
      console.log('🛑 Aborting auto-translation');
      abortController.abort();
    }
    
    toast.info('Stopping auto-translation... (finishing current operation)');
  };

  const saveEnglishContent = async (translationId: string, newContent: string) => {
    try {
      setSavingContent(translationId);
      
      const { error } = await supabase
        .from('content_translations')
        .update({ content_value: newContent })
        .eq('id', translationId);

      if (error) throw error;
      
      // Update local state and original values
      setEnglishTranslations(prev => 
        prev.map(item => 
          item.id === translationId 
            ? { ...item, content_value: newContent }
            : item
        )
      );
      
      setOriginalTranslations(prev => ({
        ...prev,
        [translationId]: {
          ...prev[translationId],
          content_value: newContent
        }
      }));
      
      toast.success('English content saved');
    } catch (error) {
      console.error('Error saving English content:', error);
      toast.error('Failed to save English content');
    } finally {
      setSavingContent(null);
    }
  };

  const reTranslateAllLanguages = async (englishTranslation: EnglishTranslation) => {
    setReTranslating(englishTranslation.id);
    setBulkTranslationProgress(0);

    try {
      // Get the section ID for this translation
      const { data: sectionData, error: sectionError } = await supabase
        .from('content_translations')
        .select('section_id')
        .eq('id', englishTranslation.id)
        .single();

      if (sectionError) throw sectionError;

      // Get all enabled languages
      const { data: marketLanguageAccess, error: accessError } = await supabase
        .from('market_language_access')
        .select('market_code, language_code, is_enabled')
        .eq('is_enabled', true);

      if (accessError) throw accessError;

      // Get all unique languages (excluding English)
      const allLanguages = [...new Set(
        marketLanguageAccess?.map(access => access.language_code) || []
      )].filter(lang => lang !== 'en');

      const totalTranslations = allLanguages.length;
      let completedTranslations = 0;

      // Process translations in batches
      const batchSize = 3;
      for (let i = 0; i < allLanguages.length; i += batchSize) {
        const batch = allLanguages.slice(i, i + batchSize);
        
        const batchPromises = batch.map(async (language) => {
          try {
            // Get a market for this language for AI context
            const marketForLanguage = marketLanguageAccess?.find(access => 
              access.language_code === language
            )?.market_code;

            const translatedText = await translateText({
              originalText: englishTranslation.content_value,
              targetLanguage: language,
              market: marketForLanguage,
              pageName: englishTranslation.page_name,
              sectionName: englishTranslation.section_name,
              contentKey: englishTranslation.content_key,
              customInstruction: englishTranslation.ai_instruction || undefined
            });

            if (translatedText) {
               // Use UPSERT to update existing translations with correct constraint
               const { error: upsertError } = await supabase
                 .from('content_translations')
                 .upsert({
                   section_id: sectionData.section_id,
                   language_code: language,
                   market_code: null,
                   content_key: englishTranslation.content_key,
                   content_value: translatedText,
                   content_type: 'text',
                   ai_instruction: englishTranslation.ai_instruction
                 }, {
                   onConflict: 'section_id,language_code,content_key'
                 });

              if (upsertError) {
                console.error('❌ Database error during individual translation:', upsertError);
                console.error('Failed language:', language, 'Content key:', englishTranslation.content_key);
                toast.error(`Failed to save translation for ${language}: ${upsertError.message}`);
                return false;
              }
              return true;
            }
            return false;
          } catch (error) {
            console.error('Translation error:', error);
            return false;
          }
        });

        const batchResults = await Promise.all(batchPromises);
        const successfulInBatch = batchResults.filter(Boolean).length;
        completedTranslations += successfulInBatch;
        
        setBulkTranslationProgress((completedTranslations / totalTranslations) * 100);
      }

      // Update original values to mark as no longer changed and refresh data
      setOriginalTranslations(prev => ({
        ...prev,
        [englishTranslation.id]: {
          content_value: englishTranslation.content_value,
          ai_instruction: englishTranslation.ai_instruction
        }
      }));
      
      // Refresh the data to update missing counts
      await fetchEnglishTranslations();

      if (completedTranslations > 0) {
        toast.success(`Successfully re-translated to ${completedTranslations} languages`);
      } else {
        toast.error('No translations were completed');
      }
    } catch (error) {
      console.error('Re-translation error:', error);
      toast.error('Re-translation failed');
    } finally {
      setReTranslating(null);
      setBulkTranslationProgress(0);
    }
  };


  console.log('EnglishEditor: About to render, loading:', loading);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin mr-2" />
          Loading English translations...
        </CardContent>
      </Card>
    );
  }

  console.log('EnglishEditor: Rendering main component');

  return (
    <ErrorBoundary>
      <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Languages className="h-5 w-5" />
            English Source Editor
          </CardTitle>
          <CardDescription>
            Manage English source content and translate to all markets with enhanced filtering and selection
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Enhanced Filters */}
      <TranslationFilters
        filters={filters}
        setFilters={setFilters}
        pages={pages}
        sections={sections}
        totalCount={englishTranslations.length}
        filteredCount={filteredTranslations.length}
        selectedCount={selectedTranslations.length}
      />

      {/* Enhanced Translation Controls */}
      <TranslationControls
        selectedCount={selectedTranslations.length}
        filteredCount={filteredTranslations.length}
        isAllSelected={isAllSelected}
        isPartiallySelected={isPartiallySelected}
        autoTranslating={autoTranslating}
        autoTranslationProgress={autoTranslationOverallProgress}
        currentAutoTranslatingItem={currentAutoTranslatingItem}
        onSelectAll={selectAll}
        onClearSelection={clearSelection}
        onInvertSelection={invertSelection}
        onStartAutoTranslation={startAutoTranslation}
        onStopAutoTranslation={stopAutoTranslation}
        stopping={stopping}
      />

      <div className="space-y-4">
        {filteredTranslations.map((item) => (
          <Card key={item.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Checkbox
                    checked={selectedIds.has(item.id)}
                    onCheckedChange={() => toggleSelection(item.id)}
                  />
                  <div>
                    <CardTitle className="text-lg">{item.content_key}</CardTitle>
                    <CardDescription>
                      {item.page_name} → {item.section_name}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {hasContentChanged(item) && (
                    <Badge variant="outline" className="text-xs">
                      Changed
                    </Badge>
                  )}
                   {item.missing_count > 0 ? (
                    <Badge variant="destructive" className="flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      Missing in {item.missing_count} languages
                    </Badge>
                  ) : (
                    <Badge variant="default">Fully Translated</Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="flex items-center gap-2">
                  English Content 
                  <Edit2 className="h-3 w-3 text-muted-foreground" />
                </Label>
                <Textarea
                  value={item.content_value}
                  onChange={(e) => {
                    const newValue = e.target.value;
                    setEnglishTranslations(prev => 
                      prev.map(i => 
                        i.id === item.id 
                          ? { ...i, content_value: newValue }
                          : i
                      )
                    );
                  }}
                  className="text-sm"
                  rows={Math.max(2, Math.ceil(item.content_value.length / 80))}
                />
                
                {/* Save and Re-translate buttons */}
                <div className="flex gap-2 mt-2">
                  {/* Save button - show if content differs from original */}
                  {originalTranslations[item.id]?.content_value !== item.content_value && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => saveEnglishContent(item.id, item.content_value)}
                      disabled={savingContent === item.id}
                    >
                      {savingContent === item.id ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Save className="h-4 w-4 mr-2" />
                      )}
                      Save English Content
                    </Button>
                  )}
                  
                  {/* Re-translate button - show if content has changed and item is fully translated */}
                  {hasContentChanged(item) && item.missing_count === 0 && (
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => reTranslateAllLanguages(item)}
                      disabled={reTranslating === item.id}
                    >
                      {reTranslating === item.id ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <RefreshCw className="h-4 w-4 mr-2" />
                      )}
                      Re-translate All
                    </Button>
                  )}
                </div>
                
                {/* Show change indicator */}
                {hasContentChanged(item) && (
                  <Badge variant="outline" className="text-xs mt-2">
                    Content changed - save to apply or re-translate
                  </Badge>
                )}
              </div>

              <div>
                <Label htmlFor={`ai-instruction-${item.id}`}>AI Translation Instruction</Label>
                <Textarea
                  id={`ai-instruction-${item.id}`}
                  placeholder="Optional: Add specific instructions for AI translation..."
                  value={item.ai_instruction || ''}
                  onChange={(e) => {
                    const newValue = e.target.value;
                    setEnglishTranslations(prev => 
                      prev.map(i => 
                        i.id === item.id 
                          ? { ...i, ai_instruction: newValue }
                          : i
                      )
                    );
                  }}
                  rows={2}
                />
                <div className="flex gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => saveAIInstruction(item.id, item.ai_instruction || '')}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save Instruction
                  </Button>
                  
                  {item.missing_count > 0 ? (
                    <>
                      <Button
                        size="sm"
                        onClick={() => bulkTranslateToAllMarkets(item)}
                        disabled={bulkTranslating === item.id}
                      >
                        {bulkTranslating === item.id ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Translating...
                          </>
                        ) : (
                          <>
                            <Zap className="h-4 w-4 mr-2" />
                            Translate Missing ({item.missing_count})
                          </>
                        )}
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => bulkTranslateToAllMarkets(item, true)}
                        disabled={bulkTranslating === item.id}
                      >
                        {bulkTranslating === item.id ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <RefreshCw className="h-4 w-4 mr-2" />
                        )}
                        Re-translate All
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => bulkTranslateToAllMarkets(item, true)}
                      disabled={reTranslating === item.id}
                    >
                      {reTranslating === item.id ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <RefreshCw className="h-4 w-4 mr-2" />
                      )}
                      Re-translate All Languages
                    </Button>
                  )}
                </div>
              </div>

              {(bulkTranslating === item.id || reTranslating === item.id) && bulkTranslationProgress > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{reTranslating === item.id ? 'Re-translation Progress' : 'Translation Progress'}</span>
                    <span>{Math.round(bulkTranslationProgress)}%</span>
                  </div>
                  <Progress value={bulkTranslationProgress} />
                </div>
              )}

              {item.missing_markets.length > 0 && (
                <div>
                  <Label className="text-sm text-muted-foreground">Markets affected by missing languages:</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {item.missing_markets.map((market) => (
                      <Badge key={market} variant="outline" className="text-xs">
                        {market}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTranslations.length === 0 && (
        <Card>
          <CardContent className="text-center py-12 text-muted-foreground">
            <Languages className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No English translations found matching your search.</p>
          </CardContent>
        </Card>
      )}
      </div>
    </ErrorBoundary>
  );
};