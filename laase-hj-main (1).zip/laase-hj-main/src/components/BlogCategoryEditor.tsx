import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { DialogFooter } from '@/components/ui/dialog';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { validateSlugUniqueness, generateSlug } from '@/utils/categorySlugResolver';
import { toast } from 'sonner';
import { Info } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface BlogCategoryEditorProps {
  category?: any;
  onSave: () => void;
  onCancel: () => void;
}

export const BlogCategoryEditor: React.FC<BlogCategoryEditorProps> = ({ 
  category, 
  onSave, 
  onCancel 
}) => {
  const { categories, createCategory, updateCategory } = useBlogCategories();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    category_key: '',
    slug: '',
    name: '',
    description: '',
    seo_title: '',
    seo_description: '',
    parent_id: 'none',
    display_order: 0,
    is_active: true,
  });

  useEffect(() => {
    if (category) {
      setFormData({
        category_key: category.category_key || '',
        slug: category.slug || '',
        name: category.name || '',
        description: category.description || '',
        seo_title: category.seo_title || '',
        seo_description: category.seo_description || '',
        parent_id: category.parent_id || 'none',
        display_order: category.display_order || 0,
        is_active: category.is_active !== false,
      });
    } else {
      // Reset form for new category
      setFormData({
        category_key: '',
        slug: '',
        name: '',
        description: '',
        seo_title: '',
        seo_description: '',
        parent_id: 'none',
        display_order: 0,
        is_active: true,
      });
    }
  }, [category]);

  const generateCategoryKey = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/(^_|_$)/g, '');
  };

  const handleNameChange = (name: string) => {
    setFormData(prev => ({
      ...prev,
      name,
      slug: prev.slug || generateSlug(name),
      category_key: prev.category_key || generateCategoryKey(name),
    }));
  };

  const handleSlugChange = async (slug: string) => {
    setFormData(prev => ({ ...prev, slug }));
    
    // Validate slug uniqueness (debounced validation would be better in production)
    if (slug && slug.length > 0) {
      const isUnique = await validateSlugUniqueness(slug, undefined, 'en', category?.category_key);
      if (!isUnique) {
        toast.error('This slug is already in use. Please choose a different one.');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (category) {
        await updateCategory(category.id, {
          ...formData,
          parent_id: formData.parent_id === 'none' ? undefined : formData.parent_id,
        });
        toast.success('Category updated successfully');
      } else {
        await createCategory({
          ...formData,
          parent_id: formData.parent_id === 'none' ? undefined : formData.parent_id,
        });
        toast.success('Category created successfully');
      }
      onSave();
    } catch (error) {
      toast.error(category ? 'Failed to update category' : 'Failed to create category');
    } finally {
      setLoading(false);
    }
  };

  const availableParents = categories.filter(c => c.id !== category?.id);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>Language Notice:</strong> Please enter all content in English. 
          Translations to other markets are managed through the Translation Engine.
        </AlertDescription>
      </Alert>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Category Name *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => handleNameChange(e.target.value)}
            placeholder="Enter category name"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="category_key">Category Key *</Label>
          <Input
            id="category_key"
            value={formData.category_key}
            onChange={(e) => setFormData(prev => ({ ...prev, category_key: e.target.value }))}
            placeholder="category_key"
            className="font-mono text-sm"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="slug">URL Slug * (English)</Label>
          <Input
            id="slug"
            value={formData.slug}
            onChange={(e) => handleSlugChange(e.target.value)}
            placeholder="url-slug"
            className="font-mono text-sm"
            required
          />
          <p className="text-xs text-muted-foreground">
            This creates the base English slug. Market-specific translations are handled via the Translation Engine.
          </p>
        </div>
        <div className="space-y-2">
          <Label htmlFor="parent_id">Parent Category</Label>
          <Select 
            value={formData.parent_id} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, parent_id: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select parent category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No parent</SelectItem>
              {availableParents.map((parent) => (
                <SelectItem key={parent.id} value={parent.id}>
                  {parent.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Brief description of this category"
          rows={3}
        />
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-medium">SEO Settings</h3>
        
        <div className="space-y-2">
          <Label htmlFor="seo_title">SEO Title</Label>
          <Input
            id="seo_title"
            value={formData.seo_title}
            onChange={(e) => setFormData(prev => ({ ...prev, seo_title: e.target.value }))}
            placeholder="SEO-optimized title for search engines"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="seo_description">SEO Description</Label>
          <Textarea
            id="seo_description"
            value={formData.seo_description}
            onChange={(e) => setFormData(prev => ({ ...prev, seo_description: e.target.value }))}
            placeholder="Brief description for search engine results"
            rows={2}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="display_order">Display Order</Label>
          <Input
            id="display_order"
            type="number"
            value={formData.display_order}
            onChange={(e) => setFormData(prev => ({ ...prev, display_order: parseInt(e.target.value) || 0 }))}
            min="0"
          />
        </div>
        <div className="flex items-center space-x-2 pt-6">
          <Switch
            id="is_active"
            checked={formData.is_active}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
          />
          <Label htmlFor="is_active">Active</Label>
        </div>
      </div>

      <DialogFooter>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? 'Saving...' : (category ? 'Update Category' : 'Create Category')}
        </Button>
      </DialogFooter>
    </form>
  );
};