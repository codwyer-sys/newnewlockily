import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useSessionValidation } from '@/hooks/useSessionValidation';
import { useToast } from '@/hooks/use-toast';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronRight } from 'lucide-react';

interface DebugPanelProps {
  className?: string;
}

export const DebugPanel: React.FC<DebugPanelProps> = ({ className }) => {
  const { user, session } = useAuth();
  const { isValidSession, validationError, validateSession } = useSessionValidation();
  const { toast } = useToast();
  const [isExpanded, setIsExpanded] = useState(false);
  const [testResults, setTestResults] = useState<Record<string, any>>({});
  const [isTesting, setIsTesting] = useState(false);

  const runDatabaseTest = async () => {
    setIsTesting(true);
    const results: Record<string, any> = {};

    try {
      // Test 1: Basic connectivity
      console.log('🔧 Testing database connectivity...');
      const start = Date.now();
      const { data: testData, error: testError } = await supabase
        .from('user_roles')
        .select('count')
        .limit(1);
      
      results.connectivity = {
        success: !testError,
        error: testError?.message,
        duration: Date.now() - start
      };

      // Test 2: User role check
      console.log('🔧 Testing user role...');
      const { data: roleData, error: roleError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user?.id)
        .limit(1);

      results.userRole = {
        success: !roleError,
        error: roleError?.message,
        roles: roleData?.map(r => r.role) || [],
        hasLocksmithRole: roleData?.some(r => r.role === 'locksmith') || false
      };

      // Test 3: Locksmith preferences
      console.log('🔧 Testing locksmith preferences...');
      const { data: prefsData, error: prefsError } = await supabase
        .from('locksmith_auto_bid_preferences')
        .select('*')
        .eq('locksmith_id', user?.id);

      results.autoBidPreferences = {
        success: !prefsError,
        error: prefsError?.message,
        count: prefsData?.length || 0,
        enabledCount: prefsData?.filter(p => p.is_enabled)?.length || 0
      };

      // Test 4: Global pricing settings
      console.log('🔧 Testing global pricing settings...');
      const { data: globalData, error: globalError } = await supabase
        .from('global_pricing_settings')
        .select('*')
        .eq('locksmith_id', user?.id)
        .maybeSingle();

      results.globalSettings = {
        success: !globalError,
        error: globalError?.message,
        exists: !!globalData
      };

      // Test 5: Referral settings
      console.log('🔧 Testing referral settings...');
      const { data: referralData, error: referralError } = await supabase
        .from('locksmith_referral_settings')
        .select('*')
        .eq('locksmith_id', user?.id)
        .maybeSingle();

      results.referralSettings = {
        success: !referralError,
        error: referralError?.message,
        exists: !!referralData,
        percentage: referralData?.default_referral_fee_percentage
      };

      // Test 6: Quote insertion capability
      console.log('🔧 Testing quote insertion permissions...');
      const { error: quoteError } = await supabase
        .from('quotes')
        .select('id')
        .eq('locksmith_id', user?.id)
        .limit(1);

      results.quotePermissions = {
        success: !quoteError,
        error: quoteError?.message
      };

      setTestResults(results);
      
      toast({
        title: "Database Test Complete",
        description: "Check the debug panel for detailed results"
      });

    } catch (error) {
      console.error('🔧 Database test failed:', error);
      results.error = error.message;
      setTestResults(results);
      
      toast({
        title: "Database Test Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsTesting(false);
    }
  };

  const getStatusColor = (success: boolean | undefined) => {
    if (success === undefined) return 'secondary';
    return success ? 'default' : 'destructive';
  };

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
          <CollapsibleTrigger asChild>
            <div className="flex items-center justify-between cursor-pointer">
              <CardTitle className="text-lg">Debug Panel</CardTitle>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  Dev Mode
                </Badge>
                {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </div>
            </div>
          </CollapsibleTrigger>
          
          <CollapsibleContent>
            <CardContent className="pt-4 space-y-4">
              {/* Authentication Status */}
              <div className="space-y-2">
                <h4 className="font-medium">Authentication Status</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>User: <Badge variant={user ? 'default' : 'destructive'}>{user ? 'Authenticated' : 'Not Auth'}</Badge></div>
                  <div>Session: <Badge variant={session ? 'default' : 'destructive'}>{session ? 'Valid' : 'Invalid'}</Badge></div>
                  <div>Session Valid: <Badge variant={getStatusColor(isValidSession)}>{isValidSession?.toString() || 'Unknown'}</Badge></div>
                  <div>User ID: <span className="font-mono text-xs">{user?.id?.slice(0, 8) || 'None'}</span></div>
                </div>
                {validationError && (
                  <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                    {validationError}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button 
                  onClick={runDatabaseTest} 
                  disabled={isTesting}
                  size="sm"
                >
                  {isTesting ? 'Testing...' : 'Test Database'}
                </Button>
                <Button 
                  onClick={validateSession} 
                  variant="outline"
                  size="sm"
                >
                  Validate Session
                </Button>
              </div>

              {/* Test Results */}
              {Object.keys(testResults).length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-medium">Test Results</h4>
                  <div className="space-y-2 text-xs">
                    {Object.entries(testResults).map(([key, result]) => (
                      <div key={key} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <span className="font-medium">{key}</span>
                        <div className="flex items-center gap-2">
                          <Badge variant={getStatusColor(result.success)}>
                            {result.success ? 'Pass' : 'Fail'}
                          </Badge>
                          {result.error && (
                            <span className="text-red-600 max-w-32 truncate" title={result.error}>
                              {result.error}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Stats */}
              {testResults.autoBidPreferences && (
                <div className="text-xs bg-blue-50 p-2 rounded">
                  <div>Auto-bid categories: {testResults.autoBidPreferences.enabledCount}/{testResults.autoBidPreferences.count}</div>
                  <div>Global settings: {testResults.globalSettings?.exists ? 'Configured' : 'Missing'}</div>
                  <div>Referral fee: {testResults.referralSettings?.percentage || 'Default (20%)'}%</div>
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </CardHeader>
    </Card>
  );
};