import React, { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Loader2, CreditCard, AlertCircle } from 'lucide-react';
import { useStripeAccount } from '@/hooks/useStripeAccount';
import StripeMissingFieldsForm from './StripeMissingFieldsForm';
import StripeAccountStatus from './StripeAccountStatus';
import StripeRequirements from './StripeRequirements';


const StripeConnectSettings = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showMissingFields, setShowMissingFields] = useState(false);
  
  const {
    loading,
    creating,
    profileLoading,
    accountStatus,
    locksmithProfile,
    setLocksmithProfile,
    fetchAccountStatus,
    proceedWithStripeCreation
  } = useStripeAccount();


  const createConnectAccount = async () => {
    // Check if locksmith profile exists and is complete
    if (!locksmithProfile) {
      toast({
        title: "Profil mangler",
        description: "Du skal først oprette din smedevirksomheds profil for at kunne modtage betalinger.",
        variant: "destructive"
      });
      return;
    }

    // Check for missing required fields
    const requiredFields = ['company_name', 'address', 'city', 'postal_code'];
    const missingFields = requiredFields.filter(field => !locksmithProfile[field]);
    
    // Also check if user has email in auth
    if (!user?.email) {
      toast({
        title: "Email mangler",
        description: "Du skal have en gyldig email adresse for at oprette en Stripe-konto.",
        variant: "destructive"
      });
      return;
    }

    // If there are missing fields, show the form instead of creating account
    if (missingFields.length > 0) {
      setShowMissingFields(true);
      return;
    }

    // All required fields are present, proceed with Stripe account creation
    await proceedWithStripeCreation();
  };


  const getStatusBadge = () => {
    if (!accountStatus?.connected || !accountStatus.account) {
      return <Badge variant="secondary">Ikke tilsluttet</Badge>;
    }

    const account = accountStatus.account;
    
    if (account.charges_enabled && account.payouts_enabled) {
      return <Badge variant="default" className="bg-green-600">Aktiv</Badge>;
    }
    
    if (account.details_submitted) {
      return <Badge variant="outline">Under behandling</Badge>;
    }
    
    return <Badge variant="destructive">Kræver handling</Badge>;
  };

  if (loading || profileLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Betalingsindstillinger</h2>
        <p className="text-muted-foreground mt-2">
          Administrer din betalingskonto for at modtage betalinger
        </p>
      </div>

      {/* Account Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="h-5 w-5" />
            <span>Betalingskonto</span>
            {getStatusBadge()}
          </CardTitle>
          <CardDescription>
            Din forbindelse til betalingssystemet for at modtage betalinger fra kunder
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!locksmithProfile ? (
            <div className="text-center py-6">
              <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
               <h3 className="text-lg font-semibold mb-2">Profil mangler</h3>
               <p className="text-muted-foreground mb-4">
                 Du skal først udfylde din smedevirksomheds profil før du kan oprette en betalingskonto.
               </p>
              <Button 
                onClick={() => window.location.href = '/locksmith-signup'}
                variant="outline"
              >
                Udfyld Profil
              </Button>
            </div>
          ) : showMissingFields ? (
            <StripeMissingFieldsForm
              locksmithProfile={locksmithProfile}
              onSave={setLocksmithProfile}
              onCancel={() => setShowMissingFields(false)}
              onComplete={proceedWithStripeCreation}
            />
          ) : !accountStatus?.connected ? (
            <div className="text-center py-6">
              <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
               <h3 className="text-lg font-semibold mb-2">Ingen betalingskonto tilsluttet</h3>
               <p className="text-muted-foreground mb-4">
                 Du skal oprette en betalingskonto for at kunne modtage betalinger fra kunder.
               </p>
               <Button onClick={createConnectAccount} disabled={creating}>
                 {creating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                 Opret betalingskonto
               </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <StripeAccountStatus 
                accountStatus={accountStatus} 
                onRefreshStatus={fetchAccountStatus} 
              />
              <StripeRequirements accountStatus={accountStatus} />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction History Card - Placeholder for now */}
      <Card>
        <CardHeader>
          <CardTitle>Transaktionshistorik</CardTitle>
          <CardDescription>
            Oversigt over betalinger og udbetalinger
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p>Transaktionshistorik vil blive vist her når du begynder at modtage betalinger.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StripeConnectSettings;