import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Footer7 } from "@/components/ui/footer-7";
import { FaFacebook, FaInstagram, FaTwitter, FaPhone } from "react-icons/fa";

const LocksmithFooter = () => {
  const locksmithSections = [
    {
      title: "Tjenester",
      links: [
        { name: "Akut låseservice", href: "#services" },
        { name: "Låsudskiftning", href: "#services" },
        { name: "Nøgleservice", href: "#services" },
        { name: "Sikkerhedsrådgivning", href: "/postnummer-sikkerhed" },
      ],
    },
    {
      title: "Information",
      links: [
        { name: "Sådan virker det", href: "#how-it-works" },
        { name: "Priser", href: "#pricing" },
        { name: "Postnummer sikkerhed", href: "/postnummer-sikkerhed" },
        { name: "Bliv låsesmed-partner", href: "/locksmith-signup" },
      ],
    },
    {
      title: "Support",
      links: [
        { name: "Ring nu: 70 20 30 40", href: "tel:70203040" },
        { name: "Ofte stillede spørgsmål", href: "#faq" },
        { name: "Kontakt os", href: "#contact" },
        { name: "Administration", href: "/content-admin" },
      ],
    },
  ];

  const socialLinks = [
    { icon: <FaFacebook className="size-5" />, href: "#", label: "Facebook" },
    { icon: <FaInstagram className="size-5" />, href: "#", label: "Instagram" },
    { icon: <FaTwitter className="size-5" />, href: "#", label: "Twitter" },
    { icon: <FaPhone className="size-5" />, href: "tel:70203040", label: "Ring nu" },
  ];

  const legalLinks = [
    { name: "Handelsbetingelser", href: "#terms" },
    { name: "Privatlivspolitik", href: "#privacy" },
    { name: "Cookiepolitik", href: "#cookies" },
  ];

  return (
    <Footer7
      logo={{
        url: "/",
        src: "/lovable-uploads/57166235-1698-4ec1-b97a-4f4ed9310ab8.png",
        alt: "Lockily",
        title: "",
      }}
      sections={locksmithSections}
      description="Danmarks hurtigste låseservice platform. Få øjeblikkelige tilbud fra certificerede låsesmede i dit område på under 20 sekunder."
      socialLinks={socialLinks}
      copyright="© 2024 Lockily. Alle rettigheder forbeholdes."
      legalLinks={legalLinks}
    />
  );
};

export default LocksmithFooter;