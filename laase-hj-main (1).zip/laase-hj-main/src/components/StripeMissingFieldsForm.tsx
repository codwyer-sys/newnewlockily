import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertCircle, Save, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface MissingFieldsForm {
  company_name: string;
  address: string;
  city: string;
  postal_code: string;
  contact_person: string;
}

interface Props {
  locksmithProfile: any;
  onSave: (updatedProfile: any) => void;
  onCancel: () => void;
  onComplete: () => Promise<void>;
}

const StripeMissingFieldsForm: React.FC<Props> = ({ 
  locksmithProfile, 
  onSave, 
  onCancel, 
  onComplete 
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [missingFieldsForm, setMissingFieldsForm] = useState<MissingFieldsForm>({
    company_name: locksmithProfile?.company_name || '',
    address: locksmithProfile?.address || '',
    city: locksmithProfile?.city || '',
    postal_code: locksmithProfile?.postal_code || '',
    contact_person: locksmithProfile?.contact_person || ''
  });

  const saveMissingFields = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update(missingFieldsForm)
        .eq('id', user?.id);

      if (error) throw error;

      // Update local state
      const updatedProfile = { ...locksmithProfile, ...missingFieldsForm };
      onSave(updatedProfile);
      
      toast({
        title: "Profil opdateret",
        description: "Dine oplysninger er gemt. Opretter nu Stripe-konto..."
      });

      // Now proceed with Stripe account creation
      await onComplete();
    } catch (error: any) {
      toast({
        title: "Fejl",
        description: error.message || "Kunne ikke gemme oplysninger.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const isFormValid = missingFieldsForm.company_name && 
                     missingFieldsForm.address && 
                     missingFieldsForm.city && 
                     missingFieldsForm.postal_code;

  return (
    <div className="space-y-4">
      <div className="text-center mb-4">
        <AlertCircle className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
        <h3 className="text-lg font-semibold mb-1">Udfyld manglende oplysninger</h3>
        <p className="text-muted-foreground text-sm">
          Vi skal bruge disse oplysninger for at oprette din Stripe-konto
        </p>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        <div>
          <Label htmlFor="company_name">Virksomhedsnavn *</Label>
          <Input
            id="company_name"
            value={missingFieldsForm.company_name}
            onChange={(e) => setMissingFieldsForm(prev => ({ ...prev, company_name: e.target.value }))}
            placeholder="Indtast virksomhedsnavn"
          />
        </div>
        
        <div>
          <Label htmlFor="address">Adresse *</Label>
          <Input
            id="address"
            value={missingFieldsForm.address}
            onChange={(e) => setMissingFieldsForm(prev => ({ ...prev, address: e.target.value }))}
            placeholder="Indtast adresse"
          />
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label htmlFor="postal_code">Postnummer *</Label>
            <Input
              id="postal_code"
              value={missingFieldsForm.postal_code}
              onChange={(e) => setMissingFieldsForm(prev => ({ ...prev, postal_code: e.target.value }))}
              placeholder="1234"
            />
          </div>
          <div>
            <Label htmlFor="city">By *</Label>
            <Input
              id="city"
              value={missingFieldsForm.city}
              onChange={(e) => setMissingFieldsForm(prev => ({ ...prev, city: e.target.value }))}
              placeholder="København"
            />
          </div>
        </div>
        
        <div>
          <Label htmlFor="contact_person">Kontaktperson</Label>
          <Input
            id="contact_person"
            value={missingFieldsForm.contact_person}
            onChange={(e) => setMissingFieldsForm(prev => ({ ...prev, contact_person: e.target.value }))}
            placeholder="Indtast kontaktperson"
          />
        </div>
      </div>
      
      <div className="flex space-x-2 pt-4">
        <Button 
          onClick={saveMissingFields} 
          disabled={saving || !isFormValid}
          className="flex-1"
        >
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          <Save className="mr-2 h-4 w-4" />
          Gem og opret Stripe-konto
        </Button>
        <Button 
          variant="outline" 
          onClick={onCancel}
          disabled={saving}
        >
          Annuller
        </Button>
      </div>
    </div>
  );
};

export default StripeMissingFieldsForm;