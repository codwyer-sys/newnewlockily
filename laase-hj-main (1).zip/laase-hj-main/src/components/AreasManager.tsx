import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, MapPin, Hash } from 'lucide-react';
import { useAreas, Area } from '@/hooks/useAreas';
import { useCities, City } from '@/hooks/useCities';
import { useMarket } from '@/contexts/MarketContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface AreaFormData {
  name: string;
  slug: string;
  city_id: string;
  latitude?: number;
  longitude?: number;
  postal_codes: string[];
  seo_title?: string;
  seo_description?: string;
  seo_keywords: string[];
  featured_image_url?: string;
  featured_image_alt?: string;
  is_active: boolean;
}

export const AreasManager: React.FC = () => {
  const { market } = useMarket();
  const { cities } = useCities(market.country_code);
  const { areas, loading, fetchAreas } = useAreas();
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<Area | null>(null);
  const [selectedCityId, setSelectedCityId] = useState<string>('');
  const [formData, setFormData] = useState<AreaFormData>({
    name: '',
    slug: '',
    city_id: '',
    postal_codes: [],
    seo_keywords: [],
    is_active: true,
  });

  // Filter cities to only metropolitan ones
  const metropolitanCities = cities.filter(city => city.is_metropolitan);

  const resetForm = () => {
    setFormData({
      name: '',
      slug: '',
      city_id: selectedCityId || '',
      postal_codes: [],
      seo_keywords: [],
      is_active: true,
    });
    setEditingArea(null);
  };

  const openEditDialog = (area: Area) => {
    setEditingArea(area);
    setFormData({
      name: area.name,
      slug: area.slug,
      city_id: area.city_id,
      latitude: area.latitude,
      longitude: area.longitude,
      postal_codes: area.postal_codes || [],
      seo_title: area.seo_title,
      seo_description: area.seo_description,
      seo_keywords: area.seo_keywords || [],
      featured_image_url: area.featured_image_url,
      featured_image_alt: area.featured_image_alt,
      is_active: area.is_active,
    });
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.city_id) {
      toast({
        title: 'Error',
        description: 'Please select a city',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      const areaData = {
        ...formData,
        postal_codes: formData.postal_codes.filter(pc => pc.trim()),
        seo_keywords: formData.seo_keywords.filter(k => k.trim()),
      };

      if (editingArea) {
        const { error } = await supabase
          .from('areas')
          .update(areaData)
          .eq('id', editingArea.id);
        
        if (error) throw error;
        
        toast({
          title: 'Success',
          description: 'Area updated successfully',
        });
      } else {
        const { error } = await supabase
          .from('areas')
          .insert([areaData]);
        
        if (error) throw error;
        
        toast({
          title: 'Success',
          description: 'Area created successfully',
        });
      }
      
      setDialogOpen(false);
      resetForm();
      fetchAreas();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save area',
        variant: 'destructive',
      });
    }
  };

  const handleDelete = async (areaId: string) => {
    try {
      const { error } = await supabase
        .from('areas')
        .delete()
        .eq('id', areaId);
      
      if (error) throw error;
      
      toast({
        title: 'Success',
        description: 'Area deleted successfully',
      });
      
      fetchAreas();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete area',
        variant: 'destructive',
      });
    }
  };

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  const handleNameChange = (name: string) => {
    setFormData(prev => ({
      ...prev,
      name,
      slug: prev.slug || generateSlug(name),
    }));
  };

  const getCityName = (cityId: string) => {
    const city = cities.find(c => c.id === cityId);
    return city?.name || 'Unknown City';
  };

  // Filter areas by selected city if one is selected
  const filteredAreas = selectedCityId 
    ? areas.filter(area => area.city_id === selectedCityId)
    : areas;

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Areas Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-row items-center justify-between">
          <CardTitle>Areas Management</CardTitle>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm} disabled={metropolitanCities.length === 0}>
                <Plus className="h-4 w-4 mr-2" />
                Add Area
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingArea ? 'Edit Area' : 'Add New Area'}</DialogTitle>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="city_id">Metropolitan City</Label>
                  <Select
                    value={formData.city_id}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, city_id: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a metropolitan city" />
                    </SelectTrigger>
                    <SelectContent>
                      {metropolitanCities.map((city) => (
                        <SelectItem key={city.id} value={city.id}>
                          {city.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Area Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleNameChange(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="slug">URL Slug</Label>
                    <Input
                      id="slug"
                      value={formData.slug}
                      onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="latitude">Latitude</Label>
                    <Input
                      id="latitude"
                      type="number"
                      step="any"
                      value={formData.latitude || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, latitude: e.target.value ? parseFloat(e.target.value) : undefined }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="longitude">Longitude</Label>
                    <Input
                      id="longitude"
                      type="number"
                      step="any"
                      value={formData.longitude || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, longitude: e.target.value ? parseFloat(e.target.value) : undefined }))}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="postal_codes">Postal Codes (comma-separated)</Label>
                  <Input
                    id="postal_codes"
                    value={formData.postal_codes.join(', ')}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      postal_codes: e.target.value.split(',').map(s => s.trim()).filter(s => s)
                    }))}
                    placeholder="2100, 2200, 2300"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
                  />
                  <Label htmlFor="is_active">Active</Label>
                </div>

                <div>
                  <Label htmlFor="seo_title">SEO Title</Label>
                  <Input
                    id="seo_title"
                    value={formData.seo_title || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, seo_title: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="seo_description">SEO Description</Label>
                  <Textarea
                    id="seo_description"
                    value={formData.seo_description || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, seo_description: e.target.value }))}
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="featured_image_url">Featured Image URL</Label>
                    <Input
                      id="featured_image_url"
                      value={formData.featured_image_url || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, featured_image_url: e.target.value }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="featured_image_alt">Featured Image Alt Text</Label>
                    <Input
                      id="featured_image_alt"
                      value={formData.featured_image_alt || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, featured_image_alt: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingArea ? 'Update' : 'Create'} Area
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        
        {metropolitanCities.length > 0 && (
          <div className="mt-4">
            <Label htmlFor="city-filter">Filter by City</Label>
            <Select value={selectedCityId} onValueChange={setSelectedCityId}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="All cities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All cities</SelectItem>
                {metropolitanCities.map((city) => (
                  <SelectItem key={city.id} value={city.id}>
                    {city.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </CardHeader>
      
      <CardContent>
        {metropolitanCities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No metropolitan cities found. Areas can only be created for metropolitan cities.
          </div>
        ) : (
          <div className="space-y-4">
            {filteredAreas.map((area) => (
              <div key={area.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold">{area.name}</h3>
                    <Badge variant="outline">{getCityName(area.city_id)}</Badge>
                    {!area.is_active && (
                      <Badge variant="destructive">Inactive</Badge>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>/{area.slug}</span>
                    
                    {area.latitude && area.longitude && (
                      <div className="flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span>{area.latitude.toFixed(2)}, {area.longitude.toFixed(2)}</span>
                      </div>
                    )}
                    
                    {area.postal_codes && area.postal_codes.length > 0 && (
                      <div className="flex items-center">
                        <Hash className="h-3 w-3 mr-1" />
                        <span>{area.postal_codes.length} postal codes</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(area)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Area</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete "{area.name}"? This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(area.id)}>
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
            
            {filteredAreas.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                {selectedCityId ? 'No areas found for this city.' : 'No areas found. Add your first area to get started.'}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};