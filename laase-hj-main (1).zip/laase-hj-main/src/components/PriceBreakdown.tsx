import React from 'react';
import { PriceBreakdown as PriceBreakdownType } from '@/utils/priceCalculator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calculator, Clock, MapPin } from 'lucide-react';

interface PriceBreakdownProps {
  breakdown: PriceBreakdownType;
  className?: string;
}

export const PriceBreakdown: React.FC<PriceBreakdownProps> = ({ breakdown, className }) => {
  const formatCurrency = (amount: number) => `${amount.toFixed(0)} kr`;

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Calculator className="w-4 h-4" />
          Prisberegning
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Base Price */}
        <div className="flex justify-between items-center">
          <span className="text-sm">Grundpris</span>
          <span className="font-medium">{formatCurrency(breakdown.basePrice)}</span>
        </div>

        {/* Follow-up Question Fees */}
        {breakdown.followUpFees.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium text-muted-foreground">Tillæg for svar:</div>
            {breakdown.followUpFees.map((fee, index) => (
              <div key={index} className="flex justify-between items-start text-sm pl-4">
                <div className="flex-1">
                  <div className="truncate">{fee.question}</div>
                  <div className="text-xs text-muted-foreground">
                    {fee.answer} ({fee.type === 'percentage' ? `${(fee.fee / breakdown.basePrice * 100).toFixed(0)}%` : 'fast beløb'})
                  </div>
                </div>
                <span className="ml-2 font-medium">+{formatCurrency(fee.fee)}</span>
              </div>
            ))}
          </div>
        )}

        {/* Time Surcharge */}
        {breakdown.timeSurcharge.amount > 0 && (
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Clock className="w-3 h-3" />
              <span className="text-sm">
                {breakdown.timeSurcharge.type === 'both' && 'Nat + weekend tillæg'}
                {breakdown.timeSurcharge.type === 'nighttime' && 'Nattillæg'}
                {breakdown.timeSurcharge.type === 'weekend' && 'Weekend tillæg'}
              </span>
            </div>
            <span className="font-medium">+{formatCurrency(breakdown.timeSurcharge.amount)}</span>
          </div>
        )}

        {/* Distance Fee */}
        {breakdown.distanceFee > 0 && (
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <MapPin className="w-3 h-3" />
              <span className="text-sm">Afstandstillæg</span>
            </div>
            <span className="font-medium">+{formatCurrency(breakdown.distanceFee)}</span>
          </div>
        )}


        {/* Total */}
        <div className="border-t pt-3 flex justify-between items-center">
          <span className="font-semibold">Total foreslået pris</span>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              AutoByd
            </Badge>
            <span className="font-bold text-lg">{formatCurrency(breakdown.total)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};