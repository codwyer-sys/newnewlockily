import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useMarket } from '@/contexts/MarketContext';
import { useMarketUrl } from '@/hooks/useMarketUrl';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string[];
  canonicalUrl?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
  // For blog posts - enables hreflang generation
  isGlobalContent?: boolean;
  contentSlug?: string;
  // Available markets for hreflang (if global content)
  availableMarkets?: Array<{ country_code: string; country_name: string }>;
  // Structured data
  structuredData?: object;
}

export const SEOHead: React.FC<SEOHeadProps> = ({
  title,
  description,
  keywords,
  canonicalUrl,
  ogTitle,
  ogDescription,
  ogImage,
  twitterTitle,
  twitterDescription,
  twitterImage,
  isGlobalContent = false,
  contentSlug,
  availableMarkets = [],
  structuredData
}) => {
  const { market } = useMarket();
  const { generateUrl } = useMarketUrl();

  // Generate canonical URL if not provided
  const finalCanonicalUrl = canonicalUrl || 
    (typeof window !== 'undefined' ? window.location.href : '');

  // Generate hreflang URLs for global content
  const hreflangUrls = isGlobalContent && contentSlug && availableMarkets.length > 0
    ? availableMarkets.map(m => ({
        hreflang: m.country_code.toLowerCase(),
        url: `${window.location.origin}${generateUrl(`blog/${contentSlug}`, m.country_code)}`
      }))
    : [];

  // Market-specific title suffix
  const marketTitle = title ? `${title} | ${market.country_name}` : market.country_name;

  return (
    <Helmet>
      {/* Basic meta tags */}
      <title>{marketTitle}</title>
      {description && <meta name="description" content={description} />}
      {keywords && keywords.length > 0 && (
        <meta name="keywords" content={keywords.join(', ')} />
      )}
      
      {/* Canonical URL */}
      <link rel="canonical" href={finalCanonicalUrl} />
      
      {/* Hreflang tags for global content */}
      {hreflangUrls.map(({ hreflang, url }) => (
        <link key={hreflang} rel="alternate" hrefLang={hreflang} href={url} />
      ))}
      
      {/* Open Graph tags */}
      <meta property="og:title" content={ogTitle || marketTitle} />
      <meta property="og:description" content={ogDescription || description || ''} />
      <meta property="og:url" content={finalCanonicalUrl} />
      <meta property="og:type" content="article" />
      <meta property="og:locale" content={getLocaleForMarket(market.country_code)} />
      {ogImage && <meta property="og:image" content={ogImage} />}
      
      {/* Twitter Card tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={twitterTitle || ogTitle || marketTitle} />
      <meta name="twitter:description" content={twitterDescription || ogDescription || description || ''} />
      {twitterImage && <meta name="twitter:image" content={twitterImage} />}
      
      {/* Market-specific meta tags */}
      <meta name="geo.region" content={market.country_code} />
      <meta name="geo.placename" content={market.country_name} />
      
      {/* Structured data */}
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
};

// Helper function to get locale string for market
const getLocaleForMarket = (countryCode: string): string => {
  const localeMap: Record<string, string> = {
    'DK': 'da_DK',
    'NO': 'nb_NO',
    'SE': 'sv_SE',
    'UK': 'en_GB',
    'US': 'en_US',
    'DE': 'de_DE',
    'FR': 'fr_FR',
    'ES': 'es_ES',
    'IT': 'it_IT',
    'CA': 'en_CA',
    'PL': 'pl_PL',
    'CZ': 'cs_CZ',
    'PT': 'pt_PT',
    'FI': 'fi_FI',
    'IE': 'en_IE'
  };
  
  return localeMap[countryCode] || 'en_US';
};