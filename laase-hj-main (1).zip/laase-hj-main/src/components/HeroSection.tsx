import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MapPin, Shield, Clock, Users } from 'lucide-react';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useMarketAddressSearch } from '@/hooks/useMarketAddressSearch';
import { useMarketAwareBookingForm } from "@/hooks/useMarketAwareBookingForm";
import { useLocksmithData } from "@/hooks/useLocksmithData";
import UrgencySelector from "@/components/UrgencySelector";
import JobTypeSelector from "@/components/JobTypeSelector";
import FollowUpQuestions from "@/components/FollowUpQuestions";
import BookingButtons from "@/components/BookingButtons";
import ContactInfoDialog from "@/components/ContactInfoDialog";
import { useLanguage } from '@/contexts/LanguageContext';
import { useMarket } from '@/contexts/MarketContext';
import { useNavigate } from 'react-router-dom';
const HeroSection: React.FC = () => {
  const { t } = useLanguage();
  const { market } = useMarket();
  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(true);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [showContactDialog, setShowContactDialog] = useState(false);
  const [localIsBookingInProgress, setLocalIsBookingInProgress] = useState(false);
  const { getCurrentLocation, isLoadingLocation } = useGeolocation();
  
  const {
    // Address props
    address,
    setAddress,
    skipAddressSearch,
    setSkipAddressSearch,
    showSuggestions,
    setShowSuggestions,
    hasSelectedSuggestion,
    setHasSelectedSuggestion,
    addressSuggestions,
    isAddressLoading,
    handleAddressSelect,
    
    // Urgency props
    urgency,
    selectedDate,
    onUrgencySelect,
    onDateChange,
    showUrgency,
    
    // Job type props
    jobType,
    onJobTypeSelect,
    showJobType,
    
    // Follow up props
    followUpAnswers,
    onFollowUpAnswer,
    showFollowUp,
    
    // Booking props
    showBookingButtons,
    isBookingDisabled,
    isBookingInProgress,
    handleStartBooking,
    
    // Market-specific helpers
    getAddressPlaceholder,
    addressError
  } = useMarketAwareBookingForm();
  
  const { createBooking } = useLocksmithData();
  

  const handleAddressChange = (value: string) => {
    setAddress(value);
    setSkipAddressSearch(false);
    setHasSelectedSuggestion(false);
    
    // Show suggestions when typing if there's content
    if (value.length >= 3) {
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };
  const handleAddressSelectLocal = (selectedAddress: string) => {
    handleAddressSelect(selectedAddress);
    setShowBookingForm(true);
  };
  const handleGetLocation = async () => {
    const location = await getCurrentLocation();
    if (location) {
      setHasSelectedSuggestion(true);
      setShowSuggestions(false);
      setSkipAddressSearch(true);
      setAddress(location);
      setShowBookingForm(true);
      // Also trigger the image analysis by calling the same logic as address selection
      handleAddressSelect(location);
    }
  };

  const handleBookingButtonClick = () => {
    setShowContactDialog(true);
  };

  const handleContactInfoSubmit = async (contactInfo: { name: string; phone: string }) => {
    // Prevent multiple submissions
    if (localIsBookingInProgress) {
      console.log('⚠️ Booking already in progress, ignoring duplicate submission');
      return;
    }

    setLocalIsBookingInProgress(true);
    
    try {
      console.log('🚀 Starting booking submission process');
      
      // Update follow-up answers with contact info
      const updatedFollowUpAnswers = {
        ...followUpAnswers,
        customerName: contactInfo.name,
        customerPhone: contactInfo.phone
      };
      
      // Create booking directly with the locksmith data hook
      const bookingData = {
        address,
        urgency,
        selectedDate,
        jobType,
        followUpAnswers: updatedFollowUpAnswers
      };
      
      const booking = await createBooking(bookingData);
      
      console.log('✅ Booking created successfully, navigating to status page');
      
      // Close dialog and navigate to waiting page
      setShowContactDialog(false);
      navigate(`/${market.country_code.toLowerCase()}/booking-status/${booking.id}`);
      
    } catch (error) {
      console.error('❌ Booking submission failed:', error);
      
      // Show user-friendly error message
      let errorMessage = 'Der opstod en fejl ved oprettelse af din booking. Prøv venligst igen.';
      
      if ((error as any)?.message?.includes('Job category not found')) {
        errorMessage = 'Den valgte service blev ikke fundet. Prøv venligst at vælge en service igen.';
      } else if ((error as any)?.message?.includes('unique_job_number')) {
        errorMessage = 'Der opstod en teknisk fejl. Prøv venligst igen om et øjeblik.';
      }
      
      // Use toast notification for error feedback
      // toast.error(errorMessage); // Uncomment if you want to show toast
      alert(errorMessage); // Simple alert for now
      
    } finally {
      setLocalIsBookingInProgress(false);
    }
  };
  return <section className="pt-24 pb-16 lg:pt-32 lg:pb-24 bg-background">
      <div className="container-wide">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            {/* Enhanced Badge */}
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-success text-white text-sm font-semibold mb-8 shadow-lg">
              <Shield className="w-5 h-5 mr-2" />
              {t('home.hero.subtitle')}
            </div>

            {/* Enhanced Headline */}
            <h1 className="text-heading-hero font-headline font-bold text-foreground mb-8 leading-tight">
              {t('home.hero.title')}
            </h1>
            
            {/* Value Proposition */}
            <p className="text-body-lg text-foreground mb-10 max-w-lg mx-auto lg:mx-0">
              {t('home.hero.description')}
            </p>

            {/* Enhanced Booking Form Container */}
            <div className="bg-card rounded-xl p-6 md:p-8 border-2 border-primary/20 mb-6 md:mb-8 shadow-xl hover:shadow-2xl transition-all duration-300 space-y-6 md:space-y-8 relative overflow-hidden">
              {/* Urgency indicator */}
              {urgency === 'nu' && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cta-primary to-warning"></div>
              )}
              {/* Address Section */}
              <div>
                <div className="space-y-4">
                  <div className="relative">
                    <Input 
                      type="text" 
                      placeholder={t('home.hero.address_placeholder')}
                      value={address}
                      onChange={e => handleAddressChange(e.target.value)} 
                      className="text-lg md:text-xl p-6 md:p-8 h-18 md:h-22 bg-white text-card-foreground border-2 border-primary/50 focus:border-primary focus:ring-4 focus:ring-primary/20 rounded-2xl font-semibold placeholder:text-muted-foreground/70 shadow-xl hover:shadow-2xl transition-all duration-300 focus:scale-[1.02]" 
                    />
                    
                    {/* Address Suggestions Dropdown */}
                    {showSuggestions && addressSuggestions.length > 0 && address.length > 2 && (
                      <div className="absolute top-full left-0 right-0 bg-white border border-border rounded-lg mt-1 shadow-lg z-20 max-h-48 overflow-y-auto">
                        {addressSuggestions.map((suggestion, index) => (
                          <button key={index} className="w-full text-left px-3 py-3 hover:bg-secondary/50 active:bg-secondary transition-colors border-b border-border/50 last:border-b-0 first:rounded-t-lg last:rounded-b-lg group" onClick={() => handleAddressSelectLocal(suggestion.fullAddress)}>
                            <div className="font-medium text-card-foreground text-sm group-hover:text-card-foreground/90">
                              {suggestion.displayText}
                            </div>
                            <div className="text-xs text-muted-foreground mt-0.5 group-hover:text-muted-foreground/80">
                              {t('home.hero.click_to_select')}
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                    
                    {/* Loading State */}
                    {isAddressLoading && address.length > 2 && (
                      <div className="absolute top-full left-0 right-0 bg-white border-2 border-border rounded-lg mt-1 shadow-xl z-20 px-4 py-4">
                        <div className="text-sm text-muted-foreground flex items-center">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                          Søger efter adresser...
                        </div>
                      </div>
                    )}
                    
                    {/* Error State */}
                    {addressError && address.length > 2 && (
                      <div className="absolute top-full left-0 right-0 bg-white border-2 border-border rounded-lg mt-1 shadow-xl z-20 px-4 py-4">
                        <div className="text-sm text-red-600">
                          {addressError}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-px bg-border"></div>
                    <span className="text-muted-foreground text-xs font-medium px-2">{t('home.hero.or')}</span>
                    <div className="flex-1 h-px bg-border"></div>
                  </div>
                  
                  <Button 
                    variant="default" 
                    onClick={handleGetLocation} 
                    disabled={isLoadingLocation}
                    className="w-full h-14 md:h-18 text-base md:text-xl font-headline font-bold btn-location rounded-xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <MapPin className={`w-6 h-6 md:w-7 md:h-7 mr-3 md:mr-4 ${isLoadingLocation ? 'animate-spin' : ''}`} />
                    {isLoadingLocation ? t('home.hero.getting_location') : t('home.hero.use_location')}
                  </Button>
                </div>
              </div>

              {/* Progressive Form Sections */}
              {showBookingForm && (
                <div className="space-y-4 md:space-y-6 animate-fade-in">
                  {showJobType && (
                    <div className="animate-fade-in">
                      <JobTypeSelector
                        jobType={jobType}
                        onJobTypeSelect={onJobTypeSelect}
                      />
                    </div>
                  )}

                  {showFollowUp && jobType && (
                    <div className="animate-fade-in">
                      <FollowUpQuestions
                        jobType={jobType}
                        answers={followUpAnswers}
                        onAnswerChange={onFollowUpAnswer}
                      />
                    </div>
                  )}

                  <UrgencySelector
                    urgency={urgency}
                    selectedDate={selectedDate}
                    onUrgencySelect={onUrgencySelect}
                    onDateChange={onDateChange}
                    showUrgency={showUrgency}
                  />

                  {showBookingButtons && (
                    <div className="animate-fade-in">
                       <BookingButtons
                         isDisabled={isBookingDisabled}
                         isBookingInProgress={localIsBookingInProgress}
                         onStartBooking={handleBookingButtonClick}
                       />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Phone CTA */}
            {!showBookingForm && (
              <div className="text-center lg:text-left">
                <p className="text-sm text-foreground/60 mb-2">{t('home.hero.prefer_call')}</p>
                <Button variant="outline" size="lg" className="font-headline bg-background border-foreground/20 text-foreground hover:bg-foreground/10">
                  {t('home.hero.call_number')}
                </Button>
              </div>
            )}
          </div>

          {/* Enhanced Right Content - Social Proof Cards */}
          {!showBookingForm && (
            <div className="grid grid-cols-1 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-xl border-l-4 border-primary">
              <div className="flex items-center space-x-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <Clock className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <div className="font-headline font-bold text-foreground text-xl mb-1">{t('home.hero.service_24_7')}</div>
                  <div className="text-muted-foreground text-base">{t('home.hero.service_24_7_desc')}</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-xl border-l-4 border-success">
              <div className="flex items-center space-x-6">
                <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center">
                  <Shield className="w-8 h-8 text-success" />
                </div>
                <div>
                  <div className="font-headline font-bold text-foreground text-xl mb-1">{t('home.hero.certified_count')}</div>
                  <div className="text-muted-foreground text-base">{t('home.hero.certified_desc')}</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl p-8 shadow-xl border-l-4 border-primary">
              <div className="flex items-center space-x-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <Users className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <div className="font-headline font-bold text-foreground text-xl mb-1">{t('home.hero.satisfied_count')}</div>
                  <div className="text-muted-foreground text-base">{t('home.hero.satisfied_desc')}</div>
                </div>
              </div>
            </div>
            </div>
          )}
        </div>
      </div>

      {/* Contact Info Dialog */}
       <ContactInfoDialog
         open={showContactDialog}
         onOpenChange={setShowContactDialog}
         onSubmit={handleContactInfoSubmit}
         isSubmitting={localIsBookingInProgress}
       />
    </section>;
};
export default HeroSection;