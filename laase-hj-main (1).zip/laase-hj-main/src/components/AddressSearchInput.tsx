import React, { useState, useRef } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin, Check } from "lucide-react";
import { useMarketAddressSearch } from '@/hooks/useMarketAddressSearch';
import { AddressSearchResult } from '@/services/address/types';

interface AddressSearchInputProps {
  label: string;
  value: string;
  onChange: (address: string, coordinates?: { lat: number; lng: number }) => void;
  placeholder?: string;
  required?: boolean;
}

const AddressSearchInput: React.FC<AddressSearchInputProps> = ({
  label,
  value,
  onChange,
  placeholder = "Indtast adresse",
  required = false
}) => {
  const [query, setQuery] = useState(value);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const { suggestions, isLoading, error } = useMarketAddressSearch(query, true);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setQuery(newValue);
    setShowSuggestions(true);
    
    // If user clears the input, also clear the parent state
    if (!newValue.trim()) {
      onChange('');
    }
  };

  const handleSuggestionClick = (suggestion: AddressSearchResult) => {
    const formattedAddress = suggestion.fullAddress || suggestion.displayText;
    setQuery(formattedAddress);
    setShowSuggestions(false);
    
    // Extract coordinates if available
    const coordinates = suggestion.coordinates ? {
      lat: suggestion.coordinates.latitude,
      lng: suggestion.coordinates.longitude
    } : undefined;
    
    onChange(formattedAddress, coordinates);
    inputRef.current?.blur();
  };

  const handleFocus = () => {
    if (query.length >= 3) {
      setShowSuggestions(true);
    }
  };

  const handleBlur = () => {
    // Delay hiding suggestions to allow click events
    setTimeout(() => setShowSuggestions(false), 200);
  };

  return (
    <div className="space-y-2">
      <Label htmlFor={label.toLowerCase().replace(/\s+/g, '_')}>
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="relative">
        <div className="relative">
          <Input
            ref={inputRef}
            id={label.toLowerCase().replace(/\s+/g, '_')}
            type="text"
            value={query}
            onChange={handleInputChange}
            onFocus={handleFocus}
            onBlur={handleBlur}
            placeholder={placeholder}
            className="pl-10"
          />
          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        </div>
        
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-60 overflow-y-auto">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                type="button"
                className="w-full text-left px-4 py-3 hover:bg-accent hover:text-accent-foreground transition-colors border-b border-border last:border-b-0 flex items-center gap-2"
                onClick={() => handleSuggestionClick(suggestion)}
              >
                <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span className="truncate">
                  {suggestion.fullAddress || suggestion.displayText}
                </span>
              </button>
            ))}
          </div>
        )}
        
        {error && (
          <p className="text-sm text-destructive mt-1">{error}</p>
        )}
        
        {isLoading && (
          <p className="text-sm text-muted-foreground mt-1">Søger adresser...</p>
        )}
      </div>
    </div>
  );
};

export default AddressSearchInput;