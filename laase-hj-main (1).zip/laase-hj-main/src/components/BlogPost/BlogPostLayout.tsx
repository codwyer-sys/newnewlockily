import React from 'react';
import { MarketAwareBlogPost } from '@/hooks/useMarketAwareBlogPosts';
import { BlogPostHero } from './BlogPostHero';
import { BlogAuthor } from './BlogAuthor';
import { TableOfContents } from './TableOfContents';
import { SocialShareButtons } from './SocialShareButtons';
import { RelatedPosts } from './RelatedPosts';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { useMarket } from '@/contexts/MarketContext';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { processQuillContent } from '@/utils/processQuillContent';
import 'quill/dist/quill.snow.css';

interface BlogPostLayoutProps {
  post: MarketAwareBlogPost;
  readingTime: number;
}

export const BlogPostLayout: React.FC<BlogPostLayoutProps> = ({ post, readingTime }) => {
  const { market } = useMarket();
  const { categories } = useBlogCategories(market.country_code, 'en');
  const currentUrl = window.location.href;
  const title = post.market_title || post.title;
  const excerpt = post.market_excerpt || post.excerpt;
  const rawContent = post.market_content || post.content;
  const content = processQuillContent(rawContent);
  
  // Get the category for this post
  const category = post.category_id ? categories.find(c => c.id === post.category_id) : null;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <BlogPostHero post={post} readingTime={readingTime} />

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Two Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content Column */}
            <div className="lg:col-span-3">
              {/* Article Content */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <div 
                    className="quill-content prose prose-lg max-w-none dark:prose-invert
                      prose-headings:scroll-mt-24
                      prose-h2:text-2xl prose-h2:font-bold prose-h2:mt-12 prose-h2:mb-6
                      prose-h3:text-xl prose-h3:font-semibold prose-h3:mt-8 prose-h3:mb-4
                      prose-h4:text-lg prose-h4:font-medium prose-h4:mt-6 prose-h4:mb-3
                      prose-p:text-base prose-p:leading-7 prose-p:mb-4
                      prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                      prose-img:rounded-lg prose-img:shadow-md
                      prose-blockquote:border-l-4 prose-blockquote:border-primary prose-blockquote:pl-6 prose-blockquote:italic
                      prose-code:bg-muted prose-code:px-2 prose-code:py-1 prose-code:rounded
                      prose-pre:bg-muted prose-pre:p-4 prose-pre:rounded-lg
                      prose-li:mb-2
                      prose-ul:mb-6 prose-ol:mb-6
                      [&_.ql-editor]:p-0 [&_.ql-editor]:border-0"
                    dangerouslySetInnerHTML={{ __html: content }}
                  />
                </CardContent>
              </Card>

              {/* Social Share */}
              <SocialShareButtons
                url={currentUrl}
                title={title}
                description={excerpt}
                className="mb-8"
              />

              {/* Author Info */}
              <div className="mb-8">
                <BlogAuthor authorId={post.author_id} category={category} />
              </div>

              {/* Related Posts */}
              <RelatedPosts currentPost={post} />
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="space-y-6">
                {/* Table of Contents */}
                <TableOfContents content={rawContent} />

                {/* Mobile Social Share */}
                <div className="lg:hidden">
                  <SocialShareButtons
                    url={currentUrl}
                    title={title}
                    description={excerpt}
                  />
                </div>

                {/* Author Info (Mobile) */}
                <div className="lg:hidden">
                  <BlogAuthor authorId={post.author_id} category={category} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};