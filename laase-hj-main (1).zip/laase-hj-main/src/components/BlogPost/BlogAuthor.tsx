import React, { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Building, MapPin, ExternalLink, Award } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { BlogCategoryWithTranslations } from '@/hooks/useBlogCategories';

interface AuthorProfile {
  id: string;
  first_name?: string;
  last_name?: string;
  company_name?: string;
  city?: string;
  description?: string;
  website?: string;
  specializations?: string[];
}

interface BlogAuthorProps {
  authorId?: string;
  category?: BlogCategoryWithTranslations | null;
}

export const BlogAuthor: React.FC<BlogAuthorProps> = ({ authorId, category }) => {
  const [author, setAuthor] = useState<AuthorProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAuthor = async () => {
      if (!authorId) {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('id, first_name, last_name, company_name, city, description, website, specializations')
          .eq('id', authorId)
          .single();

        if (error) {
          console.error('Error fetching author:', error);
        } else {
          setAuthor(data);
        }
      } catch (error) {
        console.error('Error fetching author:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAuthor();
  }, [authorId]);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 bg-muted rounded-full"></div>
              <div className="space-y-2">
                <div className="h-4 bg-muted rounded w-32"></div>
                <div className="h-3 bg-muted rounded w-24"></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Fallback to Lockily Team if no author found
  if (!author) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src="/lovable-uploads/57166235-1698-4ec1-b97a-4f4ed9310ab8.png" alt="Lockily Team" />
              <AvatarFallback>
                <Building className="h-8 w-8" />
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="text-lg font-semibold mb-1">Lockily Team</h3>
              <p className="text-sm text-muted-foreground mb-3">Professional Locksmith Network</p>
              <p className="text-sm text-muted-foreground">
                Our team of expert locksmiths brings years of experience in security, emergency services, 
                and professional locksmith solutions. We're committed to providing reliable, trustworthy 
                advice and services to keep your property secure.
              </p>
              <div className="flex items-center gap-2 mt-3">
                <Badge variant="secondary" className="text-xs">
                  Expert Team
                </Badge>
                <Badge variant="secondary" className="text-xs">
                  24/7 Service
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const fullName = [author.first_name, author.last_name].filter(Boolean).join(' ');
  const initials = [author.first_name?.[0], author.last_name?.[0]].filter(Boolean).join('');

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16">
            <AvatarFallback className="text-lg font-semibold">
              {initials || <User className="h-8 w-8" />}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <h3 className="text-lg font-semibold mb-1">
              {fullName || 'Locksmith Expert'}
            </h3>
            
            {/* Company and Location */}
            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
              {author.company_name && (
                <div className="flex items-center gap-1">
                  <Building className="h-3 w-3" />
                  <span>{author.company_name}</span>
                </div>
              )}
              {author.city && (
                <div className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  <span>{author.city}</span>
                </div>
              )}
            </div>

            {/* Description */}
            {author.description && (
              <p className="text-sm text-muted-foreground mb-3">
                {author.description}
              </p>
            )}

            {/* Specializations */}
            {author.specializations && author.specializations.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {author.specializations.map((spec, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {spec}
                  </Badge>
                ))}
              </div>
            )}

            {/* Website */}
            {author.website && (
              <a
                href={author.website}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sm text-primary hover:text-primary/80 transition-colors"
              >
                <ExternalLink className="h-3 w-3" />
                Visit Website
              </a>
            )}

            {/* E-E-A-T Indicators */}
            <div className="flex items-center gap-2 mt-3">
              <Badge variant="outline" className="text-xs">
                <Award className="h-3 w-3 mr-1" />
                Expert in {category ? category.name : 'Locksmith Services'}
              </Badge>
              <Badge variant="outline" className="text-xs">
                Verified Expert
              </Badge>
              <Badge variant="outline" className="text-xs">
                Licensed Professional
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};