import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TOCItem {
  id: string;
  text: string;
  level: number;
  element: HTMLElement;
}

interface TableOfContentsProps {
  content: string;
  className?: string;
}

export const TableOfContents: React.FC<TableOfContentsProps> = ({ content, className }) => {
  const [tocItems, setTocItems] = useState<TOCItem[]>([]);
  const [activeId, setActiveId] = useState<string>('');
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    // Parse the content to extract headings
    const parser = new DOMParser();
    const doc = parser.parseFromString(content, 'text/html');
    const headings = doc.querySelectorAll('h2, h3, h4');
    
    const items: TOCItem[] = [];
    headings.forEach((heading, index) => {
      const level = parseInt(heading.tagName.charAt(1));
      const text = heading.textContent || '';
      const id = `heading-${index}`;
      
      // Add ID to the actual heading in the DOM
      setTimeout(() => {
        const actualHeading = document.querySelector(`h${level}:nth-of-type(${Math.floor(index/3) + 1})`);
        if (actualHeading && !actualHeading.id) {
          actualHeading.id = id;
        }
      }, 100);

      items.push({
        id,
        text,
        level,
        element: heading as HTMLElement
      });
    });

    setTocItems(items);
  }, [content]);

  useEffect(() => {
    // Set up intersection observer for active section tracking
    const observerOptions = {
      rootMargin: '-20% 0% -35% 0%',
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveId(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all headings
    tocItems.forEach((item) => {
      const element = document.getElementById(item.id);
      if (element) {
        observer.observe(element);
      }
    });

    return () => observer.disconnect();
  }, [tocItems]);

  const scrollToHeading = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
  };

  if (tocItems.length === 0) {
    return null;
  }

  return (
    <Card className={cn('sticky top-24', className)}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <div className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Table of Contents
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="h-6 w-6 p-0 md:hidden"
          >
            {isCollapsed ? (
              <ChevronDown className="h-3 w-3" />
            ) : (
              <ChevronUp className="h-3 w-3" />
            )}
          </Button>
        </CardTitle>
      </CardHeader>
      
      <CardContent className={cn('pt-0', isCollapsed && 'hidden md:block')}>
        <nav className="space-y-1">
          {tocItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollToHeading(item.id)}
              className={cn(
                'block w-full text-left text-sm py-2 px-3 rounded-md transition-colors hover:bg-muted',
                'border-l-2 border-transparent hover:border-primary/50',
                {
                  'ml-4': item.level === 3,
                  'ml-8': item.level === 4,
                  'bg-muted border-primary text-primary': activeId === item.id,
                  'text-muted-foreground hover:text-foreground': activeId !== item.id,
                }
              )}
            >
              <span className="line-clamp-2">{item.text}</span>
            </button>
          ))}
        </nav>

        {/* Reading Progress */}
        <div className="mt-4 pt-4 border-t">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span>Reading Progress</span>
            <span>{Math.round((tocItems.findIndex(item => item.id === activeId) + 1) / tocItems.length * 100)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-1.5">
            <div 
              className="bg-primary h-1.5 rounded-full transition-all duration-300"
              style={{ 
                width: `${(tocItems.findIndex(item => item.id === activeId) + 1) / tocItems.length * 100}%` 
              }}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};