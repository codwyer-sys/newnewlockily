import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Calendar, Globe, Clock } from 'lucide-react';
import { MarketAwareBlogPost } from '@/hooks/useMarketAwareBlogPosts';
import { useHeaderThemeSection } from '@/hooks/useHeaderThemeSection';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { useMarket } from '@/contexts/MarketContext';
import { useNavigate } from 'react-router-dom';

interface BlogPostHeroProps {
  post: MarketAwareBlogPost;
  readingTime: number;
}

export const BlogPostHero: React.FC<BlogPostHeroProps> = ({ post, readingTime }) => {
  const sectionRef = useHeaderThemeSection('dark', 'blog-post-hero');
  const { generateUrl, generateBlogPostUrlWithCategory } = useMarketUrl();
  const { market } = useMarket();
  const { categories } = useBlogCategories(market.country_code, 'en');
  const navigate = useNavigate();

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <section 
      ref={sectionRef}
      className="relative min-h-[60vh] flex items-end bg-slate-900 text-white overflow-hidden"
    >
      {/* Category Breadcrumb */}
      {post.category_id && (
        <div className="absolute top-4 left-4 z-20">
          {(() => {
            const category = categories.find(c => c.id === post.category_id);
            return category ? (
              <Badge variant="outline" className="border-white/20 text-white bg-white/10 backdrop-blur-sm">
                <Globe className="h-3 w-3 mr-1" />
                {category.name}
              </Badge>
            ) : null;
          })()}
        </div>
      )}
      {/* Featured Image Background */}
      {post.featured_image_url && (
        <div className="absolute inset-0">
          <img
            src={post.featured_image_url}
            alt={post.featured_image_alt || post.market_title}
            className="w-full h-full object-cover"
          />
          {/* Brand color overlay */}
          <div className="absolute inset-0 bg-slate-900/70"></div>
        </div>
      )}

      {/* Fallback gradient background if no featured image */}
      {!post.featured_image_url && (
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900"></div>
      )}

      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.05%22%3E%3Ccircle%20cx%3D%2230%22%20cy%3D%2230%22%20r%3D%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="max-w-4xl">
          {/* Back Button */}
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => navigate(generateUrl('blog'))}
            className="mb-6 text-white hover:text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Blog
          </Button>

          {/* Meta Info */}
          <div className="flex items-center gap-3 mb-6 flex-wrap">
            {post.is_global && (
              <Badge variant="outline" className="border-white/20 text-white bg-white/10 backdrop-blur-sm">
                <Globe className="h-3 w-3 mr-1" />
                Global Post
              </Badge>
            )}
            <Badge variant="outline" className="border-white/20 text-white bg-white/10 backdrop-blur-sm">
              <Calendar className="h-3 w-3 mr-1" />
              {formatDate(post.published_at || post.created_at)}
            </Badge>
            <Badge variant="outline" className="border-white/20 text-white bg-white/10 backdrop-blur-sm">
              <Clock className="h-3 w-3 mr-1" />
              {readingTime} min read
            </Badge>
          </div>

          {/* Title - Left aligned for readability */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight text-left">
            {post.market_title || post.title}
          </h1>

          {/* Excerpt */}
          {(post.market_excerpt || post.excerpt) && (
            <p className="text-xl md:text-2xl text-white/90 mb-6 leading-relaxed text-left max-w-3xl">
              {post.market_excerpt || post.excerpt}
            </p>
          )}
        </div>
      </div>

      {/* Smooth gradient transition */}
      <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-b from-transparent to-background/20 pointer-events-none"></div>
    </section>
  );
};