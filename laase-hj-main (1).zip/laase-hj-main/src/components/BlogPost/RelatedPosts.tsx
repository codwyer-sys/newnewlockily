import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { Calendar, Clock } from 'lucide-react';
import { useMarketAwareBlogPosts, MarketAwareBlogPost } from '@/hooks/useMarketAwareBlogPosts';
import { useMarketUrl } from '@/hooks/useMarketUrl';
import { useBlogCategories } from '@/hooks/useBlogCategories';
import { useMarket } from '@/contexts/MarketContext';

interface RelatedPostsProps {
  currentPost: MarketAwareBlogPost;
  limit?: number;
}

export const RelatedPosts: React.FC<RelatedPostsProps> = ({ currentPost, limit = 3 }) => {
  const { posts } = useMarketAwareBlogPosts();
  const { generateBlogPostUrl, generateBlogPostUrlWithCategory } = useMarketUrl();
  const { market } = useMarket();
  const { categories } = useBlogCategories(market.country_code, 'en');
  const [relatedPosts, setRelatedPosts] = useState<MarketAwareBlogPost[]>([]);

  useEffect(() => {
    // Filter out current post and get related posts
    const otherPosts = posts.filter(post => 
      post.id !== currentPost.id && 
      post.status === 'published'
    );

    // Priority logic for related posts:
    // 1. Same category
    // 2. Similar keywords (if available)
    // 3. Recent posts
    let related = otherPosts;

    // First, prioritize same category
    if (currentPost.category_id) {
      const sameCategory = otherPosts.filter(post => 
        post.category_id === currentPost.category_id
      );
      const otherCategory = otherPosts.filter(post => 
        post.category_id !== currentPost.category_id
      );
      related = [...sameCategory, ...otherCategory];
    }

    // Sort by published date (most recent first)
    related.sort((a, b) => {
      const dateA = new Date(a.published_at || a.created_at).getTime();
      const dateB = new Date(b.published_at || b.created_at).getTime();
      return dateB - dateA;
    });

    setRelatedPosts(related.slice(0, limit));
  }, [posts, currentPost, limit]);

  const calculateReadTime = (content: string) => {
    const wordsPerMinute = 200;
    const words = content.trim().split(/\s+/).length;
    return Math.ceil(words / wordsPerMinute);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (relatedPosts.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Related Articles</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {relatedPosts.map((post) => {
          const title = post.market_title || post.title;
          const excerpt = post.market_excerpt || post.excerpt;
          const content = post.market_content || post.content;
          const slug = post.market_slug || post.slug;
          
          // Find category and generate proper URL
          const category = post.category_id ? categories.find(c => c.id === post.category_id) : null;
          const postUrl = category 
            ? generateBlogPostUrlWithCategory(category.slug, slug)
            : generateBlogPostUrl(slug);

          return (
            <div key={post.id} className="group">
              <Link to={postUrl} className="block">
                <div className="flex gap-4 p-4 rounded-lg hover:bg-muted/50 transition-colors">
                  {/* Thumbnail */}
                  <div className="flex-shrink-0">
                    <div className="w-20 h-20 rounded-lg overflow-hidden bg-muted">
                      {post.featured_image_url ? (
                        <img
                          src={post.featured_image_url}
                          alt={post.featured_image_alt || title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
                          <span className="text-lg">📝</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm group-hover:text-primary transition-colors line-clamp-2 mb-2">
                      {title}
                    </h3>
                    
                    {excerpt && (
                      <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                        {excerpt}
                      </p>
                    )}

                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>{formatDate(post.published_at || post.created_at)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{calculateReadTime(content)} min</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};