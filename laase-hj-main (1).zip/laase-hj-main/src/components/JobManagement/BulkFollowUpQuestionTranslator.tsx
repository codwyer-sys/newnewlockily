import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Bot, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAITranslation } from "@/hooks/useAITranslation";
import { useFollowUpQuestionsManager } from "@/hooks/useFollowUpQuestionsManager";
import { supabase } from "@/integrations/supabase/client";

const LANGUAGES = [
  { code: 'da', name: 'Danish' },
  { code: 'en', name: 'English' },
  { code: 'de', name: 'German' },
  { code: 'sv', name: 'Swedish' },
  { code: 'no', name: 'Norwegian' }
];

const MARKETS = [
  { code: 'DK', name: 'Denmark' },
  { code: 'UK', name: 'United Kingdom' },
  { code: 'DE', name: 'Germany' },
  { code: 'SE', name: 'Sweden' },
  { code: 'NO', name: 'Norway' }
];

export const BulkFollowUpQuestionTranslator: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [selectedMarket, setSelectedMarket] = useState('');
  const [isTranslating, setIsTranslating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentItem, setCurrentItem] = useState('');
  
  const { toast } = useToast();
  const { translateText } = useAITranslation();
  const { questions, refreshQuestions } = useFollowUpQuestionsManager();

  const handleBulkTranslate = async () => {
    if (!selectedLanguage) {
      toast({ title: "Error", description: "Please select a language", variant: "destructive" });
      return;
    }

    setIsTranslating(true);
    setProgress(0);
    
    const total = questions.length;
    let completed = 0;

    try {
      for (const question of questions) {
        setCurrentItem(`Translating "${question.question}"`);
        
        // Check if translation already exists
        const { data: existing } = await supabase
          .from('follow_up_question_translations')
          .select('id')
          .eq('follow_up_question_id', question.id)
          .eq('language_code', selectedLanguage)
          .eq('market_code', selectedMarket || null)
          .maybeSingle();

        if (!existing) {
          // Translate question
          const translatedQuestion = await translateText({
            originalText: question.question,
            targetLanguage: selectedLanguage,
            market: selectedMarket,
            context: 'follow-up question',
            customInstruction: 'Translate this locksmith follow-up question. Make it clear and professional for emergency service customers.',
            placement: 'bulk translation'
          });

          let translatedOptions: string[] | undefined;
          
          // Translate options if they exist
          if (question.options && question.options.length > 0) {
            const optionsText = question.options.join(', ');
            const translatedOptionsText = await translateText({
              originalText: optionsText,
              targetLanguage: selectedLanguage,
              market: selectedMarket,
              context: 'multiple choice options',
              customInstruction: 'Translate these multiple choice options for locksmith services. Keep them concise and clear, return as comma-separated values.',
              placement: 'bulk translation'
            });
            
            if (translatedOptionsText) {
              translatedOptions = translatedOptionsText.split(',').map(s => s.trim()).filter(s => s);
            }
          }

          if (translatedQuestion) {
            // Save translation
            await supabase
              .from('follow_up_question_translations')
              .insert({
                follow_up_question_id: question.id,
                language_code: selectedLanguage,
                market_code: selectedMarket || null,
                question: translatedQuestion,
                options: translatedOptions ? JSON.stringify(translatedOptions) : null,
                option_icons: question.option_icons
              });
          }
        }

        completed++;
        setProgress((completed / total) * 100);
      }

      await refreshQuestions();
      toast({ title: "Success", description: `Translated ${total} follow-up questions` });
      setIsOpen(false);
    } catch (error: any) {
      toast({ 
        title: "Error", 
        description: error.message || "Bulk translation failed", 
        variant: "destructive" 
      });
    } finally {
      setIsTranslating(false);
      setProgress(0);
      setCurrentItem('');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <MessageSquare className="w-4 h-4 mr-2" />
          Bulk AI Translate
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bot className="w-5 h-5" />
            Bulk Translate Follow-up Questions
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Target Language *</label>
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage} disabled={isTranslating}>
              <SelectTrigger>
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium">Target Market</label>
            <Select value={selectedMarket} onValueChange={setSelectedMarket} disabled={isTranslating}>
              <SelectTrigger>
                <SelectValue placeholder="Select market (optional)" />
              </SelectTrigger>
              <SelectContent>
                {MARKETS.map((market) => (
                  <SelectItem key={market.code} value={market.code}>
                    {market.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isTranslating && (
            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">{currentItem}</div>
              <Progress value={progress} className="w-full" />
              <div className="text-xs text-muted-foreground">{Math.round(progress)}% complete</div>
            </div>
          )}
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsOpen(false)} disabled={isTranslating}>
              Cancel
            </Button>
            <Button onClick={handleBulkTranslate} disabled={!selectedLanguage || isTranslating}>
              {isTranslating ? 'Translating...' : 'Start Translation'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};