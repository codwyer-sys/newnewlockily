import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit, Plus, Save, X, Languages, GripVertical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useFollowUpQuestionsManager } from "@/hooks/useFollowUpQuestionsManager";
import { FollowUpQuestionTranslationDialog } from "./FollowUpQuestionTranslationDialog";
import { BulkFollowUpQuestionTranslator } from "./BulkFollowUpQuestionTranslator";

interface JobCategory {
  id: string;
  name: string;
  emoji: string;
}

interface FollowUpQuestion {
  id: string;
  job_category_id?: string;
  question: string;
  question_key: string;
  question_type: 'radio' | 'number' | 'text' | 'checkbox';
  options?: string[];
  option_icons?: Record<string, string>;
  is_required: boolean;
  is_global: boolean;
  order_index: number;
}

const QUESTION_TYPES = [
  { value: 'radio', label: 'Radio Buttons' },
  { value: 'checkbox', label: 'Checkboxes' },
  { value: 'number', label: 'Number Input' },
  { value: 'text', label: 'Text Input' }
];

const FollowUpQuestionsManager = () => {
  const { 
    questions, 
    categories,
    loading, 
    createQuestion, 
    updateQuestion, 
    deleteQuestion, 
    refreshQuestions 
  } = useFollowUpQuestionsManager();
  
  const [editingQuestion, setEditingQuestion] = useState<FollowUpQuestion | null>(null);
  const [showNewQuestion, setShowNewQuestion] = useState(false);
  const [selectedQuestionForTranslation, setSelectedQuestionForTranslation] = useState<FollowUpQuestion | null>(null);
  const { toast } = useToast();

  const handleSave = async (questionData: Partial<FollowUpQuestion>) => {
    try {
      if (editingQuestion?.id) {
        await updateQuestion(editingQuestion.id, questionData);
        setEditingQuestion(null);
      } else {
        await createQuestion(questionData);
        setShowNewQuestion(false);
      }
      toast({
        title: "Success",
        description: editingQuestion ? "Question updated" : "Question created"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Are you sure you want to delete this question?")) return;
    
    try {
      await deleteQuestion(id);
      toast({
        title: "Success",
        description: "Question deleted"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const QuestionForm = ({ question, onSave, onCancel }: {
    question?: FollowUpQuestion | null;
    onSave: (data: Partial<FollowUpQuestion>) => void;
    onCancel: () => void;
  }) => {
    const [formData, setFormData] = useState({
      job_category_id: question?.job_category_id || '',
      question: question?.question || '',
      question_key: question?.question_key || '',
      question_type: question?.question_type || 'radio' as const,
      options: question?.options?.join(', ') || '',
      is_required: question?.is_required ?? true,
      is_global: question?.is_global || false,
      order_index: question?.order_index || 0
    });

    const handleSave = () => {
      const data: Partial<FollowUpQuestion> = {
        ...formData,
        job_category_id: formData.is_global ? undefined : formData.job_category_id || undefined,
        options: formData.question_type === 'radio' || formData.question_type === 'checkbox' 
          ? formData.options.split(',').map(s => s.trim()).filter(s => s)
          : undefined
      };
      onSave(data);
    };

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{question ? 'Edit Question' : 'New Question'}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="is_global"
              checked={formData.is_global}
              onCheckedChange={(checked) => setFormData({ ...formData, is_global: checked })}
            />
            <Label htmlFor="is_global">Global Question (shows for all categories)</Label>
          </div>
          
          {!formData.is_global && (
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={formData.job_category_id} onValueChange={(value) => setFormData({ ...formData, job_category_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.emoji} {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label htmlFor="question">Question</Label>
            <Input
              id="question"
              value={formData.question}
              onChange={(e) => setFormData({ ...formData, question: e.target.value })}
              placeholder="Enter the question"
            />
          </div>

          <div>
            <Label htmlFor="question_key">Question Key</Label>
            <Input
              id="question_key"
              value={formData.question_key}
              onChange={(e) => setFormData({ ...formData, question_key: e.target.value })}
              placeholder="camelCase key for the question"
            />
          </div>

          <div>
            <Label htmlFor="question_type">Question Type</Label>
            <Select value={formData.question_type} onValueChange={(value: any) => setFormData({ ...formData, question_type: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {QUESTION_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {(formData.question_type === 'radio' || formData.question_type === 'checkbox') && (
            <div>
              <Label htmlFor="options">Options (comma separated)</Label>
              <Textarea
                id="options"
                value={formData.options}
                onChange={(e) => setFormData({ ...formData, options: e.target.value })}
                placeholder="Option 1, Option 2, Option 3"
              />
            </div>
          )}

          <div>
            <Label htmlFor="order_index">Order Index</Label>
            <Input
              id="order_index"
              type="number"
              value={formData.order_index}
              onChange={(e) => setFormData({ ...formData, order_index: parseInt(e.target.value) || 0 })}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="is_required"
              checked={formData.is_required}
              onCheckedChange={(checked) => setFormData({ ...formData, is_required: checked })}
            />
            <Label htmlFor="is_required">Required</Label>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-muted rounded animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 bg-muted rounded animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Follow-up Questions</h1>
          <p className="text-muted-foreground mt-1">
            Manage follow-up questions and their translations across markets
          </p>
        </div>
        <div className="flex gap-2">
          <BulkFollowUpQuestionTranslator />
          <Button onClick={() => setShowNewQuestion(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Question
          </Button>
        </div>
      </div>

      {showNewQuestion && (
        <QuestionForm
          onSave={handleSave}
          onCancel={() => setShowNewQuestion(false)}
        />
      )}
      
      {editingQuestion && (
        <QuestionForm
          question={editingQuestion}
          onSave={handleSave}
          onCancel={() => setEditingQuestion(null)}
        />
      )}

      <div className="space-y-3">
        {questions.map((question) => {
          const category = categories.find(c => c.id === question.job_category_id);
          return (
            <Card key={question.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <GripVertical className="w-4 h-4 text-muted-foreground" />
                      {question.is_global ? (
                        <Badge variant="default">Global</Badge>
                      ) : (
                        <Badge variant="secondary">
                          {category?.emoji} {category?.name}
                        </Badge>
                      )}
                      <Badge variant="outline">{question.question_type}</Badge>
                      {question.is_required && <Badge variant="destructive">Required</Badge>}
                      <span className="text-xs text-muted-foreground">Order: {question.order_index}</span>
                    </div>
                    <h4 className="font-medium text-foreground mb-1">{question.question}</h4>
                    <p className="text-sm text-muted-foreground">Key: {question.question_key}</p>
                    {question.options && (
                      <p className="text-sm text-muted-foreground">
                        Options: {question.options.join(', ')}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedQuestionForTranslation(question)}
                      title="Manage translations"
                    >
                      <Languages className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditingQuestion(question)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(question.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
        {questions.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No questions yet. Create your first question above.
          </div>
        )}
      </div>

      {selectedQuestionForTranslation && (
        <FollowUpQuestionTranslationDialog
          question={selectedQuestionForTranslation}
          open={!!selectedQuestionForTranslation}
          onOpenChange={() => setSelectedQuestionForTranslation(null)}
        />
      )}
    </div>
  );
};

export default FollowUpQuestionsManager;