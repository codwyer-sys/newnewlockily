import React, { useState, useEffect } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface JobCategory {
  id: string;
  name: string;
  emoji: string;
  description: string;
  requires_image: boolean;
  created_at: string;
  updated_at: string;
}

interface JobCategoryDeleteDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  category: JobCategory | null;
  categories: JobCategory[];
  onConfirmDelete: (categoryId: string, reassignToCategoryId?: string) => Promise<void>;
}

export const JobCategoryDeleteDialog: React.FC<JobCategoryDeleteDialogProps> = ({
  open,
  onOpenChange,
  category,
  categories,
  onConfirmDelete,
}) => {
  const [bookingCount, setBookingCount] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [selectedTargetCategory, setSelectedTargetCategory] = useState<string>('');

  // Get available categories for reassignment (excluding the one being deleted)
  const availableCategories = categories.filter(cat => cat.id !== category?.id);

  useEffect(() => {
    if (category && open) {
      fetchBookingCount();
      setSelectedTargetCategory('');
    }
  }, [category, open]);

  const fetchBookingCount = async () => {
    if (!category) return;
    
    setLoading(true);
    try {
      const { count, error } = await supabase
        .from('bookings')
        .select('*', { count: 'exact', head: true })
        .eq('job_category_id', category.id);
      
      if (error) throw error;
      setBookingCount(count || 0);
    } catch (error) {
      console.error('Error fetching booking count:', error);
      setBookingCount(0);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!category) return;
    
    setDeleting(true);
    try {
      await onConfirmDelete(
        category.id, 
        bookingCount > 0 ? selectedTargetCategory : undefined
      );
      onOpenChange(false);
    } catch (error) {
      console.error('Error deleting category:', error);
    } finally {
      setDeleting(false);
    }
  };

  const canDelete = bookingCount === 0 || (bookingCount > 0 && selectedTargetCategory);
  const isLastCategory = categories.length === 1;

  if (!category) return null;

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            Delete Category
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-4">
              <p>
                Are you sure you want to delete the category <strong>"{category.name}"</strong>?
              </p>
              
              {loading ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Checking for associated bookings...
                </div>
              ) : (
                <>
                  {isLastCategory ? (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        This is the last remaining category and cannot be deleted. You must have at least one category.
                      </AlertDescription>
                    </Alert>
                  ) : bookingCount > 0 ? (
                    <div className="space-y-3">
                      <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          This category has <strong>{bookingCount}</strong> associated booking{bookingCount > 1 ? 's' : ''}. 
                          You must reassign these bookings to another category before deletion.
                        </AlertDescription>
                      </Alert>
                      
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Reassign bookings to:</label>
                        <Select value={selectedTargetCategory} onValueChange={setSelectedTargetCategory}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category..." />
                          </SelectTrigger>
                          <SelectContent>
                            {availableCategories.map((cat) => (
                              <SelectItem key={cat.id} value={cat.id}>
                                {cat.emoji} {cat.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  ) : (
                    <Alert>
                      <AlertDescription>
                        This category has no associated bookings and can be safely deleted.
                      </AlertDescription>
                    </Alert>
                  )}
                </>
              )}
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        <AlertDialogFooter>
          <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirmDelete}
            disabled={!canDelete || loading || deleting || isLastCategory}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {bookingCount > 0 ? 'Reassigning & Deleting...' : 'Deleting...'}
              </>
            ) : (
              `Delete Category`
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};