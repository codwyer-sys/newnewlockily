import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit, Plus, Save, X, Languages } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useJobCategoriesManager } from "@/hooks/useJobCategoriesManager";
import { JobCategoryTranslationDialog } from "./JobCategoryTranslationDialog";
import { BulkJobCategoryTranslator } from "./BulkJobCategoryTranslator";
import { JobCategoryDeleteDialog } from "./JobCategoryDeleteDialog";

interface JobCategory {
  id: string;
  name: string;
  emoji: string;
  description: string;
  requires_image: boolean;
  created_at: string;
  updated_at: string;
}

const JobCategoriesManager = () => {
  const { 
    categories, 
    loading, 
    createCategory, 
    updateCategory, 
    deleteCategory, 
    deleteCategoryWithReassignment,
    refreshCategories 
  } = useJobCategoriesManager();
  
  const [editingCategory, setEditingCategory] = useState<JobCategory | null>(null);
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [selectedCategoryForTranslation, setSelectedCategoryForTranslation] = useState<JobCategory | null>(null);
  const [categoryToDelete, setCategoryToDelete] = useState<JobCategory | null>(null);
  const { toast } = useToast();

  const handleSave = async (categoryData: Partial<JobCategory>) => {
    try {
      if (editingCategory?.id) {
        await updateCategory(editingCategory.id, categoryData);
        setEditingCategory(null);
      } else {
        await createCategory(categoryData);
        setShowNewCategory(false);
      }
      toast({
        title: "Success",
        description: editingCategory ? "Category updated" : "Category created"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleDelete = (category: JobCategory) => {
    setCategoryToDelete(category);
  };

  const handleConfirmDelete = async (categoryId: string, reassignToCategoryId?: string) => {
    try {
      if (reassignToCategoryId) {
        await deleteCategoryWithReassignment(categoryId, reassignToCategoryId);
        toast({
          title: "Success",
          description: "Category deleted and bookings reassigned successfully"
        });
      } else {
        await deleteCategory(categoryId);
        toast({
          title: "Success",
          description: "Category deleted successfully"
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
      throw error;
    }
  };

  const CategoryForm = ({ category, onSave, onCancel }: {
    category?: JobCategory | null;
    onSave: (data: Partial<JobCategory>) => void;
    onCancel: () => void;
  }) => {
    const [formData, setFormData] = useState({
      name: category?.name || '',
      emoji: category?.emoji || '',
      description: category?.description || '',
      requires_image: category?.requires_image || false
    });

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>{category ? 'Edit Category' : 'New Category'}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Enter category name"
            />
          </div>
          
          <div>
            <Label htmlFor="emoji">Emoji</Label>
            <Input
              id="emoji"
              value={formData.emoji}
              onChange={(e) => setFormData({ ...formData, emoji: e.target.value })}
              placeholder="Choose an emoji"
            />
          </div>
          
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Enter category description"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              id="requires_image"
              checked={formData.requires_image}
              onCheckedChange={(checked) => setFormData({ ...formData, requires_image: checked })}
            />
            <Label htmlFor="requires_image">Requires Image Upload</Label>
          </div>
          
          <div className="flex gap-2">
            <Button onClick={() => onSave(formData)}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-muted rounded animate-pulse"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-muted rounded animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Job Categories</h1>
          <p className="text-muted-foreground mt-1">
            Manage job categories and their translations across markets
          </p>
        </div>
        <div className="flex gap-2">
          <BulkJobCategoryTranslator />
          <Button onClick={() => setShowNewCategory(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Add Category
          </Button>
        </div>
      </div>

      {showNewCategory && (
        <CategoryForm
          onSave={handleSave}
          onCancel={() => setShowNewCategory(false)}
        />
      )}
      
      {editingCategory && (
        <CategoryForm
          category={editingCategory}
          onSave={handleSave}
          onCancel={() => setEditingCategory(null)}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((category) => (
          <Card key={category.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{category.emoji}</span>
                  <div>
                    <h3 className="font-semibold text-foreground">{category.name}</h3>
                    <p className="text-sm text-muted-foreground">{category.description}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setSelectedCategoryForTranslation(category)}
                    title="Manage translations"
                  >
                    <Languages className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditingCategory(category)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDelete(category)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                {category.requires_image && (
                  <Badge variant="secondary" className="text-xs">
                    Requires Image
                  </Badge>
                )}
                <div className="text-xs text-muted-foreground">
                  Created: {new Date(category.created_at).toLocaleDateString()}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedCategoryForTranslation && (
        <JobCategoryTranslationDialog
          category={selectedCategoryForTranslation}
          open={!!selectedCategoryForTranslation}
          onOpenChange={() => setSelectedCategoryForTranslation(null)}
        />
      )}

      <JobCategoryDeleteDialog
        open={!!categoryToDelete}
        onOpenChange={(open) => !open && setCategoryToDelete(null)}
        category={categoryToDelete}
        categories={categories}
        onConfirmDelete={handleConfirmDelete}
      />
    </div>
  );
};

export default JobCategoriesManager;