import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Save, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { AITranslateButton } from "@/components/ui/ai-translate-button";

interface FollowUpQuestion {
  id: string;
  question: string;
  question_key: string;
  question_type: string;
  options?: string[];
}

interface QuestionTranslation {
  id: string;
  language_code: string;
  market_code: string;
  question: string;
  options?: string[];
  option_icons?: Record<string, string>;
}

interface FollowUpQuestionTranslationDialogProps {
  question: FollowUpQuestion;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const LANGUAGES = [
  { code: 'da', name: 'Danish' },
  { code: 'en', name: 'English' },
  { code: 'de', name: 'German' },
  { code: 'sv', name: 'Swedish' },
  { code: 'no', name: 'Norwegian' }
];

const MARKETS = [
  { code: 'DK', name: 'Denmark' },
  { code: 'UK', name: 'United Kingdom' },
  { code: 'DE', name: 'Germany' },
  { code: 'SE', name: 'Sweden' },
  { code: 'NO', name: 'Norway' }
];

export const FollowUpQuestionTranslationDialog: React.FC<FollowUpQuestionTranslationDialogProps> = ({
  question,
  open,
  onOpenChange
}) => {
  const [translations, setTranslations] = useState<QuestionTranslation[]>([]);
  const [newTranslation, setNewTranslation] = useState({
    language_code: '',
    market_code: '',
    question: '',
    options: ''
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open && question.id) {
      fetchTranslations();
    }
  }, [open, question.id]);

  const fetchTranslations = async () => {
    try {
      const { data, error } = await supabase
        .from('follow_up_question_translations')
        .select('*')
        .eq('follow_up_question_id', question.id)
        .order('language_code');
      
      if (error) throw error;
      const transformedTranslations: QuestionTranslation[] = (data || []).map(item => ({
        id: item.id,
        language_code: item.language_code,
        market_code: item.market_code,
        question: item.question,
        options: item.options ? (item.options as string[]) : undefined,
        option_icons: item.option_icons ? (item.option_icons as Record<string, string>) : undefined
      }));
      setTranslations(transformedTranslations);
    } catch (error) {
      console.error('Error fetching translations:', error);
    }
  };

  const addTranslation = async () => {
    if (!newTranslation.language_code || !newTranslation.question) {
      toast({
        title: "Error",
        description: "Language and question are required",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const translationData: any = {
        follow_up_question_id: question.id,
        language_code: newTranslation.language_code,
        market_code: newTranslation.market_code || null,
        question: newTranslation.question
      };

      // Handle options if the question type supports them
      if ((question.question_type === 'radio' || question.question_type === 'checkbox') && newTranslation.options) {
        translationData.options = newTranslation.options.split(',').map(s => s.trim()).filter(s => s);
      }

      const { error } = await supabase
        .from('follow_up_question_translations')
        .insert([translationData]);
      
      if (error) throw error;
      
      setNewTranslation({
        language_code: '',
        market_code: '',
        question: '',
        options: ''
      });
      
      await fetchTranslations();
      toast({
        title: "Success",
        description: "Translation added"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteTranslation = async (id: string) => {
    try {
      const { error } = await supabase
        .from('follow_up_question_translations')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await fetchTranslations();
      toast({
        title: "Success",
        description: "Translation deleted"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const hasOptions = question.question_type === 'radio' || question.question_type === 'checkbox';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Manage Translations for "{question.question}"
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Question Info */}
          <div className="p-4 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline">{question.question_type}</Badge>
              <span className="text-sm text-muted-foreground">Key: {question.question_key}</span>
            </div>
            {question.options && (
              <div className="text-sm text-muted-foreground">
                Original options: {question.options.join(', ')}
              </div>
            )}
          </div>

          {/* Existing Translations */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Existing Translations</h3>
            <div className="space-y-3">
              {translations.map((translation) => (
                <div key={translation.id} className="flex items-start justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline">
                        {LANGUAGES.find(l => l.code === translation.language_code)?.name || translation.language_code}
                      </Badge>
                      {translation.market_code && (
                        <Badge variant="secondary">
                          {MARKETS.find(m => m.code === translation.market_code)?.name || translation.market_code}
                        </Badge>
                      )}
                    </div>
                    <div className="font-medium">{translation.question}</div>
                    {translation.options && (
                      <div className="text-sm text-muted-foreground mt-1">
                        Options: {translation.options.join(', ')}
                      </div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTranslation(translation.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              {translations.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No translations yet. Add one below.
                </div>
              )}
            </div>
          </div>

          {/* Add New Translation */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Add New Translation</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="language">Language *</Label>
                <Select
                  value={newTranslation.language_code}
                  onValueChange={(value) => setNewTranslation({ ...newTranslation, language_code: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="market">Market</Label>
                <Select
                  value={newTranslation.market_code}
                  onValueChange={(value) => setNewTranslation({ ...newTranslation, market_code: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select market (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {MARKETS.map((market) => (
                      <SelectItem key={market.code} value={market.code}>
                        {market.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mt-4">
              <Label htmlFor="question">Question *</Label>
              <div className="flex gap-2">
                <Input
                  id="question"
                  value={newTranslation.question}
                  onChange={(e) => setNewTranslation({ ...newTranslation, question: e.target.value })}
                  placeholder="Translated question text"
                  className="flex-1"
                />
                <AITranslateButton
                  originalText={question.question}
                  targetLanguage={newTranslation.language_code}
                  market={newTranslation.market_code}
                  context="follow-up question"
                  onTranslated={(text) => setNewTranslation({ ...newTranslation, question: text })}
                  customInstruction="Translate this locksmith follow-up question. Make it clear and professional for emergency service customers."
                  disabled={!newTranslation.language_code}
                />
              </div>
            </div>
            
            {hasOptions && (
              <div className="mt-4">
                <Label htmlFor="options">Options (comma separated)</Label>
                <div className="space-y-2">
                  <Textarea
                    id="options"
                    value={newTranslation.options}
                    onChange={(e) => setNewTranslation({ ...newTranslation, options: e.target.value })}
                    placeholder="Translated option 1, Translated option 2, ..."
                    rows={3}
                    className="flex-1"
                  />
                  <AITranslateButton
                    originalText={question.options?.join(', ') || ''}
                    targetLanguage={newTranslation.language_code}
                    market={newTranslation.market_code}
                    context="multiple choice options"
                    onTranslated={(text) => setNewTranslation({ ...newTranslation, options: text })}
                    customInstruction="Translate these multiple choice options for locksmith services. Keep them concise and clear, return as comma-separated values."
                    disabled={!newTranslation.language_code || !question.options}
                    size="sm"
                    variant="ghost"
                  />
                </div>
              </div>
            )}
            
            <div className="flex justify-end mt-4">
              <Button onClick={addTranslation} disabled={loading}>
                <Plus className="w-4 h-4 mr-2" />
                Add Translation
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
