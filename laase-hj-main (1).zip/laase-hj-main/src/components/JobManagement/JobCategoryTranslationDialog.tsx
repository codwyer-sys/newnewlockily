import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Save, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { AITranslateButton } from "@/components/ui/ai-translate-button";

interface JobCategory {
  id: string;
  name: string;
  description: string;
}

interface Translation {
  id: string;
  language_code: string;
  market_code: string;
  name: string;
  description: string;
}

interface JobCategoryTranslationDialogProps {
  category: JobCategory;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const LANGUAGES = [
  { code: 'da', name: 'Danish' },
  { code: 'en', name: 'English' },
  { code: 'de', name: 'German' },
  { code: 'sv', name: 'Swedish' },
  { code: 'no', name: 'Norwegian' }
];

const MARKETS = [
  { code: 'DK', name: 'Denmark' },
  { code: 'UK', name: 'United Kingdom' },
  { code: 'DE', name: 'Germany' },
  { code: 'SE', name: 'Sweden' },
  { code: 'NO', name: 'Norway' }
];

export const JobCategoryTranslationDialog: React.FC<JobCategoryTranslationDialogProps> = ({
  category,
  open,
  onOpenChange
}) => {
  const [translations, setTranslations] = useState<Translation[]>([]);
  const [newTranslation, setNewTranslation] = useState({
    language_code: '',
    market_code: '',
    name: '',
    description: ''
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open && category.id) {
      fetchTranslations();
    }
  }, [open, category.id]);

  const fetchTranslations = async () => {
    try {
      const { data, error } = await supabase
        .from('job_category_translations')
        .select('*')
        .eq('job_category_id', category.id)
        .order('language_code');
      
      if (error) throw error;
      setTranslations(data || []);
    } catch (error) {
      console.error('Error fetching translations:', error);
    }
  };

  const addTranslation = async () => {
    if (!newTranslation.language_code || !newTranslation.name) {
      toast({
        title: "Error",
        description: "Language and name are required",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      const { error } = await supabase
        .from('job_category_translations')
        .insert([{
          job_category_id: category.id,
          language_code: newTranslation.language_code,
          market_code: newTranslation.market_code || null,
          name: newTranslation.name,
          description: newTranslation.description || null
        }]);
      
      if (error) throw error;
      
      setNewTranslation({
        language_code: '',
        market_code: '',
        name: '',
        description: ''
      });
      
      await fetchTranslations();
      toast({
        title: "Success",
        description: "Translation added"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteTranslation = async (id: string) => {
    try {
      const { error } = await supabase
        .from('job_category_translations')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await fetchTranslations();
      toast({
        title: "Success",
        description: "Translation deleted"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Manage Translations for "{category.name}"
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Existing Translations */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Existing Translations</h3>
            <div className="space-y-3">
              {translations.map((translation) => (
                <div key={translation.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline">
                        {LANGUAGES.find(l => l.code === translation.language_code)?.name || translation.language_code}
                      </Badge>
                      {translation.market_code && (
                        <Badge variant="secondary">
                          {MARKETS.find(m => m.code === translation.market_code)?.name || translation.market_code}
                        </Badge>
                      )}
                    </div>
                    <div className="font-medium">{translation.name}</div>
                    {translation.description && (
                      <div className="text-sm text-muted-foreground">{translation.description}</div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteTranslation(translation.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
              {translations.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No translations yet. Add one below.
                </div>
              )}
            </div>
          </div>

          {/* Add New Translation */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Add New Translation</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="language">Language *</Label>
                <Select
                  value={newTranslation.language_code}
                  onValueChange={(value) => setNewTranslation({ ...newTranslation, language_code: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="market">Market</Label>
                <Select
                  value={newTranslation.market_code}
                  onValueChange={(value) => setNewTranslation({ ...newTranslation, market_code: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select market (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    {MARKETS.map((market) => (
                      <SelectItem key={market.code} value={market.code}>
                        {market.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="name">Name *</Label>
                <div className="flex gap-2">
                  <Input
                    id="name"
                    value={newTranslation.name}
                    onChange={(e) => setNewTranslation({ ...newTranslation, name: e.target.value })}
                    placeholder="Translated category name"
                    className="flex-1"
                  />
                  <AITranslateButton
                    originalText={category.name}
                    targetLanguage={newTranslation.language_code}
                    market={newTranslation.market_code}
                    context="job category name"
                    onTranslated={(text) => setNewTranslation({ ...newTranslation, name: text })}
                    customInstruction="Translate this locksmith job category name. Keep it concise and professional."
                    disabled={!newTranslation.language_code}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <div className="flex gap-2 items-end">
                  <div className="flex-1">
                    <Textarea
                      id="description"
                      value={newTranslation.description}
                      onChange={(e) => setNewTranslation({ ...newTranslation, description: e.target.value })}
                      placeholder="Translated description"
                      rows={3}
                    />
                  </div>
                  <AITranslateButton
                    originalText={category.description}
                    targetLanguage={newTranslation.language_code}
                    market={newTranslation.market_code}
                    context="job category description"
                    onTranslated={(text) => setNewTranslation({ ...newTranslation, description: text })}
                    customInstruction="Translate this locksmith job category description. Be clear and professional."
                    disabled={!newTranslation.language_code}
                  />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end mt-4">
              <Button onClick={addTranslation} disabled={loading}>
                <Plus className="w-4 h-4 mr-2" />
                Add Translation
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
