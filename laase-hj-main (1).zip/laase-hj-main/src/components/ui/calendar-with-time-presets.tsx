
"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface CalendarWithTimePresetsProps {
  onDateTimeSelect: (date: Date, time: string) => void;
}

export function CalendarWithTimePresets({ onDateTimeSelect }: CalendarWithTimePresetsProps) {
  const [date, setDate] = React.useState<Date | undefined>(new Date())
  const [selectedTime, setSelectedTime] = React.useState<string | null>("10:00")
  
  const timeSlots = Array.from({ length: 37 }, (_, i) => {
    const totalMinutes = i * 15
    const hour = Math.floor(totalMinutes / 60) + 9
    const minute = totalMinutes % 60
    return `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`
  })

  const bookedDates = Array.from(
    { length: 3 },
    (_, i) => new Date(2025, 5, 17 + i)
  )

  React.useEffect(() => {
    if (date && selectedTime) {
      const [hours, minutes] = selectedTime.split(':').map(Number);
      const dateTime = new Date(date);
      dateTime.setHours(hours, minutes, 0, 0);
      onDateTimeSelect(dateTime, selectedTime);
    }
  }, [date, selectedTime, onDateTimeSelect]);

  return (
    <Card className="gap-0 p-0 bg-white border-gray-200">
      <CardContent className="relative p-0 md:pr-48">
        <div className="p-6">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            defaultMonth={date}
            disabled={bookedDates}
            showOutsideDays={false}
            modifiers={{
              booked: bookedDates,
            }}
            modifiersClassNames={{
              booked: "[&>button]:line-through opacity-100",
            }}
            className="bg-transparent p-0 text-black [--cell-size:--spacing(10)] md:[--cell-size:--spacing(12)]"
            formatters={{
              formatWeekdayName: (date) => {
                return date.toLocaleString("da-DK", { weekday: "short" })
              },
            }}
          />
        </div>
        <div className="no-scrollbar inset-y-0 right-0 flex max-h-72 w-full scroll-pb-6 flex-col gap-4 overflow-y-auto border-t border-gray-200 p-6 md:absolute md:max-h-none md:w-48 md:border-t-0 md:border-l">
          <div className="grid gap-2">
            {timeSlots.map((time) => (
              <Button
                key={time}
                variant={selectedTime === time ? "default" : "outline"}
                onClick={() => setSelectedTime(time)}
                className={`w-full shadow-none ${
                  selectedTime === time 
                    ? "bg-system-blue text-white hover:bg-system-blue/90" 
                    : "border-gray-200 bg-white text-black hover:border-system-blue hover:bg-gray-50"
                }`}
              >
                {time}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-4 border-t border-gray-200 px-6 !py-5 md:flex-row">
        <div className="text-sm text-gray-600">
          {date && selectedTime ? (
            <>
              Dit møde er booket til{" "}
              <span className="font-medium text-black">
                {date?.toLocaleDateString("da-DK", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                })}{" "}
              </span>
              kl. <span className="font-medium text-black">{selectedTime}</span>.
            </>
          ) : (
            <>Vælg en dato og tidspunkt for dit møde.</>
          )}
        </div>
      </CardFooter>
    </Card>
  )
}
