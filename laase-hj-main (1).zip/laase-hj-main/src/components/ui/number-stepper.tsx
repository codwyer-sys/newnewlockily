import React from 'react';
import { Button } from "@/components/ui/button";
import { Minus, Plus } from "lucide-react";
import { cn } from "@/lib/utils";

interface NumberStepperProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  className?: string;
}

const NumberStepper: React.FC<NumberStepperProps> = ({
  value,
  onChange,
  min = 1,
  max,
  className
}) => {
  const handleDecrease = () => {
    if (value > min) {
      onChange(value - 1);
    }
  };

  const handleIncrease = () => {
    if (!max || value < max) {
      onChange(value + 1);
    }
  };

  const canDecrease = value > min;
  const canIncrease = !max || value < max;

  return (
    <div className={cn("flex items-center justify-center space-x-3", className)}>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={handleDecrease}
        disabled={!canDecrease}
        className="h-10 w-10 rounded-full border-2 border-border hover:border-primary/50 disabled:opacity-50"
        aria-label="Decrease quantity"
      >
        <Minus className="h-4 w-4" />
      </Button>
      
      <div className="flex items-center justify-center min-w-[60px]">
        <span className="text-2xl font-semibold text-card-foreground">
          {value}
        </span>
      </div>
      
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={handleIncrease}
        disabled={!canIncrease}
        className="h-10 w-10 rounded-full border-2 border-border hover:border-primary/50 disabled:opacity-50"
        aria-label="Increase quantity"
      >
        <Plus className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default NumberStepper;