
import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const glassButtonVariants = cva(
  "inline-flex items-center justify-center gap-apple-2 whitespace-nowrap font-apple text-apple-headline font-semibold ring-offset-background transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-system-blue focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 glass-button",
  {
    variants: {
      variant: {
        default: "glass text-system-gray hover:bg-black/10 active:bg-black/20",
        primary: "glass-adaptive bg-system-blue/80 text-white hover:bg-system-blue/90 active:bg-system-blue/95 backdrop-blur-xl",
        secondary: "glass text-system-gray hover:bg-black/10 active:bg-black/20",
        destructive: "glass bg-red-500/80 text-white hover:bg-red-500/90 active:bg-red-500/95",
        capsule: "glass rounded-apple-capsule px-apple-6",
      },
      size: {
        default: "h-12 px-apple-4 py-apple-2 rounded-apple-medium",
        sm: "h-10 px-apple-3 text-apple-subhead rounded-apple-small",
        lg: "h-14 px-apple-6 text-apple-title3 rounded-apple-large",
        icon: "h-12 w-12 rounded-apple-medium",
        capsule: "h-12 px-apple-6 rounded-apple-capsule",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface GlassButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof glassButtonVariants> {
  asChild?: boolean
}

const GlassButton = React.forwardRef<HTMLButtonElement, GlassButtonProps>(
  ({ className, variant, size, asChild = false, children, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    
    return (
      <Comp
        className={cn(glassButtonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      >
        {children}
      </Comp>
    )
  }
)
GlassButton.displayName = "GlassButton"

export { GlassButton, glassButtonVariants }
