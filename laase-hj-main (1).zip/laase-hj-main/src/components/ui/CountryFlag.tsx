import React from 'react';
import { cn } from '@/lib/utils';

interface CountryFlagProps {
  code: string | null;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const CountryFlag: React.FC<CountryFlagProps> = ({ 
  code, 
  className, 
  size = 'md' 
}) => {
  if (!code) return <span className="text-muted-foreground">🏳️</span>;
  
  // Convert country codes to flag icon format
  const getFlagClass = (countryCode: string): string => {
    const lowerCode = countryCode.toLowerCase();
    // Handle special cases
    if (lowerCode === 'uk') return 'fi-gb';
    return `fi-${lowerCode}`;
  };

  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5', 
    lg: 'w-6 h-6'
  };

  return (
    <span 
      className={cn(
        'fi inline-block rounded-sm overflow-hidden',
        getFlagClass(code),
        sizeClasses[size],
        className
      )}
      role="img"
      aria-label={code}
    />
  );
};