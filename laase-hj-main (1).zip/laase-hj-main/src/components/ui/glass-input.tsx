
import * as React from "react"
import { cn } from "@/lib/utils"

export interface GlassInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  variant?: 'default' | 'capsule'
}

const GlassInput = React.forwardRef<HTMLInputElement, GlassInputProps>(
  ({ className, type, variant = 'default', ...props }, ref) => {
    const variantClasses = {
      default: "rounded-apple-medium",
      capsule: "rounded-apple-capsule"
    }
    
    return (
      <input
        type={type}
        className={cn(
          "flex h-12 w-full glass border-0 bg-transparent px-apple-4 py-apple-3 text-apple-body font-apple placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-system-blue focus-visible:ring-offset-0 disabled:cursor-not-allowed disabled:opacity-50 transition-all duration-200 text-black",
          variantClasses[variant],
          "focus:scale-[1.02] focus:shadow-lg",
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
GlassInput.displayName = "GlassInput"

export { GlassInput }
