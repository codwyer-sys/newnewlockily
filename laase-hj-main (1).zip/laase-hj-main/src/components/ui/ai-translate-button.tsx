import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Bot, Loader2 } from 'lucide-react';
import { useAITranslation } from '@/hooks/useAITranslation';
import { toast } from 'sonner';

interface AITranslateButtonProps {
  originalText: string;
  targetLanguage: string;
  market?: string;
  context?: string;
  onTranslated: (translatedText: string) => void;
  customInstruction?: string;
  placement?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg';
  disabled?: boolean;
}

export const AITranslateButton: React.FC<AITranslateButtonProps> = ({
  originalText,
  targetLanguage,
  market,
  context = 'locksmith service interface',
  onTranslated,
  customInstruction,
  placement = 'admin interface',
  variant = 'outline',
  size = 'sm',
  disabled = false
}) => {
  const { translateText, isTranslating } = useAITranslation();
  const [abortController, setAbortController] = useState<AbortController | null>(null);

  const handleTranslate = async () => {
    if (isTranslating) {
      // Cancel current translation
      abortController?.abort();
      setAbortController(null);
      return;
    }

    if (!originalText.trim()) {
      toast.error('No text to translate');
      return;
    }

    const controller = new AbortController();
    setAbortController(controller);

    try {
      const translatedText = await translateText({
        originalText,
        targetLanguage,
        market,
        context,
        customInstruction: customInstruction || `Translate this ${context} text with professional locksmith terminology. Maintain emergency service appropriate tone.`,
        placement,
        abortSignal: controller.signal
      });

      if (translatedText && !controller.signal.aborted) {
        onTranslated(translatedText);
        toast.success('Translation completed');
      }
    } catch (error) {
      if (!controller.signal.aborted) {
        console.error('Translation failed:', error);
      }
    } finally {
      setAbortController(null);
    }
  };

  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      onClick={handleTranslate}
      disabled={disabled || !originalText.trim()}
      className="flex items-center gap-2"
    >
      {isTranslating ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          Cancel
        </>
      ) : (
        <>
          <Bot className="w-4 h-4" />
          AI Translate
        </>
      )}
    </Button>
  );
};