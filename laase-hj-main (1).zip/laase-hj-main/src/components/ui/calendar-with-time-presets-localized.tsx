"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { useLanguage } from '@/contexts/LanguageContext'
import { useMarket } from '@/contexts/MarketContext'

interface CalendarWithTimePresetsLocalizedProps {
  onDateTimeSelect: (date: Date, time: string) => void;
}

export function CalendarWithTimePresetsLocalized({ onDateTimeSelect }: CalendarWithTimePresetsLocalizedProps) {
  const [date, setDate] = React.useState<Date | undefined>(new Date())
  const [selectedTime, setSelectedTime] = React.useState<string | null>(null)
  const { t, language } = useLanguage()
  const { market } = useMarket()
  
  // Market-aware locale detection
  const locale = React.useMemo(() => {
    if (market.country_code === 'US') return 'en-US'
    if (market.country_code === 'UK') return 'en-GB'
    if (market.country_code === 'DE') return 'de-DE'
    if (market.country_code === 'FR') return 'fr-FR'
    if (market.country_code === 'ES') return 'es-ES'
    if (market.country_code === 'SV') return 'sv-SE'
    if (market.country_code === 'NO') return 'nb-NO'
    if (market.country_code === 'GA') return 'ga-IE'
    return `${language}-${market.country_code}`
  }, [language, market.country_code])

  // Market-aware week start (US: Sunday=0, Europe: Monday=1, Middle East: Saturday=6)
  const weekStartsOn = React.useMemo(() => {
    if (market.country_code === 'US') return 0 // Sunday
    if (['SA', 'AE', 'IL'].includes(market.country_code)) return 6 // Saturday  
    return 1 // Monday for Europe and most other countries
  }, [market.country_code])

  // Market-aware time format (12h for US, 24h for others)
  const use24Hour = market.country_code !== 'US'
  
  // Dynamic time slots starting from current time + 1.5 hours (24/7 availability)
  const timeSlots = React.useMemo(() => {
    const now = new Date()
    const earliestTime = new Date(now.getTime() + 1.5 * 60 * 60 * 1000) // +1.5 hours
    const selectedDate = date || new Date()
    
    // If selected date is today, start from earliest available time
    // If selected date is future, start from beginning of day
    const isToday = selectedDate.toDateString() === now.toDateString()
    const startHour = isToday ? earliestTime.getHours() : 0
    const startMinute = isToday ? Math.ceil(earliestTime.getMinutes() / 15) * 15 : 0
    
    const slots = []
    
    // Generate time slots for the entire day (24 hours)
    for (let hour = 0; hour < 24; hour++) {
      for (let minute = 0; minute < 60; minute += 15) {
        // Skip times before earliest available time on current day
        if (isToday && (hour < startHour || (hour === startHour && minute < startMinute))) {
          continue
        }
        
        if (use24Hour) {
          slots.push(`${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`)
        } else {
          const period = hour >= 12 ? 'PM' : 'AM'
          const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
          slots.push(`${displayHour}:${minute.toString().padStart(2, "0")} ${period}`)
        }
      }
    }
    
    return slots
  }, [use24Hour, date])
  
  // Auto-select first available time when date changes
  React.useEffect(() => {
    if (timeSlots.length > 0 && !selectedTime) {
      setSelectedTime(timeSlots[0])
    }
  }, [timeSlots, selectedTime])

  const bookedDates = Array.from(
    { length: 3 },
    (_, i) => new Date(2025, 5, 17 + i)
  )

  React.useEffect(() => {
    if (date && selectedTime) {
      let hours: number, minutes: number
      
      if (use24Hour) {
        [hours, minutes] = selectedTime.split(':').map(Number)
      } else {
        const [time, period] = selectedTime.split(' ')
        const [h, m] = time.split(':').map(Number)
        hours = period === 'PM' && h !== 12 ? h + 12 : period === 'AM' && h === 12 ? 0 : h
        minutes = m
      }
      
      const dateTime = new Date(date)
      dateTime.setHours(hours, minutes, 0, 0)
      onDateTimeSelect(dateTime, selectedTime)
    }
  }, [date, selectedTime, onDateTimeSelect, use24Hour])

  return (
    <Card className="gap-0 p-0 bg-card border-border">
      <CardContent className="relative p-0 md:pr-48">
        <div className="p-6">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            defaultMonth={date}
            weekStartsOn={weekStartsOn}
            disabled={bookedDates}
            showOutsideDays={false}
            modifiers={{
              booked: bookedDates,
            }}
            modifiersClassNames={{
              booked: "[&>button]:line-through opacity-100",
            }}
            className="bg-transparent p-0 text-card-foreground [--cell-size:--spacing(10)] md:[--cell-size:--spacing(12)]"
            formatters={{
              formatWeekdayName: (date) => {
                return date.toLocaleString(locale, { weekday: "short" })
              },
            }}
          />
        </div>
        <div className="no-scrollbar inset-y-0 right-0 flex max-h-72 w-full scroll-pb-6 flex-col gap-4 overflow-y-auto border-t border-border p-6 md:absolute md:max-h-none md:w-48 md:border-t-0 md:border-l">
          <div className="grid gap-2">
            {timeSlots.map((time) => (
              <Button
                key={time}
                variant={selectedTime === time ? "default" : "outline"}
                onClick={() => setSelectedTime(time)}
                className="w-full"
              >
                {time}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-4 border-t border-border px-6 !py-5 md:flex-row">
        <div className="text-sm text-muted-foreground">
          {date && selectedTime ? (
            <>
              <span>
                {date?.toLocaleDateString(locale, {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                })}{" "}
              </span>
              <span>{t('calendar.at_time')} </span>
              <span className="font-medium text-card-foreground">{selectedTime}</span>
            </>
          ) : (
            <span>{t('calendar.select_date')}</span>
          )}
        </div>
      </CardFooter>
    </Card>
  )
}