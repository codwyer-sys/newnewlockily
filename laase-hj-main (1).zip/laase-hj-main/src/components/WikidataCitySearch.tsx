import React, { useState, useEffect } from 'react';
import { Search, Globe, MapPin, Users, Plus, Loader2, Languages } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMarket } from '@/contexts/MarketContext';
import { useCityTranslations } from '@/hooks/useCityTranslations';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface MapboxCity {
  id: string;
  name: string;
  country: string;
  countryCode?: string;
  population?: number;
  latitude?: number;
  longitude?: number;
  timezone?: string;
  administrativeLevel?: string;
  localNames?: { [languageCode: string]: string };
}

interface WikidataCitySearchProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCityImported: () => void;
  selectedMarket?: string;
}

export const WikidataCitySearch: React.FC<WikidataCitySearchProps> = ({
  open,
  onOpenChange,
  onCityImported,
  selectedMarket: parentSelectedMarket,
}) => {
  const { market } = useMarket();
  const { toast } = useToast();
  const { saveCityTranslations } = useCityTranslations();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MapboxCity[]>([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState<string | null>(null);
  const [selectedMarket, setSelectedMarket] = useState<string>(
    parentSelectedMarket && parentSelectedMarket !== 'ALL' ? parentSelectedMarket : market.country_code
  );
  const [availableMarkets, setAvailableMarkets] = useState<Array<{country_code: string, country_name: string}>>([]);

  const searchCities = async (query: string) => {
    if (query.length < 3) {
      setSearchResults([]);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('mapbox-city-search', {
        body: { action: 'search', query, marketCode: selectedMarket }
      });

      if (error) throw error;
      
      // Handle both error responses and successful responses
      if (data.error) {
        console.warn('Mapbox search warning:', data.error);
        toast({
          title: 'Search Notice',
          description: data.error,
          variant: 'default',
        });
      }
      
      setSearchResults(data.cities || []);
    } catch (error: any) {
      console.error('Search error:', error);
      
      let errorMessage = 'Failed to search cities from Mapbox';
      if (error.message?.includes('timeout') || error.status === 408) {
        errorMessage = 'Search timed out - try a more specific query';
      } else if (error.message?.includes('network')) {
        errorMessage = 'Network error - please check your connection';
      }
      
      toast({
        title: 'Search Error',
        description: errorMessage,
        variant: 'destructive',
      });
      setSearchResults([]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch available markets
  useEffect(() => {
    const fetchMarkets = async () => {
      try {
        const { data, error } = await supabase
          .from('markets')
          .select('country_code, country_name')
          .order('country_name');

        if (error) throw error;
        
        // Add "All Countries" option at the beginning
        const marketsWithAll = [
          { country_code: 'ALL', country_name: 'All Countries' },
          ...(data || [])
        ];
        
        setAvailableMarkets(marketsWithAll);
      } catch (error) {
        console.error('Error fetching markets:', error);
      }
    };

    fetchMarkets();
  }, []);

  // Update selected market when parent changes
  useEffect(() => {
    if (parentSelectedMarket && parentSelectedMarket !== 'ALL') {
      setSelectedMarket(parentSelectedMarket);
    }
  }, [parentSelectedMarket]);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery) {
        searchCities(searchQuery);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchQuery, selectedMarket]); // Include selectedMarket in dependencies

  const generateSlug = (name: string) => {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  };

  // Map country codes to market codes
  const mapCountryToMarket = (countryCode?: string): string => {
    const mapping: { [key: string]: string } = {
      'DK': 'DK', 'Denmark': 'DK',
      'DE': 'DE', 'Germany': 'DE', 
      'GB': 'UK', 'United Kingdom': 'UK',
      'US': 'US', 'United States': 'US',
      'SE': 'SE', 'Sweden': 'SE',
      'NO': 'NO', 'Norway': 'NO',
      'IE': 'IE', 'Ireland': 'IE',
      'FR': 'FR', 'France': 'FR',
      'ES': 'ES', 'Spain': 'ES',
      'PL': 'PL', 'Poland': 'PL',
      'CA': 'CA', 'Canada': 'CA',
      'PT': 'PT', 'Portugal': 'PT',
      'IT': 'IT', 'Italy': 'IT',
      'FI': 'FI', 'Finland': 'FI',
      'CZ': 'CZ', 'Czech Republic': 'CZ',
    };
    
    return countryCode ? (mapping[countryCode] || market.country_code) : market.country_code;
  };

  // Get language code for a market
  const getLanguageForMarket = (marketCode?: string): string => {
    const languageMap: { [key: string]: string } = {
      'DK': 'da',
      'DE': 'de',
      'SE': 'sv',
      'NO': 'no',
      'GB': 'en',
      'UK': 'en',
      'US': 'en',
      'CA': 'en',
      'FR': 'fr',
      'ES': 'es',
      'IT': 'it',
      'PL': 'pl',
      'PT': 'pt',
      'FI': 'fi',
      'CZ': 'cs',
      'IE': 'en',
    };
    
    return languageMap[marketCode || ''] || 'en';
  };

  const importCity = async (city: MapboxCity) => {
    setImporting(city.id);
    try {
      // Step 1: Get detailed information with dual language calls
      const detectedMarket = mapCountryToMarket(city.countryCode);
      const { data: detailData, error: detailError } = await supabase.functions.invoke('mapbox-city-search', {
        body: { action: 'details', cityId: city.id, marketCode: detectedMarket }
      });

      if (detailError) throw detailError;
      
      const detailedCity = detailData.city;
      
      // Step 2: Check if city already exists
      const { data: existingCity } = await supabase
        .from('cities')
        .select('id')
        .eq('name', detailedCity.name)
        .eq('market_code', detectedMarket)
        .single();

      if (existingCity) {
        toast({
          title: 'City Already Exists',
          description: `${detailedCity.name} is already in your database`,
          variant: 'destructive',
        });
        return;
      }

      // Step 3: Insert the city with English name as primary
      const { data: insertedCity, error: insertError } = await supabase
        .from('cities')
        .insert([{
          name: detailedCity.name, // Always English name
          slug: generateSlug(detailedCity.name),
          market_code: detectedMarket,
          latitude: detailedCity.latitude,
          longitude: detailedCity.longitude,
          population: detailedCity.population,
          administrative_level: detailedCity.administrativeLevel,
          is_active: true,
          is_metropolitan: (detailedCity.population || 0) > 100000,
          seo_title: `${detailedCity.name} - Professional Locksmith Services`,
          seo_description: `Find trusted locksmiths in ${detailedCity.name}. Emergency and scheduled locksmith services available 24/7.`
        }])
        .select()
        .single();

      if (insertError) throw insertError;

      // Step 4: Handle local name translation
      const marketLanguage = getLanguageForMarket(detectedMarket);
      let localNameSaved = false;

      // Try to use Mapbox-provided localized name first
      if (insertedCity && detailedCity.localNames) {
        try {
          const localizedName = detailedCity.localNames[marketLanguage];
          
          if (localizedName && localizedName !== detailedCity.name) {
            await saveCityTranslations(
              insertedCity.id,
              { [marketLanguage]: localizedName },
              'mapbox_native',
              detectedMarket
            );
            console.log(`✅ Saved Mapbox localized name: ${localizedName} for ${detailedCity.name}`);
            localNameSaved = true;
          }
        } catch (error) {
          console.warn('Failed to save Mapbox localized name:', error);
        }
      }

      // Step 5: Always ensure we have a local name (AI fallback if needed)
      if (insertedCity && !localNameSaved && marketLanguage !== 'en') {
        try {
          console.log(`🤖 Using AI fallback for ${detailedCity.name} → ${marketLanguage}`);
          
          const { data: aiResult, error: aiError } = await supabase.functions.invoke('ai-translate-city-names', {
            body: {
              cityId: insertedCity.id,
              cityName: detailedCity.name,
              marketCode: detectedMarket,
              coordinates: {
                latitude: detailedCity.latitude,
                longitude: detailedCity.longitude
              }
            }
          });
          
          if (aiError) {
            console.warn('AI translation failed:', aiError);
          } else {
            console.log(`✅ AI translation completed for ${detailedCity.name}: ${aiResult?.translatedName}`);
            localNameSaved = true;
          }
        } catch (error) {
          console.warn('AI translation fallback failed:', error);
        }
      }

      // Determine the translation source for user feedback
      let translationSource = 'English only';
      if (localNameSaved) {
        translationSource = detailedCity.localNames ? 'Mapbox localized' : 'AI translated';
      }
      
      toast({
        title: 'Success', 
        description: `${detailedCity.name} imported successfully with ${translationSource} name`,
      });

      onCityImported();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Import error:', error);
      toast({
        title: 'Import Error',
        description: error.message || 'Failed to import city',
        variant: 'destructive',
      });
    } finally {
      setImporting(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Import Cities from Mapbox
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="market-select">Search Market</Label>
            <Select value={selectedMarket} onValueChange={(value) => {
              setSelectedMarket(value);
              setSearchResults([]); // Clear results when market changes
            }}>
              <SelectTrigger id="market-select">
                <SelectValue placeholder="Select market to search in..." />
              </SelectTrigger>
              <SelectContent>
                {availableMarkets.map((marketOption) => (
                  <SelectItem key={marketOption.country_code} value={marketOption.country_code}>
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      {marketOption.country_name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Type at least 3 characters to search cities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            {loading && (
              <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
            )}
          </div>

          <div className="grid gap-3 max-h-96 overflow-y-auto">
            {searchResults.map((city) => (
              <Card key={city.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                      <div className="flex-1">
                       <div className="flex items-center gap-2 mb-2">
                         <h3 className="font-semibold">
                           {city.name}
                           {city.localNames && Object.values(city.localNames)[0] && (
                             <span className="text-sm text-muted-foreground ml-2">
                               ({Object.values(city.localNames)[0]})
                             </span>
                           )}
                         </h3>
                         <Badge variant="outline">{city.country}</Badge>
                         {selectedMarket !== 'ALL' && selectedMarket !== mapCountryToMarket(city.countryCode) && (
                           <Badge variant="secondary">Cross-market</Badge>
                         )}
                       </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        {city.latitude && city.longitude && (
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            <span>{city.latitude.toFixed(2)}, {city.longitude.toFixed(2)}</span>
                          </div>
                        )}
                        
                        {city.population && (
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            <span>{city.population.toLocaleString()}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <Button
                      size="sm"
                      onClick={() => importCity(city)}
                      disabled={importing === city.id}
                    >
                      {importing === city.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <Plus className="h-4 w-4 mr-1" />
                          Import
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {searchQuery && !loading && searchResults.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No cities found for "{searchQuery}"
              </div>
            )}
            
            {!searchQuery && (
              <div className="text-center py-8 text-muted-foreground">
                {selectedMarket === 'ALL' 
                  ? 'Type at least 3 characters to search cities worldwide'
                  : `Type at least 3 characters to search cities in ${availableMarkets.find(m => m.country_code === selectedMarket)?.country_name || selectedMarket}`
                }
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};