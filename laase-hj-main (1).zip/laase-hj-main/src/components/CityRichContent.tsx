import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Shield, Star } from 'lucide-react';

interface City {
  id: string;
  name: string;
  content?: string;
  content_last_updated?: string;
  webhook_processed?: boolean;
}

interface CityRichContentProps {
  city: City;
}

export const CityRichContent: React.FC<CityRichContentProps> = ({ city }) => {
  const hasRichContent = city.content && city.webhook_processed;

  if (!hasRichContent) {
    // Fallback content when AI hasn't processed the city yet
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                24/7 Emergency Service
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Round-the-clock locksmith services in {city.name}. Emergency lockouts, 
                broken keys, and security issues resolved quickly by certified professionals.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Certified Professionals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                All locksmiths in {city.name} are fully licensed, insured, and background-checked. 
                Professional installation and repair of all lock types and security systems.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Local Coverage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Complete coverage throughout {city.name} and surrounding areas. 
                Fast response times with local professionals who know the area.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Our Services in {city.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-3">
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <span>Emergency Lockout Assistance</span>
                  <Badge variant="secondary">24/7</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <span>Lock Installation & Repair</span>
                  <Badge variant="secondary">Professional</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <span>Key Cutting & Duplication</span>
                  <Badge variant="secondary">Fast</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <span>Security System Installation</span>
                  <Badge variant="secondary">Expert</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <span>Commercial & Residential</span>
                  <Badge variant="secondary">All Types</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Why Choose Our {city.name} Locksmiths</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Star className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Highly Rated</h4>
                    <p className="text-sm text-muted-foreground">
                      Top-rated locksmiths with excellent customer reviews
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Shield className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Fully Insured</h4>
                    <p className="text-sm text-muted-foreground">
                      Complete insurance coverage for your peace of mind
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Fast Response</h4>
                    <p className="text-sm text-muted-foreground">
                      Quick arrival times throughout {city.name}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MapPin className="h-5 w-5 text-purple-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Local Expertise</h4>
                    <p className="text-sm text-muted-foreground">
                      Local professionals familiar with {city.name} area
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Display AI-generated rich content
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div 
          className="prose prose-lg max-w-none"
          dangerouslySetInnerHTML={{ __html: city.content }}
        />
        
        {city.content_last_updated && (
          <div className="mt-8 text-sm text-muted-foreground text-center">
            Content last updated: {new Date(city.content_last_updated).toLocaleDateString()}
          </div>
        )}
      </div>
    </div>
  );
};