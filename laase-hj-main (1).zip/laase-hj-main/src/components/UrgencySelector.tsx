import React from 'react';
import { Button } from "@/components/ui/button";
import { Clock, Calendar, Check } from "lucide-react";
import { CalendarWithTimePresetsLocalized } from "@/components/ui/calendar-with-time-presets-localized";
import { useLanguage } from '@/contexts/LanguageContext';

interface UrgencySelectorProps {
  urgency: string;
  selectedDate: string;
  onUrgencySelect: (urgency: string) => void;
  onDateChange: (date: string) => void;
  showUrgency: boolean;
}

const UrgencySelector: React.FC<UrgencySelectorProps> = ({
  urgency,
  selectedDate,
  onUrgencySelect,
  onDateChange,
  showUrgency
}) => {
  const { t } = useLanguage();
  
  if (!showUrgency) return null;

  const handleUrgencyClick = (selectedUrgency: string) => {
    onUrgencySelect(selectedUrgency);
    if (selectedUrgency === "nu" || selectedUrgency === "asap") {
      onDateChange("");
    }
  };

  const handleDateTimeSelect = (date: Date, time: string) => {
    onDateChange(date.toISOString());
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div>
        <label className="block text-sm font-medium text-card-foreground mb-2">
          {t('home.booking.urgency_title')}
        </label>
        <div className="grid grid-cols-2 gap-4">
          <Button
            type="button"
            variant={urgency === "nu" ? "default" : "outline"}
            onClick={() => handleUrgencyClick("nu")}
            className={`h-16 md:h-20 flex items-center justify-start gap-3 md:gap-4 p-3 md:p-4 transition-all duration-200 ${
              urgency === "nu" 
                ? "bg-primary text-primary-foreground border border-primary" 
                : "bg-card border border-border hover:border-primary hover:bg-primary/5"
            }`}
          >
            <Clock className="w-5 h-5 md:w-6 md:h-6 text-red-500 flex-shrink-0" />
            <div className="text-left flex-1 min-w-0">
              <div className={`font-headline font-bold text-sm md:text-base ${
                urgency === "nu" ? "text-primary-foreground" : "text-card-foreground"
              }`}>{t('home.booking.urgency_now')}</div>
               <div className={`text-xs md:text-sm flex items-center gap-1 mt-0.5 md:mt-1 ${
                 urgency === "nu" ? "text-primary-foreground/80" : "text-muted-foreground"
               }`}>
                 <Check className="w-3 h-3 text-green-500 flex-shrink-0" />
                 <span className="sm:hidden">{t('home.booking.urgency_now_mobile')}</span>
                 <span className="hidden sm:inline">{t('home.booking.urgency_now_desc')}</span>
               </div>
            </div>
          </Button>
          
          <Button
            type="button"
            variant={urgency === "scheduled" ? "default" : "outline"}
            onClick={() => handleUrgencyClick("scheduled")}
            className={`h-16 md:h-20 flex items-center justify-start gap-3 md:gap-4 p-3 md:p-4 transition-all duration-200 ${
              urgency === "scheduled" 
                ? "bg-primary text-primary-foreground border border-primary" 
                : "bg-card border border-border hover:border-primary hover:bg-primary/5"
            }`}
          >
            <Calendar className={`w-5 h-5 md:w-6 md:h-6 flex-shrink-0 ${
              urgency === "scheduled" ? "text-primary-foreground" : "text-card-foreground"
            }`} />
            <div className="text-left flex-1 min-w-0">
              <div className={`font-headline font-bold text-sm md:text-base ${
                urgency === "scheduled" ? "text-primary-foreground" : "text-card-foreground"
              }`}>{t('home.booking.urgency_later')}</div>
               <div className={`text-xs md:text-sm mt-0.5 md:mt-1 ${
                 urgency === "scheduled" ? "text-primary-foreground/80" : "text-muted-foreground"
               }`}>
                 <span className="sm:hidden">Fra 1,5t</span>
                 <span className="hidden sm:inline">Planlæg besøg - tilgængelig 24/7/365 fra 1,5 timer</span>
               </div>
            </div>
          </Button>
        </div>
      </div>

      {urgency === "scheduled" && (
        <div className="space-y-2 animate-fade-in">
          <CalendarWithTimePresetsLocalized onDateTimeSelect={handleDateTimeSelect} />
        </div>
      )}
    </div>
  );
};

export default UrgencySelector;