import React, { useState, useEffect } from 'react';
import { Label } from "@/components/ui/label";
import { useTranslatedFollowUpQuestions } from "@/hooks/useTranslatedFollowUpQuestions";
import QuestionProgressIndicator from "@/components/QuestionProgressIndicator";
import QuestionInput from "@/components/QuestionInput";
import { useLanguage } from '@/contexts/LanguageContext';

interface FollowUpQuestionsProps {
  jobType: string;
  answers: Record<string, any>;
  onAnswerChange: (questionKey: string, answer: any) => void;
}

const FollowUpQuestions: React.FC<FollowUpQuestionsProps> = ({ 
  jobType, 
  answers, 
  onAnswerChange 
}) => {
  const { t } = useLanguage();
  const { questions, loading } = useTranslatedFollowUpQuestions(jobType);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const currentQuestion = questions[currentQuestionIndex];
  const isCurrentAnswered = currentQuestion ? 
    answers[currentQuestion.question_key] !== undefined && 
    answers[currentQuestion.question_key] !== "" : false;

  const handleAnswerSelect = (answer: any) => {
    if (!currentQuestion) return;
    
    onAnswerChange(currentQuestion.question_key, answer);
    
    if (currentQuestionIndex < questions.length - 1) {
      setTimeout(() => {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      }, 300);
    }
  };

  const handleCheckboxChange = (option: string, checked: boolean) => {
    if (!currentQuestion) return;
    
    const currentAnswers = answers[currentQuestion.question_key] || [];
    let newAnswers;
    
    if (checked) {
      newAnswers = [...currentAnswers, option];
    } else {
      newAnswers = currentAnswers.filter((item: string) => item !== option);
    }
    
    onAnswerChange(currentQuestion.question_key, newAnswers);
  };

  if (!jobType || questions.length === 0) {
    if (loading) {
      return (
        <div className="space-y-4 animate-fade-in">
          <label className="block text-sm font-medium text-card-foreground mb-2">
            {t('home.booking.follow_up_title')}
          </label>
          <div className="space-y-4">
            <div className="h-6 bg-muted rounded animate-pulse"></div>
            <div className="space-y-3">
              <div className="h-12 bg-muted rounded animate-pulse"></div>
              <div className="h-12 bg-muted rounded animate-pulse"></div>
              <div className="h-12 bg-muted rounded animate-pulse"></div>
            </div>
          </div>
        </div>
      );
    }
    return null;
  }

  if (!currentQuestion) {
    return null;
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <label className="block text-sm font-medium text-card-foreground mb-2">
        {t('home.booking.follow_up_title')}
      </label>

      <QuestionProgressIndicator 
        currentIndex={currentQuestionIndex}
        totalQuestions={questions.length}
      />

      <div className="space-y-4">
        <div className="mb-4">
          <Label className="text-card-foreground font-headline font-semibold text-base block mb-4">
            {currentQuestion.question}
          </Label>
        </div>

        <QuestionInput
          question={currentQuestion}
          answer={answers[currentQuestion.question_key]}
          onAnswerSelect={handleAnswerSelect}
          onCheckboxChange={handleCheckboxChange}
        />
      </div>

      <div className="text-left">
        <div className="text-sm text-muted-foreground">
          {isCurrentAnswered && currentQuestionIndex === questions.length - 1 
            ? t('follow_up.all_answered')
            : isCurrentAnswered 
            ? t('follow_up.answered')
            : currentQuestion.is_required 
            ? t('follow_up.choose_answer')
            : t('follow_up.optional')}
        </div>
      </div>
    </div>
  );
};

export default FollowUpQuestions;