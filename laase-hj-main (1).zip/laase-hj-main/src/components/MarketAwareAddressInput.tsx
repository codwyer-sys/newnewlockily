import React, { useState, useRef } from 'react';
import { GlassInput } from "@/components/ui/glass-input";
import { GlassButton } from "@/components/ui/glass-button";
import { GlassCard } from "@/components/ui/glass-card";
import { MapPin } from "lucide-react";
import { useMarket } from '@/contexts/MarketContext';
import { supabase } from '@/integrations/supabase/client';
import { useMarketAddressSearch } from "@/hooks/useMarketAddressSearch";
import { useGeolocation } from "@/hooks/useGeolocation";
import { AddressSearchResult } from '@/services/address/types';

interface MarketAwareAddressInputProps {
  address: string;
  onAddressChange: (address: string) => void;
  onLocationClick?: () => void;
  className?: string;
}

interface UKAddress {
  address: string;
  postcode: string;
  coordinates: {
    latitude: number;
    longitude: number;
  };
}

const MarketAwareAddressInput: React.FC<MarketAwareAddressInputProps> = ({
  address,
  onAddressChange,
  onLocationClick,
  className
}) => {
  const { market } = useMarket();
  const [ukAddresses, setUkAddresses] = useState<UKAddress[]>([]);
  const [showUkSuggestions, setShowUkSuggestions] = useState(false);
  const [isLoadingUkAddresses, setIsLoadingUkAddresses] = useState(false);
  const [postcode, setPostcode] = useState('');
  const addressInputRef = useRef<HTMLInputElement>(null);
  
  console.log('🌍 Current market in MarketAwareAddressInput:', market.country_code);
  
  // Use market-aware address search for DK market only
  const { suggestions: addressSuggestions } = useMarketAddressSearch(address, market.country_code === 'DK');
  const { getCurrentLocation, isLoadingLocation } = useGeolocation();
  const [showDkSuggestions, setShowDkSuggestions] = useState(false);

  const handleUkPostcodeLookup = async (postcodeInput: string) => {
    // More lenient check for UK postcodes - allow shorter inputs
    if (postcodeInput.length < 4) return;

    console.log('🔍 Looking up UK postcode:', postcodeInput);
    setIsLoadingUkAddresses(true);
    try {
      const { data, error } = await supabase.functions.invoke('uk-postcode-lookup', {
        body: { postcode: postcodeInput }
      });

      if (error) {
        console.error('UK postcode lookup error:', error);
        throw error;
      }
      
      console.log('UK postcode lookup response:', data);
      if (data?.addresses && data.addresses.length > 0) {
        setUkAddresses(data.addresses);
        setShowUkSuggestions(true);
        console.log('✅ Found', data.addresses.length, 'addresses for', postcodeInput);
      } else {
        console.log('❌ No addresses found for postcode:', postcodeInput);
        setUkAddresses([]);
        setShowUkSuggestions(false);
      }
    } catch (error) {
      console.error('UK postcode lookup failed:', error);
      setUkAddresses([]);
      setShowUkSuggestions(false);
    } finally {
      setIsLoadingUkAddresses(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    
    if (market.country_code === 'UK') {
      setPostcode(value);
      onAddressChange(value); // Update parent component too
      // Clear previous suggestions
      setUkAddresses([]);
      setShowUkSuggestions(false);
      
      // Trigger postcode lookup when it looks like a UK postcode
      if (value.length >= 4) {
        console.log('🇬🇧 Triggering UK postcode lookup for:', value);
        handleUkPostcodeLookup(value);
      }
    } else {
      // Danish address handling (existing logic)
      onAddressChange(value);
      if (value.length >= 3 && market.country_code === 'DK') {
        setShowDkSuggestions(true);
      } else {
        setShowDkSuggestions(false);
      }
    }
  };

  const handleUkAddressSelect = (ukAddress: UKAddress) => {
    onAddressChange(ukAddress.address);
    setShowUkSuggestions(false);
    setPostcode(ukAddress.address);
    if (addressInputRef.current) {
      addressInputRef.current.blur();
    }
  };

  const handleDkAddressSelect = (suggestion: AddressSearchResult) => {
    onAddressChange(suggestion.fullAddress);
    setShowDkSuggestions(false);
    if (addressInputRef.current) {
      addressInputRef.current.blur();
    }
  };

  const handleLocationClick = async () => {
    if (onLocationClick) {
      onLocationClick();
    } else {
      const location = await getCurrentLocation();
      if (location) {
        onAddressChange(location);
        setShowDkSuggestions(false);
        setShowUkSuggestions(false);
      }
    }
  };

  const getPlaceholder = () => {
    switch (market.country_code) {
      case 'UK':
        return 'Enter your postcode (e.g., SW1A 1AA)';
      case 'US':
        return 'Enter your address';
      case 'DE':
        return 'Geben Sie Ihre Adresse ein';
      default:
        return 'Hvor skal du bruge en låsesmed?';
    }
  };

  return (
    <div className={`space-y-apple-4 relative ${className}`}>
      <div className="flex gap-apple-3">
        <div className="relative flex-1">
          <div className="relative">
            <GlassInput
              ref={addressInputRef}
              placeholder={getPlaceholder()}
              value={market.country_code === 'UK' ? postcode : address}
              onChange={handleInputChange}
              onFocus={() => {
                if (market.country_code === 'DK' && addressSuggestions.length > 0 && address.length >= 3) {
                  setShowDkSuggestions(true);
                }
              }}
              onBlur={() => {
                setTimeout(() => {
                  setShowDkSuggestions(false);
                  setShowUkSuggestions(false);
                }, 150);
              }}
              variant="capsule"
              className="pl-12 h-14 text-apple-body placeholder:text-system-gray2"
              autoFocus
            />
            <MapPin className="absolute left-apple-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-system-gray2" />
          </div>
          
          {/* UK Address Suggestions */}
          {market.country_code === 'UK' && showUkSuggestions && ukAddresses.length > 0 && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-2 max-h-60 overflow-y-auto"
            >
              {ukAddresses.map((ukAddress, index) => (
                <button
                  key={index}
                  className="w-full text-left px-apple-4 py-apple-3 hover:bg-system-blue/10 active:bg-system-blue/20 transition-colors text-apple-body font-apple border-b border-system-gray6 last:border-b-0 rounded-none first:rounded-t-apple-large last:rounded-b-apple-large"
                  onClick={() => handleUkAddressSelect(ukAddress)}
                >
                  {ukAddress.address}
                </button>
              ))}
            </GlassCard>
          )}

          {/* Danish Address Suggestions */}
          {market.country_code === 'DK' && showDkSuggestions && addressSuggestions.length > 0 && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-2 max-h-60 overflow-y-auto"
            >
              {addressSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full text-left px-apple-4 py-apple-3 hover:bg-system-blue/10 active:bg-system-blue/20 transition-colors text-apple-body font-apple border-b border-system-gray6 last:border-b-0 rounded-none first:rounded-t-apple-large last:rounded-b-apple-large"
                  onClick={() => handleDkAddressSelect(suggestion)}
                >
                  {suggestion.displayText}
                </button>
              ))}
            </GlassCard>
          )}

          {/* Loading indicator for UK */}
          {market.country_code === 'UK' && isLoadingUkAddresses && (
            <GlassCard 
              variant="thick"
              className="absolute z-50 w-full mt-apple-2 py-apple-4 text-center"
            >
              <div className="text-system-gray2">Looking up addresses...</div>
            </GlassCard>
          )}
        </div>
        
        <GlassButton
          type="button"
          variant="primary"
          size="capsule"
          onClick={handleLocationClick}
          disabled={isLoadingLocation}
          className="h-14 px-apple-6 min-w-[140px] text-apple-callout font-semibold text-white"
        >
          <MapPin className={`w-5 h-5 ${isLoadingLocation ? 'animate-spin' : ''}`} />
          {market.country_code === 'UK' ? 'My Location' : 
           market.country_code === 'US' ? 'My Location' :
           market.country_code === 'DE' ? 'Mein Standort' : 'Min lokation'}
        </GlassButton>
      </div>
    </div>
  );
};

export default MarketAwareAddressInput;