
import React from 'react';
import { MessageSquare, Hash, Type, CheckSquare } from "lucide-react";

interface QuestionTypeIconProps {
  type: string;
}

const QuestionTypeIcon: React.FC<QuestionTypeIconProps> = ({ type }) => {
  switch (type) {
    case 'radio':
      return <MessageSquare className="w-5 h-5 text-system-blue" />;
    case 'checkbox':
      return <CheckSquare className="w-5 h-5 text-system-blue" />;
    case 'number':
      return <Hash className="w-5 h-5 text-system-blue" />;
    case 'text':
      return <Type className="w-5 h-5 text-system-blue" />;
    default:
      return <MessageSquare className="w-5 h-5 text-system-blue" />;
  }
};

export default QuestionTypeIcon;
