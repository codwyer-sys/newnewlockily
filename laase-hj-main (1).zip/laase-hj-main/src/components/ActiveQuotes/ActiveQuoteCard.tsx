import React, { useState } from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, Euro, MessageSquare, X, Edit2 } from "lucide-react";
import { ActiveQuote } from "@/hooks/useActiveQuotes";
import { useLanguage } from "@/contexts/LanguageContext";

interface ActiveQuoteCardProps {
  quote: ActiveQuote;
  onWithdraw: (quoteId: string) => Promise<boolean>;
  onUpdate: (quoteId: string, updates: { price?: number; message?: string }) => Promise<boolean>;
}

export const ActiveQuoteCard: React.FC<ActiveQuoteCardProps> = ({ 
  quote, 
  onWithdraw,
  onUpdate 
}) => {
  const { t } = useLanguage();
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const formatTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expires = new Date(expiresAt);
    const diffMs = expires.getTime() - now.getTime();
    
    if (diffMs <= 0) return "Udløbet";
    
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) {
      return `${diffHours}t ${diffMinutes}m tilbage`;
    }
    return `${diffMinutes}m tilbage`;
  };

  const formatArrivalTime = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} min`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return remainingMinutes > 0 ? `${hours}t ${remainingMinutes}m` : `${hours}t`;
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'emergency': return 'destructive';
      case 'high': return 'default';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'secondary';
    }
  };

  const handleWithdraw = async () => {
    setIsWithdrawing(true);
    try {
      await onWithdraw(quote.id);
    } finally {
      setIsWithdrawing(false);
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{quote.job_category.emoji || '🔒'}</span>
            <div>
              <h3 className="font-semibold text-lg">{quote.job_category.name}</h3>
              <p className="text-sm text-muted-foreground">Job #{quote.booking.job_number}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={getUrgencyColor(quote.booking.urgency)}>
              {quote.booking.urgency}
            </Badge>
            <Badge variant="outline" className="text-xs">
              <Clock className="w-3 h-3 mr-1" />
              {formatTimeRemaining(quote.expires_at)}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Address */}
        <div className="flex items-start gap-2">
          <MapPin className="w-4 h-4 mt-0.5 text-muted-foreground" />
          <p className="text-sm text-muted-foreground flex-1">{quote.booking.address}</p>
        </div>

        {/* Quote Details */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Dit tilbud</p>
            <div className="flex items-center gap-1">
              <Euro className="w-4 h-4 text-muted-foreground" />
              <span className="font-semibold text-lg">{quote.price.toFixed(0)} kr</span>
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Ankomsttid</p>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="font-medium">{formatArrivalTime(quote.estimated_arrival_minutes)}</span>
            </div>
          </div>
        </div>

        {/* Distance */}
        {quote.distance_km > 0 && (
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Afstand</p>
            <p className="text-sm">{quote.distance_km.toFixed(1)} km</p>
          </div>
        )}

        {/* Message */}
        {quote.message && (
          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <MessageSquare className="w-3 h-3 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">Besked</p>
            </div>
            <p className="text-sm bg-muted/30 p-2 rounded">{quote.message}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => setIsEditing(!isEditing)}
          >
            <Edit2 className="w-4 h-4 mr-2" />
            Rediger
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleWithdraw}
            disabled={isWithdrawing}
            className="text-destructive hover:text-destructive"
          >
            <X className="w-4 h-4 mr-2" />
            {isWithdrawing ? 'Trækker tilbage...' : 'Træk tilbage'}
          </Button>
        </div>

        {/* Quick Edit Form */}
        {isEditing && (
          <div className="border-t pt-4 space-y-3">
            <p className="text-sm font-medium">Rediger tilbud</p>
            {/* TODO: Add edit form */}
            <p className="text-xs text-muted-foreground">Redigeringsfunktion kommer snart</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};