import React from 'react';
import { Card } from "@/components/ui/card";
import { Loader2, Quote } from "lucide-react";
import { ActiveQuoteCard } from "./ActiveQuoteCard";
import { useActiveQuotes } from "@/hooks/useActiveQuotes";
import { useToast } from "@/hooks/use-toast";

export const ActiveQuotesSection: React.FC = () => {
  const { quotes, loading, error, withdrawQuote, updateQuote } = useActiveQuotes();
  const { toast } = useToast();

  const handleWithdraw = async (quoteId: string) => {
    const success = await withdrawQuote(quoteId);
    if (success) {
      toast({
        title: "Tilbud trukket tilbage",
        description: "Dit tilbud er blevet trukket tilbage og vil ikke længere være synligt for kunden."
      });
    } else {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved at trække tilbuddet tilbage. Prøv igen.",
        variant: "destructive"
      });
    }
    return success;
  };

  const handleUpdate = async (quoteId: string, updates: { price?: number; message?: string }) => {
    const success = await updateQuote(quoteId, updates);
    if (success) {
      toast({
        title: "Tilbud opdateret",
        description: "Dit tilbud er blevet opdateret."
      });
    } else {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved opdatering af tilbuddet. Prøv igen.",
        variant: "destructive"
      });
    }
    return success;
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Aktive Tilbud</h2>
        <div className="flex items-center justify-center p-8">
          <Loader2 className="h-6 w-6 animate-spin mr-2" />
          <span>Henter dine aktive tilbud...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Aktive Tilbud</h2>
        <Card className="p-6 text-center">
          <p className="text-destructive">Fejl ved indlæsning af tilbud: {error}</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Quote className="w-5 h-5" />
        <h2 className="text-xl font-semibold">Aktive Tilbud</h2>
        {quotes.length > 0 && (
          <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
            {quotes.length}
          </span>
        )}
      </div>

      {quotes.length === 0 ? (
        <Card className="p-8 text-center">
          <Quote className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground text-lg font-medium mb-2">
            Ingen aktive tilbud
          </p>
          <p className="text-sm text-muted-foreground">
            Dine afgivne tilbud vil blive vist her, indtil de udløber eller accepteres af kunden.
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quotes.map(quote => (
            <ActiveQuoteCard
              key={quote.id}
              quote={quote}
              onWithdraw={handleWithdraw}
              onUpdate={handleUpdate}
            />
          ))}
        </div>
      )}
    </div>
  );
};