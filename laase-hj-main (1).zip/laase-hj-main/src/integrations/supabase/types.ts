export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      address_provider_configs: {
        Row: {
          config_data: Json | null
          created_at: string | null
          id: string
          is_enabled: boolean | null
          is_primary: boolean | null
          market_code: string | null
          priority: number | null
          provider_name: string
          updated_at: string | null
        }
        Insert: {
          config_data?: Json | null
          created_at?: string | null
          id?: string
          is_enabled?: boolean | null
          is_primary?: boolean | null
          market_code?: string | null
          priority?: number | null
          provider_name: string
          updated_at?: string | null
        }
        Update: {
          config_data?: Json | null
          created_at?: string | null
          id?: string
          is_enabled?: boolean | null
          is_primary?: boolean | null
          market_code?: string | null
          priority?: number | null
          provider_name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "address_provider_configs_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      address_validation_rules: {
        Row: {
          created_at: string | null
          error_message: string | null
          id: string
          input_type: string
          market_code: string | null
          min_length: number | null
          placeholder_text: string | null
          updated_at: string | null
          validation_regex: string | null
        }
        Insert: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          input_type: string
          market_code?: string | null
          min_length?: number | null
          placeholder_text?: string | null
          updated_at?: string | null
          validation_regex?: string | null
        }
        Update: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          input_type?: string
          market_code?: string | null
          min_length?: number | null
          placeholder_text?: string | null
          updated_at?: string | null
          validation_regex?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "address_validation_rules_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      admin_profiles: {
        Row: {
          access_level: string | null
          created_at: string
          department: string | null
          id: string
          last_login: string | null
          permissions: Json | null
          updated_at: string
        }
        Insert: {
          access_level?: string | null
          created_at?: string
          department?: string | null
          id: string
          last_login?: string | null
          permissions?: Json | null
          updated_at?: string
        }
        Update: {
          access_level?: string | null
          created_at?: string
          department?: string | null
          id?: string
          last_login?: string | null
          permissions?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_profiles_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_translation_settings: {
        Row: {
          business_context: string
          created_at: string
          id: string
          max_tokens: number
          model: string
          prompt_template: string
          system_message: string
          temperature: number
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          business_context?: string
          created_at?: string
          id?: string
          max_tokens?: number
          model?: string
          prompt_template?: string
          system_message?: string
          temperature?: number
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          business_context?: string
          created_at?: string
          id?: string
          max_tokens?: number
          model?: string
          prompt_template?: string
          system_message?: string
          temperature?: number
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      area_translations: {
        Row: {
          area_id: string
          created_at: string
          id: string
          is_official: boolean
          language_code: string
          local_name: string
          market_code: string | null
          source: string
          updated_at: string
        }
        Insert: {
          area_id: string
          created_at?: string
          id?: string
          is_official?: boolean
          language_code: string
          local_name: string
          market_code?: string | null
          source?: string
          updated_at?: string
        }
        Update: {
          area_id?: string
          created_at?: string
          id?: string
          is_official?: boolean
          language_code?: string
          local_name?: string
          market_code?: string | null
          source?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "area_translations_area_id_fkey"
            columns: ["area_id"]
            isOneToOne: false
            referencedRelation: "areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "area_translations_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      areas: {
        Row: {
          city_id: string
          created_at: string
          featured_image_alt: string | null
          featured_image_url: string | null
          id: string
          is_active: boolean
          latitude: number | null
          longitude: number | null
          name: string
          postal_codes: string[] | null
          seo_description: string | null
          seo_keywords: string[] | null
          seo_title: string | null
          slug: string
          updated_at: string
        }
        Insert: {
          city_id: string
          created_at?: string
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          is_active?: boolean
          latitude?: number | null
          longitude?: number | null
          name: string
          postal_codes?: string[] | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug: string
          updated_at?: string
        }
        Update: {
          city_id?: string
          created_at?: string
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          is_active?: boolean
          latitude?: number | null
          longitude?: number | null
          name?: string
          postal_codes?: string[] | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "areas_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      auto_bid_exclusions: {
        Row: {
          created_at: string
          excluded_answer_values: string[]
          follow_up_question_id: string
          id: string
          job_category_id: string
          locksmith_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          excluded_answer_values?: string[]
          follow_up_question_id: string
          id?: string
          job_category_id: string
          locksmith_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          excluded_answer_values?: string[]
          follow_up_question_id?: string
          id?: string
          job_category_id?: string
          locksmith_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      blog_categories: {
        Row: {
          category_key: string
          created_at: string
          display_order: number | null
          id: string
          is_active: boolean | null
          parent_id: string | null
          slug: string
          updated_at: string
        }
        Insert: {
          category_key: string
          created_at?: string
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          parent_id?: string | null
          slug: string
          updated_at?: string
        }
        Update: {
          category_key?: string
          created_at?: string
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          parent_id?: string | null
          slug?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "blog_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_post_locations: {
        Row: {
          area_id: string | null
          city_id: string | null
          created_at: string
          id: string
          market_code: string | null
          post_id: string
        }
        Insert: {
          area_id?: string | null
          city_id?: string | null
          created_at?: string
          id?: string
          market_code?: string | null
          post_id: string
        }
        Update: {
          area_id?: string | null
          city_id?: string | null
          created_at?: string
          id?: string
          market_code?: string | null
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_post_locations_area_id_fkey"
            columns: ["area_id"]
            isOneToOne: false
            referencedRelation: "areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_post_locations_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_post_locations_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
          {
            foreignKeyName: "blog_post_locations_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "blog_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_post_market_seo: {
        Row: {
          canonical_url: string | null
          content: string | null
          created_at: string
          excerpt: string | null
          id: string
          market_code: string
          og_description: string | null
          og_image_url: string | null
          og_title: string | null
          post_id: string
          seo_description: string | null
          seo_keywords: string[] | null
          seo_title: string | null
          slug: string | null
          title: string | null
          twitter_description: string | null
          twitter_image_url: string | null
          twitter_title: string | null
          updated_at: string
        }
        Insert: {
          canonical_url?: string | null
          content?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          market_code: string
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          post_id: string
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug?: string | null
          title?: string | null
          twitter_description?: string | null
          twitter_image_url?: string | null
          twitter_title?: string | null
          updated_at?: string
        }
        Update: {
          canonical_url?: string | null
          content?: string | null
          created_at?: string
          excerpt?: string | null
          id?: string
          market_code?: string
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          post_id?: string
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug?: string | null
          title?: string | null
          twitter_description?: string | null
          twitter_image_url?: string | null
          twitter_title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_blog_post_market_seo_market_code"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
          {
            foreignKeyName: "fk_blog_post_market_seo_post_id"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "blog_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_posts: {
        Row: {
          author_id: string
          canonical_url: string | null
          category_id: string | null
          content: string
          created_at: string
          excerpt: string | null
          featured_image_alt: string | null
          featured_image_url: string | null
          id: string
          is_global: boolean | null
          last_viewed_at: string | null
          market_code: string | null
          og_description: string | null
          og_image_url: string | null
          og_title: string | null
          published_at: string | null
          schema_data: Json | null
          schema_type: string | null
          seo_description: string | null
          seo_keywords: string[] | null
          seo_title: string | null
          slug: string
          status: string | null
          title: string
          twitter_description: string | null
          twitter_image_url: string | null
          twitter_title: string | null
          updated_at: string
          view_count: number | null
        }
        Insert: {
          author_id: string
          canonical_url?: string | null
          category_id?: string | null
          content: string
          created_at?: string
          excerpt?: string | null
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          is_global?: boolean | null
          last_viewed_at?: string | null
          market_code?: string | null
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          published_at?: string | null
          schema_data?: Json | null
          schema_type?: string | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug: string
          status?: string | null
          title: string
          twitter_description?: string | null
          twitter_image_url?: string | null
          twitter_title?: string | null
          updated_at?: string
          view_count?: number | null
        }
        Update: {
          author_id?: string
          canonical_url?: string | null
          category_id?: string | null
          content?: string
          created_at?: string
          excerpt?: string | null
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          is_global?: boolean | null
          last_viewed_at?: string | null
          market_code?: string | null
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          published_at?: string | null
          schema_data?: Json | null
          schema_type?: string | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug?: string
          status?: string | null
          title?: string
          twitter_description?: string | null
          twitter_image_url?: string | null
          twitter_title?: string | null
          updated_at?: string
          view_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "blog_posts_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_posts_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "blog_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "blog_posts_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      bookings: {
        Row: {
          address: string
          admin_notes: string | null
          area_id: string | null
          booking_source: string | null
          call_duration_seconds: number | null
          call_id: string | null
          call_metadata: Json | null
          call_transcription: string | null
          caller_phone_number: string | null
          city_id: string | null
          created_at: string | null
          customer_id: string | null
          estimated_price: number | null
          final_price: number | null
          follow_up_answers: Json | null
          id: string
          job_category_id: string
          job_number: number | null
          job_stage: Database["public"]["Enums"]["job_stage_enum"] | null
          job_stage_changed_at: string | null
          job_type: string
          locksmith_id: string | null
          market: string | null
          notes: string | null
          priority_level: string | null
          scheduled_date: string | null
          status: string | null
          status_changed_at: string | null
          status_changed_by: string | null
          updated_at: string | null
          urgency: string
        }
        Insert: {
          address: string
          admin_notes?: string | null
          area_id?: string | null
          booking_source?: string | null
          call_duration_seconds?: number | null
          call_id?: string | null
          call_metadata?: Json | null
          call_transcription?: string | null
          caller_phone_number?: string | null
          city_id?: string | null
          created_at?: string | null
          customer_id?: string | null
          estimated_price?: number | null
          final_price?: number | null
          follow_up_answers?: Json | null
          id?: string
          job_category_id: string
          job_number?: number | null
          job_stage?: Database["public"]["Enums"]["job_stage_enum"] | null
          job_stage_changed_at?: string | null
          job_type: string
          locksmith_id?: string | null
          market?: string | null
          notes?: string | null
          priority_level?: string | null
          scheduled_date?: string | null
          status?: string | null
          status_changed_at?: string | null
          status_changed_by?: string | null
          updated_at?: string | null
          urgency: string
        }
        Update: {
          address?: string
          admin_notes?: string | null
          area_id?: string | null
          booking_source?: string | null
          call_duration_seconds?: number | null
          call_id?: string | null
          call_metadata?: Json | null
          call_transcription?: string | null
          caller_phone_number?: string | null
          city_id?: string | null
          created_at?: string | null
          customer_id?: string | null
          estimated_price?: number | null
          final_price?: number | null
          follow_up_answers?: Json | null
          id?: string
          job_category_id?: string
          job_number?: number | null
          job_stage?: Database["public"]["Enums"]["job_stage_enum"] | null
          job_stage_changed_at?: string | null
          job_type?: string
          locksmith_id?: string | null
          market?: string | null
          notes?: string | null
          priority_level?: string | null
          scheduled_date?: string | null
          status?: string | null
          status_changed_at?: string | null
          status_changed_by?: string | null
          updated_at?: string | null
          urgency?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_area_id_fkey"
            columns: ["area_id"]
            isOneToOne: false
            referencedRelation: "areas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_market_fkey"
            columns: ["market"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
          {
            foreignKeyName: "fk_bookings_job_category"
            columns: ["job_category_id"]
            isOneToOne: false
            referencedRelation: "job_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      calendar_sync_settings: {
        Row: {
          buffer_minutes_after: number | null
          buffer_minutes_before: number | null
          busy_event_types: string[] | null
          created_at: string
          id: string
          locksmith_id: string
          override_manual_status: boolean | null
          selected_calendars: string[] | null
          sync_enabled: boolean
          updated_at: string
        }
        Insert: {
          buffer_minutes_after?: number | null
          buffer_minutes_before?: number | null
          busy_event_types?: string[] | null
          created_at?: string
          id?: string
          locksmith_id: string
          override_manual_status?: boolean | null
          selected_calendars?: string[] | null
          sync_enabled?: boolean
          updated_at?: string
        }
        Update: {
          buffer_minutes_after?: number | null
          buffer_minutes_before?: number | null
          busy_event_types?: string[] | null
          created_at?: string
          id?: string
          locksmith_id?: string
          override_manual_status?: boolean | null
          selected_calendars?: string[] | null
          sync_enabled?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      cities: {
        Row: {
          administrative_level: string | null
          content: string | null
          content_last_updated: string | null
          created_at: string
          featured_image_alt: string | null
          featured_image_url: string | null
          id: string
          is_active: boolean
          is_metropolitan: boolean
          latitude: number | null
          longitude: number | null
          market_code: string
          name: string
          population: number | null
          seo_description: string | null
          seo_keywords: string[] | null
          seo_title: string | null
          slug: string
          status: string
          timezone: string | null
          updated_at: string
          webhook_processed: boolean | null
          wikidata_id: string | null
          wikidata_last_updated: string | null
        }
        Insert: {
          administrative_level?: string | null
          content?: string | null
          content_last_updated?: string | null
          created_at?: string
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          is_active?: boolean
          is_metropolitan?: boolean
          latitude?: number | null
          longitude?: number | null
          market_code: string
          name: string
          population?: number | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug: string
          status?: string
          timezone?: string | null
          updated_at?: string
          webhook_processed?: boolean | null
          wikidata_id?: string | null
          wikidata_last_updated?: string | null
        }
        Update: {
          administrative_level?: string | null
          content?: string | null
          content_last_updated?: string | null
          created_at?: string
          featured_image_alt?: string | null
          featured_image_url?: string | null
          id?: string
          is_active?: boolean
          is_metropolitan?: boolean
          latitude?: number | null
          longitude?: number | null
          market_code?: string
          name?: string
          population?: number | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          seo_title?: string | null
          slug?: string
          status?: string
          timezone?: string | null
          updated_at?: string
          webhook_processed?: boolean | null
          wikidata_id?: string | null
          wikidata_last_updated?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "cities_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      city_translations: {
        Row: {
          city_id: string
          created_at: string
          id: string
          is_official: boolean
          language_code: string
          local_name: string
          market_code: string | null
          source: string
          updated_at: string
        }
        Insert: {
          city_id: string
          created_at?: string
          id?: string
          is_official?: boolean
          language_code: string
          local_name: string
          market_code?: string | null
          source?: string
          updated_at?: string
        }
        Update: {
          city_id?: string
          created_at?: string
          id?: string
          is_official?: boolean
          language_code?: string
          local_name?: string
          market_code?: string | null
          source?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "city_translations_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "city_translations_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      content_pages: {
        Row: {
          created_at: string
          description: string | null
          id: string
          page_key: string
          page_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          page_key: string
          page_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          page_key?: string
          page_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      content_sections: {
        Row: {
          created_at: string
          description: string | null
          id: string
          page_id: string
          section_key: string
          section_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          page_id: string
          section_key: string
          section_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          page_id?: string
          section_key?: string
          section_name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_sections_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "content_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      content_translations: {
        Row: {
          ai_instruction: string | null
          content_key: string
          content_type: string
          content_value: string
          created_at: string
          id: string
          language_code: string
          market_code: string | null
          notes: string | null
          section_id: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          ai_instruction?: string | null
          content_key: string
          content_type?: string
          content_value: string
          created_at?: string
          id?: string
          language_code: string
          market_code?: string | null
          notes?: string | null
          section_id: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          ai_instruction?: string | null
          content_key?: string
          content_type?: string
          content_value?: string
          created_at?: string
          id?: string
          language_code?: string
          market_code?: string | null
          notes?: string | null
          section_id?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "content_translations_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
          {
            foreignKeyName: "content_translations_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "content_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      customer_profiles: {
        Row: {
          billing_address: string | null
          billing_city: string | null
          billing_postal_code: string | null
          contact_preferences: Json | null
          created_at: string
          emergency_contact_name: string | null
          emergency_contact_phone: string | null
          id: string
          updated_at: string
        }
        Insert: {
          billing_address?: string | null
          billing_city?: string | null
          billing_postal_code?: string | null
          contact_preferences?: Json | null
          created_at?: string
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          billing_address?: string | null
          billing_city?: string | null
          billing_postal_code?: string | null
          contact_preferences?: Json | null
          created_at?: string
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customer_profiles_id_fkey"
            columns: ["id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      email_brand_settings: {
        Row: {
          border_color: string | null
          company_address: string | null
          company_name: string | null
          contact_email: string | null
          created_at: string
          font_family: string | null
          footer_background_color: string | null
          header_background_color: string | null
          id: string
          logo_url: string | null
          primary_color: string | null
          privacy_policy_url: string | null
          secondary_color: string | null
          unsubscribe_url: string | null
          updated_at: string
        }
        Insert: {
          border_color?: string | null
          company_address?: string | null
          company_name?: string | null
          contact_email?: string | null
          created_at?: string
          font_family?: string | null
          footer_background_color?: string | null
          header_background_color?: string | null
          id?: string
          logo_url?: string | null
          primary_color?: string | null
          privacy_policy_url?: string | null
          secondary_color?: string | null
          unsubscribe_url?: string | null
          updated_at?: string
        }
        Update: {
          border_color?: string | null
          company_address?: string | null
          company_name?: string | null
          contact_email?: string | null
          created_at?: string
          font_family?: string | null
          footer_background_color?: string | null
          header_background_color?: string | null
          id?: string
          logo_url?: string | null
          primary_color?: string | null
          privacy_policy_url?: string | null
          secondary_color?: string | null
          unsubscribe_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          language_code: string
          market_code: string | null
          provider_response: Json | null
          recipient_email: string
          send_status: string | null
          sent_at: string | null
          subject: string | null
          template_id: string | null
          variables_used: Json | null
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          language_code: string
          market_code?: string | null
          provider_response?: Json | null
          recipient_email: string
          send_status?: string | null
          sent_at?: string | null
          subject?: string | null
          template_id?: string | null
          variables_used?: Json | null
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          language_code?: string
          market_code?: string | null
          provider_response?: Json | null
          recipient_email?: string
          send_status?: string | null
          sent_at?: string | null
          subject?: string | null
          template_id?: string | null
          variables_used?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "email_send_log_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "email_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      email_template_content: {
        Row: {
          content_key: string
          content_section: string
          content_type: string | null
          created_at: string
          default_content: string
          id: string
          is_required: boolean | null
          template_id: string
          updated_at: string
        }
        Insert: {
          content_key: string
          content_section: string
          content_type?: string | null
          created_at?: string
          default_content: string
          id?: string
          is_required?: boolean | null
          template_id: string
          updated_at?: string
        }
        Update: {
          content_key?: string
          content_section?: string
          content_type?: string | null
          created_at?: string
          default_content?: string
          id?: string
          is_required?: boolean | null
          template_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "email_template_content_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "email_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      email_template_translations: {
        Row: {
          ai_instruction: string | null
          created_at: string
          id: string
          language_code: string
          market_code: string | null
          template_content_id: string
          translated_by: string | null
          translated_content: string
          translation_status: string | null
          updated_at: string
        }
        Insert: {
          ai_instruction?: string | null
          created_at?: string
          id?: string
          language_code: string
          market_code?: string | null
          template_content_id: string
          translated_by?: string | null
          translated_content: string
          translation_status?: string | null
          updated_at?: string
        }
        Update: {
          ai_instruction?: string | null
          created_at?: string
          id?: string
          language_code?: string
          market_code?: string | null
          template_content_id?: string
          translated_by?: string | null
          translated_content?: string
          translation_status?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "email_template_translations_template_content_id_fkey"
            columns: ["template_content_id"]
            isOneToOne: false
            referencedRelation: "email_template_content"
            referencedColumns: ["id"]
          },
        ]
      }
      email_templates: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          requires_variables: Json | null
          template_key: string
          template_name: string
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          requires_variables?: Json | null
          template_key: string
          template_name: string
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          requires_variables?: Json | null
          template_key?: string
          template_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      follow_up_question_pricing: {
        Row: {
          answer_value: string
          created_at: string
          fee_amount: number
          fee_type: string
          follow_up_question_id: string
          id: string
          job_category_id: string
          locksmith_id: string
          updated_at: string
        }
        Insert: {
          answer_value: string
          created_at?: string
          fee_amount?: number
          fee_type?: string
          follow_up_question_id: string
          id?: string
          job_category_id: string
          locksmith_id: string
          updated_at?: string
        }
        Update: {
          answer_value?: string
          created_at?: string
          fee_amount?: number
          fee_type?: string
          follow_up_question_id?: string
          id?: string
          job_category_id?: string
          locksmith_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      follow_up_question_translations: {
        Row: {
          created_at: string
          follow_up_question_id: string
          id: string
          language_code: string
          market_code: string | null
          option_icons: Json | null
          options: Json | null
          question: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          follow_up_question_id: string
          id?: string
          language_code: string
          market_code?: string | null
          option_icons?: Json | null
          options?: Json | null
          question: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          follow_up_question_id?: string
          id?: string
          language_code?: string
          market_code?: string | null
          option_icons?: Json | null
          options?: Json | null
          question?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "follow_up_question_translations_follow_up_question_id_fkey"
            columns: ["follow_up_question_id"]
            isOneToOne: false
            referencedRelation: "follow_up_questions"
            referencedColumns: ["id"]
          },
        ]
      }
      follow_up_questions: {
        Row: {
          created_at: string
          id: string
          is_global: boolean | null
          is_required: boolean | null
          job_category_id: string | null
          option_icons: Json | null
          options: Json | null
          order_index: number | null
          question: string
          question_key: string
          question_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_global?: boolean | null
          is_required?: boolean | null
          job_category_id?: string | null
          option_icons?: Json | null
          options?: Json | null
          order_index?: number | null
          question: string
          question_key: string
          question_type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_global?: boolean | null
          is_required?: boolean | null
          job_category_id?: string | null
          option_icons?: Json | null
          options?: Json | null
          order_index?: number | null
          question?: string
          question_key?: string
          question_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "follow_up_questions_job_category_id_fkey"
            columns: ["job_category_id"]
            isOneToOne: false
            referencedRelation: "job_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      geocoding_cache: {
        Row: {
          address: string
          created_at: string
          expires_at: string
          id: string
          latitude: number
          longitude: number
        }
        Insert: {
          address: string
          created_at?: string
          expires_at?: string
          id?: string
          latitude: number
          longitude: number
        }
        Update: {
          address?: string
          created_at?: string
          expires_at?: string
          id?: string
          latitude?: number
          longitude?: number
        }
        Relationships: []
      }
      global_pricing_settings: {
        Row: {
          base_radius_km: number
          combine_nighttime_weekend_fees: boolean
          created_at: string
          fee_per_km_above_radius: number
          id: string
          locksmith_id: string
          nighttime_end_hour: number
          nighttime_fee_amount: number
          nighttime_fee_type: string
          nighttime_start_hour: number
          updated_at: string
          weekend_fee_amount: number
          weekend_fee_type: string
        }
        Insert: {
          base_radius_km?: number
          combine_nighttime_weekend_fees?: boolean
          created_at?: string
          fee_per_km_above_radius?: number
          id?: string
          locksmith_id: string
          nighttime_end_hour?: number
          nighttime_fee_amount?: number
          nighttime_fee_type?: string
          nighttime_start_hour?: number
          updated_at?: string
          weekend_fee_amount?: number
          weekend_fee_type?: string
        }
        Update: {
          base_radius_km?: number
          combine_nighttime_weekend_fees?: boolean
          created_at?: string
          fee_per_km_above_radius?: number
          id?: string
          locksmith_id?: string
          nighttime_end_hour?: number
          nighttime_fee_amount?: number
          nighttime_fee_type?: string
          nighttime_start_hour?: number
          updated_at?: string
          weekend_fee_amount?: number
          weekend_fee_type?: string
        }
        Relationships: []
      }
      image_analysis_logs: {
        Row: {
          actual_job_type: string | null
          analysis_result: Json
          created_at: string
          id: string
          image_url: string
          model_used: string
          updated_at: string
          user_confirmed: boolean | null
        }
        Insert: {
          actual_job_type?: string | null
          analysis_result: Json
          created_at?: string
          id?: string
          image_url: string
          model_used?: string
          updated_at?: string
          user_confirmed?: boolean | null
        }
        Update: {
          actual_job_type?: string | null
          analysis_result?: Json
          created_at?: string
          id?: string
          image_url?: string
          model_used?: string
          updated_at?: string
          user_confirmed?: boolean | null
        }
        Relationships: []
      }
      job_categories: {
        Row: {
          created_at: string
          description: string | null
          emoji: string | null
          id: string
          name: string
          requires_image: boolean | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          emoji?: string | null
          id?: string
          name: string
          requires_image?: boolean | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          emoji?: string | null
          id?: string
          name?: string
          requires_image?: boolean | null
          updated_at?: string
        }
        Relationships: []
      }
      job_category_translations: {
        Row: {
          created_at: string
          description: string | null
          id: string
          job_category_id: string
          language_code: string
          market_code: string | null
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          job_category_id: string
          language_code: string
          market_code?: string | null
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          job_category_id?: string
          language_code?: string
          market_code?: string | null
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_category_translations_job_category_id_fkey"
            columns: ["job_category_id"]
            isOneToOne: false
            referencedRelation: "job_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      language_mappings: {
        Row: {
          created_at: string
          id: string
          language_code: string
          language_name: string
          market_code: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          language_code: string
          language_name: string
          market_code?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          language_code?: string
          language_name?: string
          market_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "language_mappings_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      locksmith_auto_bid_preferences: {
        Row: {
          base_price: number | null
          created_at: string
          excluded_follow_up_answers: Json | null
          id: string
          is_enabled: boolean
          job_category_id: string
          locksmith_id: string
          updated_at: string
        }
        Insert: {
          base_price?: number | null
          created_at?: string
          excluded_follow_up_answers?: Json | null
          id?: string
          is_enabled?: boolean
          job_category_id: string
          locksmith_id: string
          updated_at?: string
        }
        Update: {
          base_price?: number | null
          created_at?: string
          excluded_follow_up_answers?: Json | null
          id?: string
          is_enabled?: boolean
          job_category_id?: string
          locksmith_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      locksmith_promotions: {
        Row: {
          created_at: string
          created_by: string
          discount_percentage: number
          id: string
          is_active: boolean
          jobs_count: number | null
          jobs_used: number
          locksmith_id: string
          promotion_type: Database["public"]["Enums"]["promotion_type"]
          updated_at: string
          valid_until: string | null
        }
        Insert: {
          created_at?: string
          created_by: string
          discount_percentage: number
          id?: string
          is_active?: boolean
          jobs_count?: number | null
          jobs_used?: number
          locksmith_id: string
          promotion_type: Database["public"]["Enums"]["promotion_type"]
          updated_at?: string
          valid_until?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string
          discount_percentage?: number
          id?: string
          is_active?: boolean
          jobs_count?: number | null
          jobs_used?: number
          locksmith_id?: string
          promotion_type?: Database["public"]["Enums"]["promotion_type"]
          updated_at?: string
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "locksmith_promotions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "locksmith_promotions_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      locksmith_referral_settings: {
        Row: {
          created_at: string
          default_referral_fee_percentage: number
          id: string
          is_active: boolean
          locksmith_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          default_referral_fee_percentage?: number
          id?: string
          is_active?: boolean
          locksmith_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          default_referral_fee_percentage?: number
          id?: string
          is_active?: boolean
          locksmith_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "locksmith_referral_settings_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      locksmith_status: {
        Row: {
          busy_until: string | null
          created_at: string
          id: string
          is_calendar_controlled: boolean | null
          locksmith_id: string
          manual_override_until: string | null
          status: string
          updated_at: string
        }
        Insert: {
          busy_until?: string | null
          created_at?: string
          id?: string
          is_calendar_controlled?: boolean | null
          locksmith_id: string
          manual_override_until?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          busy_until?: string | null
          created_at?: string
          id?: string
          is_calendar_controlled?: boolean | null
          locksmith_id?: string
          manual_override_until?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      market_language_access: {
        Row: {
          created_at: string
          id: string
          is_enabled: boolean
          is_primary: boolean
          language_code: string
          market_code: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_enabled?: boolean
          is_primary?: boolean
          language_code: string
          market_code: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_enabled?: boolean
          is_primary?: boolean
          language_code?: string
          market_code?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "market_language_access_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      markets: {
        Row: {
          address_api_provider: string | null
          business_reg_field: string
          business_reg_label: string
          country_code: string
          country_name: string
          created_at: string
          currency_code: string
          currency_symbol: string
          default_lat: number | null
          default_lng: number | null
          distance_unit: string
          emergency_number: string
          updated_at: string
        }
        Insert: {
          address_api_provider?: string | null
          business_reg_field: string
          business_reg_label: string
          country_code: string
          country_name: string
          created_at?: string
          currency_code: string
          currency_symbol: string
          default_lat?: number | null
          default_lng?: number | null
          distance_unit?: string
          emergency_number: string
          updated_at?: string
        }
        Update: {
          address_api_provider?: string | null
          business_reg_field?: string
          business_reg_label?: string
          country_code?: string
          country_name?: string
          created_at?: string
          currency_code?: string
          currency_symbol?: string
          default_lat?: number | null
          default_lng?: number | null
          distance_unit?: string
          emergency_number?: string
          updated_at?: string
        }
        Relationships: []
      }
      media_files: {
        Row: {
          alt_text: string | null
          caption: string | null
          created_at: string
          file_path: string
          file_size: number
          filename: string
          height: number | null
          id: string
          market_code: string | null
          mime_type: string
          original_filename: string
          updated_at: string
          uploaded_by: string | null
          width: number | null
        }
        Insert: {
          alt_text?: string | null
          caption?: string | null
          created_at?: string
          file_path: string
          file_size: number
          filename: string
          height?: number | null
          id?: string
          market_code?: string | null
          mime_type: string
          original_filename: string
          updated_at?: string
          uploaded_by?: string | null
          width?: number | null
        }
        Update: {
          alt_text?: string | null
          caption?: string | null
          created_at?: string
          file_path?: string
          file_size?: number
          filename?: string
          height?: number | null
          id?: string
          market_code?: string | null
          mime_type?: string
          original_filename?: string
          updated_at?: string
          uploaded_by?: string | null
          width?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "media_files_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
          {
            foreignKeyName: "media_files_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      menu_items: {
        Row: {
          created_at: string
          display_order: number
          href: string | null
          id: string
          is_visible: boolean
          menu_key: string
          menu_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          href?: string | null
          id?: string
          is_visible?: boolean
          menu_key: string
          menu_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          href?: string | null
          id?: string
          is_visible?: boolean
          menu_key?: string
          menu_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      nylas_integrations: {
        Row: {
          calendar_accounts: Json | null
          created_at: string
          id: string
          last_sync_at: string | null
          locksmith_id: string
          nylas_grant_id: string
          sync_enabled: boolean
          updated_at: string
        }
        Insert: {
          calendar_accounts?: Json | null
          created_at?: string
          id?: string
          last_sync_at?: string | null
          locksmith_id: string
          nylas_grant_id: string
          sync_enabled?: boolean
          updated_at?: string
        }
        Update: {
          calendar_accounts?: Json | null
          created_at?: string
          id?: string
          last_sync_at?: string | null
          locksmith_id?: string
          nylas_grant_id?: string
          sync_enabled?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      payment_transactions: {
        Row: {
          amount_total: number
          booking_id: string | null
          created_at: string
          customer_id: string | null
          id: string
          locksmith_amount: number
          locksmith_id: string | null
          platform_fee: number | null
          status: string | null
          stripe_payment_intent_id: string | null
          updated_at: string
        }
        Insert: {
          amount_total: number
          booking_id?: string | null
          created_at?: string
          customer_id?: string | null
          id?: string
          locksmith_amount: number
          locksmith_id?: string | null
          platform_fee?: number | null
          status?: string | null
          stripe_payment_intent_id?: string | null
          updated_at?: string
        }
        Update: {
          amount_total?: number
          booking_id?: string | null
          created_at?: string
          customer_id?: string | null
          id?: string
          locksmith_amount?: number
          locksmith_id?: string | null
          platform_fee?: number | null
          status?: string | null
          stripe_payment_intent_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_transactions_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_transactions_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_transactions: {
        Row: {
          amount: number
          created_at: string
          id: string
          locksmith_id: string
          status: string | null
          stripe_transfer_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          locksmith_id: string
          status?: string | null
          stripe_transfer_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          locksmith_id?: string
          status?: string | null
          stripe_transfer_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payout_transactions_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      pricing_configs: {
        Row: {
          base_price: number | null
          created_at: string | null
          id: string
          job_category_id: string | null
          locksmith_id: string | null
        }
        Insert: {
          base_price?: number | null
          created_at?: string | null
          id?: string
          job_category_id?: string | null
          locksmith_id?: string | null
        }
        Update: {
          base_price?: number | null
          created_at?: string | null
          id?: string
          job_category_id?: string | null
          locksmith_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pricing_configs_job_category_id_fkey"
            columns: ["job_category_id"]
            isOneToOne: false
            referencedRelation: "job_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pricing_configs_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          address_latitude: number | null
          address_longitude: number | null
          city: string | null
          company_name: string | null
          contact_person: string | null
          created_at: string
          cvr_number: string | null
          description: string | null
          emergency_available: boolean | null
          first_name: string | null
          id: string
          last_name: string | null
          market: string | null
          phone: string | null
          postal_code: string | null
          specializations: string[] | null
          status: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address?: string | null
          address_latitude?: number | null
          address_longitude?: number | null
          city?: string | null
          company_name?: string | null
          contact_person?: string | null
          created_at?: string
          cvr_number?: string | null
          description?: string | null
          emergency_available?: boolean | null
          first_name?: string | null
          id: string
          last_name?: string | null
          market?: string | null
          phone?: string | null
          postal_code?: string | null
          specializations?: string[] | null
          status?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address?: string | null
          address_latitude?: number | null
          address_longitude?: number | null
          city?: string | null
          company_name?: string | null
          contact_person?: string | null
          created_at?: string
          cvr_number?: string | null
          description?: string | null
          emergency_available?: boolean | null
          first_name?: string | null
          id?: string
          last_name?: string | null
          market?: string | null
          phone?: string | null
          postal_code?: string | null
          specializations?: string[] | null
          status?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_market_fkey"
            columns: ["market"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      quotes: {
        Row: {
          booking_id: string
          created_at: string
          distance_km: number
          estimated_arrival_minutes: number
          expires_at: string
          id: string
          locksmith_address: string | null
          locksmith_id: string
          message: string | null
          price: number
          status: string
          updated_at: string
        }
        Insert: {
          booking_id: string
          created_at?: string
          distance_km: number
          estimated_arrival_minutes: number
          expires_at?: string
          id?: string
          locksmith_address?: string | null
          locksmith_id: string
          message?: string | null
          price: number
          status?: string
          updated_at?: string
        }
        Update: {
          booking_id?: string
          created_at?: string
          distance_km?: number
          estimated_arrival_minutes?: number
          expires_at?: string
          id?: string
          locksmith_address?: string | null
          locksmith_id?: string
          message?: string | null
          price?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "quotes_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotes_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_fee_applications: {
        Row: {
          application_date: string
          applied_percentage: number
          booking_id: string
          fee_amount: number
          id: string
          locksmith_id: string
          original_amount: number
          promotion_id: string | null
        }
        Insert: {
          application_date?: string
          applied_percentage: number
          booking_id: string
          fee_amount: number
          id?: string
          locksmith_id: string
          original_amount: number
          promotion_id?: string | null
        }
        Update: {
          application_date?: string
          applied_percentage?: number
          booking_id?: string
          fee_amount?: number
          id?: string
          locksmith_id?: string
          original_amount?: number
          promotion_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "referral_fee_applications_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_fee_applications_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "referral_fee_applications_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "locksmith_promotions"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          booking_id: string | null
          comment: string | null
          created_at: string | null
          customer_id: string | null
          id: string
          locksmith_id: string | null
          rating: number | null
        }
        Insert: {
          booking_id?: string | null
          comment?: string | null
          created_at?: string | null
          customer_id?: string | null
          id?: string
          locksmith_id?: string | null
          rating?: number | null
        }
        Update: {
          booking_id?: string | null
          comment?: string | null
          created_at?: string | null
          customer_id?: string | null
          id?: string
          locksmith_id?: string | null
          rating?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "reviews_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      seo_meta_tags: {
        Row: {
          canonical_url: string | null
          created_at: string
          id: string
          market_code: string | null
          meta_description: string | null
          meta_keywords: string[] | null
          meta_title: string | null
          og_description: string | null
          og_image_url: string | null
          og_title: string | null
          og_type: string | null
          page_path: string
          robots_content: string | null
          schema_markup: Json | null
          twitter_card: string | null
          twitter_description: string | null
          twitter_image_url: string | null
          twitter_title: string | null
          updated_at: string
        }
        Insert: {
          canonical_url?: string | null
          created_at?: string
          id?: string
          market_code?: string | null
          meta_description?: string | null
          meta_keywords?: string[] | null
          meta_title?: string | null
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          og_type?: string | null
          page_path: string
          robots_content?: string | null
          schema_markup?: Json | null
          twitter_card?: string | null
          twitter_description?: string | null
          twitter_image_url?: string | null
          twitter_title?: string | null
          updated_at?: string
        }
        Update: {
          canonical_url?: string | null
          created_at?: string
          id?: string
          market_code?: string | null
          meta_description?: string | null
          meta_keywords?: string[] | null
          meta_title?: string | null
          og_description?: string | null
          og_image_url?: string | null
          og_title?: string | null
          og_type?: string | null
          page_path?: string
          robots_content?: string | null
          schema_markup?: Json | null
          twitter_card?: string | null
          twitter_description?: string | null
          twitter_image_url?: string | null
          twitter_title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "seo_meta_tags_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      seo_redirects: {
        Row: {
          created_at: string
          from_path: string
          id: string
          is_active: boolean | null
          market_code: string | null
          redirect_type: number | null
          to_path: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          from_path: string
          id?: string
          is_active?: boolean | null
          market_code?: string | null
          redirect_type?: number | null
          to_path: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          from_path?: string
          id?: string
          is_active?: boolean | null
          market_code?: string | null
          redirect_type?: number | null
          to_path?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "seo_redirects_market_code_fkey"
            columns: ["market_code"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      service_areas: {
        Row: {
          center_address: string | null
          center_coordinates: unknown | null
          created_at: string | null
          id: string
          locksmith_id: string | null
          market: string | null
          max_distance_km: number | null
          postal_codes: string[] | null
          service_type: string | null
        }
        Insert: {
          center_address?: string | null
          center_coordinates?: unknown | null
          created_at?: string | null
          id?: string
          locksmith_id?: string | null
          market?: string | null
          max_distance_km?: number | null
          postal_codes?: string[] | null
          service_type?: string | null
        }
        Update: {
          center_address?: string | null
          center_coordinates?: unknown | null
          created_at?: string | null
          id?: string
          locksmith_id?: string | null
          market?: string | null
          max_distance_km?: number | null
          postal_codes?: string[] | null
          service_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "service_areas_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_areas_market_fkey"
            columns: ["market"]
            isOneToOne: false
            referencedRelation: "markets"
            referencedColumns: ["country_code"]
          },
        ]
      }
      sms_notification_queue: {
        Row: {
          booking_id: string
          created_at: string
          error_message: string | null
          id: string
          max_retries: number
          message_data: Json
          next_retry_at: string | null
          phone_number: string
          processed_at: string | null
          retry_count: number
          status: string
        }
        Insert: {
          booking_id: string
          created_at?: string
          error_message?: string | null
          id?: string
          max_retries?: number
          message_data?: Json
          next_retry_at?: string | null
          phone_number: string
          processed_at?: string | null
          retry_count?: number
          status?: string
        }
        Update: {
          booking_id?: string
          created_at?: string
          error_message?: string | null
          id?: string
          max_retries?: number
          message_data?: Json
          next_retry_at?: string | null
          phone_number?: string
          processed_at?: string | null
          retry_count?: number
          status?: string
        }
        Relationships: []
      }
      sms_notification_settings: {
        Row: {
          created_at: string
          daily_limit: number | null
          id: string
          is_enabled: boolean | null
          market_code: string | null
          sender_name: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          daily_limit?: number | null
          id?: string
          is_enabled?: boolean | null
          market_code?: string | null
          sender_name?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          daily_limit?: number | null
          id?: string
          is_enabled?: boolean | null
          market_code?: string | null
          sender_name?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      sms_template_types: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          required_variables: Json | null
          template_key: string
          template_name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          required_variables?: Json | null
          template_key: string
          template_name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          required_variables?: Json | null
          template_key?: string
          template_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      stripe_connect_accounts: {
        Row: {
          account_status: string | null
          charges_enabled: boolean | null
          created_at: string
          details_submitted: boolean | null
          id: string
          locksmith_id: string
          payouts_enabled: boolean | null
          requirements: Json | null
          stripe_account_id: string | null
          updated_at: string
        }
        Insert: {
          account_status?: string | null
          charges_enabled?: boolean | null
          created_at?: string
          details_submitted?: boolean | null
          id?: string
          locksmith_id: string
          payouts_enabled?: boolean | null
          requirements?: Json | null
          stripe_account_id?: string | null
          updated_at?: string
        }
        Update: {
          account_status?: string | null
          charges_enabled?: boolean | null
          created_at?: string
          details_submitted?: boolean | null
          id?: string
          locksmith_id?: string
          payouts_enabled?: boolean | null
          requirements?: Json | null
          stripe_account_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "stripe_connect_accounts_locksmith_id_fkey"
            columns: ["locksmith_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      translation_history: {
        Row: {
          change_reason: string | null
          changed_at: string
          changed_by: string | null
          id: string
          new_value: string
          old_value: string | null
          translation_id: string
        }
        Insert: {
          change_reason?: string | null
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_value: string
          old_value?: string | null
          translation_id: string
        }
        Update: {
          change_reason?: string | null
          changed_at?: string
          changed_by?: string | null
          id?: string
          new_value?: string
          old_value?: string | null
          translation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "translation_history_translation_id_fkey"
            columns: ["translation_id"]
            isOneToOne: false
            referencedRelation: "content_translations"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["user_role"]
          user_id: string | null
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["user_role"]
          user_id?: string | null
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          user_id?: string | null
        }
        Relationships: []
      }
      webhook_logs: {
        Row: {
          call_metadata: Json | null
          client_ip: string | null
          created_at: string
          error_message: string | null
          error_stack: string | null
          execution_time_ms: number | null
          function_name: string
          id: string
          request_body: Json | null
          request_headers: Json | null
          request_method: string
          request_url: string | null
          response_body: Json | null
          response_headers: Json | null
          response_status_code: number | null
          user_agent: string | null
        }
        Insert: {
          call_metadata?: Json | null
          client_ip?: string | null
          created_at?: string
          error_message?: string | null
          error_stack?: string | null
          execution_time_ms?: number | null
          function_name: string
          id?: string
          request_body?: Json | null
          request_headers?: Json | null
          request_method?: string
          request_url?: string | null
          response_body?: Json | null
          response_headers?: Json | null
          response_status_code?: number | null
          user_agent?: string | null
        }
        Update: {
          call_metadata?: Json | null
          client_ip?: string | null
          created_at?: string
          error_message?: string | null
          error_stack?: string | null
          execution_time_ms?: number | null
          function_name?: string
          id?: string
          request_body?: Json | null
          request_headers?: Json | null
          request_method?: string
          request_url?: string | null
          response_body?: Json | null
          response_headers?: Json | null
          response_status_code?: number | null
          user_agent?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      sms_queue_summary: {
        Row: {
          count: number | null
          newest: string | null
          oldest: string | null
          status: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      backfill_city_translations: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      get_effective_referral_fee: {
        Args: { locksmith_uuid: string }
        Returns: number
      }
      get_user_profile: {
        Args: { user_id: string }
        Returns: {
          id: string
          first_name: string
          last_name: string
          phone: string
          email: string
          role: string
          profile_data: Json
        }[]
      }
      has_role: {
        Args: {
          _user_id: string
          _role: Database["public"]["Enums"]["user_role"]
        }
        Returns: boolean
      }
      mark_sms_failed: {
        Args: { queue_id: string; error_msg: string }
        Returns: undefined
      }
      mark_sms_processing: {
        Args: { queue_id: string }
        Returns: boolean
      }
      mark_sms_sent: {
        Args: { queue_id: string }
        Returns: undefined
      }
      sync_follow_up_questions_to_content: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      sync_job_categories_to_content: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
    }
    Enums: {
      job_stage_enum:
        | "waiting_for_quotes"
        | "awaiting_client_feedback"
        | "awaiting_locksmith_acceptance"
        | "locksmith_en_route"
        | "locksmith_on_job"
        | "job_finished"
      promotion_type: "percentage_on_next_jobs" | "percentage_until_date"
      user_role: "customer" | "locksmith" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      job_stage_enum: [
        "waiting_for_quotes",
        "awaiting_client_feedback",
        "awaiting_locksmith_acceptance",
        "locksmith_en_route",
        "locksmith_on_job",
        "job_finished",
      ],
      promotion_type: ["percentage_on_next_jobs", "percentage_until_date"],
      user_role: ["customer", "locksmith", "admin"],
    },
  },
} as const
