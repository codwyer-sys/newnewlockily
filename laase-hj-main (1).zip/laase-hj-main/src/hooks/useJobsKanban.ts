import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { LocksmithJob } from '@/types/locksmith';
import { useToast } from '@/hooks/use-toast';

export const useJobsKanban = () => {
  const [jobs, setJobs] = useState<LocksmithJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const fetchJobs = async () => {
    try {
    const { data: bookings, error } = await supabase
      .from('bookings')
      .select(`
        *,
        job_categories (name, emoji)
      `)
      .order('created_at', { ascending: false });

      if (error) throw error;

      const transformedJobs: LocksmithJob[] = bookings?.map(booking => {
        const followUpAnswers = booking.follow_up_answers as any || {};
        const categoryName = booking.job_categories?.name || 'Unknown Category';
        
        return {
          id: booking.id,
          jobNumber: booking.job_number || 0,
          categoryId: booking.job_category_id || '',
          categoryName: categoryName,
          category: categoryName, // Backwards compatibility
          address: booking.address,
          lockBrand: followUpAnswers.lock_brand || followUpAnswers.lockBrand,
          urgency: booking.urgency === 'nu' ? 'emergency' : booking.urgency as 'low' | 'medium' | 'high' | 'emergency',
          timeRequested: booking.created_at,
          customerPhone: followUpAnswers.phone || followUpAnswers.customerPhone || 'Not available',
          customerName: followUpAnswers.customerName || followUpAnswers.name || 'Unknown Customer',
          timing: followUpAnswers.timing || followUpAnswers.when_needed,
          scheduledDate: booking.scheduled_date,
          followUpAnswers: followUpAnswers,
          status: booking.status || 'waiting_for_quotes',
          adminNotes: booking.admin_notes,
          priority: booking.priority_level || 'medium',
          statusChangedAt: booking.status_changed_at,
          statusChangedBy: booking.status_changed_by,
          market: booking.market || 'DK'
        };
      }) || [];

      setJobs(transformedJobs);
      setError(null);
    } catch (err) {
      console.error('Error fetching jobs:', err);
      setError(err as Error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateJobStatus = async (jobId: string, newStatus: string) => {
    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ 
          status: newStatus,
          status_changed_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (error) throw error;

      // Update local state
      setJobs(prevJobs => 
        prevJobs.map(job => 
          job.id === jobId 
            ? { ...job, status: newStatus, statusChangedAt: new Date().toISOString() }
            : job
        )
      );

      toast({
        title: "Status Updated",
        description: `Job status changed to ${newStatus.replace('_', ' ')}`
      });
    } catch (err) {
      console.error('Error updating job status:', err);
      throw err;
    } finally {
      setIsUpdating(false);
    }
  };

  // Set up real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('jobs-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings'
        },
        (payload) => {
          console.log('Real-time update:', payload);
          // Refresh jobs when changes occur
          fetchJobs();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    fetchJobs();
  }, []);

  return {
    jobs,
    isLoading,
    error,
    updateJobStatus,
    isUpdating,
    refetch: fetchJobs
  };
};