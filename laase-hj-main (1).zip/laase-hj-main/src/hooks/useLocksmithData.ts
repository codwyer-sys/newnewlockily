
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface LocksmithProfile {
  id: string;
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  cvr_number: string | null;
  company_name: string | null;
  address: string | null;
  postal_code: string | null;
  city: string | null;
  contact_person: string | null;
  status: string | null;
  specializations: string[] | null;
  description: string | null;
  website: string | null;
  emergency_available: boolean | null;
  created_at: string;
  updated_at: string;
}

export const useLocksmithData = () => {
  const [locksmiths, setLocksmiths] = useState<LocksmithProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchLocksmiths = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .not('cvr_number', 'is', null)
        .eq('status', 'approved');

      if (error) throw error;
      setLocksmiths(data || []);
    } catch (error) {
      console.error('Error fetching locksmiths:', error);
      toast.error('Failed to load locksmiths');
    } finally {
      setIsLoading(false);
    }
  };

  const getLocksmithsByArea = async (postalCode: string) => {
    try {
      const { data, error } = await supabase
        .from('service_areas')
        .select(`
          locksmith_id,
          profiles (*)
        `)
        .contains('postal_codes', [postalCode]);

      if (error) throw error;
      return data?.map(item => item.profiles).filter(Boolean) || [];
    } catch (error) {
      console.error('Error fetching locksmiths by area:', error);
      return [];
    }
  };

  const createBooking = async (bookingData: {
    address: string;
    urgency: string;
    selectedDate: string;
    jobType: string; // This is now a UUID from JobTypeSelector
    followUpAnswers: Record<string, any>;
    languageCode?: string;
    marketCode?: string;
  }) => {
    const maxRetries = 3;
    let attempt = 0;

    while (attempt < maxRetries) {
      try {
        attempt++;
        console.log(`🔄 [createBooking] Attempt ${attempt}/${maxRetries}`);
        
        // Get user if authenticated, but don't require it
        const { data: { user } } = await supabase.auth.getUser();

        // Validate that the job category ID exists (jobType is now a UUID)
        console.log('🔍 [createBooking] Looking for job category with ID:', bookingData.jobType);
        
        const { data: jobCategory, error: categoryError } = await supabase
          .from('job_categories')
          .select('id, name')
          .eq('id', bookingData.jobType)
          .maybeSingle();

        console.log('🔍 [createBooking] Job category lookup result:', jobCategory, 'Error:', categoryError);

        if (categoryError) {
          console.error('Error fetching job category:', categoryError);
          throw categoryError;
        }

        if (!jobCategory) {
          console.error('Job category not found for ID:', bookingData.jobType);
          throw new Error(`Job category not found: ${bookingData.jobType}`);
        }

        const { data, error } = await supabase
          .from('bookings')
          .insert({
            customer_id: user?.id || null, // Allow null for anonymous bookings
            address: bookingData.address,
            urgency: bookingData.urgency,
            scheduled_date: bookingData.selectedDate ? new Date(bookingData.selectedDate).toISOString() : null,
            job_type: jobCategory.name, // Store the category name for backwards compatibility
            job_category_id: bookingData.jobType, // jobType is now the UUID
            follow_up_answers: {
              ...bookingData.followUpAnswers,
              preferredLanguage: bookingData.languageCode,
              marketCode: bookingData.marketCode
            },
            status: 'waiting_for_quotes'
          })
          .select()
          .single();

        if (error) {
          // Handle job number constraint violation specifically
          if (error.code === '23505' && error.message?.includes('unique_job_number')) {
            console.warn(`⚠️ [createBooking] Job number conflict on attempt ${attempt}, retrying...`);
            if (attempt < maxRetries) {
              // Exponential backoff: wait 100ms, 200ms, 400ms
              await new Promise(resolve => setTimeout(resolve, 100 * Math.pow(2, attempt - 1)));
              continue;
            }
          }
          throw error;
        }

        console.log('✅ [createBooking] Successfully created booking:', data);
        return data;
        
      } catch (error) {
        console.error(`❌ [createBooking] Attempt ${attempt} failed:`, error);
        
        // If it's the last attempt or not a retryable error, throw
        if (attempt >= maxRetries || 
            (error as any)?.code !== '23505' || 
            !(error as any)?.message?.includes('unique_job_number')) {
          throw error;
        }
      }
    }

    // This should never be reached, but just in case
    throw new Error('Maximum retry attempts exceeded');
  };

  useEffect(() => {
    fetchLocksmiths();
  }, []);

  return {
    locksmiths,
    isLoading,
    fetchLocksmiths,
    getLocksmithsByArea,
    createBooking
  };
};
