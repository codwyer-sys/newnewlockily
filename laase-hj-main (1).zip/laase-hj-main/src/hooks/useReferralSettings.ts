import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface ReferralSettings {
  id: string;
  locksmith_id: string;
  default_referral_fee_percentage: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface LocksmithPromotion {
  id: string;
  locksmith_id: string;
  promotion_type: 'percentage_on_next_jobs' | 'percentage_until_date';
  discount_percentage: number;
  jobs_count?: number;
  valid_until?: string;
  jobs_used: number;
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export const useReferralSettings = (locksmithId?: string) => {
  const [settings, setSettings] = useState<ReferralSettings | null>(null);
  const [promotions, setPromotions] = useState<LocksmithPromotion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  const fetchSettings = async () => {
    if (!locksmithId) return;
    
    try {
      setIsLoading(true);
      
      // Fetch referral settings
      const { data: settingsData, error: settingsError } = await supabase
        .from('locksmith_referral_settings')
        .select('*')
        .eq('locksmith_id', locksmithId)
        .maybeSingle();

      if (settingsError) throw settingsError;

      // If no settings exist, create default ones
      if (!settingsData) {
        const { data: newSettings, error: createError } = await supabase
          .from('locksmith_referral_settings')
          .insert({ locksmith_id: locksmithId })
          .select()
          .single();
        
        if (createError) throw createError;
        setSettings(newSettings);
      } else {
        setSettings(settingsData);
      }

      // Fetch active promotions
      const { data: promotionsData, error: promotionsError } = await supabase
        .from('locksmith_promotions')
        .select('*')
        .eq('locksmith_id', locksmithId)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (promotionsError) throw promotionsError;
      setPromotions(promotionsData || []);

      setError(null);
    } catch (err) {
      console.error('Error fetching referral settings:', err);
      setError(err as Error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateDefaultFee = async (percentage: number) => {
    if (!locksmithId || !settings) return;

    try {
      const { data, error } = await supabase
        .from('locksmith_referral_settings')
        .update({ default_referral_fee_percentage: percentage })
        .eq('locksmith_id', locksmithId)
        .select()
        .single();

      if (error) throw error;
      
      setSettings(data);
      toast({
        title: "Default fee updated",
        description: `Referral fee set to ${percentage}%`
      });
    } catch (err) {
      console.error('Error updating default fee:', err);
      toast({
        title: "Error",
        description: "Failed to update default referral fee",
        variant: "destructive"
      });
      throw err;
    }
  };

  const createPromotion = async (promotion: Omit<LocksmithPromotion, 'id' | 'created_at' | 'updated_at' | 'jobs_used'>) => {
    try {
      const { data, error } = await supabase
        .from('locksmith_promotions')
        .insert({
          ...promotion,
          locksmith_id: locksmithId
        })
        .select()
        .single();

      if (error) throw error;
      
      setPromotions(prev => [data, ...prev]);
      toast({
        title: "Promotion created",
        description: "New referral promotion has been added"
      });

      return data;
    } catch (err) {
      console.error('Error creating promotion:', err);
      toast({
        title: "Error",
        description: "Failed to create promotion",
        variant: "destructive"
      });
      throw err;
    }
  };

  const deactivatePromotion = async (promotionId: string) => {
    try {
      const { error } = await supabase
        .from('locksmith_promotions')
        .update({ is_active: false })
        .eq('id', promotionId);

      if (error) throw error;
      
      setPromotions(prev => prev.filter(p => p.id !== promotionId));
      toast({
        title: "Promotion deactivated",
        description: "Promotion has been removed"
      });
    } catch (err) {
      console.error('Error deactivating promotion:', err);
      toast({
        title: "Error",
        description: "Failed to deactivate promotion",
        variant: "destructive"
      });
      throw err;
    }
  };

  const getEffectiveFee = async (locksmithId: string): Promise<number> => {
    try {
      console.log('🔧 getEffectiveFee - Attempting to get fee for:', locksmithId);
      
      const { data, error } = await supabase.rpc('get_effective_referral_fee', {
        locksmith_uuid: locksmithId
      });

      if (error) {
        console.error('🔧 getEffectiveFee - RPC error:', error);
        throw error;
      }
      
      console.log('🔧 getEffectiveFee - Success:', data);
      return data || 20.0;
    } catch (err) {
      console.error('🔧 getEffectiveFee - Failed, using fallback:', err);
      
      // Try direct table query as fallback
      try {
        const { data: settingsData, error: settingsError } = await supabase
          .from('locksmith_referral_settings')
          .select('default_referral_fee_percentage')
          .eq('locksmith_id', locksmithId)
          .eq('is_active', true)
          .maybeSingle();
        
        if (!settingsError && settingsData) {
          console.log('🔧 getEffectiveFee - Fallback success:', settingsData.default_referral_fee_percentage);
          return settingsData.default_referral_fee_percentage;
        }
      } catch (fallbackErr) {
        console.error('🔧 getEffectiveFee - Fallback also failed:', fallbackErr);
      }
      
      console.log('🔧 getEffectiveFee - Using default 20%');
      return 20.0; // Default fallback
    }
  };

  useEffect(() => {
    fetchSettings();
  }, [locksmithId]);

  return {
    settings,
    promotions,
    isLoading,
    error,
    updateDefaultFee,
    createPromotion,
    deactivatePromotion,
    getEffectiveFee,
    refetch: fetchSettings
  };
};