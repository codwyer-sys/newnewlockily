import { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";
import { useMarket } from '@/contexts/MarketContext';
import { useLanguage } from '@/contexts/LanguageContext';

interface JobCategoryWithTranslation {
  id: string;
  name: string;
  description: string;
  emoji: string;
  requires_image: boolean;
}

export const useTranslatedJobCategories = () => {
  const [categories, setCategories] = useState<JobCategoryWithTranslation[]>([]);
  const [loading, setLoading] = useState(true);
  const { market } = useMarket();
  const { language } = useLanguage();

  useEffect(() => {
    fetchTranslatedCategories();
  }, [market.country_code, language]);

  const fetchTranslatedCategories = async () => {
    try {
      setLoading(true);
      
      // First get all categories with fallback to original data
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('job_categories')
        .select('*')
        .order('name');
      
      if (categoriesError) throw categoriesError;
      
      // Then get translations for current language/market
      const { data: translationsData, error: translationsError } = await supabase
        .from('job_category_translations')
        .select('*')
        .eq('language_code', language)
        .eq('market_code', market.country_code);
      
      if (translationsError) throw translationsError;
      
      // Merge categories with their translations
      const translatedCategories = categoriesData.map(category => {
        const translation = translationsData.find(t => t.job_category_id === category.id);
        return {
          id: category.id,
          name: translation?.name || category.name,
          description: translation?.description || category.description,
          emoji: category.emoji,
          requires_image: category.requires_image
        };
      });
      
      setCategories(translatedCategories);
    } catch (error) {
      console.error('Error fetching translated categories:', error);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  };

  return { categories, loading, refetch: fetchTranslatedCategories };
};