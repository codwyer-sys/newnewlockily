import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface CityTranslation {
  id: string;
  city_id: string;
  language_code: string;
  market_code?: string;
  local_name: string;
  is_official: boolean;
  source: 'wikidata' | 'manual' | 'ai_generated' | 'mapbox_native';
  created_at: string;
  updated_at: string;
}

export const useCityTranslations = (cityId?: string) => {
  const [translations, setTranslations] = useState<CityTranslation[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchTranslations = async () => {
    try {
      let query = supabase
        .from('city_translations')
        .select('*')
        .order('language_code');

      if (cityId) {
        query = query.eq('city_id', cityId);
      }

      const { data, error } = await query;

      if (error) throw error;
      setTranslations((data || []) as CityTranslation[]);
    } catch (error) {
      console.error('Error fetching city translations:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch city translations',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const saveCityTranslations = async (
    cityId: string,
    translations: { [languageCode: string]: string },
    source: 'wikidata' | 'manual' | 'ai_generated' | 'mapbox_native' = 'wikidata',
    marketCode?: string
  ) => {
    try {
      const translationData = Object.entries(translations).map(([languageCode, localName]) => ({
        city_id: cityId,
        language_code: languageCode,
        market_code: marketCode,
        local_name: localName,
        is_official: source === 'wikidata' || source === 'mapbox_native',
        source,
      }));

      const { error } = await supabase
        .from('city_translations')
        .upsert(translationData, {
          onConflict: 'city_id,language_code,market_code',
        });

      if (error) throw error;

      toast({
        title: 'Success',
        description: `Saved ${translationData.length} translations`,
      });

      if (cityId) {
        fetchTranslations();
      }
    } catch (error: any) {
      console.error('Error saving city translations:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to save translations',
        variant: 'destructive',
      });
    }
  };

  const getCityTranslation = async (
    cityId: string,
    languageCode: string,
    marketCode?: string
  ): Promise<string | null> => {
    try {
      let query = supabase
        .from('city_translations')
        .select('local_name')
        .eq('city_id', cityId)
        .eq('language_code', languageCode);

      if (marketCode) {
        query = query.eq('market_code', marketCode);
      }

      const { data, error } = await query.single();

      if (error) return null;
      return data?.local_name || null;
    } catch (error) {
      console.error('Error fetching city translation:', error);
      return null;
    }
  };

  const generateAITranslations = async (
    cityNames: string[],
    targetLanguage: string,
    marketCode: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('ai-localize-names', {
        body: {
          names: cityNames,
          targetLanguage,
          marketCode,
        },
      });

      if (error) throw error;

      return data.localizedNames || [];
    } catch (error: any) {
      console.error('Error generating AI translations:', error);
      toast({
        title: 'AI Translation Error',
        description: error.message || 'Failed to generate AI translations',
        variant: 'destructive',
      });
      return [];
    }
  };

  useEffect(() => {
    if (cityId) {
      fetchTranslations();
    }
  }, [cityId]);

  return {
    translations,
    loading,
    fetchTranslations,
    saveCityTranslations,
    getCityTranslation,
    generateAITranslations,
  };
};