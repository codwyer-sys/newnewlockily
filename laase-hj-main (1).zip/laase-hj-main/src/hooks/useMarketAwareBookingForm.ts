import { useState, useEffect } from 'react';
import { useMarket } from '@/contexts/MarketContext';
import { useBookingFormWithLocksmith } from './useBookingFormWithLocksmith';
import { useMarketAddressSearch } from './useMarketAddressSearch';
import { supabase } from "@/integrations/supabase/client";

export const useMarketAwareBookingForm = () => {
  const { market } = useMarket();
  
  // Get the base booking form functionality
  const bookingForm = useBookingFormWithLocksmith();
  
  // Use market-aware address search
  const { 
    suggestions: addressSuggestions, 
    isLoading: isAddressLoading,
    error: addressError,
    clearSuggestions
  } = useMarketAddressSearch(bookingForm.address, !bookingForm.skipAddressSearch);


  // Market-specific validation and configuration
  const [marketConfig, setMarketConfig] = useState<any>(null);

  // Load market-specific configuration
  useEffect(() => {
    const loadMarketConfig = async () => {
      try {
        // Load market-specific form configuration if available
        const { data: config } = await supabase
          .from('markets')
          .select('*')
          .eq('country_code', market.country_code)
          .single();
        
        setMarketConfig(config);
      } catch (error) {
        console.error('Error loading market config:', error);
      }
    };

    loadMarketConfig();
  }, [market.country_code]);

  // Enhanced address selection with market-specific behavior
  const handleAddressSelect = (selectedAddress: string) => {
    console.log('🎯 Address selected:', selectedAddress);
    bookingForm.setAddress(selectedAddress);
    bookingForm.setHasSelectedSuggestion(true);
    bookingForm.setShowSuggestions(false);
    bookingForm.setSkipAddressSearch(true);
    clearSuggestions();
  };


  // Market-specific placeholder text
  const getAddressPlaceholder = () => {
    switch (market.country_code) {
      case 'UK':
        return 'Enter your postcode (e.g., SW1A 1AA)';
      case 'US':
        return 'Enter your address';
      case 'DE':
        return 'Geben Sie Ihre Adresse ein';
      default:
        return 'Hvor skal du bruge en låsesmed?';
    }
  };

  // Market-specific emergency number display
  const getEmergencyNumber = () => {
    return market.emergency_number || '112';
  };

  // Market-specific business registration field
  const getBusinessRegField = () => {
    return {
      field: market.business_reg_field || 'cvr_number',
      label: market.business_reg_label || 'CVR Nummer'
    };
  };

  // Reset form when market changes (with stable dependency)
  useEffect(() => {
    console.log('🌍 useMarketAwareBookingForm: Market changed to:', market.country_code);
    // The form will be automatically reset when the component remounts due to route change
    clearSuggestions();
  }, [market.country_code]); // Removed clearSuggestions from dependencies to prevent infinite loop

  return {
    ...bookingForm,
    // Expose setters for form reset
    setUrgency: (value: string) => {
      // Access the internal state setters through the form hook
      const currentForm = useBookingFormWithLocksmith();
      // Since we can't access setters directly, we'll reset via the hook
    },
    setSelectedDate: (value: string) => {},
    setJobType: (value: string) => {},
    setFollowUpAnswers: (value: Record<string, any>) => {},
    
    // Override with market-aware versions
    addressSuggestions,
    isAddressLoading,
    addressError,
    handleAddressSelect,
    
    // Market-specific helpers
    market,
    marketConfig,
    getAddressPlaceholder,
    getEmergencyNumber,
    getBusinessRegField,
    
    // Enhanced functionality
    clearAddressSuggestions: clearSuggestions
  };
};