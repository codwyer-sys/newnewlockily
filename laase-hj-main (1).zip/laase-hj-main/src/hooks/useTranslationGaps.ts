import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface TranslationGap {
  contentKey: string;
  sectionName: string;
  pageName: string;
  sectionId: string;
  missingLanguages: string[];
  missingMarkets: string[];
  priority: 'high' | 'medium' | 'low';
}

interface GapAnalysis {
  totalGaps: number;
  gapsByMarket: Record<string, number>;
  gapsByLanguage: Record<string, number>;
  criticalGaps: TranslationGap[];
  allGaps: TranslationGap[];
}

const CRITICAL_SECTIONS = ['header', 'navigation', 'home', 'footer'];
const CRITICAL_KEYS = ['title', 'heading', 'cta', 'button'];

export const useTranslationGaps = () => {
  const [analysis, setAnalysis] = useState<GapAnalysis>({
    totalGaps: 0,
    gapsByMarket: {},
    gapsByLanguage: {},
    criticalGaps: [],
    allGaps: []
  });
  const [loading, setLoading] = useState(true);

  const fetchGapAnalysis = async () => {
    try {
      setLoading(true);

      // Get all content structure (pages, sections, and expected translations)
      const { data: sections, error: sectionsError } = await supabase
        .from('content_sections')
        .select(`
          id,
          section_key,
          section_name,
          page:content_pages!inner(page_name)
        `);

      if (sectionsError) throw sectionsError;

      // Get all existing translations
      const { data: translations, error: translationsError } = await supabase
        .from('content_translations')
        .select('section_id, content_key, language_code, market_code, content_value');

      if (translationsError) throw translationsError;

      // Get all markets
      const { data: markets, error: marketsError } = await supabase
        .from('markets')
        .select('country_code');

      if (marketsError) throw marketsError;

      const expectedLanguages = ['da', 'en'];
      const expectedMarkets = markets?.map(m => m.country_code) || [];

      // Analyze gaps
      const gaps: TranslationGap[] = [];
      const translationMap = new Map<string, Set<string>>();

      // Build map of existing translations
      translations?.forEach(t => {
        const key = `${t.section_id}:${t.content_key}`;
        if (!translationMap.has(key)) {
          translationMap.set(key, new Set());
        }
        translationMap.get(key)?.add(`${t.language_code}:${t.market_code || 'global'}`);
      });

      // Find unique content keys per section
      const contentKeysPerSection = translations?.reduce((acc, t) => {
        if (!acc[t.section_id]) acc[t.section_id] = new Set();
        acc[t.section_id].add(t.content_key);
        return acc;
      }, {} as Record<string, Set<string>>) || {};

      // Check for gaps
      sections?.forEach(section => {
        const contentKeys = contentKeysPerSection[section.id] || new Set();
        
        contentKeys.forEach(contentKey => {
          const translationKey = `${section.id}:${contentKey}`;
          const existingTranslations = translationMap.get(translationKey) || new Set();

          const missingLanguages: string[] = [];
          const missingMarkets: string[] = [];

          // Check language gaps
          expectedLanguages.forEach(lang => {
            const hasLang = Array.from(existingTranslations).some(t => t.startsWith(`${lang}:`));
            if (!hasLang) missingLanguages.push(lang);
          });

          // Check market gaps
          expectedMarkets.forEach(market => {
            const hasMarket = Array.from(existingTranslations).some(t => t.endsWith(`:${market}`));
            if (!hasMarket) missingMarkets.push(market);
          });

          if (missingLanguages.length > 0 || missingMarkets.length > 0) {
            // Determine priority
            let priority: 'high' | 'medium' | 'low' = 'low';
            
            if (CRITICAL_SECTIONS.some(cs => section.section_key.toLowerCase().includes(cs)) ||
                CRITICAL_KEYS.some(ck => contentKey.toLowerCase().includes(ck))) {
              priority = 'high';
            } else if (section.page.page_name.toLowerCase().includes('home') || 
                      section.section_name.toLowerCase().includes('main')) {
              priority = 'medium';
            }

            gaps.push({
              contentKey,
              sectionName: section.section_name,
              pageName: section.page.page_name,
              sectionId: section.id,
              missingLanguages,
              missingMarkets,
              priority
            });
          }
        });
      });

      // Calculate statistics
      const totalGaps = gaps.length;
      const criticalGaps = gaps.filter(g => g.priority === 'high');

      const gapsByMarket = expectedMarkets.reduce((acc, market) => {
        acc[market] = gaps.filter(g => g.missingMarkets.includes(market)).length;
        return acc;
      }, {} as Record<string, number>);

      const gapsByLanguage = expectedLanguages.reduce((acc, lang) => {
        acc[lang] = gaps.filter(g => g.missingLanguages.includes(lang)).length;
        return acc;
      }, {} as Record<string, number>);

      setAnalysis({
        totalGaps,
        gapsByMarket,
        gapsByLanguage,
        criticalGaps,
        allGaps: gaps
      });

    } catch (error) {
      console.error('Error analyzing translation gaps:', error);
    } finally {
      setLoading(false);
    }
  };

  const createMissingTranslations = async (gaps: TranslationGap[]) => {
    try {
      const newTranslations = [];

      for (const gap of gaps) {
        for (const lang of gap.missingLanguages) {
          for (const market of gap.missingMarkets) {
            newTranslations.push({
              section_id: gap.sectionId,
              language_code: lang,
              content_key: gap.contentKey,
              content_value: '',
              content_type: 'text',
              market_code: market === 'global' ? null : market
            });
          }
        }
      }

      if (newTranslations.length > 0) {
        const { error } = await supabase
          .from('content_translations')
          .insert(newTranslations);

        if (error) throw error;
        
        // Refresh analysis
        await fetchGapAnalysis();
        return newTranslations.length;
      }

      return 0;
    } catch (error) {
      console.error('Error creating missing translations:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchGapAnalysis();
  }, []);

  return {
    analysis,
    loading,
    createMissingTranslations,
    refetch: fetchGapAnalysis
  };
};