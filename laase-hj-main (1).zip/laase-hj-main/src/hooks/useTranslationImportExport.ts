import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ExportData {
  page: string;
  section: string;
  content_key: string;
  language: string;
  market: string;
  value: string;
  notes?: string;
}

interface ImportValidationError {
  row: number;
  field: string;
  message: string;
}

interface ImportPreview {
  data: ExportData[];
  errors: ImportValidationError[];
  stats: {
    totalRows: number;
    validRows: number;
    newTranslations: number;
    updates: number;
  };
}

export const useTranslationImportExport = () => {
  const [loading, setLoading] = useState(false);
  const [importPreview, setImportPreview] = useState<ImportPreview | null>(null);

  const exportTranslations = async (format: 'csv' | 'json', filters?: {
    market?: string;
    language?: string;
    page?: string;
  }) => {
    try {
      setLoading(true);

      let query = supabase
        .from('content_translations')
        .select(`
          content_key,
          language_code,
          market_code,
          content_value,
          notes,
          section:content_sections!inner(
            section_name,
            page:content_pages!inner(page_name)
          )
        `)
        .order('section.page.page_name')
        .order('section.section_name')
        .order('content_key');

      // Apply filters
      if (filters?.market && filters.market !== 'all') {
        query = query.eq('market_code', filters.market);
      }
      if (filters?.language && filters.language !== 'all') {
        query = query.eq('language_code', filters.language);
      }

      const { data, error } = await query;

      if (error) throw error;

      const exportData: ExportData[] = data?.map(item => ({
        page: item.section.page.page_name,
        section: item.section.section_name,
        content_key: item.content_key,
        language: item.language_code,
        market: item.market_code || 'global',
        value: item.content_value,
        notes: item.notes || ''
      })) || [];

      if (format === 'csv') {
        return exportToCsv(exportData);
      } else {
        return exportToJson(exportData);
      }

    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export translations');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const exportToCsv = (data: ExportData[]) => {
    const headers = ['page', 'section', 'content_key', 'language', 'market', 'value', 'notes'];
    const csvContent = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header as keyof ExportData] || '';
          // Escape quotes and wrap in quotes if contains comma or quote
          return typeof value === 'string' && (value.includes(',') || value.includes('"')) 
            ? `"${value.replace(/"/g, '""')}"` 
            : value;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `translations_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    return csvContent;
  };

  const exportToJson = (data: ExportData[]) => {
    const jsonContent = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `translations_${new Date().toISOString().split('T')[0]}.json`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    return jsonContent;
  };

  const validateImportData = async (file: File): Promise<ImportPreview> => {
    try {
      setLoading(true);
      const text = await file.text();
      let data: ExportData[] = [];
      const errors: ImportValidationError[] = [];

      if (file.name.endsWith('.csv')) {
        data = parseCsv(text, errors);
      } else if (file.name.endsWith('.json')) {
        try {
          data = JSON.parse(text);
        } catch (e) {
          errors.push({ row: 0, field: 'file', message: 'Invalid JSON format' });
        }
      } else {
        errors.push({ row: 0, field: 'file', message: 'Unsupported file format. Use CSV or JSON.' });
      }

      // Validate each row
      const validRows = data.filter((row, index) => {
        let isValid = true;

        // Required fields validation
        if (!row.page?.trim()) {
          errors.push({ row: index + 1, field: 'page', message: 'Page is required' });
          isValid = false;
        }
        if (!row.section?.trim()) {
          errors.push({ row: index + 1, field: 'section', message: 'Section is required' });
          isValid = false;
        }
        if (!row.content_key?.trim()) {
          errors.push({ row: index + 1, field: 'content_key', message: 'Content key is required' });
          isValid = false;
        }
        if (!row.language?.trim()) {
          errors.push({ row: index + 1, field: 'language', message: 'Language is required' });
          isValid = false;
        }

        // Language validation
        if (row.language && !['da', 'en'].includes(row.language)) {
          errors.push({ row: index + 1, field: 'language', message: 'Language must be "da" or "en"' });
          isValid = false;
        }

        return isValid;
      });

      // Check which translations are new vs updates
      const { data: existingTranslations } = await supabase
        .from('content_translations')
        .select('section_id, content_key, language_code, market_code')
        .in('content_key', validRows.map(r => r.content_key));

      const existingSet = new Set(
        existingTranslations?.map(t => 
          `${t.content_key}:${t.language_code}:${t.market_code || 'global'}`
        ) || []
      );

      const newTranslations = validRows.filter(row => 
        !existingSet.has(`${row.content_key}:${row.language}:${row.market || 'global'}`)
      ).length;

      const updates = validRows.length - newTranslations;

      const preview: ImportPreview = {
        data: validRows,
        errors,
        stats: {
          totalRows: data.length,
          validRows: validRows.length,
          newTranslations,
          updates
        }
      };

      setImportPreview(preview);
      return preview;

    } catch (error) {
      console.error('Import validation error:', error);
      toast.error('Failed to validate import file');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const parseCsv = (csvText: string, errors: ImportValidationError[]): ExportData[] => {
    const lines = csvText.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
      errors.push({ row: 0, field: 'file', message: 'CSV file must have headers and at least one data row' });
      return [];
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
    const requiredHeaders = ['page', 'section', 'content_key', 'language', 'market', 'value'];
    
    const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
    if (missingHeaders.length > 0) {
      errors.push({ 
        row: 0, 
        field: 'headers', 
        message: `Missing required headers: ${missingHeaders.join(', ')}` 
      });
      return [];
    }

    return lines.slice(1).map((line, index) => {
      const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
      const row: any = {};
      
      headers.forEach((header, i) => {
        row[header] = values[i] || '';
      });

      return row as ExportData;
    });
  };

  const importTranslations = async (preview: ImportPreview) => {
    try {
      setLoading(true);
      console.log(`📥 [Import] Starting import of ${preview.data.length} translations`);

      // Get section mappings
      const { data: sections, error: sectionsError } = await supabase
        .from('content_sections')
        .select(`
          id,
          section_name,
          page:content_pages!inner(page_name)
        `);

      if (sectionsError) {
        console.error('❌ [Import] Failed to get section mappings:', sectionsError);
        throw sectionsError;
      }

      const sectionMap = new Map<string, string>();
      sections?.forEach(section => {
        const key = `${section.page.page_name}:${section.section_name}`;
        sectionMap.set(key, section.id);
      });

      console.log(`📋 [Import] Created section mappings for ${sectionMap.size} sections:`, 
        Array.from(sectionMap.keys()));

      // Prepare translations for upsert with validation
      const translationsToUpsert = preview.data.map((row, index) => {
        const sectionKey = `${row.page}:${row.section}`;
        const sectionId = sectionMap.get(sectionKey);
        
        if (!sectionId) {
          console.warn(`⚠️ [Import] Row ${index + 1}: No section ID found for "${sectionKey}"`);
        }

        const translation = {
          section_id: sectionId,
          content_key: row.content_key,
          language_code: row.language,
          market_code: row.market === 'global' ? null : row.market,
          content_value: row.value,
          content_type: 'text',
          notes: row.notes || null
        };

        console.log(`📝 [Import] Row ${index + 1} prepared:`, {
          sectionKey,
          sectionId,
          contentKey: row.content_key,
          language: row.language,
          market: row.market,
          valueLength: row.value.length,
          hasNotes: !!row.notes
        });

        return translation;
      }).filter((t, index) => {
        if (!t.section_id) {
          console.error(`❌ [Import] Filtering out row ${index + 1}: Missing section ID`);
          return false;
        }
        return true;
      });

      console.log(`✅ [Import] ${translationsToUpsert.length}/${preview.data.length} translations have valid section IDs`);

      if (translationsToUpsert.length === 0) {
        const error = 'No valid translations to import - all rows have missing section IDs';
        console.error(`❌ [Import] ${error}`);
        throw new Error(error);
      }

      // Group by constraints for better error reporting
      const constraintGroups = new Map<string, number>();
      translationsToUpsert.forEach(t => {
        const constraintKey = `${t.section_id}:${t.language_code}:${t.content_key}`;
        constraintGroups.set(constraintKey, (constraintGroups.get(constraintKey) || 0) + 1);
      });

      const duplicateConstraints = Array.from(constraintGroups.entries()).filter(([_, count]) => count > 1);
      if (duplicateConstraints.length > 0) {
        console.warn(`⚠️ [Import] Found ${duplicateConstraints.length} constraint duplicates:`, 
          duplicateConstraints.map(([key, count]) => `${key} (${count} times)`));
      }

      console.log(`💾 [Import] Upserting ${translationsToUpsert.length} translations to database...`);

      // Upsert translations with enhanced error handling
      const { error, data: upsertData } = await supabase
        .from('content_translations')
        .upsert(translationsToUpsert, {
          onConflict: 'section_id,language_code,content_key'
        })
        .select('id, content_key, language_code');

      if (error) {
        console.error('❌ [Import] Database upsert failed:', {
          error: error,
          errorCode: error.code,
          errorMessage: error.message,
          translationsCount: translationsToUpsert.length
        });
        throw error;
      }

      console.log(`✅ [Import] Successfully imported ${translationsToUpsert.length} translations`);
      console.log(`📊 [Import] Upsert result:`, {
        attempted: translationsToUpsert.length,
        returned: upsertData?.length || 0
      });

      toast.success(`Successfully imported ${translationsToUpsert.length} translations`);
      setImportPreview(null);
      
      return translationsToUpsert.length;

    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ [Import] Import failed:', {
        error: error,
        errorMessage: errorMsg,
        previewDataLength: preview.data.length,
        stack: error instanceof Error ? error.stack : undefined
      });
      toast.error(`Failed to import translations: ${errorMsg}`);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    importPreview,
    exportTranslations,
    validateImportData,
    importTranslations,
    clearPreview: () => setImportPreview(null)
  };
};