import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface DistanceResult {
  distance: number;
  duration: number;
  fromCoordinates: [number, number];
  toCoordinates: [number, number];
  route?: any;
}

export const useMapBoxDistance = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const calculateDistance = useCallback(async (from: string, to: string): Promise<DistanceResult | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const { data, error: functionError } = await supabase.functions.invoke('mapbox-distance', {
        body: { from, to }
      });

      if (functionError) {
        throw new Error(functionError.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to calculate distance';
      setError(errorMessage);
      console.error('Distance calculation error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    calculateDistance,
    isLoading,
    error
  };
};