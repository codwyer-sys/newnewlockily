import { useState } from 'react';

interface PostalCodeInfo {
  code: string;
  city: string;
  municipality: string;
}

export const usePostalCodeValidation = () => {
  const [isLoading, setIsLoading] = useState(false);

  const validateAndGetInfo = async (postalCode: string): Promise<PostalCodeInfo | null> => {
    if (!/^\d{4}$/.test(postalCode)) {
      return null;
    }

    setIsLoading(true);
    try {
      const response = await fetch(
        `https://api.dataforsyningen.dk/postnumre?nr=${postalCode}`
      );

      if (!response.ok) {
        return null;
      }

      const data = await response.json();
      
      if (!data || data.length === 0) {
        return null;
      }

      const location = data[0];
      
      return {
        code: postalCode,
        city: location.navn,
        municipality: location.kommuner?.[0]?.navn || 'Ukendt kommune'
      };
    } catch (error) {
      console.error('Error validating postal code:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    validateAndGetInfo,
    isLoading
  };
};