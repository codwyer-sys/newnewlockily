import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/hooks/use-toast';
import { LocksmithJob } from '@/types/locksmith';

interface UseQuoteSubmissionProps {
  job: LocksmithJob | null;
  localDistance: { km: number; duration: number } | null;
}

export const useQuoteSubmission = ({ job, localDistance }: UseQuoteSubmissionProps) => {
  const [isSubmittingBid, setIsSubmittingBid] = useState(false);
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();

  const handleSubmitBid = async (
    amount: string, 
    notes: string, 
    arrivalTime: string, 
    address: string
  ): Promise<{ success: boolean; error?: string }> => {
    if (!amount || !user || !job) {
      toast({
        title: t('job_cards.actions.error'),
        description: 'Missing required information for bid submission',
        variant: "destructive"
      });
      return { success: false, error: 'Missing required fields' };
    }

    try {
      const parsedPrice = parseFloat(amount);
      if (isNaN(parsedPrice) || parsedPrice <= 0) {
        throw new Error('Invalid price amount.');
      }

      // Calculate estimated arrival in minutes
      let estimatedArrivalMinutes = 30; // Default fallback
      
      if (arrivalTime) {
        const [hours, minutes] = arrivalTime.split(':').map(Number);
        if (!isNaN(hours) && !isNaN(minutes)) {
          const now = new Date();
          const arrivalDate = new Date();
          arrivalDate.setHours(hours, minutes, 0, 0);
          
          // If the time is earlier than now, assume it's for the next day
          if (arrivalDate <= now) {
            arrivalDate.setDate(arrivalDate.getDate() + 1);
          }
          
          estimatedArrivalMinutes = Math.max(1, Math.round((arrivalDate.getTime() - now.getTime()) / (1000 * 60)));
        }
      }

      // Check for existing quote first
      const { data: existingQuote, error: existingError } = await supabase
        .from('quotes')
        .select('id')
        .eq('booking_id', job.id)
        .eq('locksmith_id', user.id)
        .maybeSingle();

      if (existingError) {
        console.error('Error checking existing quote:', existingError);
        throw new Error('Failed to check existing bids');
      }

      if (existingQuote) {
        throw new Error('You have already submitted a bid for this job.');
      }

      // Create quote directly in database
      const { data: newQuote, error: insertError } = await supabase
        .from('quotes')
        .insert({
          booking_id: job.id,
          locksmith_id: user.id,
          price: parsedPrice,
          estimated_arrival_minutes: estimatedArrivalMinutes,
          distance_km: localDistance?.km || 0,
          message: notes || null,
          locksmith_address: address
        })
        .select()
        .single();

      if (insertError) {
        console.error('Database insert error:', insertError);
        
        // Handle specific database errors
        if (insertError.code === '23505') {
          throw new Error('You have already submitted a bid for this job.');
        } else if (insertError.code === '23503') {
          throw new Error('Job not found or invalid.');
        } else {
          throw new Error('Failed to submit bid. Please try again.');
        }
      }

      if (!newQuote) {
        throw new Error('Failed to create quote');
      }

      toast({
        title: t('job_cards.actions.bid_sent'),
        description: `${t('job_cards.actions.bid_sent_desc')} ${amount} kr`
      });

      return { success: true };
      
    } catch (error) {
      console.error('Bid submission error:', error);
      
      let errorMessage = t('job_cards.actions.bid_error');
      
      if (error.message?.includes('already submitted')) {
        errorMessage = 'You have already submitted a bid for this job.';
      } else if (error.message?.includes('Invalid price')) {
        errorMessage = 'Please enter a valid price amount.';
      } else if (error.message?.includes('Job not found')) {
        errorMessage = 'Job not found or no longer available.';
      } else {
        errorMessage = error.message || 'Failed to submit bid. Please try again.';
      }
      
      toast({
        title: t('job_cards.actions.error'),
        description: errorMessage,
        variant: "destructive"
      });
      
      return { success: false, error: error.message };
    }
  };

  return {
    isSubmittingBid,
    setIsSubmittingBid,
    handleSubmitBid
  };
};