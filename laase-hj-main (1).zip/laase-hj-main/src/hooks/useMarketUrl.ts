import { useMarket } from '@/contexts/MarketContext';
import { useCallback } from 'react';

export const useMarketUrl = () => {
  const { market } = useMarket();

  const generateUrl = useCallback((path: string, targetMarket?: string) => {
    const marketCode = (targetMarket || market.country_code).toLowerCase();
    
    // Remove leading slash if present
    const cleanPath = path.startsWith('/') ? path.slice(1) : path;
    
    // Don't add market for admin routes
    if (cleanPath.startsWith('admin') || cleanPath.startsWith('auth') || cleanPath.startsWith('locksmith-')) {
      return `/${cleanPath}`;
    }
    
    // Add market prefix for content routes
    return `/${marketCode}/${cleanPath}`;
  }, [market.country_code]);

  const generateBlogPostUrl = useCallback((slug: string, targetMarket?: string) => {
    return generateUrl(`blog/${slug}`, targetMarket);
  }, [generateUrl]);

  const generateBlogPostUrlWithCategory = useCallback((categorySlug: string, postSlug: string, targetMarket?: string) => {
    return generateUrl(`blog/${categorySlug}/${postSlug}`, targetMarket);
  }, [generateUrl]);

  const generateMarketHomepage = useCallback((targetMarket?: string) => {
    const marketCode = (targetMarket || market.country_code).toLowerCase();
    return `/${marketCode}/`;
  }, [market.country_code]);

  const generateCityUrl = useCallback((citySlug: string, targetMarket?: string) => {
    return generateUrl(`cities/${citySlug}`, targetMarket);
  }, [generateUrl]);

  const generateAreaUrl = useCallback((citySlug: string, areaSlug: string, targetMarket?: string) => {
    return generateUrl(`cities/${citySlug}/${areaSlug}`, targetMarket);
  }, [generateUrl]);

  const generateCityBlogUrl = useCallback((citySlug: string, targetMarket?: string) => {
    return generateUrl(`blog/cities/${citySlug}`, targetMarket);
  }, [generateUrl]);

  const generateAreaBlogUrl = useCallback((citySlug: string, areaSlug: string, targetMarket?: string) => {
    return generateUrl(`blog/areas/${areaSlug}`, targetMarket);
  }, [generateUrl]);

  return {
    generateUrl,
    generateBlogPostUrl,
    generateBlogPostUrlWithCategory,
    generateMarketHomepage,
    generateCityUrl,
    generateAreaUrl,
    generateCityBlogUrl,
    generateAreaBlogUrl,
    currentMarket: market.country_code.toLowerCase()
  };
};

// Utility function that can be used outside of React components
export const generateMarketUrl = (path: string, marketCode: string) => {
  const market = marketCode.toLowerCase();
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;
  
  // Don't add market for admin routes
  if (cleanPath.startsWith('admin') || cleanPath.startsWith('auth') || cleanPath.startsWith('locksmith-')) {
    return `/${cleanPath}`;
  }
  
  return `/${market}/${cleanPath}`;
};