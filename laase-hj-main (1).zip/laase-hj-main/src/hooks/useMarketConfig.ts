import { useMarket } from '@/contexts/MarketContext';

export const useMarketConfig = () => {
  const { market, formatCurrency, formatDistance } = useMarket();

  const getBusinessFieldName = () => {
    switch (market.country_code) {
      case 'UK':
        return 'company_number';
      case 'US':
        return 'business_license';
      case 'DE':
        return 'handelsregister';
      case 'PL':
        return 'nip_number';
      case 'CA':
        return 'business_number';
      case 'PT':
        return 'nipc_number';
      case 'IT':
        return 'partita_iva';
      case 'FI':
        return 'business_id';
      case 'CZ':
        return 'ico_number';
      default:
        return 'cvr_number';
    }
  };

  const getBusinessFieldLabel = () => {
    return market.business_reg_label;
  };

  const getBusinessValidationPattern = () => {
    switch (market.country_code) {
      case 'UK':
        return /^\d{8}$/; // 8 digits for UK company number
      case 'DK':
        return /^\d{8}$/; // 8 digits for CVR
      case 'US':
        return /^.{1,50}$/; // Variable format for US business licenses
      case 'DE':
        return /^.{1,20}$/; // Variable format for German Handelsregister
      case 'PL':
        return /^\d{10}$/; // 10 digits for Polish NIP
      case 'CA':
        return /^\d{9}$/; // 9 digits for Canadian Business Number
      case 'PT':
        return /^\d{9}$/; // 9 digits for Portuguese NIPC
      case 'IT':
        return /^\d{11}$/; // 11 digits for Italian Partita IVA
      case 'FI':
        return /^\d{7}-\d$/; // Finnish Y-tunnus format (7 digits + dash + check digit)
      case 'CZ':
        return /^\d{8}$/; // 8 digits for Czech IČO
      default:
        return /^.+$/;
    }
  };

  const getPostalCodePattern = () => {
    switch (market.country_code) {
      case 'UK':
        return /^[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}$/i; // UK postcode
      case 'DK':
        return /^\d{4}$/; // Danish postal code
      case 'US':
        return /^\d{5}(-\d{4})?$/; // US ZIP code
      case 'DE':
        return /^\d{5}$/; // German postal code
      case 'PL':
        return /^\d{2}-\d{3}$/; // Polish postal code (XX-XXX)
      case 'CA':
        return /^[A-Z]\d[A-Z]\s?\d[A-Z]\d$/i; // Canadian postal code (ANA NAN)
      case 'PT':
        return /^\d{4}-\d{3}$/; // Portuguese postal code (XXXX-XXX)
      case 'IT':
        return /^\d{5}$/; // Italian postal code
      case 'FI':
        return /^\d{5}$/; // Finnish postal code
      case 'CZ':
        return /^\d{3}\s?\d{2}$/; // Czech postal code (XXX XX)
      default:
        return /^.+$/;
    }
  };

  const getPhonePattern = () => {
    switch (market.country_code) {
      case 'UK':
        return /^(\+44|0)[1-9]\d{8,9}$/;
      case 'DK':
        return /^(\+45)?\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{2}$/;
      case 'US':
        return /^(\+1)?[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
      case 'DE':
        return /^(\+49|0)[1-9]\d{1,14}$/;
      case 'PL':
        return /^(\+48)?\s?\d{3}\s?\d{3}\s?\d{3}$/;
      case 'CA':
        return /^(\+1)?[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
      case 'PT':
        return /^(\+351)?\s?\d{3}\s?\d{3}\s?\d{3}$/;
      case 'IT':
        return /^(\+39)?\s?\d{3}\s?\d{3}\s?\d{4}$/;
      case 'FI':
        return /^(\+358|0)\d{1,3}\s?\d{3,7}$/;
      case 'CZ':
        return /^(\+420)?\s?\d{3}\s?\d{3}\s?\d{3}$/;
      default:
        return /^.+$/;
    }
  };

  return {
    market,
    formatCurrency,
    formatDistance,
    getBusinessFieldName,
    getBusinessFieldLabel,
    getBusinessValidationPattern,
    getPostalCodePattern,
    getPhonePattern
  };
};