import { useState, useEffect } from 'react';
import { LocksmithJob } from '@/types/locksmith';

interface UseBidFormProps {
  job: LocksmithJob | null;
  finalPrices: any;
  priceBreakdown: any;
}

export const useBidForm = ({ job, finalPrices, priceBreakdown }: UseBidFormProps) => {
  const [bidAmount, setBidAmount] = useState('');
  const [bidNotes, setBidNotes] = useState('');
  const [editingPriceComponent, setEditingPriceComponent] = useState<string | null>(null);
  const [customPrices, setCustomPrices] = useState<{
    basePrice?: number;
    timeSurcharge?: number;
    distanceFee?: number;
    materials?: number;
  }>({});
  const [chargeClientForReferral, setChargeClientForReferral] = useState(false);
  const [materialEnabled, setMaterialEnabled] = useState(false);

  // Update bid amount when price changes
  useEffect(() => {
    if (finalPrices && finalPrices.total > 0) {
      setBidAmount(finalPrices.total.toString());
    } else if (!priceBreakdown) {
      setBidAmount('');
    }
  }, [finalPrices?.total, priceBreakdown]);

  // Initialize form when job changes
  useEffect(() => {
    if (job) {
      setCustomPrices({});
      setMaterialEnabled(false);
    }
  }, [job]);

  const handlePriceEdit = (component: string, value: string) => {
    const numValue = parseFloat(value) || 0;
    setCustomPrices(prev => ({
      ...prev,
      [component]: numValue
    }));
  };

  const resetForm = () => {
    setBidAmount('');
    setBidNotes('');
    setEditingPriceComponent(null);
    setCustomPrices({});
    setChargeClientForReferral(false);
    setMaterialEnabled(false);
  };

  return {
    // State
    bidAmount,
    bidNotes,
    editingPriceComponent,
    customPrices,
    chargeClientForReferral,
    materialEnabled,
    
    // Actions
    setBidAmount,
    setBidNotes,
    setEditingPriceComponent,
    setCustomPrices,
    setChargeClientForReferral,
    setMaterialEnabled,
    handlePriceEdit,
    resetForm
  };
};