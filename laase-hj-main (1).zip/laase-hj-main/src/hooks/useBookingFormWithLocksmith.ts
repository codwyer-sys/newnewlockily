
import { useState, useEffect, useCallback } from 'react';
import { useBookingFormValidation } from './useBookingFormValidation';
import { useLocksmithData } from './useLocksmithData';
import { useLanguage } from '@/contexts/LanguageContext';
import { useMarket } from '@/contexts/MarketContext';
import { supabase } from "@/integrations/supabase/client";
import { toast } from 'sonner';

export const useBookingFormWithLocksmith = () => {
  // Context hooks
  const { language } = useLanguage();
  const { market } = useMarket();
  
  // Address state
  const [address, setAddress] = useState('');
  const [skipAddressSearch, setSkipAddressSearch] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [hasSelectedSuggestion, setHasSelectedSuggestion] = useState(false);
  
  // Urgency state
  const [urgency, setUrgency] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  
  // Job type state
  const [jobType, setJobType] = useState('');
  
  // Follow-up answers state
  const [followUpAnswers, setFollowUpAnswers] = useState<Record<string, any>>({});
  
  // Visibility state
  const [showUrgency, setShowUrgency] = useState(false);
  const [showJobType, setShowJobType] = useState(false);
  const [showFollowUp, setShowFollowUp] = useState(false);
  const [showBookingButtons, setShowBookingButtons] = useState(false);

  // Locksmith integration
  const { createBooking } = useLocksmithData();
  const [isBookingInProgress, setIsBookingInProgress] = useState(false);

  const getRequiredQuestionsForJobType = useCallback(async (type: string): Promise<string[]> => {
    try {
      const { data, error } = await supabase
        .from('follow_up_questions')
        .select('question_key')
        .or(`job_category_id.eq.${type},is_global.eq.true`)
        .eq('is_required', true);
      
      if (error) {
        console.error('Error fetching required questions:', error);
        return [];
      }
      
      return data?.map(q => q.question_key) || [];
    } catch (error) {
      console.error('Error fetching required questions:', error);
      return [];
    }
  }, []);

  const { isBookingDisabled, allFollowUpAnswered } = useBookingFormValidation({
    address,
    urgency,
    selectedDate,
    jobType,
    followUpAnswers,
    getRequiredQuestionsForJobType
  });

  // Show next section based on completed fields - NEW ORDER: Address → Job Type → Follow Up → Urgency
  useEffect(() => {
    if (address && hasSelectedSuggestion) {
      setShowJobType(true);
    }
  }, [address, hasSelectedSuggestion]);

  useEffect(() => {
    if (jobType) {
      setShowFollowUp(true);
    }
  }, [jobType]);

  useEffect(() => {
    if (allFollowUpAnswered && jobType) {
      setShowUrgency(true);
    }
  }, [allFollowUpAnswered, jobType]);

  useEffect(() => {
    if (urgency && allFollowUpAnswered && !isBookingDisabled) {
      setShowBookingButtons(true);
    }
  }, [urgency, allFollowUpAnswered, isBookingDisabled]);

  const handleUrgencySelect = (selectedUrgency: string) => {
    setUrgency(selectedUrgency);
  };

  const handleDateChange = (date: string) => {
    setSelectedDate(date);
  };

  const handleJobTypeSelect = (type: string) => {
    setJobType(type);
    setFollowUpAnswers({});
  };

  const handleFollowUpAnswer = (questionKey: string, answer: any) => {
    setFollowUpAnswers(prev => ({
      ...prev,
      [questionKey]: answer
    }));
  };

  const handleStartBooking = async () => {
    if (isBookingDisabled) return;

    setIsBookingInProgress(true);
    try {
      const bookingData = {
        address,
        urgency,
        selectedDate,
        jobType,
        followUpAnswers,
        languageCode: language,
        marketCode: market.country_code
      };

      const booking = await createBooking(bookingData);
      
      // Try to send SMS immediately if phone number is provided
      const customerPhone = followUpAnswers.customerPhone;
      if (customerPhone) {
        try {
          console.log('🚀 Attempting immediate SMS send for booking:', booking.id);
          const { data, error } = await supabase.functions.invoke('send-immediate-sms', {
            body: {
              booking_id: booking.id,
              phone_number: customerPhone,
              message_data: {
                booking_id: booking.id,
                job_number: booking.job_number,
                follow_up_answers: followUpAnswers,
                market_code: market.country_code,
                address,
                created_at: booking.created_at
              }
            }
          });

          if (error || !data?.success) {
            console.warn('⚠️ Immediate SMS failed, will rely on queue system:', error || data?.error);
          } else {
            console.log('✅ SMS sent immediately!', data.message_sid);
          }
        } catch (error) {
          console.warn('⚠️ Immediate SMS error, will rely on queue system:', error);
        }
      }
      
      toast.success('Booking request submitted successfully!');
      
      // Return the booking data for the parent component to handle
      return booking;
    } catch (error: any) {
      console.error('Booking error:', error);
      toast.error(error.message || 'Failed to create booking. Please try again.');
      throw error;
    } finally {
      setIsBookingInProgress(false);
    }
  };

  return {
    // Address props
    address,
    setAddress,
    skipAddressSearch,
    setSkipAddressSearch,
    showSuggestions,
    setShowSuggestions,
    hasSelectedSuggestion,
    setHasSelectedSuggestion,
    
    // Urgency props
    urgency,
    selectedDate,
    onUrgencySelect: handleUrgencySelect,
    onDateChange: handleDateChange,
    showUrgency,
    
    // Job type props
    jobType,
    onJobTypeSelect: handleJobTypeSelect,
    showJobType,
    
    // Follow up props
    followUpAnswers,
    onFollowUpAnswer: handleFollowUpAnswer,
    showFollowUp,
    
    // Booking props
    showBookingButtons,
    isBookingDisabled,
    isBookingInProgress,
    handleStartBooking
  };
};
