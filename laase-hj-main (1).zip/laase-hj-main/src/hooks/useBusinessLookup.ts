import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMarket } from '@/contexts/MarketContext';

interface BusinessData {
  company_name: string;
  address: string;
  postal_code: string;
  city: string;
  phone: string;
  email: string;
}

export const useBusinessLookup = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { market } = useMarket();

  const lookupBusiness = async (businessNumber: string): Promise<BusinessData | null> => {
    setIsLoading(true);
    setError(null);
    
    try {
      let functionName = 'cvr-lookup';
      let paramName = 'cvr';

      // Determine which function to call based on market
      switch (market.country_code) {
        case 'UK':
          functionName = 'uk-company-lookup';
          paramName = 'companyNumber';
          break;
        case 'DK':
        default:
          functionName = 'cvr-lookup';
          paramName = 'cvr';
          break;
      }

      console.log(`Looking up business in ${market.country_code}:`, businessNumber);

      const { data, error } = await supabase.functions.invoke(functionName, {
        body: { [paramName]: businessNumber }
      });

      if (error) {
        console.error('Business lookup error:', error);
        setError(error.message || 'Failed to lookup business');
        return null;
      }

      if (data && data.company_name) {
        console.log('Business lookup successful:', data);
        return data;
      } else {
        setError('Business not found');
        return null;
      }
    } catch (err: any) {
      console.error('Business lookup failed:', err);
      setError(err.message || 'Failed to lookup business');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    lookupBusiness,
    isLoading,
    error,
    clearError: () => setError(null)
  };
};