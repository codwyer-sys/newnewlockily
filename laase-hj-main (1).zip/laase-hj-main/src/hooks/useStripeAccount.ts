import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface StripeAccount {
  id: string;
  charges_enabled: boolean;
  payouts_enabled: boolean;
  details_submitted: boolean;
  requirements: {
    currently_due?: string[];
    eventually_due?: string[];
  };
  business_profile?: {
    name?: string;
    support_email?: string;
  };
}

interface AccountStatus {
  connected: boolean;
  account: StripeAccount | null;
  onboardingUrl?: string;
}

export const useStripeAccount = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [accountStatus, setAccountStatus] = useState<AccountStatus | null>(null);
  const [locksmithProfile, setLocksmithProfile] = useState<any>(null);
  const [profileLoading, setProfileLoading] = useState(true);

  const fetchLocksmithProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .maybeSingle();

      if (error) throw error;
      
      // Check if user has locksmith role and required fields
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user?.id)
        .eq('role', 'locksmith')
        .maybeSingle();
      
      setLocksmithProfile(roleData && data ? data : null);
    } catch (error: any) {
      console.error('Error fetching locksmith profile:', error);
    } finally {
      setProfileLoading(false);
    }
  };

  const fetchAccountStatus = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('get-connect-account-status');
      
      if (error) throw error;
      
      if (data.success) {
        setAccountStatus(data);
      } else {
        throw new Error(data.error);
      }
    } catch (error: any) {
      console.error('Error fetching account status:', error);
      toast({
        title: "Fejl",
        description: "Kunne ikke hente kontostatus.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const proceedWithStripeCreation = async () => {
    setCreating(true);
    try {
      console.log('Starting Stripe account creation process...');
      const { data, error } = await supabase.functions.invoke('create-connect-account');
      
      if (error) {
        console.error('Supabase function error:', error);
        throw error;
      }
      
      console.log('Create account response:', data);
      
      if (data.success && data.onboardingUrl) {
        console.log('Redirecting to Stripe onboarding:', data.onboardingUrl);
        window.location.href = data.onboardingUrl;
      } else {
        console.error('Account creation failed:', data);
        throw new Error(data.error || 'Failed to create account');
      }
    } catch (error: any) {
      console.error('Error creating account:', error);
      toast({
        title: "Fejl",
        description: error.message || "Kunne ikke oprette Stripe-konto.",
        variant: "destructive"
      });
    } finally {
      setCreating(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchLocksmithProfile();
      fetchAccountStatus();
    }
  }, [user]);

  return {
    loading,
    creating,
    profileLoading,
    accountStatus,
    locksmithProfile,
    setLocksmithProfile,
    fetchAccountStatus,
    proceedWithStripeCreation
  };
};