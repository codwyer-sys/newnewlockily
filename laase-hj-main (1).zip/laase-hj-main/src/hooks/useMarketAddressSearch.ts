import { useState, useEffect, useCallback } from 'react';
import { useMarket } from '@/contexts/MarketContext';
import { supabase } from '@/integrations/supabase/client';
import { AddressSearchResult } from '@/services/address/types';

interface UseMarketAddressSearchResult {
  suggestions: AddressSearchResult[];
  isLoading: boolean;
  error: string | null;
  validationRules: { min_length: number; placeholder_text: string } | null;
  validateInput: (input: string) => { isValid: boolean; errors: string[] };
  clearSuggestions: () => void;
}

export const useMarketAddressSearch = (
  query: string,
  enabled: boolean = true
): UseMarketAddressSearchResult => {
  const { market } = useMarket();
  const [suggestions, setSuggestions] = useState<AddressSearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Clear suggestions when market changes
  useEffect(() => {
    setSuggestions([]);
    setError(null);
  }, [market.country_code]);

  const searchAddresses = useCallback(async (searchQuery: string) => {
    if (!enabled || searchQuery.length < 3) {
      setSuggestions([]);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const { data, error: searchError } = await supabase.functions.invoke('unified-address-lookup', {
        body: { 
          query: searchQuery,
          marketCode: market.country_code
        }
      });

      if (searchError) {
        setError(`Address search failed: ${searchError.message || 'Unknown error'}`);
        setSuggestions([]);
        return;
      }

      if (!data?.results) {
        setError('Address search service unavailable');
        setSuggestions([]);
        return;
      }

      if (data.results.length === 0) {
        setSuggestions([]);
        return;
      }

      setSuggestions(data.results);
    } catch (err) {
      setError(`Address search failed: ${err instanceof Error ? err.message : 'Network error'}`);
      setSuggestions([]);
    } finally {
      setIsLoading(false);
    }
  }, [enabled, market.country_code]);

  // Debounced search
  useEffect(() => {
    if (!query.trim()) {
      setSuggestions([]);
      setIsLoading(false);
      return;
    }

    const timeoutId = setTimeout(() => {
      searchAddresses(query.trim());
    }, 300);

    return () => {
      clearTimeout(timeoutId);
    };
  }, [query, searchAddresses]);

  const validateInput = useCallback((input: string) => {
    // Simple validation - just check minimum length
    const errors: string[] = [];
    if (input.length < 3) {
      errors.push('Input must be at least 3 characters long');
    }
    return {
      isValid: errors.length === 0,
      errors
    };
  }, []);

  const clearSuggestions = useCallback(() => {
    setSuggestions([]);
    setError(null);
  }, []);

  return {
    suggestions,
    isLoading,
    error,
    validationRules: { min_length: 3, placeholder_text: 'Enter your address' },
    validateInput,
    clearSuggestions
  };
};