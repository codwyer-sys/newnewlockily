import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export const useLocksmithQuoteHistory = () => {
  const [quotedJobIds, setQuotedJobIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const loadQuoteHistory = async () => {
    if (!user) {
      setQuotedJobIds(new Set());
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      // Get ALL booking_ids where this locksmith has submitted ANY quote (regardless of status)
      const { data: quotesData, error: quotesError } = await supabase
        .from('quotes')
        .select('booking_id')
        .eq('locksmith_id', user.id);

      if (quotesError) {
        console.error('Error loading quote history:', quotesError);
        setQuotedJobIds(new Set());
      } else {
        const jobIds = new Set(quotesData?.map(quote => quote.booking_id) || []);
        setQuotedJobIds(jobIds);
        console.log('🔍 [useLocksmithQuoteHistory] Loaded quote history for', jobIds.size, 'jobs');
      }
    } catch (err) {
      console.error('Error loading quote history:', err);
      setQuotedJobIds(new Set());
    } finally {
      setLoading(false);
    }
  };

  // Set up real-time subscription for quote changes
  useEffect(() => {
    if (!user) return;

    // Initial load
    loadQuoteHistory();

    // Set up real-time subscription to reload when quotes change
    const channel = supabase
      .channel('quote-history-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'quotes',
          filter: `locksmith_id=eq.${user.id}`
        },
        () => {
          // Reload quote history when any quote changes
          loadQuoteHistory();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  return {
    quotedJobIds,
    loading,
    refetch: loadQuoteHistory
  };
};