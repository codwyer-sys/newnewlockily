import { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";

interface JobCategory {
  id: string;
  name: string;
  emoji: string;
}

interface FollowUpQuestion {
  id: string;
  job_category_id?: string;
  question: string;
  question_key: string;
  question_type: 'radio' | 'number' | 'text' | 'checkbox';
  options?: string[];
  option_icons?: Record<string, string>;
  is_required: boolean;
  is_global: boolean;
  order_index: number;
}

export const useFollowUpQuestionsManager = () => {
  const [questions, setQuestions] = useState<FollowUpQuestion[]>([]);
  const [categories, setCategories] = useState<JobCategory[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchQuestions = async () => {
    try {
      const { data, error } = await supabase
        .from('follow_up_questions')
        .select('*')
        .order('order_index');
      
      if (error) throw error;
      
      const transformedQuestions: FollowUpQuestion[] = (data || []).map(item => ({
        id: item.id,
        job_category_id: item.job_category_id || undefined,
        question: item.question,
        question_key: item.question_key,
        question_type: item.question_type as 'radio' | 'number' | 'text' | 'checkbox',
        options: item.options ? (item.options as string[]) : undefined,
        option_icons: item.option_icons ? (item.option_icons as Record<string, string>) : undefined,
        is_required: item.is_required || false,
        is_global: item.is_global || false,
        order_index: item.order_index || 0
      }));
      
      setQuestions(transformedQuestions);
    } catch (error) {
      console.error('Error fetching questions:', error);
      throw error;
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('job_categories')
        .select('id, name, emoji')
        .order('name');
      
      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
      throw error;
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      await Promise.all([fetchQuestions(), fetchCategories()]);
    } finally {
      setLoading(false);
    }
  };

  const createQuestion = async (questionData: Partial<FollowUpQuestion>) => {
    const { data, error } = await supabase
      .from('follow_up_questions')
      .insert([{
        job_category_id: questionData.job_category_id || null,
        question: questionData.question || '',
        question_key: questionData.question_key || '',
        question_type: questionData.question_type || 'radio',
        options: questionData.options || null,
        is_required: questionData.is_required !== undefined ? questionData.is_required : true,
        is_global: questionData.is_global || false,
        order_index: questionData.order_index || 0
      }])
      .select()
      .single();
    
    if (error) throw error;
    await fetchQuestions();
    return data;
  };

  const updateQuestion = async (id: string, questionData: Partial<FollowUpQuestion>) => {
    const { data, error } = await supabase
      .from('follow_up_questions')
      .update(questionData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    await fetchQuestions();
    return data;
  };

  const deleteQuestion = async (id: string) => {
    const { error } = await supabase
      .from('follow_up_questions')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    await fetchQuestions();
  };

  const refreshQuestions = () => {
    fetchData();
  };

  useEffect(() => {
    fetchData();
  }, []);

  return {
    questions,
    categories,
    loading,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    refreshQuestions
  };
};