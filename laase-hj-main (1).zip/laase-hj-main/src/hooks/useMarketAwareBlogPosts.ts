import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMarket } from '@/contexts/MarketContext';
import { resolveCategorySlug } from '@/utils/categorySlugResolver';

export interface MarketAwareBlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt?: string;
  content: string;
  featured_image_url?: string;
  featured_image_alt?: string;
  author_id?: string;
  category_id?: string;
  market_code?: string;
  is_global?: boolean;
  status: 'draft' | 'published' | 'archived';
  published_at?: string;
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string[];
  view_count: number;
  created_at: string;
  updated_at: string;
  // Market-specific content (resolved from market SEO table if global post)
  market_title?: string;
  market_slug?: string;
  market_excerpt?: string;
  market_content?: string;
  market_seo_title?: string;
  market_seo_description?: string;
  market_seo_keywords?: string[];
}

export const useMarketAwareBlogPosts = () => {
  const [posts, setPosts] = useState<MarketAwareBlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { market } = useMarket();

  const fetchMarketAwarePosts = async () => {
    try {
      console.log('Fetching posts for market:', market.country_code);
      
      // Fetch only market-relevant posts: current market posts + global posts, only published ones
      const { data: postsData, error: postsError } = await supabase
        .from('blog_posts')
        .select(`
          id,
          title,
          slug,
          excerpt,
          content,
          featured_image_url,
          featured_image_alt,
          author_id,
          category_id,
          market_code,
          is_global,
          status,
          published_at,
          seo_title,
          seo_description,
          seo_keywords,
          view_count,
          created_at,
          updated_at
        `)
        .eq('status', 'published')
        .or(`market_code.eq.${market.country_code},is_global.eq.true`)
        .order('created_at', { ascending: false });

      if (postsError) throw postsError;

      console.log('Fetched posts:', postsData?.length || 0);

      // Fetch market-specific SEO data only for global posts
      const globalPostIds = (postsData || [])
        .filter(post => post.is_global)
        .map(post => post.id);

      let marketSeoData = [];
      if (globalPostIds.length > 0) {
        const { data: seoData, error: seoError } = await supabase
          .from('blog_post_market_seo')
          .select('*')
          .eq('market_code', market.country_code)
          .in('post_id', globalPostIds);

        if (seoError) {
          console.error('Error fetching market SEO data:', seoError);
        } else {
          marketSeoData = seoData || [];
        }
      }

      console.log('Fetched market SEO data:', marketSeoData.length);

      // Combine posts with market-specific data
      const marketAwarePosts: MarketAwareBlogPost[] = (postsData || []).map(post => {
        const marketSeo = marketSeoData?.find(seo => seo.post_id === post.id);
        
        return {
          ...post,
          status: post.status as 'draft' | 'published' | 'archived',
          // Use market-specific content if available, otherwise fall back to original
          market_title: marketSeo?.title || post.title,
          market_slug: marketSeo?.slug || post.slug,
          market_excerpt: marketSeo?.excerpt || post.excerpt,
          market_content: marketSeo?.content || post.content,
          market_seo_title: marketSeo?.seo_title || post.seo_title,
          market_seo_description: marketSeo?.seo_description || post.seo_description,
          market_seo_keywords: marketSeo?.seo_keywords || post.seo_keywords,
        };
      });

      console.log('Final market-aware posts:', marketAwarePosts.length);
      setPosts(marketAwarePosts);
    } catch (error) {
      console.error('Error fetching market-aware blog posts:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch blog posts',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getPostByCategoryAndSlug = useCallback(async (categorySlug: string, postSlug: string): Promise<MarketAwareBlogPost | null> => {
    try {
      console.log('Fetching post by category and slug:', categorySlug, postSlug);
      
      // First, find the category by slug
      const { data: section } = await supabase
        .from('content_sections')
        .select('id')
        .eq('section_key', 'category_management')
        .maybeSingle();

      let categoryId = null;
      if (section) {
        // Try to find category by market-specific slug first
        const { data: categoryTranslation } = await supabase
          .from('content_translations')
          .select('content_key')
          .eq('section_id', section.id)
          .eq('content_value', categorySlug)
          .eq('language_code', 'en')
          .eq('market_code', market.country_code)
          .like('content_key', '%_slug')
          .maybeSingle();

        if (categoryTranslation) {
          const categoryKey = categoryTranslation.content_key.replace('_slug', '');
          const { data: category } = await supabase
            .from('blog_categories')
            .select('id')
            .eq('category_key', categoryKey)
            .maybeSingle();
          categoryId = category?.id;
        }

        // If not found, try global slug
        if (!categoryId) {
          const { data: globalCategoryTranslation } = await supabase
            .from('content_translations')
            .select('content_key')
            .eq('section_id', section.id)
            .eq('content_value', categorySlug)
            .eq('language_code', 'en')
            .is('market_code', null)
            .like('content_key', '%_slug')
            .maybeSingle();

          if (globalCategoryTranslation) {
            const categoryKey = globalCategoryTranslation.content_key.replace('_slug', '');
            const { data: category } = await supabase
              .from('blog_categories')
              .select('id')
              .eq('category_key', categoryKey)
              .maybeSingle();
            categoryId = category?.id;
          }
        }
      }

      if (!categoryId) {
        console.log('Category not found for slug:', categorySlug);
        return null;
      }

      // Now find the post by slug and category
      let { data: postData, error: postError } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('slug', postSlug)
        .eq('category_id', categoryId)
        .eq('status', 'published')
        .maybeSingle();

      // If not found, check market-specific slug in SEO table
      if (!postData) {
        const { data: marketSeoData, error: seoError } = await supabase
          .from('blog_post_market_seo')
          .select('*, blog_posts!inner(*)')
          .eq('slug', postSlug)
          .eq('market_code', market.country_code)
          .eq('blog_posts.category_id', categoryId)
          .eq('blog_posts.status', 'published')
          .maybeSingle();

        if (!seoError && marketSeoData) {
          postData = marketSeoData.blog_posts;
        }
      }

      if (!postData) {
        console.log('Post not found for slug:', postSlug, 'in category:', categoryId);
        return null;
      }

      // Get market-specific content if it's a global post
      let marketSeo = null;
      if (postData.is_global) {
        const { data: seoData } = await supabase
          .from('blog_post_market_seo')
          .select('*')
          .eq('post_id', postData.id)
          .eq('market_code', market.country_code)
          .maybeSingle();
        
        marketSeo = seoData;
      }

      const result = {
        ...postData,
        status: postData.status as 'draft' | 'published' | 'archived',
        market_title: marketSeo?.title || postData.title,
        market_slug: marketSeo?.slug || postData.slug,
        market_excerpt: marketSeo?.excerpt || postData.excerpt,
        market_content: marketSeo?.content || postData.content,
        market_seo_title: marketSeo?.seo_title || postData.seo_title,
        market_seo_description: marketSeo?.seo_description || postData.seo_description,
        market_seo_keywords: marketSeo?.seo_keywords || postData.seo_keywords,
      };
      
      console.log('Found post:', result.title);
      return result;
    } catch (error) {
      console.error('Error fetching blog post by category and slug:', error);
      return null;
    }
  }, [market.country_code]);

  const getPostBySlug = useCallback(async (slug: string): Promise<MarketAwareBlogPost | null> => {
    try {
      console.log('Fetching post by slug:', slug);
      
      // First, try to find a post with this exact slug in the current market
      let { data: postData, error: postError } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('slug', slug)
        .eq('market_code', market.country_code)
        .eq('status', 'published')
        .single();

      // If not found, check if it's a global post with market-specific slug
      if (postError || !postData) {
        const { data: marketSeoData, error: seoError } = await supabase
          .from('blog_post_market_seo')
          .select('*, blog_posts(*)')
          .eq('slug', slug)
          .eq('market_code', market.country_code)
          .single();

        if (!seoError && marketSeoData) {
          postData = marketSeoData.blog_posts;
        }
      }

      // If still not found, check if it's a global post with the original slug
      if (!postData) {
        const { data: globalPostData, error: globalError } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('slug', slug)
          .eq('is_global', true)
          .eq('status', 'published')
          .single();

        if (!globalError && globalPostData) {
          postData = globalPostData;
        }
      }

      if (!postData) {
        console.log('Post not found for slug:', slug);
        return null;
      }

      // Get market-specific content if it's a global post
      let marketSeo = null;
      if (postData.is_global) {
        const { data: seoData } = await supabase
          .from('blog_post_market_seo')
          .select('*')
          .eq('post_id', postData.id)
          .eq('market_code', market.country_code)
          .single();
        
        marketSeo = seoData;
      }

      const result = {
        ...postData,
        status: postData.status as 'draft' | 'published' | 'archived',
        market_title: marketSeo?.title || postData.title,
        market_slug: marketSeo?.slug || postData.slug,
        market_excerpt: marketSeo?.excerpt || postData.excerpt,
        market_content: marketSeo?.content || postData.content,
        market_seo_title: marketSeo?.seo_title || postData.seo_title,
        market_seo_description: marketSeo?.seo_description || postData.seo_description,
        market_seo_keywords: marketSeo?.seo_keywords || postData.seo_keywords,
      };
      
      console.log('Found post:', result.title);
      return result;
    } catch (error) {
      console.error('Error fetching blog post by slug:', error);
      return null;
    }
  }, [market.country_code]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchMarketAwarePosts();
    };

    loadData();
  }, [market.country_code]);

  return {
    posts,
    loading,
    fetchMarketAwarePosts,
    getPostBySlug,
    getPostByCategoryAndSlug,
    currentMarket: market.country_code
  };
};