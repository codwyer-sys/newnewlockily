import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface EmailTemplate {
  id: string;
  template_key: string;
  template_name: string;
  description?: string;
  category: string;
  is_active: boolean;
  requires_variables: any;
}

interface SendEmailRequest {
  templateId: string;
  recipientEmail: string;
  variables: Record<string, any>;
  languageCode?: string;
}

export const useEmailTemplates = () => {
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .eq('is_active', true)
        .order('template_name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error fetching email templates:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch email templates',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const sendEmail = async (request: SendEmailRequest): Promise<boolean> => {
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: request
      });

      if (error) throw error;

      if (data?.success) {
        toast({
          title: 'Email Sent',
          description: `Email sent successfully using template: ${data.templateUsed}`,
        });
        return true;
      } else {
        throw new Error(data?.error || 'Failed to send email');
      }
    } catch (error) {
      console.error('Error sending email:', error);
      toast({
        title: 'Email Failed',
        description: error instanceof Error ? error.message : 'Failed to send email',
        variant: 'destructive',
      });
      return false;
    } finally {
      setSending(false);
    }
  };

  return {
    templates,
    loading,
    sending,
    sendEmail,
    refetch: fetchTemplates
  };
};