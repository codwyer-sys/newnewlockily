import { useEffect, useRef } from 'react';
import { useHeaderTheme, HeaderTheme } from '@/contexts/HeaderThemeContext';

export const useHeaderThemeSection = (theme: HeaderTheme, sectionId: string) => {
  const { registerSection, unregisterSection } = useHeaderTheme();
  const elementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    registerSection(sectionId, theme, element);

    return () => {
      unregisterSection(sectionId);
    };
  }, [theme, sectionId, registerSection, unregisterSection]);

  return elementRef;
};