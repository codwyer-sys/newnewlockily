import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface WebhookAnalytics {
  totalCalls: number;
  successRate: number;
  avgResponseTime: number;
  errorRate: number;
  callsPerHour: Array<{ hour: string; calls: number }>;
  popularWebhooks: Array<{ webhook: string; calls: number }>;
  errorsByWebhook: Array<{ webhook: string; errors: number }>;
  responseTimeByWebhook: Array<{ webhook: string; avgTime: number }>;
}

export const useWebhookAnalytics = (timeRange: string = '24h') => {
  const [analytics, setAnalytics] = useState<WebhookAnalytics | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAnalytics = async () => {
    setIsLoading(true);
    try {
      // Get function logs from the webhook_logs table
      const { data: functionLogs, error } = await supabase.functions.invoke('get-function-logs', {
        body: { 
          timeRange, 
          functions: [
            'validate-address', 
            'get-job-categories', 
            'get-follow-up-questions', 
            'get-available-times', 
            'create-booking-from-call'
          ],
          limit: 1000
        }
      });

      if (error) {
        console.error('Error fetching webhook analytics:', error);
        setAnalytics(getMockAnalytics());
      } else if (functionLogs?.logs && functionLogs.logs.length > 0) {
        // Process real data from webhook logs
        setAnalytics(processWebhookLogs(functionLogs.logs));
      } else {
        // No logs found, show empty analytics
        setAnalytics(getEmptyAnalytics());
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
      setAnalytics(getMockAnalytics());
    } finally {
      setIsLoading(false);
    }
  };

  const refresh = () => {
    fetchAnalytics();
  };

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  return { analytics, isLoading, refresh };
};

const getTimeCondition = (timeRange: string) => {
  const now = new Date();
  switch (timeRange) {
    case '1h':
      return new Date(now.getTime() - 60 * 60 * 1000);
    case '24h':
      return new Date(now.getTime() - 24 * 60 * 60 * 1000);
    case '7d':
      return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    case '30d':
      return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    default:
      return new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }
};

// Process real webhook logs into analytics
const processWebhookLogs = (logs: any[]): WebhookAnalytics => {
  const totalCalls = logs.length;
  const successfulCalls = logs.filter(log => log.success).length;
  const successRate = totalCalls > 0 ? (successfulCalls / totalCalls) * 100 : 0;
  const errorRate = 100 - successRate;

  // Calculate average response time
  const avgResponseTime = totalCalls > 0 
    ? logs.reduce((sum, log) => sum + (log.execution_time_ms || 0), 0) / totalCalls
    : 0;

  // Group calls by hour
  const callsPerHour = Array.from({ length: 24 }, (_, i) => {
    const hour = `${i}:00`;
    const hourCalls = logs.filter(log => {
      const logHour = new Date(log.timestamp).getHours();
      return logHour === i;
    }).length;
    return { hour, calls: hourCalls };
  });

  // Count calls by webhook
  const webhookCounts = logs.reduce((acc, log) => {
    acc[log.function_id] = (acc[log.function_id] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const popularWebhooks = Object.entries(webhookCounts)
    .map(([webhook, calls]) => ({ webhook, calls: calls as number }))
    .sort((a, b) => b.calls - a.calls);

  // Count errors by webhook
  const errorCounts = logs.filter(log => !log.success).reduce((acc, log) => {
    acc[log.function_id] = (acc[log.function_id] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const errorsByWebhook = Object.entries(errorCounts)
    .map(([webhook, errors]) => ({ webhook, errors: errors as number }))
    .sort((a, b) => b.errors - a.errors);

  // Calculate average response time by webhook
  const responseTimeByWebhook = Object.keys(webhookCounts).map(webhook => {
    const webhookLogs = logs.filter(log => log.function_id === webhook);
    const avgTime = webhookLogs.length > 0
      ? webhookLogs.reduce((sum, log) => sum + (log.execution_time_ms || 0), 0) / webhookLogs.length
      : 0;
    return { webhook, avgTime: Math.round(avgTime) };
  }).sort((a, b) => b.avgTime - a.avgTime);

  return {
    totalCalls,
    successRate: Math.round(successRate * 100) / 100,
    avgResponseTime: Math.round(avgResponseTime),
    errorRate: Math.round(errorRate * 100) / 100,
    callsPerHour,
    popularWebhooks,
    errorsByWebhook,
    responseTimeByWebhook
  };
};

const getEmptyAnalytics = (): WebhookAnalytics => ({
  totalCalls: 0,
  successRate: 0,
  avgResponseTime: 0,
  errorRate: 0,
  callsPerHour: Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    calls: 0
  })),
  popularWebhooks: [],
  errorsByWebhook: [],
  responseTimeByWebhook: []
});

const getMockAnalytics = (): WebhookAnalytics => ({
  totalCalls: 1247,
  successRate: 98.5,
  avgResponseTime: 145,
  errorRate: 1.5,
  callsPerHour: Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    calls: Math.floor(Math.random() * 100) + 20
  })),
  popularWebhooks: [
    { webhook: 'get-job-categories', calls: 432 },
    { webhook: 'validate-address', calls: 387 },
    { webhook: 'get-follow-up-questions', calls: 245 },
    { webhook: 'create-booking-from-call', calls: 123 },
    { webhook: 'get-available-times', calls: 60 }
  ],
  errorsByWebhook: [
    { webhook: 'validate-address', errors: 8 },
    { webhook: 'get-job-categories', errors: 5 },
    { webhook: 'create-booking-from-call', errors: 3 },
    { webhook: 'get-follow-up-questions', errors: 2 },
    { webhook: 'get-available-times', errors: 1 }
  ],
  responseTimeByWebhook: [
    { webhook: 'validate-address', avgTime: 234 },
    { webhook: 'create-booking-from-call', avgTime: 187 },
    { webhook: 'get-follow-up-questions', avgTime: 156 },
    { webhook: 'get-job-categories', avgTime: 98 },
    { webhook: 'get-available-times', avgTime: 67 }
  ]
});