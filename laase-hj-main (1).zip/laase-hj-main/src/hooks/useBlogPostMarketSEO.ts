import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface BlogPostMarketSEO {
  id: string;
  post_id: string;
  market_code: string;
  title?: string;
  slug?: string;
  excerpt?: string;
  content?: string;
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string[];
  og_title?: string;
  og_description?: string;
  og_image_url?: string;
  twitter_title?: string;
  twitter_description?: string;
  twitter_image_url?: string;
  canonical_url?: string;
  created_at: string;
  updated_at: string;
}

interface CreateMarketSEOData {
  post_id: string;
  market_code: string;
  title?: string;
  slug?: string;
  excerpt?: string;
  content?: string;
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string[];
  og_title?: string;
  og_description?: string;
  og_image_url?: string;
  twitter_title?: string;
  twitter_description?: string;
  twitter_image_url?: string;
  canonical_url?: string;
}

export const useBlogPostMarketSEO = (postId?: string) => {
  const [marketSEO, setMarketSEO] = useState<BlogPostMarketSEO[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchMarketSEO = async () => {
    if (!postId) {
      setMarketSEO([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('blog_post_market_seo')
        .select('*')
        .eq('post_id', postId)
        .order('market_code');

      if (error) throw error;
      setMarketSEO((data || []) as BlogPostMarketSEO[]);
    } catch (error) {
      console.error('Error fetching market SEO:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch market SEO data',
        variant: 'destructive',
      });
    }
  };

  const createOrUpdateMarketSEO = async (data: CreateMarketSEOData) => {
    try {
      const { data: result, error } = await supabase
        .from('blog_post_market_seo')
        .upsert([data], { 
          onConflict: 'post_id,market_code'
        })
        .select()
        .single();

      if (error) throw error;
      
      await fetchMarketSEO();
      toast({
        title: 'Success',
        description: 'Market SEO data updated successfully',
      });
      
      return result;
    } catch (error) {
      console.error('Error updating market SEO:', error);
      toast({
        title: 'Error',
        description: 'Failed to update market SEO data',
        variant: 'destructive',
      });
      throw error;
    }
  };

  const deleteMarketSEO = async (id: string) => {
    try {
      const { error } = await supabase
        .from('blog_post_market_seo')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      await fetchMarketSEO();
      toast({
        title: 'Success',
        description: 'Market SEO data deleted successfully',
      });
    } catch (error) {
      console.error('Error deleting market SEO:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete market SEO data',
        variant: 'destructive',
      });
      throw error;
    }
  };

  const getMarketSEO = (marketCode: string): BlogPostMarketSEO | undefined => {
    return marketSEO.find(seo => seo.market_code === marketCode);
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await fetchMarketSEO();
      setLoading(false);
    };

    loadData();
  }, [postId]);

  return {
    marketSEO,
    loading,
    fetchMarketSEO,
    createOrUpdateMarketSEO,
    deleteMarketSEO,
    getMarketSEO,
  };
};