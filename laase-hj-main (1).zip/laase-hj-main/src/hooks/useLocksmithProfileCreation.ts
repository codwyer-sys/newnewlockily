
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface LocksmithProfileData {
  cvr_number: string;
  company_name: string;
  address: string;
  postal_code: string;
  city: string;
  phone: string;
  email: string;
  contact_person: string;
  website: string;
  service_areas: string[];
}

export const useLocksmithProfileCreation = () => {
  const [isCreating, setIsCreating] = useState(false);

  const createLocksmithProfile = async (profileData: LocksmithProfileData) => {
    setIsCreating(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('No authenticated user found');
      }

      console.log('Creating locksmith profile for user:', user.id);

      // Update profile with locksmith data
      const { error: locksmithError } = await supabase
        .from('profiles')
        .update({
          cvr_number: profileData.cvr_number,
          company_name: profileData.company_name,
          address: profileData.address,
          postal_code: profileData.postal_code,
          city: profileData.city,
          phone: profileData.phone,
          contact_person: profileData.contact_person,
          website: profileData.website,
          emergency_available: false,
          specializations: [],
          status: 'pending'
        })
        .eq('id', user.id);

      if (locksmithError) throw locksmithError;

      // Create service area if postal codes provided
      if (profileData.service_areas.length > 0) {
        const { error: serviceAreaError } = await supabase
          .from('service_areas')
          .insert({
            locksmith_id: user.id,
            postal_codes: profileData.service_areas
          });

        if (serviceAreaError) throw serviceAreaError;
      }

      console.log('Locksmith profile created successfully');
      toast.success('Profil oprettet med succes!');
      return true;
    } catch (error: any) {
      console.error('Error creating locksmith profile:', error);
      toast.error(error.message || 'Kunne ikke oprette profil. Prøv venligst igen.');
      return false;
    } finally {
      setIsCreating(false);
    }
  };

  return {
    createLocksmithProfile,
    isCreating
  };
};
