
import { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";

interface Question {
  id: string;
  question: string;
  question_key: string;
  question_type: 'radio' | 'number' | 'text' | 'checkbox';
  options?: string[];
  option_icons?: Record<string, string>;
  is_required: boolean;
  is_global: boolean;
  order_index: number;
}

interface UseFollowUpQuestionsProps {
  jobType: string;
  answers: Record<string, any>;
  onAnswerChange: (questionKey: string, answer: any) => void;
}

export const useFollowUpQuestions = ({ jobType, answers, onAnswerChange }: UseFollowUpQuestionsProps) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [requiresImage, setRequiresImage] = useState(false);

  useEffect(() => {
    if (jobType) {
      fetchQuestionsForJobType();
      checkImageRequirement();
    }
  }, [jobType]);

  const fetchQuestionsForJobType = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('follow_up_questions')
        .select('*')
        .or(`job_category_id.eq.${jobType},is_global.eq.true`)
        .order('order_index');
      
      if (error) {
        console.error('Error fetching questions:', error);
      } else {
        const transformedQuestions: Question[] = (data || []).map(item => ({
          id: item.id,
          question: item.question,
          question_key: item.question_key,
          question_type: item.question_type as 'radio' | 'number' | 'text' | 'checkbox',
          options: item.options ? (item.options as string[]) : undefined,
          option_icons: item.option_icons ? (item.option_icons as Record<string, string>) : undefined,
          is_required: item.is_required || false,
          is_global: item.is_global || false,
          order_index: item.order_index || 0
        }));
        setQuestions(transformedQuestions);
      }
    } catch (error) {
      console.error('Error fetching questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const checkImageRequirement = async () => {
    try {
      const { data, error } = await supabase
        .from('job_categories')
        .select('requires_image')
        .eq('id', jobType)
        .single();
      
      if (error) {
        console.error('Error checking image requirement:', error);
      } else {
        setRequiresImage(data?.requires_image || false);
      }
    } catch (error) {
      console.error('Error checking image requirement:', error);
    }
  };

  const handleAnswerSelect = (answer: any) => {
    const currentQuestion = questions[currentQuestionIndex];
    onAnswerChange(currentQuestion.question_key, answer);
    
    if (currentQuestionIndex < questions.length - 1) {
      setTimeout(() => {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      }, 300);
    }
  };

  const handleCheckboxChange = (option: string, checked: boolean) => {
    const currentQuestion = questions[currentQuestionIndex];
    const currentAnswers = answers[currentQuestion.question_key] || [];
    let newAnswers;
    
    if (checked) {
      newAnswers = [...currentAnswers, option];
    } else {
      newAnswers = currentAnswers.filter((item: string) => item !== option);
    }
    
    onAnswerChange(currentQuestion.question_key, newAnswers);
  };

  return {
    currentQuestionIndex,
    questions,
    loading,
    requiresImage,
    handleAnswerSelect,
    handleCheckboxChange,
    currentQuestion: questions[currentQuestionIndex],
    isCurrentAnswered: questions[currentQuestionIndex] ? 
      answers[questions[currentQuestionIndex].question_key] !== undefined && 
      answers[questions[currentQuestionIndex].question_key] !== "" : false
  };
};
