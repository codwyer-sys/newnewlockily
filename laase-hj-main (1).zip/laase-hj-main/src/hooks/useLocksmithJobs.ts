import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { LocksmithJob } from '@/types/locksmith';
import { fetchJobs } from '@/utils/jobFetcher';
import { setupJobSubscription } from '@/utils/jobSubscription';
import { playNotificationSound } from '@/utils/notificationSound';

export const useLocksmithJobs = () => {
  const [jobs, setJobs] = useState<LocksmithJob[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [previousJobCount, setPreviousJobCount] = useState(0);
  const { user } = useAuth();

  const handleFetchJobs = useCallback(async () => {
    if (!user) {
      console.log('🔍 [useLocksmithJobs] No user, skipping job fetch');
      setIsLoading(false);
      return;
    }

    console.log('🔍 [useLocksmithJobs] Starting job fetch for user:', user.id);
    
    try {
      const { jobs: fetchedJobs, error } = await fetchJobs(user.id);
      
      if (error) {
        console.error('🔍 [useLocksmithJobs] Error fetching jobs:', error);
        setJobs([]);
      } else {
        // Validate that fetchedJobs is an array
        if (!Array.isArray(fetchedJobs)) {
          console.error('🔍 [useLocksmithJobs] Invalid jobs data - not an array:', fetchedJobs);
          setJobs([]);
        } else {
          console.log('🔍 [useLocksmithJobs] Successfully fetched jobs:', fetchedJobs.length);
          console.log('🔍 [useLocksmithJobs] Job details:', fetchedJobs.map(job => ({
            id: job.id,
            category: job.category,
            address: job.address,
            urgency: job.urgency
          })));
          
          setJobs(fetchedJobs);
          console.log('🔍 [useLocksmithJobs] Jobs state updated with', fetchedJobs.length, 'jobs');
        }
      }
    } catch (error) {
      console.error('🔍 [useLocksmithJobs] Exception during job fetch:', error);
      setJobs([]);
    }
    
    setIsLoading(false);
  }, [user]);

  // Initial fetch
  useEffect(() => {
    handleFetchJobs();
  }, [handleFetchJobs]);

  // Play sound when new jobs are detected
  useEffect(() => {
    if (!isLoading && jobs.length > previousJobCount && previousJobCount > 0) {
      playNotificationSound();
    }
    setPreviousJobCount(jobs.length);
  }, [jobs.length, isLoading, previousJobCount]);

  // Set up real-time subscription for new jobs
  useEffect(() => {
    if (!user) return;

    console.log('🔍 [useLocksmithJobs] Setting up real-time subscription for user:', user.id);

    const cleanup = setupJobSubscription({
      userId: user.id,
      onJobChange: handleFetchJobs
    });

    return cleanup;
  }, [user, handleFetchJobs]);

  return {
    jobs,
    isLoading,
    refetch: handleFetchJobs
  };
};