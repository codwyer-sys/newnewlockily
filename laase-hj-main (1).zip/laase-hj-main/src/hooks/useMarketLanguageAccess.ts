import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface MarketLanguageAccess {
  id: string;
  market_code: string;
  language_code: string;
  is_primary: boolean;
  is_enabled: boolean;
}

interface LanguageOption {
  code: string;
  name: string;
  isPrimary: boolean;
}

export const useMarketLanguageAccess = (marketCode?: string) => {
  const [availableLanguages, setAvailableLanguages] = useState<LanguageOption[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAvailableLanguages = async (market?: string) => {
    if (!market) {
      setAvailableLanguages([]);
      setLoading(false);
      return;
    }

    try {
      const { data: accessData, error: accessError } = await supabase
        .from('market_language_access')
        .select('*')
        .eq('market_code', market)
        .eq('is_enabled', true)
        .order('is_primary', { ascending: false });

      if (accessError) throw accessError;

      const { data: mappingData, error: mappingError } = await supabase
        .from('language_mappings')
        .select('*')
        .eq('market_code', market);

      if (mappingError) throw mappingError;

      const languages: LanguageOption[] = (accessData || []).map(access => {
        const mapping = mappingData?.find(m => m.language_code === access.language_code);
        return {
          code: access.language_code,
          name: mapping?.language_name || access.language_code.toUpperCase(),
          isPrimary: access.is_primary
        };
      });

      setAvailableLanguages(languages);
    } catch (error) {
      console.error('Error fetching available languages:', error);
      setAvailableLanguages([]);
    } finally {
      setLoading(false);
    }
  };

  const isLanguageAvailable = (languageCode: string, market: string): boolean => {
    return availableLanguages.some(lang => 
      lang.code === languageCode && market === marketCode
    );
  };

  const getPrimaryLanguage = (market: string): string | null => {
    if (market !== marketCode) return null;
    const primary = availableLanguages.find(lang => lang.isPrimary);
    return primary?.code || null;
  };

  useEffect(() => {
    fetchAvailableLanguages(marketCode);
  }, [marketCode]);

  return {
    availableLanguages,
    loading,
    isLanguageAvailable,
    getPrimaryLanguage,
    refetch: () => fetchAvailableLanguages(marketCode)
  };
};