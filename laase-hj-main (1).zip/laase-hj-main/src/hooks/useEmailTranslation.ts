import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAITranslation } from '@/hooks/useAITranslation';
import { useToast } from '@/hooks/use-toast';

interface TranslateEmailContentRequest {
  templateContentId: string;
  targetLanguage: string;
  marketCode?: string;
  customInstruction?: string;
}

export const useEmailTranslation = () => {
  const [translating, setTranslating] = useState(false);
  const { translateText } = useAITranslation();
  const { toast } = useToast();

  const translateEmailContent = async (request: TranslateEmailContentRequest): Promise<boolean> => {
    setTranslating(true);
    try {
      console.log('🔤 Starting email content translation:', request);

      // Get the template content
      const { data: templateContent, error: contentError } = await supabase
        .from('email_template_content')
        .select(`
          *,
          email_templates (
            template_key,
            template_name
          )
        `)
        .eq('id', request.templateContentId)
        .single();

      if (contentError || !templateContent) {
        throw new Error('Template content not found');
      }

      // Check if translation already exists
      const { data: existingTranslation } = await supabase
        .from('email_template_translations')
        .select('id')
        .eq('template_content_id', request.templateContentId)
        .eq('language_code', request.targetLanguage)
        .eq('market_code', request.marketCode || null)
        .maybeSingle();

      // Prepare AI translation request
      const aiRequest = {
        originalText: templateContent.default_content,
        targetLanguage: request.targetLanguage,
        market: request.marketCode,
        pageName: 'email_templates',
        sectionName: templateContent.content_section,
        contentKey: templateContent.content_key,
        placement: `Email ${templateContent.content_section}`,
        context: `Email template: ${templateContent.email_templates?.template_name}. Content type: ${templateContent.content_type}`,
        customInstruction: request.customInstruction || getDefaultEmailInstruction(templateContent.content_section, templateContent.content_type)
      };

      console.log('🤖 Sending to AI translation:', {
        contentKey: templateContent.content_key,
        contentType: templateContent.content_type,
        section: templateContent.content_section,
        textLength: templateContent.default_content.length
      });

      const translatedText = await translateText(aiRequest);
      
      if (!translatedText) {
        throw new Error('AI translation failed');
      }

      // Save or update translation
      const translationData = {
        template_content_id: request.templateContentId,
        language_code: request.targetLanguage,
        market_code: request.marketCode || null,
        translated_content: translatedText,
        translation_status: 'translated' as const,
        ai_instruction: request.customInstruction,
        translated_by: (await supabase.auth.getUser()).data.user?.id
      };

      if (existingTranslation) {
        const { error: updateError } = await supabase
          .from('email_template_translations')
          .update(translationData)
          .eq('id', existingTranslation.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase
          .from('email_template_translations')
          .insert(translationData);

        if (insertError) throw insertError;
      }

      console.log('✅ Email translation saved successfully');
      
      toast({
        title: 'Translation Complete',
        description: `${templateContent.content_section} translated to ${request.targetLanguage}`,
      });

      return true;
    } catch (error) {
      console.error('❌ Email translation error:', error);
      toast({
        title: 'Translation Failed',
        description: error instanceof Error ? error.message : 'Failed to translate email content',
        variant: 'destructive',
      });
      return false;
    } finally {
      setTranslating(false);
    }
  };

  const bulkTranslateTemplate = async (
    templateId: string,
    targetLanguages: string[],
    marketCode?: string,
    customInstruction?: string
  ): Promise<void> => {
    setTranslating(true);
    try {
      console.log('🔄 Starting bulk translation:', { templateId, targetLanguages, marketCode });

      // Get all content for the template
      const { data: templateContents, error } = await supabase
        .from('email_template_content')
        .select('*')
        .eq('template_id', templateId);

      if (error || !templateContents) {
        throw new Error('Failed to fetch template contents');
      }

      const totalTranslations = templateContents.length * targetLanguages.length;
      let completedTranslations = 0;

      for (const content of templateContents) {
        for (const language of targetLanguages) {
          try {
            await translateEmailContent({
              templateContentId: content.id,
              targetLanguage: language,
              marketCode,
              customInstruction
            });
            completedTranslations++;
            
            // Update progress
            toast({
              title: 'Translation Progress',
              description: `${completedTranslations}/${totalTranslations} translations completed`,
            });
          } catch (error) {
            console.error(`Failed to translate ${content.content_section} to ${language}:`, error);
          }
        }
      }

      toast({
        title: 'Bulk Translation Complete',
        description: `Completed ${completedTranslations} translations`,
      });
    } catch (error) {
      console.error('Bulk translation error:', error);
      toast({
        title: 'Bulk Translation Failed',
        description: error instanceof Error ? error.message : 'Failed to complete bulk translation',
        variant: 'destructive',
      });
    } finally {
      setTranslating(false);
    }
  };

  return {
    translating,
    translateEmailContent,
    bulkTranslateTemplate
  };
};

function getDefaultEmailInstruction(section: string, contentType: string): string {
  const instructions = {
    subject: 'Keep email subject lines concise and compelling. Maintain urgency and clarity while being culturally appropriate.',
    preheader: 'Translate the preheader text that appears as preview text in email clients. Keep it brief and engaging.',
    body: contentType === 'html' 
      ? 'Translate the HTML email content while preserving all HTML tags and structure. Maintain formatting and links.'
      : 'Translate the email body text naturally while maintaining professional tone and clarity.',
    footer: 'Translate footer content including legal and contact information. Ensure compliance with local regulations.',
    header: 'Translate header content while maintaining brand consistency and professional appearance.'
  };

  return instructions[section as keyof typeof instructions] || 
    'Translate this email content appropriately for the target market and language.';
}