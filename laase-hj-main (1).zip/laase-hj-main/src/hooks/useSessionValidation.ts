import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export const useSessionValidation = () => {
  const { user, session } = useAuth();
  const [isValidSession, setIsValidSession] = useState<boolean | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  const validateSession = async () => {
    if (!user || !session) {
      setIsValidSession(false);
      setValidationError('No user or session found');
      return false;
    }

    try {
      console.log('🔍 Validating session integrity...');
      
      // Test 1: Check if session is not expired
      if (session.expires_at && new Date(session.expires_at * 1000) < new Date()) {
        console.error('❌ Session expired');
        setIsValidSession(false);
        setValidationError('Session expired');
        return false;
      }

      // Test 2: Test database connectivity with current session
      const { data, error } = await supabase
        .from('user_roles')
        .select('count')
        .limit(1);

      if (error) {
        console.error('❌ Database connectivity test failed:', error);
        setIsValidSession(false);
        setValidationError(`Database connectivity failed: ${error.message}`);
        return false;
      }

      // Test 3: Check if auth.uid() works by checking user roles
      const { data: roleData, error: roleError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .limit(1);

      if (roleError) {
        console.error('❌ Auth.uid() test failed:', roleError);
        setIsValidSession(false);
        setValidationError(`Authentication test failed: ${roleError.message}`);
        return false;
      }

      console.log('✅ Session validation passed');
      setIsValidSession(true);
      setValidationError(null);
      return true;

    } catch (error) {
      console.error('❌ Session validation error:', error);
      setIsValidSession(false);
      setValidationError(`Validation error: ${error.message}`);
      return false;
    }
  };

  const refreshSession = async () => {
    try {
      console.log('🔄 Refreshing session...');
      const { data, error } = await supabase.auth.refreshSession();
      
      if (error) {
        console.error('❌ Session refresh failed:', error);
        return false;
      }

      console.log('✅ Session refreshed successfully');
      return true;
    } catch (error) {
      console.error('❌ Session refresh error:', error);
      return false;
    }
  };

  useEffect(() => {
    if (user && session) {
      validateSession();
    }
  }, [user, session]);

  return {
    isValidSession,
    validationError,
    validateSession,
    refreshSession
  };
};