import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMarket } from '@/contexts/MarketContext';
import { useLanguage } from '@/contexts/LanguageContext';

interface MegaMenuCity {
  id: string;
  name: string;
  slug: string;
  local_name?: string;
  population?: number;
  market_code: string;
}

interface CitiesMegaMenuData {
  featuredCities: MegaMenuCity[];
  standardCities: MegaMenuCity[];
  loading: boolean;
}

export const useCitiesMegaMenu = () => {
  const { market } = useMarket();
  const { language } = useLanguage();
  const [data, setData] = useState<CitiesMegaMenuData>({
    featuredCities: [],
    standardCities: [],
    loading: true,
  });

  useEffect(() => {
    const fetchCities = async () => {
      setData(prev => ({ ...prev, loading: true }));
      
      try {
        let query = supabase
          .from('cities')
          .select(`
            id,
            name,
            slug,
            population,
            market_code,
            city_translations!left(local_name, language_code, market_code)
          `)
          .eq('is_active', true)
          .eq('market_code', market.country_code)
          .order('population', { ascending: false, nullsFirst: false })
          .order('name', { ascending: true })
          .limit(10);

        const { data: cities, error } = await query;

        if (error) throw error;

        // Process cities to include local names for current language
        const processedCities = (cities || []).map(city => {
          const translations = city.city_translations || [];
          
          // Find translation for current language and market
          const currentLangTranslation = translations.find(
            (t: any) => t.language_code === language && t.market_code === city.market_code
          );
          
          // Fallback to any translation for the market if current language not found
          const fallbackTranslation = translations.find(
            (t: any) => t.market_code === city.market_code
          );
          
          const translation = currentLangTranslation || fallbackTranslation;
          
          return {
            ...city,
            local_name: translation?.local_name,
            city_translations: undefined // Remove from final object
          };
        });

        // Split into featured (top 5) and standard (next 5)
        const featuredCities = processedCities.slice(0, 5);
        const standardCities = processedCities.slice(5, 10);

        setData({
          featuredCities,
          standardCities,
          loading: false,
        });
      } catch (error) {
        console.error('Error fetching cities for mega menu:', error);
        setData({
          featuredCities: [],
          standardCities: [],
          loading: false,
        });
      }
    };

    fetchCities();
  }, [market.country_code, language]);

  return data;
};