import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface ActiveQuote {
  id: string;
  booking_id: string;
  price: number;
  estimated_arrival_minutes: number;
  distance_km: number;
  message?: string;
  status: string;
  expires_at: string;
  created_at: string;
  locksmith_address?: string;
  booking: {
    id: string;
    job_number: number;
    address: string;
    job_type: string;
    urgency: string;
    scheduled_date?: string;
    follow_up_answers?: any;
    job_category_id: string;
  };
  job_category: {
    name: string;
    emoji?: string;
  };
}

export const useActiveQuotes = () => {
  const [quotes, setQuotes] = useState<ActiveQuote[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const loadActiveQuotes = async () => {
    if (!user) {
      setQuotes([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // First get quotes with booking data
      const { data: quotesData, error: quotesError } = await supabase
        .from('quotes')
        .select(`
          *,
          booking:bookings!quotes_booking_id_fkey (
            id,
            job_number,
            address,
            job_type,
            urgency,
            scheduled_date,
            follow_up_answers,
            job_category_id
          )
        `)
        .eq('locksmith_id', user.id)
        .eq('status', 'pending')
        .gt('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false });

      if (quotesError) {
        throw quotesError;
      }

      // Get job categories for all quotes
      const categoryIds = [...new Set(quotesData?.map(q => q.booking?.job_category_id).filter(Boolean))];
      const { data: categoriesData } = await supabase
        .from('job_categories')
        .select('id, name, emoji')
        .in('id', categoryIds);

      // Create a category lookup map
      const categoryMap = new Map(categoriesData?.map(cat => [cat.id, cat]) || []);

      // Transform the data to match our interface
      const transformedQuotes: ActiveQuote[] = (quotesData || []).map(quote => ({
        ...quote,
        booking: quote.booking as any,
        job_category: categoryMap.get(quote.booking?.job_category_id) || { name: 'Unknown', emoji: '🔒' }
      }));

      setQuotes(transformedQuotes);
    } catch (err) {
      console.error('Error loading active quotes:', err);
      setError('Failed to load active quotes');
    } finally {
      setLoading(false);
    }
  };

  // Set up real-time subscription for quote updates
  useEffect(() => {
    if (!user) return;

    // Initial load
    loadActiveQuotes();

    // Set up real-time subscription
    const channel = supabase
      .channel('active-quotes-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'quotes',
          filter: `locksmith_id=eq.${user.id}`
        },
        () => {
          // Reload quotes when any change occurs
          loadActiveQuotes();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const withdrawQuote = async (quoteId: string) => {
    try {
      const { error } = await supabase
        .from('quotes')
        .update({ status: 'withdrawn' })
        .eq('id', quoteId)
        .eq('locksmith_id', user?.id);

      if (error) throw error;

      // Reload quotes after withdrawal
      await loadActiveQuotes();
      return true;
    } catch (err) {
      console.error('Error withdrawing quote:', err);
      return false;
    }
  };

  const updateQuote = async (quoteId: string, updates: { price?: number; message?: string; estimated_arrival_minutes?: number }) => {
    try {
      const { error } = await supabase
        .from('quotes')
        .update(updates)
        .eq('id', quoteId)
        .eq('locksmith_id', user?.id);

      if (error) throw error;

      // Reload quotes after update
      await loadActiveQuotes();
      return true;
    } catch (err) {
      console.error('Error updating quote:', err);
      return false;
    }
  };

  return {
    quotes,
    loading,
    error,
    refetch: loadActiveQuotes,
    withdrawQuote,
    updateQuote
  };
};