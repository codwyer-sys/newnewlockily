import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useMarketAddressSearch } from '@/hooks/useMarketAddressSearch';
import { AddressSearchResult } from '@/services/address/types';

export const useAddressManagement = () => {
  const [address, setAddress] = useState(''); // Display address (business address)
  const [searchQuery, setSearchQuery] = useState(''); // Search input query
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const addressInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();

  // Address search hook
  const { 
    suggestions: addressSuggestions, 
    error: addressSearchError, 
    isLoading: isSearchingAddress 
  } = useMarketAddressSearch(searchQuery, isEditingAddress && searchQuery.length > 0);

  // Debug logging for address search
  console.log('🏠 Address search debug:', {
    address,
    searchQuery,
    isEditingAddress,
    addressSuggestions: addressSuggestions.length,
    addressSearchError,
    isSearchingAddress
  });

  // Fetch locksmith's business address
  const fetchBusinessAddress = async () => {
    if (!user) {
      console.log('🏠 No user, cannot fetch business address');
      return '';
    }
    
    try {
      console.log('🏠 Fetching business address for user:', user.id);
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('address, address_latitude, address_longitude')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('🏠 Error fetching business address:', error);
        return '';
      }

      if (profile?.address) {
        console.log('🏠 Found business address:', profile.address);
        return profile.address;
      } else {
        console.log('🏠 No business address found in profile');
      }
    } catch (error) {
      console.error('🏠 Failed to fetch business address:', error);
    }
    
    return '';
  };

  // Initialize address on mount
  useEffect(() => {
    const initializeAddress = async () => {
      if (user) {
        console.log('🏠 Initializing address...');
        const businessAddress = await fetchBusinessAddress();
        console.log('🏠 Setting initial address:', businessAddress);
        setAddress(businessAddress);
        
        // Start in editing mode if no business address is found
        if (!businessAddress || businessAddress.trim() === '') {
          console.log('🏠 No business address found, starting in edit mode');
          setIsEditingAddress(true);
        } else {
          setIsEditingAddress(false);
        }
      }
    };
    
    initializeAddress();
  }, [user]);

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    console.log('🏠 Search query changed:', newValue);
    setSearchQuery(newValue);
    
    // Always show suggestions when there's input length >= 3
    if (newValue.length >= 3) {
      setShowSuggestions(true);
      console.log('🏠 Showing suggestions for:', newValue);
    } else {
      setShowSuggestions(false);
      console.log('🏠 Hiding suggestions - input too short');
    }
  };

  const handleSuggestionClick = (suggestion: AddressSearchResult) => {
    const selectedAddress = suggestion.fullAddress || suggestion.displayText;
    setAddress(selectedAddress);
    setSearchQuery(''); // Clear the search query
    setShowSuggestions(false);
    setIsEditingAddress(false);
    if (addressInputRef.current) {
      addressInputRef.current.blur();
    }
  };

  const handleAddressFocus = () => {
    console.log('🏠 Address input focused:', { searchQuery, isEditingAddress });
    // Show suggestions if we have enough characters and there are suggestions available
    if (searchQuery.length >= 3 && addressSuggestions.length > 0) {
      setShowSuggestions(true);
      console.log('🏠 Showing existing suggestions on focus');
    }
  };

  const handleAddressBlur = () => {
    setTimeout(() => {
      setShowSuggestions(false);
    }, 150);
  };

  const handleEditToggle = () => {
    console.log('🏠 Toggle edit mode');
    if (!isEditingAddress) {
      // Entering edit mode - clear search query for fresh start
      setSearchQuery('');
      setShowSuggestions(false);
    }
    setIsEditingAddress(!isEditingAddress);
    setTimeout(() => {
      if (addressInputRef.current) {
        addressInputRef.current.focus();
      }
    }, 100);
  };

  return {
    // State
    address,
    searchQuery,
    isEditingAddress,
    showSuggestions,
    addressSuggestions,
    addressSearchError,
    isSearchingAddress,
    addressInputRef,
    
    // Actions
    setAddress,
    setSearchQuery,
    setIsEditingAddress,
    setShowSuggestions,
    handleAddressChange,
    handleSuggestionClick,
    handleAddressFocus,
    handleAddressBlur,
    handleEditToggle,
    fetchBusinessAddress
  };
};