import { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";

interface JobCategory {
  id: string;
  name: string;
  emoji: string;
  description: string;
  requires_image: boolean;
  created_at: string;
  updated_at: string;
}

export const useJobCategoriesManager = () => {
  const [categories, setCategories] = useState<JobCategory[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('job_categories')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const createCategory = async (categoryData: Partial<JobCategory>) => {
    const { data, error } = await supabase
      .from('job_categories')
      .insert([{
        name: categoryData.name || '',
        emoji: categoryData.emoji || '',
        description: categoryData.description || '',
        requires_image: categoryData.requires_image || false
      }])
      .select()
      .single();
    
    if (error) throw error;
    await fetchCategories();
    return data;
  };

  const updateCategory = async (id: string, categoryData: Partial<JobCategory>) => {
    const { data, error } = await supabase
      .from('job_categories')
      .update(categoryData)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    await fetchCategories();
    return data;
  };

  const getBookingCountForCategory = async (categoryId: string): Promise<number> => {
    const { count, error } = await supabase
      .from('bookings')
      .select('*', { count: 'exact', head: true })
      .eq('job_category_id', categoryId);
    
    if (error) throw error;
    return count || 0;
  };

  const reassignBookings = async (fromCategoryId: string, toCategoryId: string) => {
    const { error } = await supabase
      .from('bookings')
      .update({ job_category_id: toCategoryId })
      .eq('job_category_id', fromCategoryId);
    
    if (error) throw error;
  };

  const deleteCategoryWithReassignment = async (categoryId: string, reassignToCategoryId?: string) => {
    // If there are bookings to reassign, do that first
    if (reassignToCategoryId) {
      await reassignBookings(categoryId, reassignToCategoryId);
    }
    
    // Then delete the category
    const { error } = await supabase
      .from('job_categories')
      .delete()
      .eq('id', categoryId);
    
    if (error) throw error;
    await fetchCategories();
  };

  const deleteCategory = async (id: string) => {
    const { error } = await supabase
      .from('job_categories')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
    await fetchCategories();
  };

  const refreshCategories = () => {
    fetchCategories();
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return {
    categories,
    loading,
    createCategory,
    updateCategory,
    deleteCategory,
    deleteCategoryWithReassignment,
    getBookingCountForCategory,
    reassignBookings,
    refreshCategories
  };
};