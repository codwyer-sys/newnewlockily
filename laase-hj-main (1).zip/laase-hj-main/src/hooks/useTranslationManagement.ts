import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { validateContentInstruction, validateContentSet, type ContentValidationResult } from '@/utils/contentValidation';

interface Translation {
  id: string;
  section_id: string;
  language_code: string;
  content_key: string;
  content_value: string;
  content_type: string;
  market_code: string | null;
  updated_at: string;
  updated_by: string | null;
  notes: string | null;
  ai_instruction: string | null;
  section: {
    section_name: string;
    page: {
      page_name: string;
    };
  };
}

interface TranslationStats {
  totalTranslations: number;
  completionByMarket: Record<string, number>;
  completionByLanguage: Record<string, number>;
  recentlyUpdated: Translation[];
  missingCount: number;
}

export const useTranslationManagement = () => {
  const [translations, setTranslations] = useState<Translation[]>([]);
  const [stats, setStats] = useState<TranslationStats>({
    totalTranslations: 0,
    completionByMarket: {},
    completionByLanguage: {},
    recentlyUpdated: [],
    missingCount: 0
  });
  const [loading, setLoading] = useState(true);
  const [markets, setMarkets] = useState<Array<{country_code: string, country_name: string}>>([]);

  const fetchTranslations = async () => {
    try {
      const { data, error } = await supabase
        .from('content_translations')
        .select(`
          *,
          section:content_sections!inner(
            section_name,
            page:content_pages!inner(page_name)
          )
        `)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setTranslations(data || []);
    } catch (error) {
      console.error('Error fetching translations:', error);
      toast.error('Failed to fetch translations');
    }
  };

  const fetchMarkets = async () => {
    try {
      const { data, error } = await supabase
        .from('markets')
        .select('country_code, country_name')
        .order('country_code');
      
      if (error) throw error;
      setMarkets(data || []);
    } catch (error) {
      console.error('Error fetching markets:', error);
    }
  };

  const calculateStats = useMemo(() => {
    if (!translations.length) return stats;

    const totalTranslations = translations.length;
    const recentlyUpdated = translations.slice(0, 10);

    // Calculate completion by market
    const marketGroups = translations.reduce((acc, t) => {
      const market = t.market_code || 'global';
      if (!acc[market]) acc[market] = [];
      acc[market].push(t);
      return acc;
    }, {} as Record<string, Translation[]>);

    const completionByMarket = Object.entries(marketGroups).reduce((acc, [market, trans]) => {
      const filled = trans.filter(t => t.content_value.trim().length > 0).length;
      acc[market] = Math.round((filled / trans.length) * 100);
      return acc;
    }, {} as Record<string, number>);

    // Calculate completion by language
    const langGroups = translations.reduce((acc, t) => {
      if (!acc[t.language_code]) acc[t.language_code] = [];
      acc[t.language_code].push(t);
      return acc;
    }, {} as Record<string, Translation[]>);

    const completionByLanguage = Object.entries(langGroups).reduce((acc, [lang, trans]) => {
      const filled = trans.filter(t => t.content_value.trim().length > 0).length;
      acc[lang] = Math.round((filled / trans.length) * 100);
      return acc;
    }, {} as Record<string, number>);

    const missingCount = translations.filter(t => !t.content_value.trim()).length;

    return {
      totalTranslations,
      completionByMarket,
      completionByLanguage,
      recentlyUpdated,
      missingCount
    };
  }, [translations]);

  const updateTranslation = async (id: string, content_value: string, notes?: string, ai_instruction?: string) => {
    try {
      const { error } = await supabase
        .from('content_translations')
        .update({ 
          content_value,
          notes: notes || null,
          ai_instruction: ai_instruction || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
      
      await fetchTranslations();
      toast.success('Translation updated successfully');
    } catch (error) {
      console.error('Error updating translation:', error);
      toast.error('Failed to update translation');
    }
  };

  const bulkUpdateTranslations = async (updates: Array<{id: string, content_value: string, notes?: string, ai_instruction?: string}>) => {
    try {
      const promises = updates.map(update => 
        supabase
          .from('content_translations')
          .update({ 
            content_value: update.content_value,
            notes: update.notes || null,
            ai_instruction: update.ai_instruction || null,
            updated_at: new Date().toISOString()
          })
          .eq('id', update.id)
      );

      await Promise.all(promises);
      await fetchTranslations();
      toast.success(`Updated ${updates.length} translations`);
    } catch (error) {
      console.error('Error bulk updating translations:', error);
      toast.error('Failed to update translations');
    }
  };

  const createMissingTranslations = async (contentKeys: string[], sectionId: string) => {
    try {
      const languages = ['da', 'en'];
      const newTranslations = [];

      for (const key of contentKeys) {
        for (const lang of languages) {
          newTranslations.push({
            section_id: sectionId,
            language_code: lang,
            content_key: key,
            content_value: '',
            content_type: 'text'
          });
        }
      }

      const { error } = await supabase
        .from('content_translations')
        .insert(newTranslations);

      if (error) throw error;
      
      await fetchTranslations();
      toast.success(`Created ${newTranslations.length} missing translations`);
    } catch (error) {
      console.error('Error creating missing translations:', error);
      toast.error('Failed to create missing translations');
    }
  };

  const validateTranslations = () => {
    const validationResults = validateContentSet(
      translations.map(t => ({
        content_key: t.content_key,
        content_value: t.content_value,
        ai_instruction: t.ai_instruction,
        language_code: t.language_code
      }))
    );

    const issues = Object.entries(validationResults).filter(
      ([_, result]) => !result.isValid || result.warnings.length > 0
    );

    if (issues.length > 0) {
      console.warn('Content validation issues found:', issues);
      issues.forEach(([key, result]) => {
        if (result.errors.length > 0) {
          console.error(`Errors for ${key}:`, result.errors);
        }
        if (result.warnings.length > 0) {
          console.warn(`Warnings for ${key}:`, result.warnings);
        }
      });
    }

    return validationResults;
  };

  const findContentIssues = (contentKey?: string) => {
    let filteredTranslations = translations;
    
    if (contentKey) {
      filteredTranslations = translations.filter(t => t.content_key === contentKey);
    }

    const issues: Array<{
      translation: Translation;
      validation: ContentValidationResult;
    }> = [];

    filteredTranslations.forEach(translation => {
      const validation = validateContentInstruction(
        translation.content_value,
        translation.ai_instruction,
        translation.content_key
      );

      if (!validation.isValid || validation.warnings.length > 0) {
        issues.push({ translation, validation });
      }
    });

    return issues;
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchTranslations(), fetchMarkets()]);
      setLoading(false);
    };

    loadData();
  }, []);

  useEffect(() => {
    setStats(calculateStats);
  }, [calculateStats]);

  return {
    translations,
    stats,
    markets,
    loading,
    updateTranslation,
    bulkUpdateTranslations,
    createMissingTranslations,
    validateTranslations,
    findContentIssues,
    refetch: fetchTranslations
  };
};