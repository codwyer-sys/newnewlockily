import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useBlogPosts } from './useBlogPosts';
import { useBlogCategories } from './useBlogCategories';
import { toast } from 'sonner';

interface BlogPostsTableFilters {
  search: string;
  market: string;
  categories: string[];
  status: string;
  author: string;
}

const defaultFilters: BlogPostsTableFilters = {
  search: '',
  market: 'all',
  categories: [],
  status: 'all',
  author: 'all',
};

const POSTS_PER_PAGE = 10;

export const useBlogPostsTable = (marketCode?: string, languageCode: string = 'en') => {
  const { posts, categories, loading, deletePost: deleteBlogPost, createPost } = useBlogPosts(marketCode, languageCode);
  const [filters, setFilters] = useState<BlogPostsTableFilters>(defaultFilters);
  const [currentPage, setCurrentPage] = useState(1);
  const [markets, setMarkets] = useState<Array<{country_code: string, country_name: string}>>([]);

  // Fetch markets
  useEffect(() => {
    const fetchMarkets = async () => {
      const { data, error } = await supabase
        .from('markets')
        .select('country_code, country_name')
        .order('country_code');
      
      if (data && !error) {
        setMarkets(data);
      }
    };

    fetchMarkets();
  }, []);

  // Filter posts based on current filters
  const filteredPosts = useMemo(() => {
    let result = [...posts];

    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(post => 
        post.title.toLowerCase().includes(searchLower) ||
        post.excerpt?.toLowerCase().includes(searchLower) ||
        post.content.toLowerCase().includes(searchLower)
      );
    }

    // Market filter
    if (filters.market !== 'all') {
      result = result.filter(post => post.market_code === filters.market);
    }

    // Categories filter
    if (filters.categories.length > 0) {
      result = result.filter(post => 
        post.category_id && filters.categories.includes(post.category_id)
      );
    }

    // Status filter
    if (filters.status !== 'all') {
      result = result.filter(post => post.status === filters.status);
    }

    return result;
  }, [posts, filters]);

  // Pagination
  const totalCount = filteredPosts.length;
  const totalPages = Math.ceil(totalCount / POSTS_PER_PAGE);
  
  const paginatedPosts = useMemo(() => {
    const startIndex = (currentPage - 1) * POSTS_PER_PAGE;
    const endIndex = startIndex + POSTS_PER_PAGE;
    return filteredPosts.slice(startIndex, endIndex);
  }, [filteredPosts, currentPage]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);

  const updateFilters = (newFilters: Partial<BlogPostsTableFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const clearFilters = () => {
    setFilters(defaultFilters);
    setCurrentPage(1);
  };

  const deletePost = async (id: string) => {
    await deleteBlogPost(id);
  };

  const duplicatePost = async (post: any) => {
    const duplicatedPost = {
      title: `${post.title} (Copy)`,
      slug: `${post.slug}-copy-${Date.now()}`,
      content: post.content,
      excerpt: post.excerpt,
      featured_image_url: post.featured_image_url,
      featured_image_alt: post.featured_image_alt,
      author_id: post.author_id, // Keep the original author_id when duplicating
      category_id: post.category_id,
      market_code: post.market_code,
      is_global: post.is_global,
      status: 'draft' as const,
      seo_title: post.seo_title,
      seo_description: post.seo_description,
      seo_keywords: post.seo_keywords,
    };

    await createPost(duplicatedPost);
  };

  return {
    posts: paginatedPosts,
    loading,
    totalCount,
    currentPage,
    totalPages,
    filters,
    markets,
    categories,
    setCurrentPage,
    updateFilters,
    clearFilters,
    deletePost,
    duplicatePost
  };
};