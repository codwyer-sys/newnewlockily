
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

export const useGeolocation = () => {
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const { toast } = useToast();

  const getCurrentLocation = async (): Promise<string | null> => {
    setIsLoadingLocation(true);
    
    if (!navigator.geolocation) {
      toast({
        title: "Geolocation ikke understøttet",
        description: "Indtast venligst din adresse manuelt",
        variant: "destructive"
      });
      setIsLoadingLocation(false);
      return null;
    }

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          try {
            // Use MapBox reverse geocoding via Supabase Edge Function
            const { data, error } = await supabase.functions.invoke('mapbox-reverse-geocoding', {
              body: { lat: latitude, lng: longitude }
            });

            if (error) {
              throw error;
            }

            if (data?.address) {
              toast({
                title: "📍 Lokation fundet",
                description: "Din adresse er blevet udfyldt automatisk"
              });
              resolve(data.address);
            } else {
              throw new Error('Ingen adresse fundet');
            }
          } catch (error) {
            console.error('MapBox reverse geocoding failed:', error);
            toast({
              title: "Kunne ikke finde adresse",
              description: "Indtast venligst din adresse manuelt",
              variant: "destructive"
            });
            resolve(null);
          } finally {
            setIsLoadingLocation(false);
          }
        },
        (error) => {
          console.error('Geolocation error:', error);
          let errorMessage = "Indtast venligst din adresse manuelt";
          
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = "Tillad venligst lokation i din browser";
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = "Lokation ikke tilgængelig";
              break;
            case error.TIMEOUT:
              errorMessage = "Lokation timeout - prøv igen";
              break;
          }

          toast({
            title: "Lokation ikke tilgængelig",
            description: errorMessage,
            variant: "destructive"
          });
          setIsLoadingLocation(false);
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutes
        }
      );
    });
  };

  return {
    getCurrentLocation,
    isLoadingLocation
  };
};
