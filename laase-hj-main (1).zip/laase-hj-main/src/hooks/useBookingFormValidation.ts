
import { useState, useEffect } from 'react';

interface UseBookingFormValidationProps {
  address: string;
  urgency: string;
  selectedDate: string;
  jobType: string | { selection: string; details: string };
  followUpAnswers: Record<string, any>;
  getRequiredQuestionsForJobType: (type: string) => Promise<string[]>;
}

export const useBookingFormValidation = ({
  address,
  urgency,
  selectedDate,
  jobType,
  followUpAnswers,
  getRequiredQuestionsForJobType
}: UseBookingFormValidationProps) => {
  const [isBookingDisabled, setIsBookingDisabled] = useState(true);
  const [allFollowUpAnswered, setAllFollowUpAnswered] = useState(false);

  useEffect(() => {
    const checkValidation = async () => {
      const jobTypeId = typeof jobType === 'object' ? jobType.selection : jobType;
      
      if (!jobTypeId) {
        setIsBookingDisabled(true);
        setAllFollowUpAnswered(false);
        return;
      }

      const requiredQuestions = await getRequiredQuestionsForJobType(jobTypeId);
      const hasRequiredAnswers = requiredQuestions.every(q => followUpAnswers[q]);
      const basicFieldsValid = address && urgency && (urgency === "nu" || urgency === "asap" || selectedDate);
      
      setAllFollowUpAnswered(hasRequiredAnswers);
      setIsBookingDisabled(!basicFieldsValid || !hasRequiredAnswers);
    };

    checkValidation();
  }, [address, urgency, selectedDate, jobType, followUpAnswers, getRequiredQuestionsForJobType]);

  return {
    isBookingDisabled,
    allFollowUpAnswered
  };
};
