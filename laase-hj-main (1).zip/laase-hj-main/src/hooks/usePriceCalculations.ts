import { useMemo } from 'react';
import { usePriceSuggestion } from '@/hooks/usePriceSuggestion';
import { LocksmithJob } from '@/types/locksmith';

interface UsePriceCalculationsProps {
  job: LocksmithJob | null;
  localDistance: { km: number; duration: number } | null;
  chargeClientForReferral: boolean;
  customPrices: {
    basePrice?: number;
    timeSurcharge?: number;
    distanceFee?: number;
    materials?: number;
  };
  materialEnabled: boolean;
}

export const usePriceCalculations = ({ 
  job, 
  localDistance, 
  chargeClientForReferral, 
  customPrices, 
  materialEnabled 
}: UsePriceCalculationsProps) => {
  // Price calculations
  const jobForPricing = job ? { ...job, followUpAnswers: undefined } : null;
  const { 
    priceBreakdown, 
    isCalculating, 
    hasValidConfiguration 
  } = usePriceSuggestion(jobForPricing, localDistance ? { km: localDistance.km } : undefined, chargeClientForReferral);
  
  // Calculate final prices (custom or original)
  const finalPrices = useMemo(() => {
    if (!priceBreakdown) return null;
    
    return {
      basePrice: customPrices.basePrice ?? priceBreakdown.basePrice,
      timeSurcharge: customPrices.timeSurcharge ?? priceBreakdown.timeSurcharge.amount,
      distanceFee: customPrices.distanceFee ?? priceBreakdown.distanceFee,
      materials: materialEnabled ? (customPrices.materials ?? 0) : 0,
      get referralFeeAmount() {
        const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
        return priceBreakdown.referralFee ? (subtotal * priceBreakdown.referralFee.percentage) / 100 : 0;
      },
      get total() {
        const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
        return chargeClientForReferral && priceBreakdown.referralFee 
          ? subtotal + this.referralFeeAmount 
          : subtotal;
      },
      get locksmithEarnings() {
        const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
        return chargeClientForReferral 
          ? this.total 
          : (priceBreakdown.referralFee ? subtotal - this.referralFeeAmount : subtotal);
      }
    };
  }, [priceBreakdown, customPrices, materialEnabled, chargeClientForReferral]);

  return {
    priceBreakdown,
    finalPrices,
    isCalculating,
    hasValidConfiguration
  };
};