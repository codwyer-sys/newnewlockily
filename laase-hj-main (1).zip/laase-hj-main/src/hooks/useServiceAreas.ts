import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

export interface ServiceArea {
  id: string;
  locksmith_id: string;
  service_type: 'postal_codes' | 'radius';
  postal_codes: string[] | null;
  max_distance_km: number | null;
  center_address: string | null;
  center_coordinates: any | null;
  created_at: string;
}

export interface ServiceAreaInput {
  service_type: 'postal_codes' | 'radius';
  postal_codes?: string[];
  max_distance_km?: number;
  center_address?: string;
  center_coordinates?: any;
}

export const useServiceAreas = () => {
  const { user } = useAuth();
  const [serviceArea, setServiceArea] = useState<ServiceArea | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchServiceArea = async () => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase
        .from('service_areas')
        .select('*')
        .eq('locksmith_id', user.id)
        .maybeSingle();

      if (error) throw error;
      setServiceArea(data as ServiceArea | null);
    } catch (error) {
      console.error('Error fetching service area:', error);
      toast.error('Failed to load service area');
    } finally {
      setIsLoading(false);
    }
  };

  const saveServiceArea = async (input: ServiceAreaInput) => {
    if (!user?.id) return false;

    setIsUpdating(true);
    try {
      const payload = {
        locksmith_id: user.id,
        service_type: input.service_type,
        postal_codes: input.postal_codes || null,
        max_distance_km: input.max_distance_km || null,
        center_address: input.center_address || null,
        center_coordinates: input.center_coordinates || null,
      };

      let result;
      if (serviceArea) {
        result = await supabase
          .from('service_areas')
          .update(payload)
          .eq('id', serviceArea.id)
          .select()
          .single();
      } else {
        result = await supabase
          .from('service_areas')
          .insert(payload)
          .select()
          .single();
      }

      if (result.error) throw result.error;
      
      setServiceArea(result.data as ServiceArea);
      toast.success('Service area saved successfully');
      return true;
    } catch (error) {
      console.error('Error saving service area:', error);
      toast.error('Failed to save service area');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const deleteServiceArea = async () => {
    if (!serviceArea?.id) return false;

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('service_areas')
        .delete()
        .eq('id', serviceArea.id);

      if (error) throw error;
      
      setServiceArea(null);
      toast.success('Service area deleted');
      return true;
    } catch (error) {
      console.error('Error deleting service area:', error);
      toast.error('Failed to delete service area');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const isConfigured = () => {
    if (!serviceArea) return false;
    
    if (serviceArea.service_type === 'postal_codes') {
      return serviceArea.postal_codes && serviceArea.postal_codes.length > 0;
    } else {
      return serviceArea.max_distance_km && serviceArea.max_distance_km > 0;
    }
  };

  useEffect(() => {
    fetchServiceArea();
  }, [user?.id]);

  return {
    serviceArea,
    isLoading,
    isUpdating,
    isConfigured: isConfigured(),
    saveServiceArea,
    deleteServiceArea,
    refetch: fetchServiceArea,
  };
};