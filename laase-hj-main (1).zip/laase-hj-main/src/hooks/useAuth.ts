
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Session, User } from '@supabase/supabase-js';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    console.log('🔄 Initializing useAuth hook...');
    
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('🔍 Auth state changed:', {
          event,
          hasSession: !!session,
          userId: session?.user?.id,
          userEmail: session?.user?.email,
          accessToken: session?.access_token ? 'present' : 'missing',
          refreshToken: session?.refresh_token ? 'present' : 'missing',
          timestamp: new Date().toISOString()
        });
        
        setSession(session);
        setUser(session?.user ?? null);
        setIsLoading(false);
        
        // If session expired or was invalidated, trigger refresh
        if (event === 'TOKEN_REFRESHED' || event === 'SIGNED_IN') {
          console.log('✅ Session refreshed or user signed in');
        } else if (event === 'SIGNED_OUT') {
          console.log('🚪 User signed out');
        }
      }
    );

    // THEN get initial session
    console.log('🔍 Getting initial session...');
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      console.log('🔍 Initial session result:', {
        hasSession: !!session,
        sessionError: error?.message,
        userId: session?.user?.id,
        userEmail: session?.user?.email,
        isExpired: session ? new Date(session.expires_at! * 1000) < new Date() : null
      });
      
      if (error) {
        console.error('❌ Error getting initial session:', error);
      }
      
      setSession(session);
      setUser(session?.user ?? null);
      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('Error signing out:', error);
    }
  };

  return {
    user,
    session,
    isLoading,
    signOut
  };
};
