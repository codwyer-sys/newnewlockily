import { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";
import { useMarket } from '@/contexts/MarketContext';
import { useLanguage } from '@/contexts/LanguageContext';

interface FollowUpQuestionWithTranslation {
  id: string;
  job_category_id?: string;
  question: string;
  question_key: string;
  question_type: 'radio' | 'number' | 'text' | 'checkbox';
  options?: string[];
  option_icons?: Record<string, string>;
  is_required: boolean;
  is_global: boolean;
  order_index: number;
}

export const useTranslatedFollowUpQuestions = (jobType: string) => {
  const [questions, setQuestions] = useState<FollowUpQuestionWithTranslation[]>([]);
  const [loading, setLoading] = useState(true);
  const { market } = useMarket();
  const { language } = useLanguage();

  useEffect(() => {
    if (jobType) {
      fetchTranslatedQuestions();
    }
  }, [jobType, market.country_code, language]);

  const fetchTranslatedQuestions = async () => {
    try {
      setLoading(true);
      
      // Get questions for this job type or global questions
      const { data: questionsData, error: questionsError } = await supabase
        .from('follow_up_questions')
        .select('*')
        .or(`job_category_id.eq.${jobType},is_global.eq.true`)
        .order('order_index');
      
      if (questionsError) throw questionsError;
      
      // Get translations for current language/market
      const { data: translationsData, error: translationsError } = await supabase
        .from('follow_up_question_translations')
        .select('*')
        .eq('language_code', language)
        .eq('market_code', market.country_code)
        .in('follow_up_question_id', questionsData.map(q => q.id));
      
      if (translationsError) throw translationsError;
      
      // Merge questions with their translations
      const translatedQuestions: FollowUpQuestionWithTranslation[] = questionsData.map(question => {
        const translation = translationsData.find(t => t.follow_up_question_id === question.id);
        return {
          id: question.id,
          job_category_id: question.job_category_id || undefined,
          question: translation?.question || question.question,
          question_key: question.question_key,
          question_type: question.question_type as 'radio' | 'number' | 'text' | 'checkbox',
          options: translation?.options ? (translation.options as string[]) : (question.options ? (question.options as string[]) : undefined),
          option_icons: translation?.option_icons ? (translation.option_icons as Record<string, string>) : (question.option_icons ? (question.option_icons as Record<string, string>) : undefined),
          is_required: question.is_required || false,
          is_global: question.is_global || false,
          order_index: question.order_index || 0
        };
      });
      
      setQuestions(translatedQuestions);
    } catch (error) {
      console.error('Error fetching translated questions:', error);
      setQuestions([]);
    } finally {
      setLoading(false);
    }
  };

  return { questions, loading, refetch: fetchTranslatedQuestions };
};