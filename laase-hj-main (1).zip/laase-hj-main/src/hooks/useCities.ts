import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface City {
  id: string;
  name: string;
  slug: string;
  market_code: string;
  latitude?: number;
  longitude?: number;
  population?: number;
  is_metropolitan: boolean;
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string[];
  featured_image_url?: string;
  featured_image_alt?: string;
  is_active: boolean;
  status: 'draft' | 'published';
  wikidata_id?: string;
  wikidata_last_updated?: string;
  timezone?: string;
  administrative_level?: string;
  content?: string;
  content_last_updated?: string;
  webhook_processed?: boolean;
  created_at: string;
  updated_at: string;
  local_name?: string;
  translation_source?: 'wikidata' | 'manual' | 'ai_generated' | 'mapbox_native';
  translation_is_official?: boolean;
}

export const useCities = (marketCode?: string | null) => {
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCities = async () => {
    try {
      let query = supabase
        .from('cities')
        .select(`
          *,
          city_translations!left(local_name, language_code, market_code, source, is_official)
        `)
        .eq('is_active', true)
        .order('market_code', { ascending: true })
        .order('name', { ascending: true });

      if (marketCode && marketCode !== 'ALL') {
        query = query.eq('market_code', marketCode);
      }

      const { data, error } = await query;

      if (error) throw error;
      
      // Process cities to include local names and translation info
      const processedCities = (data || []).map(city => {
        // Find the best translation for this market
        const translations = city.city_translations || [];
        const marketTranslation = translations.find(
          (t: any) => t.market_code === city.market_code
        );
        
        return {
          ...city,
          status: city.status as 'draft' | 'published',
          local_name: marketTranslation?.local_name,
          translation_source: marketTranslation?.source as 'wikidata' | 'manual' | 'ai_generated' | 'mapbox_native' | undefined,
          translation_is_official: marketTranslation?.is_official,
          city_translations: undefined // Remove from final object
        };
      });
      
      setCities(processedCities);
    } catch (error) {
      console.error('Error fetching cities:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch cities',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getCityBySlug = async (slug: string, marketCode: string): Promise<City | null> => {
    try {
      const { data, error } = await supabase
        .from('cities')
        .select('*')
        .eq('slug', slug)
        .eq('market_code', marketCode)
        .eq('is_active', true)
        .single();

      if (error) throw error;
      return data ? { ...data, status: data.status as 'draft' | 'published' } : null;
    } catch (error) {
      console.error('Error fetching city by slug:', error);
      return null;
    }
  };

  useEffect(() => {
    fetchCities();
  }, [marketCode]);

  return {
    cities,
    loading,
    fetchCities,
    getCityBySlug,
  };
};