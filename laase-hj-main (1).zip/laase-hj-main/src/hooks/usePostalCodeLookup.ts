import { useState } from 'react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface PostalCodeData {
  postalCode: string;
  cityName: string;
  municipalityName: string;
  municipalityCode: string;
  regionName: string;
  burglariesPer1000: number;
  rankingInDenmark: number;
  riskScore: number;
  trend: 'stigende' | 'faldende' | 'stabil';
  latestQuarter: number;
  sameQuarterLastYear: number;
  changePercentage: number;
  nationalAverage: number;
  regionalAverage: number;
}

export const usePostalCodeLookup = () => {
  const [data, setData] = useState<PostalCodeData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validatePostalCode = (code: string): boolean => {
    const numericCode = parseInt(code);
    return code.length === 4 && numericCode >= 1000 && numericCode <= 9999;
  };

  const lookupPostalCode = async (postalCode: string) => {
    if (!validatePostalCode(postalCode)) {
      setError('Postnummer ikke gyldigt. Indtast et 4-cifret dansk postnummer.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Step 1: Get location data from DAWA API
      const locationResponse = await fetch(
        `https://api.dataforsyningen.dk/postnumre?nr=${postalCode}`
      );

      if (!locationResponse.ok) {
        throw new Error('Postnummer ikke fundet');
      }

      const locationData = await locationResponse.json();
      
      if (!locationData || locationData.length === 0) {
        throw new Error('Postnummer ikke fundet. Tjek venligst dit postnummer.');
      }

      const location = locationData[0];
      
      // Validate municipality data exists
      if (!location.kommuner || location.kommuner.length === 0) {
        throw new Error('Kommunedata ikke tilgængelig for dette postnummer.');
      }
      
      const municipality = location.kommuner[0];
      
      // Step 2: Get crime statistics (mock data for now - replace with actual API)
      const crimeStats = await fetchCrimeStatistics(municipality.kode);

      // Step 3: Process and format data
      const processedData: PostalCodeData = {
        postalCode: postalCode,
        cityName: location.navn,
        municipalityName: municipality.navn,
        municipalityCode: municipality.kode,
        regionName: location.region?.navn || 'Ukendt region',
        burglariesPer1000: crimeStats.burglariesPer1000,
        rankingInDenmark: crimeStats.ranking,
        riskScore: crimeStats.riskScore,
        trend: crimeStats.trend,
        latestQuarter: crimeStats.latestQuarter,
        sameQuarterLastYear: crimeStats.sameQuarterLastYear,
        changePercentage: crimeStats.changePercentage,
        nationalAverage: 4.2,
        regionalAverage: crimeStats.regionalAverage
      };

      setData(processedData);
      toast.success(`Data hentet for ${location.navn}`);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Der opstod en fejl ved opslag af postnummer';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCrimeStatistics = async (municipalityCode: string) => {
    try {
      console.log(`Calling edge function for municipality: ${municipalityCode}`);
      
      const { data, error } = await supabase.functions.invoke('fetch-burglary-stats', {
        body: { municipalityCode }
      });

      if (error) {
        console.error('Edge function error:', error);
        throw new Error(`Failed to fetch crime statistics: ${error.message}`);
      }

      console.log('Crime statistics response:', data);
      return data;
    } catch (error) {
      console.error('Error calling crime statistics API:', error);
      
      // Fallback to ensure the UI doesn't break
      return {
        burglariesPer1000: 0,
        ranking: 0,
        riskScore: 1,
        trend: 'stabil' as const,
        latestQuarter: 0,
        sameQuarterLastYear: 0,
        changePercentage: 0,
        regionalAverage: 0
      };
    }
  };

  return {
    data,
    isLoading,
    error,
    lookupPostalCode,
    validatePostalCode
  };
};