import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface LocksmithFilters {
  search: string;
  markets: string[];
  statuses: string[];
  cities: string[];
  minJobs: number | null;
  maxJobs: number | null;
  emergencyAvailable: boolean | null;
}

export interface LocksmithTableData {
  id: string;
  first_name: string | null;
  last_name: string | null;
  company_name: string | null;
  city: string | null;
  phone: string | null;
  status: string | null;
  market: string | null;
  email: string;
  completed_jobs: number;
  emergency_available: boolean | null;
  has_specializations: boolean;
  stripe_connected: boolean;
  created_at: string;
}

const defaultFilters: LocksmithFilters = {
  search: '',
  markets: [],
  statuses: [],
  cities: [],
  minJobs: null,
  maxJobs: null,
  emergencyAvailable: null
};

export const useLocksmithsTable = () => {
  const [locksmiths, setLocksmiths] = useState<LocksmithTableData[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState<LocksmithFilters>(defaultFilters);

  const itemsPerPage = 25;

  const fetchLocksmiths = useCallback(async () => {
    try {
      setLoading(true);

      // First get all user IDs with locksmith role
      const { data: locksmithRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'locksmith');

      if (rolesError) throw rolesError;

      const locksmithIds = locksmithRoles?.map(r => r.user_id) || [];

      if (locksmithIds.length === 0) {
        setLocksmiths([]);
        setTotalCount(0);
        setLoading(false);
        return;
      }

      // Build the query with filters
      let query = supabase
        .from('profiles')
        .select(`
          id,
          first_name,
          last_name,
          company_name,
          city,
          phone,
          status,
          market,
          emergency_available,
          specializations,
          created_at
        `)
        .in('id', locksmithIds);

      // Apply filters
      if (filters.search) {
        query = query.or(`company_name.ilike.%${filters.search}%,first_name.ilike.%${filters.search}%,last_name.ilike.%${filters.search}%,city.ilike.%${filters.search}%`);
      }

      if (filters.markets.length > 0) {
        query = query.in('market', filters.markets);
      }

      if (filters.statuses.length > 0) {
        query = query.in('status', filters.statuses);
      }

      if (filters.emergencyAvailable === true) {
        query = query.eq('emergency_available', true);
      } else if (filters.emergencyAvailable === false) {
        query = query.eq('emergency_available', false);
      }

      if (filters.cities.length > 0) {
        query = query.in('city', filters.cities);
      }

      // Get total count for pagination using separate query
      const countQuery = supabase
        .from('profiles')
        .select('id', { count: 'exact' })
        .in('id', locksmithIds);
      
      // Apply same filters for count
      if (filters.search) {
        countQuery.or(`company_name.ilike.%${filters.search}%,first_name.ilike.%${filters.search}%,last_name.ilike.%${filters.search}%,city.ilike.%${filters.search}%`);
      }
      if (filters.markets.length > 0) {
        countQuery.in('market', filters.markets);
      }
      if (filters.statuses.length > 0) {
        countQuery.in('status', filters.statuses);
      }
      if (filters.emergencyAvailable === true) {
        countQuery.eq('emergency_available', true);
      } else if (filters.emergencyAvailable === false) {
        countQuery.eq('emergency_available', false);
      }
      if (filters.cities.length > 0) {
        countQuery.in('city', filters.cities);
      }

      const { count } = await countQuery;
      setTotalCount(count || 0);

      // Apply pagination
      const from = (currentPage - 1) * itemsPerPage;
      const to = from + itemsPerPage - 1;
      
      const { data: profilesData, error: profilesError } = await query
        .range(from, to)
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Get additional data for each locksmith (we'll get emails through a different approach)
      const enrichedData = await Promise.all(
        (profilesData || []).map(async (locksmith) => {
          // Get completed jobs count
          const { count: jobsCount } = await supabase
            .from('bookings')
            .select('id', { count: 'exact' })
            .eq('locksmith_id', locksmith.id)
            .eq('status', 'completed');

          // Get stripe connection status
          const { data: stripeData } = await supabase
            .from('stripe_connect_accounts')
            .select('stripe_account_id')
            .eq('locksmith_id', locksmith.id)
            .maybeSingle();

          return {
            ...locksmith,
            email: locksmith.phone || 'N/A', // Show phone as primary contact
            completed_jobs: jobsCount || 0,
            has_specializations: Array.isArray(locksmith.specializations) && locksmith.specializations.length > 0,
            stripe_connected: !!stripeData?.stripe_account_id
          };
        })
      );

          // Apply job count filters after enrichment
          let filteredData = enrichedData;
          if (filters.minJobs !== null) {
            filteredData = filteredData.filter(l => l.completed_jobs >= filters.minJobs!);
          }
          if (filters.maxJobs !== null) {
            filteredData = filteredData.filter(l => l.completed_jobs <= filters.maxJobs!);
          }

      setLocksmiths(filteredData);
    } catch (error: any) {
      console.error('Error fetching locksmiths:', error);
    } finally {
      setLoading(false);
    }
  }, [currentPage, filters]);

  useEffect(() => {
    fetchLocksmiths();
  }, [fetchLocksmiths]);

  const updateFilters = (newFilters: Partial<LocksmithFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    setCurrentPage(1); // Reset to first page when filters change
  };

  const clearFilters = () => {
    setFilters(defaultFilters);
    setCurrentPage(1);
  };

  const totalPages = Math.ceil(totalCount / itemsPerPage);

  return {
    locksmiths,
    loading,
    totalCount,
    currentPage,
    totalPages,
    filters,
    setCurrentPage,
    updateFilters,
    clearFilters,
    refetch: fetchLocksmiths
  };
};