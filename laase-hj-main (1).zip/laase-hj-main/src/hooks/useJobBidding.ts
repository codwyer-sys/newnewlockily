import { useState, useEffect, useCallback, useMemo } from 'react';
import { LocksmithJob } from '@/types/locksmith';
import { useAuth } from '@/hooks/useAuth';
import { useMapBoxDistance } from '@/hooks/useMapBoxDistance';
import { usePriceSuggestion } from '@/hooks/usePriceSuggestion';
import { supabase } from '@/integrations/supabase/client';

interface UseJobBiddingOptions {
  job: LocksmithJob | null;
  chargeClientForReferral: boolean;
  customPrices: {
    basePrice?: number;
    timeSurcharge?: number;
    distanceFee?: number;
    materials?: number;
  };
  materialEnabled: boolean;
}

export const useJobBidding = (options: UseJobBiddingOptions) => {
  const { job, chargeClientForReferral, customPrices, materialEnabled } = options;
  const { user } = useAuth();
  const { calculateDistance } = useMapBoxDistance();
  
  // Simple state management - no editing functionality
  const [businessAddress, setBusinessAddress] = useState<string>('');
  const [distance, setDistance] = useState<{ km: number; duration: number } | null>(null);
  const [isLoadingAddress, setIsLoadingAddress] = useState(false);
  const [isCalculatingDistance, setIsCalculatingDistance] = useState(false);
  const [addressError, setAddressError] = useState<string | null>(null);

  // Price calculation hook with distance
  const jobForPricing = job ? { ...job, followUpAnswers: undefined } : null;
  const { 
    priceBreakdown, 
    isCalculating: isPriceCalculating, 
    hasValidConfiguration 
  } = usePriceSuggestion(
    jobForPricing, 
    distance && distance.km > 0 ? { km: distance.km } : undefined, 
    chargeClientForReferral
  );

  // Fetch business address from profile - ONLY ONCE
  useEffect(() => {
    if (!user) return;
    
    const fetchBusinessAddress = async () => {
      setIsLoadingAddress(true);
      setAddressError(null);
      
      try {
        const { data: profile, error } = await supabase
          .from('profiles')
          .select('address')
          .eq('id', user.id)
          .maybeSingle();

        if (error) {
          setAddressError('Failed to fetch business address');
          return;
        }

        const address = profile?.address || '';
        setBusinessAddress(address);
        
        // Calculate distance immediately if we have both addresses
        if (address && job?.address) {
          calculateDistanceOnce(address, job.address);
        }
      } catch (error) {
        setAddressError('Failed to fetch business address');
      } finally {
        setIsLoadingAddress(false);
      }
    };
    
    fetchBusinessAddress();
  }, [user?.id]); // Only depend on user ID

  // Calculate distance once when business address changes
  const calculateDistanceOnce = useCallback(async (fromAddress: string, toAddress: string) => {
    if (!fromAddress || !toAddress) return;
    
    setIsCalculatingDistance(true);
    
    try {
      const result = await calculateDistance(fromAddress, toAddress);
      
      if (result) {
        setDistance({ km: result.distance, duration: result.duration });
      } else {
        setDistance({ km: 0, duration: 0 });
      }
    } catch (error) {
      setDistance({ km: 0, duration: 0 });
    } finally {
      setIsCalculatingDistance(false);
    }
  }, [calculateDistance]);

  // Calculate distance when job address is available and we have business address
  useEffect(() => {
    if (businessAddress && job?.address && !distance) {
      calculateDistanceOnce(businessAddress, job.address);
    }
  }, [businessAddress, job?.address, distance, calculateDistanceOnce]);


  // Calculate final prices with memoization
  const finalPrices = useMemo(() => {
    if (!priceBreakdown) return null;
    
    return {
      basePrice: customPrices.basePrice ?? priceBreakdown.basePrice,
      timeSurcharge: customPrices.timeSurcharge ?? priceBreakdown.timeSurcharge.amount,
      distanceFee: customPrices.distanceFee ?? priceBreakdown.distanceFee,
      materials: materialEnabled ? (customPrices.materials ?? 0) : 0,
      get referralFeeAmount() {
        const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
        return priceBreakdown.referralFee ? (subtotal * priceBreakdown.referralFee.percentage) / 100 : 0;
      },
      get total() {
        const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
        return chargeClientForReferral && priceBreakdown.referralFee 
          ? subtotal + this.referralFeeAmount 
          : subtotal;
      },
      get locksmithEarnings() {
        const subtotal = this.basePrice + this.timeSurcharge + this.distanceFee + this.materials;
        return chargeClientForReferral 
          ? this.total 
          : (priceBreakdown.referralFee ? subtotal - this.referralFeeAmount : subtotal);
      }
    };
  }, [priceBreakdown, customPrices, materialEnabled, chargeClientForReferral]);

  return {
    // Address state - simplified
    address: businessAddress,
    isLoadingAddress,
    addressError,
    
    // Distance state
    distance: distance || { km: 0, duration: 0 },
    isCalculatingDistance,
    
    // Price state
    priceBreakdown,
    finalPrices,
    isCalculatingPrice: isPriceCalculating,
    hasValidConfiguration,
  };
};