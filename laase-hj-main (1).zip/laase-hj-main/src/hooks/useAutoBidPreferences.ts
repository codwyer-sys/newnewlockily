import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { fetchFilteredJobCategories } from '@/utils/categoryUtils';

export interface AutoBidPreference {
  id: string;
  locksmith_id: string;
  job_category_id: string;
  is_enabled: boolean;
  base_price: number | null;
  excluded_follow_up_answers: any[];
  created_at: string;
  updated_at: string;
}

export interface GlobalPricingSettings {
  id: string;
  locksmith_id: string;
  nighttime_fee_type: 'percentage' | 'fixed';
  nighttime_fee_amount: number;
  weekend_fee_type: 'percentage' | 'fixed';
  weekend_fee_amount: number;
  nighttime_start_hour: number;
  nighttime_end_hour: number;
  combine_nighttime_weekend_fees: boolean;
  base_radius_km: number;
  fee_per_km_above_radius: number;
  created_at: string;
  updated_at: string;
}

export interface FollowUpQuestionPricing {
  id: string;
  locksmith_id: string;
  job_category_id: string;
  follow_up_question_id: string;
  answer_value: string;
  fee_type: 'percentage' | 'fixed';
  fee_amount: number;
}

export interface FollowUpQuestionWithExclusions {
  id: string;
  question: string;
  question_type: string;
  options: any;
  excluded_answers: string[];
  pricing: FollowUpQuestionPricing[];
}

export interface JobCategoryWithPreference {
  id: string;
  name: string;
  description: string | null;
  emoji: string | null;
  is_enabled: boolean;
  base_price: number | null;
  follow_up_questions: FollowUpQuestionWithExclusions[];
}

export const useAutoBidPreferences = () => {
  const { user } = useAuth();
  const [categories, setCategories] = useState<JobCategoryWithPreference[]>([]);
  const [globalSettings, setGlobalSettings] = useState<GlobalPricingSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchCategoriesWithPreferences = async () => {
    if (!user?.id) {
      console.log('🔧 useAutoBidPreferences - No user ID, skipping fetch');
      return;
    }

    console.log('🔧 useAutoBidPreferences - Starting fetch for user:', user.id);

    try {
      // Fetch filtered job categories using shared utility
      console.log('🔧 useAutoBidPreferences - Fetching job categories...');
      const jobCategories = await fetchFilteredJobCategories();
      console.log('🔧 useAutoBidPreferences - Job categories fetched:', jobCategories.length);

      // Fetch existing preferences for this locksmith
      console.log('🔧 useAutoBidPreferences - Fetching preferences...');
      const { data: preferences, error: preferencesError } = await supabase
        .from('locksmith_auto_bid_preferences')
        .select('*')
        .eq('locksmith_id', user.id);

      if (preferencesError) {
        console.error('🔧 useAutoBidPreferences - Preferences error:', preferencesError);
        throw preferencesError;
      }
      console.log('🔧 useAutoBidPreferences - Preferences fetched:', preferences?.length || 0);

      // Fetch global pricing settings
      console.log('🔧 useAutoBidPreferences - Fetching global settings...');
      const { data: globalPricing, error: globalError } = await supabase
        .from('global_pricing_settings')
        .select('*')
        .eq('locksmith_id', user.id)
        .maybeSingle();

      if (globalError) {
        console.error('🔧 useAutoBidPreferences - Global settings error:', globalError);
        throw globalError;
      }
      console.log('🔧 useAutoBidPreferences - Global settings:', globalPricing ? 'found' : 'not found');
      setGlobalSettings(globalPricing as GlobalPricingSettings | null);

      // Fetch follow-up question pricing
      const { data: questionPricing, error: pricingError } = await supabase
        .from('follow_up_question_pricing')
        .select('*')
        .eq('locksmith_id', user.id);

      if (pricingError) throw pricingError;

      // Fetch follow-up questions for each category
      const categoriesWithPreferences: JobCategoryWithPreference[] = await Promise.all(
        jobCategories.map(async (category) => {
          const preference = preferences?.find(p => p.job_category_id === category.id);
          
          // Fetch follow-up questions for this category
          const { data: followUpQuestions, error: questionsError } = await supabase
            .from('follow_up_questions')
            .select('id, question, question_type, options')
            .eq('job_category_id', category.id)
            .order('order_index');

          if (questionsError) {
            console.error('Error fetching follow-up questions:', questionsError);
          }

          // Fetch exclusions for this category
          const { data: exclusions, error: exclusionsError } = await supabase
            .from('auto_bid_exclusions')
            .select('*')
            .eq('locksmith_id', user.id)
            .eq('job_category_id', category.id);

          if (exclusionsError) {
            console.error('Error fetching exclusions:', exclusionsError);
          }

          const questionsWithExclusions: FollowUpQuestionWithExclusions[] = (followUpQuestions || []).map(question => {
            const exclusion = exclusions?.find(e => e.follow_up_question_id === question.id);
            const pricing = questionPricing?.filter(p => 
              p.job_category_id === category.id && p.follow_up_question_id === question.id
            ) || [];

            return {
              id: question.id,
              question: question.question,
              question_type: question.question_type,
              options: question.options,
              excluded_answers: exclusion?.excluded_answer_values || [],
              pricing: pricing as FollowUpQuestionPricing[]
            };
          });

          return {
            id: category.id,
            name: category.name,
            description: category.description,
            emoji: category.emoji,
            is_enabled: preference?.is_enabled || false,
            base_price: preference?.base_price || null,
            follow_up_questions: questionsWithExclusions
          };
        })
      );

      console.log('🔧 useAutoBidPreferences - Final categories:', categoriesWithPreferences.map(c => ({
        name: c.name,
        id: c.id,
        enabled: c.is_enabled,
        basePrice: c.base_price,
        questionsCount: c.follow_up_questions.length
      })));

      setCategories(categoriesWithPreferences);
    } catch (error) {
      console.error('🔧 useAutoBidPreferences - Fetch failed:', error);
      toast.error('Failed to load auto-bid preferences');
    } finally {
      setIsLoading(false);
    }
  };

  const updateGlobalSettings = async (settings: Partial<GlobalPricingSettings>) => {
    if (!user?.id) return false;

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('global_pricing_settings')
        .upsert({
          locksmith_id: user.id,
          ...settings
        }, {
          onConflict: 'locksmith_id'
        });

      if (error) throw error;

      // Update local state
      setGlobalSettings(prev => prev ? { ...prev, ...settings } : null);
      toast.success('Globale indstillinger opdateret');
      return true;
    } catch (error) {
      console.error('Error updating global settings:', error);
      toast.error('Failed to update global settings');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const toggleCategoryPreference = async (categoryId: string, isEnabled: boolean) => {
    if (!user?.id) return false;

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('locksmith_auto_bid_preferences')
        .upsert({
          locksmith_id: user.id,
          job_category_id: categoryId,
          is_enabled: isEnabled
        }, {
          onConflict: 'locksmith_id,job_category_id'
        });

      if (error) throw error;

      // Update local state
      setCategories(prev => 
        prev.map(cat => 
          cat.id === categoryId 
            ? { ...cat, is_enabled: isEnabled }
            : cat
        )
      );

      toast.success(
        isEnabled 
          ? 'Auto-bud aktiveret for denne kategori'
          : 'Auto-bud deaktiveret for denne kategori'
      );
      
      return true;
    } catch (error) {
      console.error('Error updating auto-bid preference:', error);
      toast.error('Failed to update auto-bid preference');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const updateCategoryPrice = async (categoryId: string, price: number) => {
    if (!user?.id) return false;

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('locksmith_auto_bid_preferences')
        .upsert({
          locksmith_id: user.id,
          job_category_id: categoryId,
          base_price: price
        }, {
          onConflict: 'locksmith_id,job_category_id'
        });

      if (error) throw error;

      // Update local state
      setCategories(prev => 
        prev.map(cat => 
          cat.id === categoryId 
            ? { ...cat, base_price: price }
            : cat
        )
      );

      toast.success('Pris opdateret');
      return true;
    } catch (error) {
      console.error('Error updating price:', error);
      toast.error('Failed to update price');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const updateQuestionPricing = async (
    categoryId: string, 
    questionId: string, 
    answerValue: string, 
    feeType: 'percentage' | 'fixed', 
    feeAmount: number
  ) => {
    if (!user?.id) return false;

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('follow_up_question_pricing')
        .upsert({
          locksmith_id: user.id,
          job_category_id: categoryId,
          follow_up_question_id: questionId,
          answer_value: answerValue,
          fee_type: feeType,
          fee_amount: feeAmount
        }, {
          onConflict: 'locksmith_id,job_category_id,follow_up_question_id,answer_value'
        });

      if (error) throw error;

      // Update local state
      setCategories(prev => 
        prev.map(cat => 
          cat.id === categoryId 
            ? {
                ...cat,
                follow_up_questions: cat.follow_up_questions.map(q => 
                  q.id === questionId
                    ? {
                        ...q,
                        pricing: [
                          ...q.pricing.filter(p => p.answer_value !== answerValue),
                          {
                            id: '',
                            locksmith_id: user.id,
                            job_category_id: categoryId,
                            follow_up_question_id: questionId,
                            answer_value: answerValue,
                            fee_type: feeType,
                            fee_amount: feeAmount
                          }
                        ]
                      }
                    : q
                )
              }
            : cat
        )
      );

      toast.success('Prisindstilling opdateret');
      return true;
    } catch (error) {
      console.error('Error updating question pricing:', error);
      toast.error('Failed to update question pricing');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const toggleQuestionExclusion = async (categoryId: string, questionId: string, answerValue: string, isExcluded: boolean) => {
    if (!user?.id) return false;

    setIsUpdating(true);
    try {
      if (isExcluded) {
        // Add exclusion
        const { data: existing } = await supabase
          .from('auto_bid_exclusions')
          .select('excluded_answer_values')
          .eq('locksmith_id', user.id)
          .eq('job_category_id', categoryId)
          .eq('follow_up_question_id', questionId)
          .maybeSingle();

        const currentExclusions = existing?.excluded_answer_values || [];
        const newExclusions = [...currentExclusions, answerValue];

        const { error } = await supabase
          .from('auto_bid_exclusions')
          .upsert({
            locksmith_id: user.id,
            job_category_id: categoryId,
            follow_up_question_id: questionId,
            excluded_answer_values: newExclusions
          }, {
            onConflict: 'locksmith_id,job_category_id,follow_up_question_id'
          });

        if (error) throw error;
      } else {
        // Remove exclusion
        const { data: existing } = await supabase
          .from('auto_bid_exclusions')
          .select('excluded_answer_values')
          .eq('locksmith_id', user.id)
          .eq('job_category_id', categoryId)
          .eq('follow_up_question_id', questionId)
          .maybeSingle();

        if (existing) {
          const newExclusions = existing.excluded_answer_values.filter((val: string) => val !== answerValue);
          
          if (newExclusions.length === 0) {
            // Delete the record if no exclusions left
            await supabase
              .from('auto_bid_exclusions')
              .delete()
              .eq('locksmith_id', user.id)
              .eq('job_category_id', categoryId)
              .eq('follow_up_question_id', questionId);
          } else {
            // Update with remaining exclusions
            await supabase
              .from('auto_bid_exclusions')
              .update({ excluded_answer_values: newExclusions })
              .eq('locksmith_id', user.id)
              .eq('job_category_id', categoryId)
              .eq('follow_up_question_id', questionId);
          }
        }
      }

      // Update local state
      setCategories(prev => 
        prev.map(cat => 
          cat.id === categoryId 
            ? {
                ...cat,
                follow_up_questions: cat.follow_up_questions.map(q => 
                  q.id === questionId
                    ? {
                        ...q,
                        excluded_answers: isExcluded 
                          ? [...q.excluded_answers, answerValue]
                          : q.excluded_answers.filter(val => val !== answerValue)
                      }
                    : q
                )
              }
            : cat
        )
      );

      toast.success(isExcluded ? 'Eksklusion tilføjet' : 'Eksklusion fjernet');
      return true;
    } catch (error) {
      console.error('Error updating exclusion:', error);
      toast.error('Failed to update exclusion');
      return false;
    } finally {
      setIsUpdating(false);
    }
  };

  const getEnabledCategoriesCount = () => {
    return categories.filter(cat => cat.is_enabled).length;
  };

  useEffect(() => {
    fetchCategoriesWithPreferences();
  }, [user?.id]);

  return {
    categories,
    globalSettings,
    isLoading,
    isUpdating,
    toggleCategoryPreference,
    updateCategoryPrice,
    updateGlobalSettings,
    updateQuestionPricing,
    toggleQuestionExclusion,
    getEnabledCategoriesCount,
    refetch: fetchCategoriesWithPreferences,
  };
};