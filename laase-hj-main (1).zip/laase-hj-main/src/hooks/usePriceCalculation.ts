import { useMemo } from 'react';
import { PriceCalculator, PriceCalculationInput, PriceBreakdown } from '@/utils/priceCalculator';
import { usePricingData } from '@/contexts/PricingDataContext';
import { LocksmithJob } from '@/types/locksmith';

interface UsePriceCalculationProps {
  job: LocksmithJob;
  distance?: { km: number };
  chargeClientForReferral?: boolean;
}

interface UsePriceCalculationResult {
  priceBreakdown: PriceBreakdown | null;
  isCalculating: boolean;
  error: string | null;
  hasValidConfiguration: boolean;
}

export const usePriceCalculation = ({
  job,
  distance,
  chargeClientForReferral = false
}: UsePriceCalculationProps): UsePriceCalculationResult => {
  const { categories, globalSettings, referralFeePercentage, isLoading, error: dataError } = usePricingData();

  const result = useMemo(() => {
    // Return loading state
    if (isLoading) {
      return {
        priceBreakdown: null,
        isCalculating: true,
        error: null,
        hasValidConfiguration: false
      };
    }

    // Return data error
    if (dataError) {
      return {
        priceBreakdown: null,
        isCalculating: false,
        error: dataError,
        hasValidConfiguration: false
      };
    }

    // Check if job category exists
    if (!job?.categoryId) {
      return {
        priceBreakdown: null,
        isCalculating: false,
        error: 'Ingen job kategori specificeret',
        hasValidConfiguration: false
      };
    }

    // Find category configuration
    const categoryConfig = categories.find(cat => cat.id === job.categoryId);
    
    if (!categoryConfig) {
      return {
        priceBreakdown: null,
        isCalculating: false,
        error: 'Ingen AutoByd indstillinger fundet for denne kategori',
        hasValidConfiguration: false
      };
    }

    if (!categoryConfig.is_enabled) {
      return {
        priceBreakdown: null,
        isCalculating: false,
        error: 'AutoByd er ikke aktiveret for denne kategori',
        hasValidConfiguration: false
      };
    }

    if (!categoryConfig.base_price) {
      return {
        priceBreakdown: null,
        isCalculating: false,
        error: 'Ingen grundpris sat for denne kategori',
        hasValidConfiguration: false
      };
    }

    // Calculate price
    try {
      // Transform category config to match expected interface
      const transformedConfig = {
        ...categoryConfig,
        description: null,
        emoji: null,
        follow_up_questions: categoryConfig.follow_up_questions.map(q => ({
          id: q.id,
          question: q.question,
          question_type: 'single_choice',
          options: [],
          excluded_answers: [],
          pricing: q.pricing.map(p => ({
            id: `${q.id}-${p.answer_value}`,
            locksmith_id: '',
            job_category_id: categoryConfig.id,
            follow_up_question_id: q.id,
            answer_value: p.answer_value,
            fee_type: p.fee_type,
            fee_amount: p.fee_amount
          }))
        }))
      };

      // Transform global settings to match expected interface
      const transformedGlobalSettings = globalSettings ? {
        ...globalSettings,
        id: '',
        locksmith_id: '',
        created_at: '',
        updated_at: ''
      } : null;

      const calculator = new PriceCalculator(transformedConfig, transformedGlobalSettings, referralFeePercentage);
      
      const input: PriceCalculationInput = {
        jobCategory: job.categoryId,
        urgency: job.urgency,
        followUpAnswers: job.followUpAnswers,
        timeRequested: job.timeRequested,
        distance: distance?.km,
        chargeClientForReferral
      };

      const breakdown = calculator.calculate(input);

      return {
        priceBreakdown: breakdown,
        isCalculating: false,
        error: null,
        hasValidConfiguration: true
      };
    } catch (err) {
      console.error('Price calculation failed:', err);
      return {
        priceBreakdown: null,
        isCalculating: false,
        error: 'Fejl ved prisberegning',
        hasValidConfiguration: false
      };
    }
  }, [
    job?.categoryId,
    job?.urgency,
    job?.followUpAnswers,
    job?.timeRequested,
    distance?.km,
    chargeClientForReferral,
    categories,
    globalSettings,
    referralFeePercentage,
    isLoading,
    dataError
  ]);

  return result;
};