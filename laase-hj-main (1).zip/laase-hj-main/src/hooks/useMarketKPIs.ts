import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface MarketKPIs {
  totalLocksmiths: number;
  activeLocksmiths: number;
  onboardingLocksmiths: number;
  totalCities: number;
  activeCities: number;
  loading: boolean;
}

export const useMarketKPIs = (marketCode: string | null) => {
  const [kpis, setKpis] = useState<MarketKPIs>({
    totalLocksmiths: 0,
    activeLocksmiths: 0,
    onboardingLocksmiths: 0,
    totalCities: 0,
    activeCities: 0,
    loading: true,
  });

  useEffect(() => {
    const fetchKPIs = async () => {
      setKpis(prev => ({ ...prev, loading: true }));
      
      try {
        // Fetch locksmith statistics
        const { data: locksmithRoles } = await supabase
          .from('user_roles')
          .select('user_id')
          .eq('role', 'locksmith');

        if (!locksmithRoles) return;

        const locksmithIds = locksmithRoles.map(role => role.user_id);
        
        let locksmithQuery = supabase
          .from('profiles')
          .select('status, market')
          .in('id', locksmithIds);

        if (marketCode && marketCode !== 'ALL') {
          locksmithQuery = locksmithQuery.eq('market', marketCode);
        }

        const { data: locksmiths } = await locksmithQuery;

        // Fetch cities statistics
        let citiesQuery = supabase
          .from('cities')
          .select('is_active, market_code');

        if (marketCode && marketCode !== 'ALL') {
          citiesQuery = citiesQuery.eq('market_code', marketCode);
        }

        const { data: cities } = await citiesQuery;

        // Calculate locksmith KPIs
        const totalLocksmiths = locksmiths?.length || 0;
        const activeLocksmiths = locksmiths?.filter(l => l.status === 'approved').length || 0;
        const onboardingLocksmiths = locksmiths?.filter(l => l.status === 'pending').length || 0;

        // Calculate cities KPIs
        const totalCities = cities?.length || 0;
        const activeCities = cities?.filter(c => c.is_active).length || 0;

        setKpis({
          totalLocksmiths,
          activeLocksmiths,
          onboardingLocksmiths,
          totalCities,
          activeCities,
          loading: false,
        });
      } catch (error) {
        console.error('Error fetching market KPIs:', error);
        setKpis(prev => ({ ...prev, loading: false }));
      }
    };

    fetchKPIs();
  }, [marketCode]);

  return kpis;
};