import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Area {
  id: string;
  name: string;
  slug: string;
  city_id: string;
  latitude?: number;
  longitude?: number;
  postal_codes?: string[];
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string[];
  featured_image_url?: string;
  featured_image_alt?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useAreas = (cityId?: string) => {
  const [areas, setAreas] = useState<Area[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchAreas = async () => {
    try {
      let query = supabase
        .from('areas')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (cityId) {
        query = query.eq('city_id', cityId);
      }

      const { data, error } = await query;

      if (error) throw error;
      setAreas(data || []);
    } catch (error) {
      console.error('Error fetching areas:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch areas',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getAreaBySlug = async (slug: string, cityId: string): Promise<Area | null> => {
    try {
      const { data, error } = await supabase
        .from('areas')
        .select('*')
        .eq('slug', slug)
        .eq('city_id', cityId)
        .eq('is_active', true)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching area by slug:', error);
      return null;
    }
  };

  useEffect(() => {
    if (cityId) {
      fetchAreas();
    }
  }, [cityId]);

  return {
    areas,
    loading,
    fetchAreas,
    getAreaBySlug,
  };
};