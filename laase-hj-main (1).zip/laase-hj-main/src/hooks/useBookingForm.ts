
import { useState, useEffect } from 'react';
import { supabase } from "@/integrations/supabase/client";

export const useBookingForm = () => {
  const [address, setAddress] = useState("");
  const [skipAddressSearch, setSkipAddressSearch] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [hasSelectedSuggestion, setHasSelectedSuggestion] = useState(false);
  const [urgency, setUrgency] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [jobType, setJobType] = useState<string | { selection: string; details: string }>("");
  const [followUpAnswers, setFollowUpAnswers] = useState<Record<string, any>>({});
  const [showUrgency, setShowUrgency] = useState(false);
  const [showJobType, setShowJobType] = useState(false);
  const [showFollowUp, setShowFollowUp] = useState(false);

  // Show urgency when address is filled
  useEffect(() => {
    if (address.trim() && !showUrgency) {
      setShowUrgency(true);
    } else if (!address.trim() && showUrgency) {
      setShowUrgency(false);
      setUrgency("");
      setSelectedDate("");
      setJobType("");
      setFollowUpAnswers({});
      setShowJobType(false);
      setShowFollowUp(false);
    }
  }, [address, showUrgency]);

  // Show job type when urgency is selected
  useEffect(() => {
    if (urgency && (urgency === "nu" || urgency === "asap" || ((urgency === "senere" || urgency === "scheduled") && selectedDate))) {
      setShowJobType(true);
    } else {
      setShowJobType(false);
      setJobType("");
      setFollowUpAnswers({});
      setShowFollowUp(false);
    }
  }, [urgency, selectedDate]);

  // Show follow up when job type is selected
  useEffect(() => {
    const hasJobType = typeof jobType === 'string' ? jobType !== '' : jobType.selection !== '';
    if (hasJobType) {
      setShowFollowUp(true);
    } else {
      setShowFollowUp(false);
      setFollowUpAnswers({});
    }
  }, [jobType]);

  const getRequiredQuestionsForJobType = async (type: string): Promise<string[]> => {
    try {
      const { data, error } = await supabase
        .from('follow_up_questions')
        .select('question_key')
        .or(`job_category_id.eq.${type},is_global.eq.true`)
        .eq('is_required', true);
      
      if (error) {
        console.error('Error fetching required questions:', error);
        return [];
      }
      
      return data?.map(q => q.question_key) || [];
    } catch (error) {
      console.error('Error fetching required questions:', error);
      return [];
    }
  };

  return {
    // State
    address,
    setAddress,
    skipAddressSearch,
    setSkipAddressSearch,
    showSuggestions,
    setShowSuggestions,
    hasSelectedSuggestion,
    setHasSelectedSuggestion,
    urgency,
    setUrgency,
    selectedDate,
    setSelectedDate,
    jobType,
    setJobType,
    followUpAnswers,
    setFollowUpAnswers,
    showUrgency,
    showJobType,
    showFollowUp,
    // Helpers
    getRequiredQuestionsForJobType
  };
};
