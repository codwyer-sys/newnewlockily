import { useState, useCallback, useMemo } from 'react';

interface EnglishTranslation {
  id: string;
  content_key: string;
  content_value: string;
  ai_instruction: string | null;
  section_name: string;
  page_name: string;
  missing_count: number;
  missing_markets: string[];
}

export interface TranslationFilters {
  page: string;
  section: string;
  status: 'all' | 'missing' | 'complete' | 'changed';
  search: string;
}

export const useTranslationSelection = (translations: EnglishTranslation[] = [], originalTranslations: Record<string, any> = {}) => {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState<TranslationFilters>({
    page: '',
    section: '',
    status: 'all',
    search: ''
  });

  const hasContentChanged = useCallback((item: EnglishTranslation) => {
    if (!item || !originalTranslations) return false;
    const original = originalTranslations[item.id];
    if (!original) return false;
    
    return (
      original.content_value !== item.content_value ||
      original.ai_instruction !== item.ai_instruction
    );
  }, [originalTranslations]);

  const filteredTranslations = useMemo(() => {
    if (!Array.isArray(translations) || translations.length === 0) return [];
    
    try {
      return translations.filter(item => {
        if (!item) return false;
        
        // Page filter
        if (filters.page && item.page_name !== filters.page) return false;
        
        // Section filter
        if (filters.section && item.section_name !== filters.section) return false;
        
        // Status filter
        if (filters.status === 'missing' && item.missing_count === 0) return false;
        if (filters.status === 'complete' && item.missing_count > 0) return false;
        if (filters.status === 'changed' && !hasContentChanged(item)) return false;
        
        // Search filter
        if (filters.search) {
          const searchLower = filters.search.toLowerCase();
          return (
            (item.content_key || '').toLowerCase().includes(searchLower) ||
            (item.content_value || '').toLowerCase().includes(searchLower) ||
            (item.page_name || '').toLowerCase().includes(searchLower) ||
            (item.section_name || '').toLowerCase().includes(searchLower)
          );
        }
        
        return true;
      });
    } catch (error) {
      console.error('Error filtering translations:', error);
      return [];
    }
  }, [translations, filters, hasContentChanged]);

  const selectedTranslations = useMemo(() => {
    return filteredTranslations.filter(item => selectedIds.has(item.id));
  }, [filteredTranslations, selectedIds]);

  const pages = useMemo(() => {
    if (!Array.isArray(translations)) return [];
    try {
      return [...new Set(translations.filter(t => t?.page_name).map(t => t.page_name))].sort();
    } catch (error) {
      console.error('Error computing pages:', error);
      return [];
    }
  }, [translations]);

  const sections = useMemo(() => {
    if (!filters.page || !Array.isArray(translations)) return [];
    try {
      return [...new Set(translations.filter(t => t?.page_name === filters.page && t?.section_name).map(t => t.section_name))].sort();
    } catch (error) {
      console.error('Error computing sections:', error);
      return [];
    }
  }, [translations, filters.page]);

  const toggleSelection = useCallback((id: string) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  }, []);

  const selectAll = useCallback(() => {
    setSelectedIds(new Set(filteredTranslations.map(t => t.id)));
  }, [filteredTranslations]);

  const clearSelection = useCallback(() => {
    setSelectedIds(new Set());
  }, []);

  const invertSelection = useCallback(() => {
    setSelectedIds(prev => {
      const newSet = new Set<string>();
      filteredTranslations.forEach(t => {
        if (!prev.has(t.id)) {
          newSet.add(t.id);
        }
      });
      return newSet;
    });
  }, [filteredTranslations]);

  const isAllSelected = useMemo(() => {
    return filteredTranslations.length > 0 && filteredTranslations.every(t => selectedIds.has(t.id));
  }, [filteredTranslations, selectedIds]);

  const isPartiallySelected = useMemo(() => {
    return selectedIds.size > 0 && !isAllSelected;
  }, [selectedIds, isAllSelected]);

  return {
    selectedIds,
    selectedTranslations,
    filteredTranslations,
    filters,
    setFilters,
    pages,
    sections,
    toggleSelection,
    selectAll,
    clearSelection,
    invertSelection,
    isAllSelected,
    isPartiallySelected,
    hasContentChanged
  };
};