import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMarket } from '@/contexts/MarketContext';
import { useLanguage } from '@/contexts/LanguageContext';

export const useBookingStatusTranslations = () => {
  const { market } = useMarket();
  const { language } = useLanguage();
  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  // Fetch translations from database
  useEffect(() => {
    const fetchTranslations = async () => {
      try {
        const { data, error } = await supabase
          .from('content_translations')
          .select(`
            content_key,
            content_value,
            content_sections!inner(
              section_key,
              content_pages!inner(page_key)
            )
          `)
          .eq('content_sections.content_pages.page_key', 'booking_status')
          .eq('language_code', language)
          .or(`market_code.is.null,market_code.eq.${market.country_code}`);

        if (error) {
          console.error('Error fetching booking status translations:', error);
          return;
        }

        const translationMap: Record<string, string> = {};
        data?.forEach((item) => {
          const sectionKey = item.content_sections.section_key;
          const key = `${sectionKey}.${item.content_key}`;
          translationMap[key] = item.content_value;
        });

        setTranslations(translationMap);
      } catch (error) {
        console.error('Error fetching translations:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTranslations();
  }, [language, market.country_code]);

  // Helper function to get translation with fallback
  const t = (key: string, section: string, variables?: Record<string, string | number>, fallback?: string) => {
    // Always provide fallbacks to prevent blank page
    const defaultFallbacks: Record<string, string> = {
      'job_stages.stage_waiting_for_quotes_title': 'Waiting for Quotes',
      'hero_section.searching_locksmiths_message': 'Searching for locksmiths...',
      'booking_details.booking_details_title': 'Booking Details',
      'quotes_section.waiting_for_quotes_title': 'Finding Locksmiths',
      'quotes_section.finding_locksmiths_description': 'We are finding available locksmiths in your area.',
      'quotes_section.quotes_received_title': 'quotes received',
      'quotes_section.sort_by_price': 'Sort by Price',
      'quotes_section.sort_by_distance': 'Sort by Distance', 
      'quotes_section.sort_by_rating': 'Sort by Rating',
      'quotes_section.total_price_label': 'Total price',
      'quotes_section.arrives_in_label': 'Arrives in',
      'quotes_section.km_away_label': 'km away',
      'quotes_section.reviews_label': 'reviews',
      'quotes_section.accept_quote_button': 'Accept Quote',
      'quotes_section.quote_accepted_label': 'Quote Accepted',
      'actions.back_to_home_button': 'Back to Home',
      'actions.call_us_button': 'Call Us: 70 20 30 40'
    };

    const fullKey = `${section}.${key}`;
    let translation = translations[fullKey] || fallback || defaultFallbacks[fullKey] || key;
    
    // Handle variables and pluralization
    if (variables && translation !== key) {
      Object.entries(variables).forEach(([varKey, value]) => {
        if (varKey === 'count' && typeof value === 'number') {
          // Handle pluralization for count
          const plural = value === 1 ? '' : 's';
          translation = translation.replace('{plural}', plural);
          translation = translation.replace(`{${varKey}}`, value.toString());
        } else {
          translation = translation.replace(`{${varKey}}`, value.toString());
        }
      });
    }
    
    return translation;
  };

  return {
    loading,
    
    // Job stage translations
    jobStages: {
      getTitle: (stage: string) => t(`stage_${stage}_title`, 'job_stages'),
      getDescription: (stage: string) => t(`stage_${stage}_description`, 'job_stages'),
      getBadgeText: (stage: string) => t(`stage_${stage}_badge`, 'job_stages'),
    },

    // Hero section translations
    hero: {
      searchingLocksmiths: () => t('searching_locksmiths_message', 'hero_section'),
      quotesCount: (count: number) => t('quotes_count_message', 'hero_section', { count }),
      locksmithsReady: (count: number) => t('locksmiths_ready_message', 'hero_section', { count }),
      waitingConfirmation: () => t('waiting_confirmation_message', 'hero_section'),
      locksmithOnWay: () => t('locksmith_on_way_hero_message', 'hero_section'),
      workInProgress: () => t('work_in_progress_hero_message', 'hero_section'),
      serviceCompleted: () => t('service_completed_hero_message', 'hero_section'),
      processingRequest: () => t('processing_request_message', 'hero_section'),
    },

    // Booking details translations
    bookingDetails: {
      title: () => t('booking_details_title', 'booking_details'),
      addressLabel: () => t('address_label', 'booking_details'),
      urgencyLabel: () => t('urgency_label', 'booking_details'),
      urgencyNow: () => t('urgency_now', 'booking_details'),
      urgencyCanWait: () => t('urgency_can_wait', 'booking_details'),
      jobTypeLabel: () => t('job_type_label', 'booking_details'),
      createdAtLabel: () => t('created_at_label', 'booking_details'),
    },

    // Quotes section translations
    quotes: {
      waitingTitle: () => t('waiting_for_quotes_title', 'quotes_section'),
      receivedTitle: (count: number) => {
        if (count === 0) return t('waiting_for_quotes_title', 'quotes_section');
        const base = t('quotes_received_title', 'quotes_section');
        return `${count} ${base}`;
      },
      sortByPrice: () => t('sort_by_price', 'quotes_section'),
      sortByDistance: () => t('sort_by_distance', 'quotes_section'),
      sortByRating: () => t('sort_by_rating', 'quotes_section'),
      findingTitle: () => t('finding_locksmiths_title', 'quotes_section'),
      findingDescription: () => t('finding_locksmiths_description', 'quotes_section'),
      totalPriceLabel: () => t('total_price_label', 'quotes_section'),
      arrivesInLabel: () => t('arrives_in_label', 'quotes_section'),
      kmAwayLabel: () => t('km_away_label', 'quotes_section'),
      reviewsLabel: () => t('reviews_label', 'quotes_section'),
      acceptQuoteButton: (price: number) => `${t('accept_quote_button', 'quotes_section')} - ${price} kr`,
      quoteAcceptedLabel: () => t('quote_accepted_label', 'quotes_section'),
    },

    // Locksmith profile translations
    locksmithProfile: {
      professionalFallback: () => t('professional_locksmith_fallback', 'locksmith_profile'),
      arrivalLabel: () => t('arrival_label', 'locksmith_profile'),
      distanceLabel: () => t('distance_label', 'locksmith_profile'),
      ratingLabel: () => t('rating_label', 'locksmith_profile'),
      callButton: () => t('call_locksmith_button', 'locksmith_profile'),
      messageButton: () => t('send_message_button', 'locksmith_profile'),
      confirmedMessage: () => t('locksmith_confirmed_message', 'locksmith_profile'),
    },

    // ETA circle translations
    etaCircle: {
      etaLabel: () => t('eta_label', 'eta_circle'),
      almostThere: () => t('almost_there_message', 'eta_circle'),
      quotesReceived: (count: number) => t('quotes_received_message', 'eta_circle', { count }),
      confirmingAvailability: () => t('confirming_availability_message', 'eta_circle'),
      locksmithOnWay: () => t('locksmith_on_way_message', 'eta_circle'),
      workInProgress: () => t('work_in_progress_message', 'eta_circle'),
      processing: () => t('processing_message', 'eta_circle'),
    },

    // Action buttons translations
    actions: {
      backToHome: () => t('back_to_home_button', 'actions'),
      callUs: () => t('call_us_button', 'actions'),
    },

    // Loading states translations
    loadingStates: {
      loadingBooking: () => t('loading_booking_message', 'loading_states'),
      errorTitle: () => t('error_title', 'loading_states'),
      bookingNotFound: () => t('booking_not_found_message', 'loading_states'),
      returnHome: () => t('return_home_button', 'loading_states'),
    },
  };
};