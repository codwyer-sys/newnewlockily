import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface TestResult {
  success: boolean;
  responseTime: number;
  statusCode: number;
  response: any;
  error?: string;
  timestamp: Date;
}

interface TestRequest {
  webhook: string;
  payload: any;
}

export const useWebhookTesting = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<Record<string, TestResult>>({});

  const testWebhook = async (webhookId: string, payload: any): Promise<TestResult> => {
    setIsLoading(true);
    const startTime = Date.now();
    
    try {
      // Map webhook IDs to actual function names
      const functionNameMap: Record<string, string> = {
        'validate-address': 'validate-address',
        'get-job-categories': 'get-job-categories', 
        'get-follow-up-questions': 'get-follow-up-questions',
        'get-available-times': 'get-available-times',
        'create-booking-from-call': 'create-booking-from-call'
      };

      const functionName = functionNameMap[webhookId] || webhookId;
      
      const { data, error } = await supabase.functions.invoke(functionName, {
        body: payload
      });

      const responseTime = Date.now() - startTime;
      
      const result: TestResult = {
        success: !error,
        responseTime,
        statusCode: error ? (error.status || 500) : 200,
        response: data || error,
        error: error?.message,
        timestamp: new Date()
      };

      setResults(prev => ({
        ...prev,
        [webhookId]: result
      }));

      return result;
    } catch (err) {
      const result: TestResult = {
        success: false,
        responseTime: Date.now() - startTime,
        statusCode: 500,
        response: null,
        error: err instanceof Error ? err.message : 'Network or function invocation error',
        timestamp: new Date()
      };

      setResults(prev => ({
        ...prev,
        [webhookId]: result
      }));

      return result;
    } finally {
      setIsLoading(false);
    }
  };

  const testAllWebhooks = async (requests: TestRequest[]) => {
    setIsLoading(true);
    const promises = requests.map(req => testWebhook(req.webhook, req.payload));
    await Promise.all(promises);
    setIsLoading(false);
  };

  const clearResults = () => {
    setResults({});
  };

  return {
    testWebhook,
    testAllWebhooks,
    clearResults,
    isLoading,
    results
  };
};