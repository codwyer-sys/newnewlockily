import { useState, useCallback } from 'react';
import { useMapBoxPostalCodeValidation } from './useMapBoxPostalCodeValidation';

interface PostalCodeWithInfo {
  code: string;
  city: string;
}

interface ValidationCache {
  [key: string]: {
    city: string;
    timestamp: number;
  };
}

const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const useBatchPostalCodeValidation = () => {
  const { validateAndGetInfo } = useMapBoxPostalCodeValidation();
  const [cache, setCache] = useState<ValidationCache>({});
  const [isValidating, setIsValidating] = useState(false);

  const validateBatch = useCallback(async (postalCodes: string[]): Promise<PostalCodeWithInfo[]> => {
    if (postalCodes.length === 0) return [];

    setIsValidating(true);
    
    try {
      const now = Date.now();
      const results: PostalCodeWithInfo[] = [];
      const uncachedCodes: string[] = [];

      // Check cache first
      for (const code of postalCodes) {
        const cached = cache[code];
        if (cached && (now - cached.timestamp) < CACHE_DURATION) {
          results.push({ code, city: cached.city });
        } else {
          uncachedCodes.push(code);
        }
      }

      // Validate uncached codes in parallel
      if (uncachedCodes.length > 0) {
        const validationPromises = uncachedCodes.map(async (code) => {
          try {
            const info = await validateAndGetInfo(code);
            const city = info?.city || 'Ukendt by';
            
            // Update cache
            setCache(prev => ({
              ...prev,
              [code]: { city, timestamp: now }
            }));
            
            return { code, city };
          } catch (error) {
            console.error('Error validating postal code:', code, error);
            return { code, city: 'Ukendt by' };
          }
        });

        const newResults = await Promise.all(validationPromises);
        results.push(...newResults);
      }

      // Sort by original order
      return postalCodes.map(code => 
        results.find(result => result.code === code) || { code, city: 'Ukendt by' }
      );
    } finally {
      setIsValidating(false);
    }
  }, [validateAndGetInfo, cache]);

  const validateSingle = useCallback(async (postalCode: string): Promise<PostalCodeWithInfo | null> => {
    const now = Date.now();
    const cached = cache[postalCode];
    
    if (cached && (now - cached.timestamp) < CACHE_DURATION) {
      return { code: postalCode, city: cached.city };
    }

    try {
      const info = await validateAndGetInfo(postalCode);
      if (info) {
        const result = { code: postalCode, city: info.city };
        
        setCache(prev => ({
          ...prev,
          [postalCode]: { city: info.city, timestamp: now }
        }));
        
        return result;
      }
      return null;
    } catch (error) {
      console.error('Error validating postal code:', postalCode, error);
      return null;
    }
  }, [validateAndGetInfo, cache]);

  return {
    validateBatch,
    validateSingle,
    isValidating
  };
};