import { useMemo } from 'react';
import { BlogPost } from '@/hooks/useBlogPosts';
import { BlogPostMarketSEO } from '@/hooks/useBlogPostMarketSEO';

interface SEOMetaData {
  title: string;
  description: string;
  keywords: string[];
  canonicalUrl: string;
  ogTitle: string;
  ogDescription: string;
  ogImageUrl: string;
  twitterTitle: string;
  twitterDescription: string;
  twitterImageUrl: string;
  structuredData: object;
  hreflangTags: Array<{ lang: string; href: string }>;
}

export const useBlogPostSEO = (
  post: BlogPost | null,
  marketSEO: BlogPostMarketSEO[],
  currentMarket: string = 'DK',
  baseUrl: string = 'https://lockily.com'
) => {
  const seoData = useMemo<SEOMetaData | null>(() => {
    if (!post) return null;

    const currentMarketSEO = marketSEO.find(seo => seo.market_code === currentMarket);
    
    // Generate canonical URL
    const canonicalUrl = post.is_global
      ? `${baseUrl}/blog/${post.slug}`
      : `${baseUrl}/${post.market_code?.toLowerCase()}/blog/${post.slug}`;

    // Use market-specific SEO data if available, fallback to post data
    const title = currentMarketSEO?.seo_title || post.seo_title || post.title;
    const description = currentMarketSEO?.seo_description || post.seo_description || post.excerpt || '';
    const keywords = currentMarketSEO?.seo_keywords || post.seo_keywords || [];
    
    // Open Graph data
    const ogTitle = currentMarketSEO?.og_title || title;
    const ogDescription = currentMarketSEO?.og_description || description;
    const ogImageUrl = currentMarketSEO?.og_image_url || post.featured_image_url || '';
    
    // Twitter data
    const twitterTitle = currentMarketSEO?.twitter_title || ogTitle;
    const twitterDescription = currentMarketSEO?.twitter_description || ogDescription;
    const twitterImageUrl = currentMarketSEO?.twitter_image_url || ogImageUrl;

    // Generate structured data (JSON-LD)
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": title,
      "description": description,
      "image": ogImageUrl ? [ogImageUrl] : [],
      "datePublished": post.published_at || post.created_at,
      "dateModified": post.updated_at,
      "author": {
        "@type": "Organization",
        "name": "Lockily"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Lockily",
        "logo": {
          "@type": "ImageObject",
          "url": `${baseUrl}/logo.png`
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": canonicalUrl
      },
      "keywords": keywords.join(', '),
      "articleSection": post.category_id ? "Locksmith Services" : "General",
      "wordCount": post.content ? post.content.replace(/<[^>]*>/g, '').split(/\s+/).length : 0
    };

    // Generate hreflang tags for global posts
    const hreflangTags: Array<{ lang: string; href: string }> = [];
    if (post.is_global && marketSEO.length > 0) {
      // Add each market's URL
      marketSEO.forEach(seo => {
        hreflangTags.push({
          lang: seo.market_code.toLowerCase(),
          href: `${baseUrl}/${seo.market_code.toLowerCase()}/blog/${post.slug}`
        });
      });
      
      // Add default/canonical URL
      hreflangTags.push({
        lang: 'x-default',
        href: canonicalUrl
      });
    }

    return {
      title,
      description,
      keywords,
      canonicalUrl: currentMarketSEO?.canonical_url || canonicalUrl,
      ogTitle,
      ogDescription,
      ogImageUrl,
      twitterTitle,
      twitterDescription,
      twitterImageUrl,
      structuredData,
      hreflangTags
    };
  }, [post, marketSEO, currentMarket, baseUrl]);

  // Generate HTML meta tags
  const generateMetaTags = useMemo(() => {
    if (!seoData) return '';

    const tags = [
      // Basic meta tags
      `<title>${seoData.title}</title>`,
      `<meta name="description" content="${seoData.description}" />`,
      seoData.keywords.length > 0 ? `<meta name="keywords" content="${seoData.keywords.join(', ')}" />` : '',
      `<link rel="canonical" href="${seoData.canonicalUrl}" />`,
      
      // Open Graph tags
      `<meta property="og:title" content="${seoData.ogTitle}" />`,
      `<meta property="og:description" content="${seoData.ogDescription}" />`,
      `<meta property="og:type" content="article" />`,
      `<meta property="og:url" content="${seoData.canonicalUrl}" />`,
      seoData.ogImageUrl ? `<meta property="og:image" content="${seoData.ogImageUrl}" />` : '',
      
      // Twitter Card tags
      `<meta name="twitter:card" content="summary_large_image" />`,
      `<meta name="twitter:title" content="${seoData.twitterTitle}" />`,
      `<meta name="twitter:description" content="${seoData.twitterDescription}" />`,
      seoData.twitterImageUrl ? `<meta name="twitter:image" content="${seoData.twitterImageUrl}" />` : '',
      
      // Hreflang tags
      ...seoData.hreflangTags.map(tag => `<link rel="alternate" hreflang="${tag.lang}" href="${tag.href}" />`),
      
      // Structured data
      `<script type="application/ld+json">${JSON.stringify(seoData.structuredData)}</script>`
    ];

    return tags.filter(tag => tag).join('\n');
  }, [seoData]);

  return {
    seoData,
    generateMetaTags,
    isOptimized: Boolean(seoData && seoData.title && seoData.description)
  };
};