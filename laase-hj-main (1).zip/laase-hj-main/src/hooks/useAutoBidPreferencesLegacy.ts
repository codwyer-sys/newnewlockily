// Legacy hook - preserved for backwards compatibility
// New code should use usePricingData from PricingDataContext instead

import { usePricingData } from '@/contexts/PricingDataContext';

export const useAutoBidPreferences = () => {
  const { categories, globalSettings, isLoading } = usePricingData();
  
  return {
    categories,
    globalSettings,
    isLoading,
    isUpdating: false,
    error: null,
    // Legacy functions that are no longer used in the optimized system
    updatePreference: () => Promise.resolve(),
    updateGlobalSettings: () => Promise.resolve(),
    refetch: () => Promise.resolve()
  };
};

// Re-export types for backward compatibility
export * from './useAutoBidPreferences';