import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface AISettings {
  id: string;
  prompt_template: string;
  system_message: string;
  temperature: number;
  max_tokens: number;
  model: string;
  business_context: string;
  updated_at: string;
  updated_by: string | null;
}

interface LanguageMapping {
  id: string;
  language_code: string;
  language_name: string;
  market_code: string | null;
}

export const useAISettings = () => {
  const [settings, setSettings] = useState<AISettings | null>(null);
  const [languageMappings, setLanguageMappings] = useState<LanguageMapping[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('ai_translation_settings')
        .select('*')
        .single();

      if (error) throw error;
      setSettings(data);
    } catch (error) {
      console.error('Error fetching AI settings:', error);
      toast.error('Failed to fetch AI settings');
    }
  };

  const fetchLanguageMappings = async () => {
    try {
      const { data, error } = await supabase
        .from('language_mappings')
        .select('*')
        .order('market_code, language_name');

      if (error) throw error;
      setLanguageMappings(data || []);
    } catch (error) {
      console.error('Error fetching language mappings:', error);
      toast.error('Failed to fetch language mappings');
    }
  };

  const updateSettings = async (updates: Partial<AISettings>) => {
    if (!settings) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from('ai_translation_settings')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', settings.id);

      if (error) throw error;
      
      await fetchSettings();
      toast.success('AI settings updated successfully');
    } catch (error) {
      console.error('Error updating AI settings:', error);
      toast.error('Failed to update AI settings');
    } finally {
      setSaving(false);
    }
  };

  const testTranslation = async (testText: string, targetLanguage: string, marketCode: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('ai-translate', {
        body: {
          originalText: testText,
          targetLanguage,
          market: marketCode,
          pageName: 'Test',
          sectionName: 'Test Section',
          contentKey: 'test_key',
          customInstruction: 'This is a test translation'
        }
      });

      if (error) throw error;
      return data?.translatedText;
    } catch (error) {
      console.error('Test translation error:', error);
      toast.error('Test translation failed');
      return null;
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchSettings(), fetchLanguageMappings()]);
      setLoading(false);
    };

    loadData();
  }, []);

  return {
    settings,
    languageMappings,
    loading,
    saving,
    updateSettings,
    testTranslation,
    refetch: () => Promise.all([fetchSettings(), fetchLanguageMappings()])
  };
};