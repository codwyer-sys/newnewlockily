import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface TranslationRequest {
  originalText: string;
  targetLanguage: string;
  market?: string;
  pageName?: string;
  sectionName?: string;
  contentKey?: string;
  placement?: string;
  context?: string;
  customInstruction?: string;
  abortSignal?: AbortSignal;
}

interface TranslationResponse {
  originalText: string;
  translatedText: string;
  targetLanguage: string;
  market?: string;
  placement?: string;
}

export const useAITranslation = () => {
  const [isTranslating, setIsTranslating] = useState(false);

  const translateText = async (request: TranslationRequest): Promise<string | null> => {
    try {
      setIsTranslating(true);
      
      // Check if already aborted
      if (request.abortSignal?.aborted) {
        console.log('🛑 [AITranslation] Translation aborted before starting');
        return null;
      }

      // Comprehensive request validation
      if (!request.originalText?.trim()) {
        console.error('🚫 [AITranslation] Empty or missing original text for:', {
          contentKey: request.contentKey,
          targetLanguage: request.targetLanguage,
          market: request.market
        });
        if (!request.abortSignal?.aborted) {
          toast.error('Translation failed: No content to translate');
        }
        return null;
      }

      if (!request.targetLanguage?.trim()) {
        console.error('🚫 [AITranslation] Missing target language for:', request.contentKey);
        if (!request.abortSignal?.aborted) {
          toast.error('Translation failed: No target language specified');
        }
        return null;
      }

      // Log comprehensive request details
      console.log('🔤 [AITranslation] Starting translation request:', {
        contentKey: request.contentKey,
        sourceLength: request.originalText.length,
        targetLanguage: request.targetLanguage,
        market: request.market,
        page: request.pageName,
        section: request.sectionName,
        hasCustomInstruction: !!request.customInstruction,
        customInstructionLength: request.customInstruction?.length || 0
      });

      if (request.customInstruction && request.originalText.length < 10 && request.customInstruction.length > 100) {
        console.warn('⚠️ [AITranslation] AI instruction much longer than content - possible mismatch:', {
          contentLength: request.originalText.length,
          instructionLength: request.customInstruction.length,
          contentKey: request.contentKey
        });
      }

      // Make API call with timeout tracking
      const startTime = Date.now();
      console.log(`⏰ [AITranslation] Sending request to AI service at ${new Date().toISOString()}`);
      
      const { data, error } = await supabase.functions.invoke('ai-translate', {
        body: request
      });

      const endTime = Date.now();
      const duration = endTime - startTime;
      console.log(`⏱️ [AITranslation] API call completed in ${duration}ms`);

      // Check if aborted after API call
      if (request.abortSignal?.aborted) {
        console.log('🛑 [AITranslation] Translation aborted after API call');
        return null;
      }

      // Enhanced error handling with specific logging
      if (error) {
        console.error('🚫 [AITranslation] Supabase function error:', {
          error: error,
          contentKey: request.contentKey,
          targetLanguage: request.targetLanguage,
          duration: duration,
          errorType: error.name || 'Unknown'
        });
        if (!request.abortSignal?.aborted) {
          toast.error(`Translation failed: ${error.message || 'API Error'}`);
        }
        return null;
      }

      if (data?.error) {
        console.error('🚫 [AITranslation] Translation API error:', {
          apiError: data.error,
          contentKey: request.contentKey,
          targetLanguage: request.targetLanguage,
          duration: duration
        });
        if (!request.abortSignal?.aborted) {
          toast.error(`Translation failed: ${data.error}`);
        }
        return null;
      }

      if (!data?.translatedText) {
        console.error('🚫 [AITranslation] No translated text in response:', {
          response: data,
          contentKey: request.contentKey,
          targetLanguage: request.targetLanguage,
          hasData: !!data,
          dataKeys: data ? Object.keys(data) : []
        });
        if (!request.abortSignal?.aborted) {
          toast.error('Translation failed: No translated text received');
        }
        return null;
      }

      // Validate response content
      const translatedText = data.translatedText;
      if (typeof translatedText !== 'string') {
        console.error('🚫 [AITranslation] Invalid response type:', {
          responseType: typeof translatedText,
          contentKey: request.contentKey,
          targetLanguage: request.targetLanguage
        });
        return null;
      }

      if (translatedText.trim().length === 0) {
        console.warn('⚠️ [AITranslation] Empty translation received:', {
          contentKey: request.contentKey,
          targetLanguage: request.targetLanguage,
          rawResponse: translatedText
        });
        return null;
      }

      console.log('✅ [AITranslation] Translation successful:', {
        contentKey: request.contentKey,
        targetLanguage: request.targetLanguage,
        sourceLength: request.originalText.length,
        translatedLength: translatedText.length,
        duration: duration,
        preview: translatedText.substring(0, 100) + (translatedText.length > 100 ? '...' : '')
      });

      return translatedText;

    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      const errorName = error instanceof Error ? error.name : 'UnknownError';
      
      console.error('🚫 [AITranslation] Unexpected translation error:', {
        error: error,
        errorMessage: errorMsg,
        errorName: errorName,
        contentKey: request.contentKey,
        targetLanguage: request.targetLanguage,
        stack: error instanceof Error ? error.stack : undefined
      });
      
      if (!request.abortSignal?.aborted) {
        toast.error(`Translation request failed: ${errorMsg}`);
      }
      return null;
    } finally {
      setIsTranslating(false);
    }
  };

  return {
    translateText,
    isTranslating
  };
};