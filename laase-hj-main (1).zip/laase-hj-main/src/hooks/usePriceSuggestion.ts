import { usePriceCalculation } from '@/hooks/usePriceCalculation';
import { LocksmithJob } from '@/types/locksmith';

export const usePriceSuggestion = (job: LocksmithJob, distance?: { km: number }, chargeClientForReferral?: boolean) => {
  return usePriceCalculation({
    job,
    distance,
    chargeClientForReferral: chargeClientForReferral || false
  });
};