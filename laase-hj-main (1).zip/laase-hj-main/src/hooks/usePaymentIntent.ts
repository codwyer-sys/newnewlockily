import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PaymentIntentData {
  clientSecret: string;
  paymentIntentId: string;
  amount: number;
  locksmithId: string;
}

export const usePaymentIntent = () => {
  const [paymentIntents, setPaymentIntents] = useState<Map<string, PaymentIntentData>>(new Map());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createPaymentIntent = useCallback(async (quoteId: string): Promise<PaymentIntentData | null> => {
    // Check if we already have a payment intent for this quote
    const existingIntent = paymentIntents.get(quoteId);
    if (existingIntent) {
      console.log('♻️ Reusing existing payment intent for quote:', quoteId);
      return existingIntent;
    }

    setLoading(true);
    setError(null);
    console.log('💳 Creating new payment intent for quote:', quoteId);
    
    try {
      const { data, error: intentError } = await supabase.functions.invoke('create-customer-payment', {
        body: { 
          quoteId, 
          email: 'pending@payment.com' // Placeholder email
        }
      });

      if (intentError) {
        console.error('💥 Payment intent creation failed:', intentError);
        setError('Failed to initialize payment. Please try again.');
        return null;
      }

      if (!data?.client_secret || !data?.payment_intent_id) {
        console.error('💥 Invalid payment intent response:', data);
        setError('Payment initialization failed - please try again');
        return null;
      }

      const intentData: PaymentIntentData = {
        clientSecret: data.client_secret,
        paymentIntentId: data.payment_intent_id,
        amount: data.amount || 0,
        locksmithId: data.locksmith_id || ''
      };

      // Store the payment intent for reuse
      setPaymentIntents(prev => new Map(prev).set(quoteId, intentData));
      
      console.log('✅ Payment intent created and stored:', intentData.paymentIntentId);
      return intentData;

    } catch (error) {
      console.error('💥 Unexpected error creating payment intent:', error);
      setError('An unexpected error occurred. Please try again.');
      return null;
    } finally {
      setLoading(false);
    }
  }, [paymentIntents]);

  const updatePaymentIntentEmail = useCallback(async (paymentIntentId: string, email: string): Promise<boolean> => {
    console.log('📧 Updating payment intent email:', { paymentIntentId, email });
    
    try {
      const { error } = await supabase.functions.invoke('update-payment-email', {
        body: { 
          paymentIntentId,
          email: email
        }
      });

      if (error) {
        console.error('⚠️ Failed to update email:', error);
        return false;
      }

      console.log('✅ Payment intent email updated successfully');
      return true;
    } catch (error) {
      console.error('⚠️ Error updating payment email:', error);
      return false;
    }
  }, []);

  const getPaymentIntent = useCallback((quoteId: string): PaymentIntentData | undefined => {
    return paymentIntents.get(quoteId);
  }, [paymentIntents]);

  const clearPaymentIntent = useCallback((quoteId: string) => {
    setPaymentIntents(prev => {
      const newMap = new Map(prev);
      newMap.delete(quoteId);
      return newMap;
    });
  }, []);

  const clearAllPaymentIntents = useCallback(() => {
    setPaymentIntents(new Map());
  }, []);

  return {
    createPaymentIntent,
    updatePaymentIntentEmail,
    getPaymentIntent,
    clearPaymentIntent,
    clearAllPaymentIntents,
    loading,
    error
  };
};