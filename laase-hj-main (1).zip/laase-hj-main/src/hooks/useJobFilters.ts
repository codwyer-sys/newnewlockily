import { useState, useMemo } from 'react';
import { LocksmithJob } from '@/types/locksmith';

interface JobFilters {
  search: string;
  status: string[];
  dateRange: { start: string; end: string };
  market: string[];
}

export const useJobFilters = (jobs: LocksmithJob[]) => {
  const [filters, setFilters] = useState<JobFilters>({
    search: '',
    status: [],
    dateRange: { start: '', end: '' },
    market: []
  });

  const updateFilter = (key: keyof JobFilters, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      status: [],
      dateRange: { start: '', end: '' },
      market: []
    });
  };

  const filteredJobs = useMemo(() => {
    let filtered = [...jobs];

    // Search filter
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      filtered = filtered.filter(job => 
        job.customerName?.toLowerCase().includes(searchTerm) ||
        job.customerPhone?.toLowerCase().includes(searchTerm) ||
        job.address.toLowerCase().includes(searchTerm) ||
        job.jobNumber.toString().includes(searchTerm) ||
        job.category.toLowerCase().includes(searchTerm)
      );
    }

    // Status filter
    if (filters.status.length > 0) {
      filtered = filtered.filter(job => 
        filters.status.includes(job.status || 'waiting_for_quotes')
      );
    }


    // Market filter
    if (filters.market.length > 0) {
      filtered = filtered.filter(job => 
        filters.market.includes(job.market || 'DK')
      );
    }

    // Date range filter
    if (filters.dateRange.start || filters.dateRange.end) {
      filtered = filtered.filter(job => {
        const jobDate = new Date(job.timeRequested);
        const startDate = filters.dateRange.start ? new Date(filters.dateRange.start) : null;
        const endDate = filters.dateRange.end ? new Date(filters.dateRange.end) : null;

        if (startDate && jobDate < startDate) return false;
        if (endDate && jobDate > endDate) return false;
        return true;
      });
    }

    return filtered;
  }, [jobs, filters]);

  const applyFilters = (newFilters: Partial<JobFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  return {
    filters,
    filteredJobs,
    updateFilter,
    clearFilters,
    applyFilters
  };
};