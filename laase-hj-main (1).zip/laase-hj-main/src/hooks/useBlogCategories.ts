import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface BlogCategoryWithTranslations {
  id: string;
  category_key: string;
  slug: string;
  parent_id?: string;
  display_order: number;
  is_active: boolean;
  name: string;
  description?: string;
  seo_title?: string;
  seo_description?: string;
  created_at: string;
  updated_at: string;
}

interface CreateCategoryData {
  category_key: string;
  slug: string;
  parent_id?: string;
  display_order?: number;
  is_active?: boolean;
  name: string;
  description?: string;
  seo_title?: string;
  seo_description?: string;
  market_code?: string;
  language_code?: string;
}

export const useBlogCategories = (marketCode?: string, languageCode: string = 'en') => {
  const [categories, setCategories] = useState<BlogCategoryWithTranslations[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCategories = async () => {
    try {
      console.log('Fetching blog categories...');
      
      // Get categories first
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('blog_categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (categoriesError) throw categoriesError;
      console.log('Fetched categories:', categoriesData?.length || 0);

      // If no categories exist, return empty array
      if (!categoriesData || categoriesData.length === 0) {
        setCategories([]);
        return;
      }

      // Try to get the content section for blog categories
      const { data: section, error: sectionError } = await supabase
        .from('content_sections')
        .select('id')
        .eq('section_key', 'category_management')
        .single();

      // If no content section exists, use fallback category names
      if (sectionError || !section) {
        console.log('No content section found, using fallback names');
        const fallbackCategories: BlogCategoryWithTranslations[] = categoriesData.map(category => ({
          ...category,
          name: category.category_key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          description: undefined,
          seo_title: undefined,
          seo_description: undefined,
        }));
        setCategories(fallbackCategories);
        return;
      }

      // Fetch translations for all categories including slugs
      const categoryKeys = categoriesData.map(cat => cat.category_key);
      const translationKeys = categoryKeys.flatMap(key => [
        `${key}_name`,
        `${key}_description`,
        `${key}_seo_title`,
        `${key}_seo_description`,
        `${key}_slug`
      ]);

      const { data: translations, error: translationsError } = await supabase
        .from('content_translations')
        .select('content_key, content_value, market_code')
        .eq('section_id', section.id)
        .eq('language_code', languageCode)
        .in('content_key', translationKeys);

      if (translationsError) {
        console.error('Error fetching translations:', translationsError);
        // Fallback to category keys as names
        const fallbackCategories: BlogCategoryWithTranslations[] = categoriesData.map(category => ({
          ...category,
          name: category.category_key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          description: undefined,
          seo_title: undefined,
          seo_description: undefined,
        }));
        setCategories(fallbackCategories);
        return;
      }

      console.log('Fetched translations:', translations?.length || 0);

      // Combine categories with their translations
      const categoriesWithTranslations: BlogCategoryWithTranslations[] = categoriesData.map(category => {
        const getTranslation = (suffix: string) => {
          const key = `${category.category_key}_${suffix}`;
          const translation = translations?.find(t => 
            t.content_key === key && 
            (t.market_code === marketCode || (!marketCode && !t.market_code))
          );
          return translation?.content_value || '';
        };

        return {
          ...category,
          name: getTranslation('name') || category.category_key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          description: getTranslation('description'),
          seo_title: getTranslation('seo_title'),
          seo_description: getTranslation('seo_description'),
          slug: getTranslation('slug') || category.slug, // Fallback to old slug during migration
        };
      });

      console.log('Final categories with translations:', categoriesWithTranslations.length);
      setCategories(categoriesWithTranslations);
    } catch (error) {
      console.error('Error fetching blog categories:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch blog categories',
        variant: 'destructive',
      });
      setCategories([]); // Set empty array as fallback
    } finally {
      setLoading(false);
    }
  };

  const createCategory = async (categoryData: CreateCategoryData) => {
    try {
      // Get the content section for blog categories
      const { data: section } = await supabase
        .from('content_sections')
        .select('id')
        .eq('section_key', 'category_management')
        .single();

      if (!section) {
        throw new Error('Blog categories content section not found');
      }

      // Create the category structure (with temporary slug until migration makes it optional)
      const { data: category, error: categoryError } = await supabase
        .from('blog_categories')
        .insert([{
          category_key: categoryData.category_key,
          slug: categoryData.slug, // Temporary - will be removed after migration
          parent_id: categoryData.parent_id,
          display_order: categoryData.display_order || 0,
          is_active: categoryData.is_active !== false,
        }])
        .select()
        .single();

      if (categoryError) throw categoryError;

      // Create translations for the category including slug
      const translations = [
        {
          section_id: section.id,
          content_key: `${categoryData.category_key}_name`,
          content_type: 'text',
          content_value: categoryData.name,
          language_code: categoryData.language_code || 'en',
          market_code: categoryData.market_code,
        },
        {
          section_id: section.id,
          content_key: `${categoryData.category_key}_slug`,
          content_type: 'text',
          content_value: categoryData.slug,
          language_code: categoryData.language_code || 'en',
          market_code: categoryData.market_code,
        },
      ];

      if (categoryData.description) {
        translations.push({
          section_id: section.id,
          content_key: `${categoryData.category_key}_description`,
          content_type: 'text',
          content_value: categoryData.description,
          language_code: categoryData.language_code || 'en',
          market_code: categoryData.market_code,
        });
      }

      if (categoryData.seo_title) {
        translations.push({
          section_id: section.id,
          content_key: `${categoryData.category_key}_seo_title`,
          content_type: 'text',
          content_value: categoryData.seo_title,
          language_code: categoryData.language_code || 'en',
          market_code: categoryData.market_code,
        });
      }

      if (categoryData.seo_description) {
        translations.push({
          section_id: section.id,
          content_key: `${categoryData.category_key}_seo_description`,
          content_type: 'text',
          content_value: categoryData.seo_description,
          language_code: categoryData.language_code || 'en',
          market_code: categoryData.market_code,
        });
      }

      const { error: translationsError } = await supabase
        .from('content_translations')
        .insert(translations);

      if (translationsError) throw translationsError;

      await fetchCategories();
      toast({
        title: 'Success',
        description: 'Blog category created successfully',
      });

      return category;
    } catch (error) {
      console.error('Error creating blog category:', error);
      toast({
        title: 'Error',
        description: 'Failed to create blog category',
        variant: 'destructive',
      });
      throw error;
    }
  };

  const updateCategory = async (id: string, updates: Partial<CreateCategoryData>) => {
    try {
      // Get the content section for blog categories
      const { data: section } = await supabase
        .from('content_sections')
        .select('id')
        .eq('section_key', 'category_management')
        .single();

      if (!section) {
        throw new Error('Blog categories content section not found');
      }

      // Update the category structure (no longer includes slug)
      const structuralUpdates: any = {};
      if (updates.parent_id !== undefined) structuralUpdates.parent_id = updates.parent_id;
      if (updates.display_order !== undefined) structuralUpdates.display_order = updates.display_order;
      if (updates.is_active !== undefined) structuralUpdates.is_active = updates.is_active;

      if (Object.keys(structuralUpdates).length > 0) {
        const { error: categoryError } = await supabase
          .from('blog_categories')
          .update(structuralUpdates)
          .eq('id', id);

        if (categoryError) throw categoryError;
      }

      // Update translations if provided including slug
      const category = categories.find(c => c.id === id);
      if (!category) throw new Error('Category not found');

      const translationUpdates = [];
      if (updates.name) {
        translationUpdates.push({
          content_key: `${category.category_key}_name`,
          content_value: updates.name,
        });
      }
      if (updates.slug) {
        translationUpdates.push({
          content_key: `${category.category_key}_slug`,
          content_value: updates.slug,
        });
      }
      if (updates.description) {
        translationUpdates.push({
          content_key: `${category.category_key}_description`,
          content_value: updates.description,
        });
      }
      if (updates.seo_title) {
        translationUpdates.push({
          content_key: `${category.category_key}_seo_title`,
          content_value: updates.seo_title,
        });
      }
      if (updates.seo_description) {
        translationUpdates.push({
          content_key: `${category.category_key}_seo_description`,
          content_value: updates.seo_description,
        });
      }

      for (const update of translationUpdates) {
        await supabase
          .from('content_translations')
          .update({ content_value: update.content_value })
          .eq('section_id', section.id)
          .eq('content_key', update.content_key)
          .eq('language_code', updates.language_code || 'en')
          .eq('market_code', updates.market_code || null);
      }

      await fetchCategories();
      toast({
        title: 'Success',
        description: 'Blog category updated successfully',
      });
    } catch (error) {
      console.error('Error updating blog category:', error);
      toast({
        title: 'Error',
        description: 'Failed to update blog category',
        variant: 'destructive',
      });
      throw error;
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      const { error } = await supabase
        .from('blog_categories')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await fetchCategories();
      toast({
        title: 'Success',
        description: 'Blog category deleted successfully',
      });
    } catch (error) {
      console.error('Error deleting blog category:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete blog category',
        variant: 'destructive',
      });
      throw error;
    }
  };

  useEffect(() => {
    const loadCategories = async () => {
      await fetchCategories();
    };

    loadCategories();
  }, [marketCode, languageCode]);

  return {
    categories,
    loading,
    fetchCategories,
    createCategory,
    updateCategory,
    deleteCategory,
  };
};