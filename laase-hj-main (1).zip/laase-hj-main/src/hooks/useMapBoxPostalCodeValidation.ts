import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PostalCodeInfo {
  code: string;
  city: string;
  municipality: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

export const useMapBoxPostalCodeValidation = () => {
  const [isLoading, setIsLoading] = useState(false);

  const validateAndGetInfo = async (postalCode: string): Promise<PostalCodeInfo | null> => {
    if (!/^\d{4}$/.test(postalCode)) {
      return null;
    }

    setIsLoading(true);
    try {
      console.log('🔍 [MapBox Postal] Validating postal code:', postalCode);
      
      const { data, error } = await supabase.functions.invoke('mapbox-postal-code-lookup', {
        body: { postalCode }
      });

      if (error) {
        console.error('🔍 [MapBox Postal] Error:', error);
        return null;
      }

      if (!data || data.error) {
        console.warn('🔍 [MapBox Postal] No data or error in response:', data);
        return null;
      }

      console.log('🔍 [MapBox Postal] Success:', data);

      return {
        code: data.code,
        city: data.city,
        municipality: data.municipality || data.city,
        coordinates: data.coordinates
      };
    } catch (error) {
      console.error('🔍 [MapBox Postal] Exception:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    validateAndGetInfo,
    isLoading
  };
};