import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface JobUpdateData {
  customerName?: string;
  customerPhone?: string;
  address?: string;
  adminNotes?: string;
  priority?: string;
  status?: string;
  [key: string]: any;
}

export const useJobStatusUpdate = () => {
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const updateJobStatus = async (jobId: string, newStatus: string) => {
    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ 
          status: newStatus,
          status_changed_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (error) throw error;

      toast({
        title: "Status Updated",
        description: `Job status changed successfully`
      });
    } catch (error) {
      console.error('Error updating job status:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update job status. Please try again.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setIsUpdating(false);
    }
  };

  const updateJobStage = async (jobId: string, newStage: string, locksmithId?: string) => {
    setIsUpdating(true);
    try {
      const updateData: any = {
        job_stage: newStage,
        job_stage_changed_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      // If locksmith ID is provided, assign them to the job
      if (locksmithId) {
        updateData.locksmith_id = locksmithId;
      }

      const { error } = await supabase
        .from('bookings')
        .update(updateData)
        .eq('id', jobId);

      if (error) throw error;

      toast({
        title: "Job Stage Updated",
        description: `Job progressed to ${newStage.replace('_', ' ')}`
      });
    } catch (error) {
      console.error('Error updating job stage:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update job stage. Please try again.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setIsUpdating(false);
    }
  };

  const updateJobDetails = async (jobId: string, updates: JobUpdateData) => {
    setIsUpdating(true);
    try {
      // Prepare the update object
      const updateData: any = {
        updated_at: new Date().toISOString()
      };

      // Map frontend fields to database fields
      if (updates.adminNotes !== undefined) updateData.admin_notes = updates.adminNotes;
      if (updates.priority !== undefined) updateData.priority_level = updates.priority;
      if (updates.status !== undefined) {
        updateData.status = updates.status;
        updateData.status_changed_at = new Date().toISOString();
      }

      // Handle follow_up_answers updates
      if (updates.customerName || updates.customerPhone) {
        // First, get the current follow_up_answers
        const { data: currentJob, error: fetchError } = await supabase
          .from('bookings')
          .select('follow_up_answers')
          .eq('id', jobId)
          .single();

        if (fetchError) throw fetchError;

        const currentAnswers = (currentJob.follow_up_answers as Record<string, any>) || {};
        const updatedAnswers = { ...currentAnswers };

        if (updates.customerName) updatedAnswers.customerName = updates.customerName;
        if (updates.customerPhone) updatedAnswers.customerPhone = updates.customerPhone;

        updateData.follow_up_answers = updatedAnswers;
      }

      // Handle other direct field updates
      if (updates.address !== undefined) updateData.address = updates.address;

      const { error } = await supabase
        .from('bookings')
        .update(updateData)
        .eq('id', jobId);

      if (error) throw error;

      toast({
        title: "Job Updated",
        description: "Job details have been successfully updated."
      });
    } catch (error) {
      console.error('Error updating job details:', error);
      toast({
        title: "Update Failed",
        description: "Failed to update job details. Please try again.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setIsUpdating(false);
    }
  };

  return {
    updateJobStatus,
    updateJobStage,
    updateJobDetails,
    isUpdating
  };
};